import CachedAutomaticConstructor
import Init.Data.Vector.OfFn

namespace PEqualNP.Outside.AutomaticConstructor.GuardVector

open PEqualNP.Search
open PEqualNP.Outside.SparseDualHornAlgorithm
open PEqualNP.Outside.CertifiedConstructorSolver
open PEqualNP.Outside.MatchingCertificates
open PEqualNP.Outside.GuardedCNFEncoding

variable {r h : Nat}

abbrev Matcher (r h : Nat) :=
  (Fin r → List (Fin h)) → (Fin r → Bool) → MatchingLoop.Result r h

def guardValues (visible : Assignment) (guards : Fin r → Clause) : Vector Bool r :=
  Vector.ofFn (fun i => Clause.eval visible (guards i))

theorem guardValues_lookup (visible : Assignment) (guards : Fin r → Clause) :
    (guardValues visible guards).get = fun i => Clause.eval visible (guards i) := by
  funext i
  change (Vector.ofFn (fun j => Clause.eval visible (guards j)))[i.val] = _
  exact Vector.getElem_ofFn i.isLt

/-- Revalidate an actual matching or cut with the very same row Booleans
used during search. A lifted SAT witness uses those Booleans to mask edges. -/
def finishMatching (offset : Nat) (visible : Assignment) (N : Fin r → Finset (Fin h))
    (g : Fin r → Bool) : MatchingLoop.Result r h → CertifiedConstructorSolver.Result
  | .inconclusive => .invalidCertificate
  | .success certificate =>
    if successCheck N g certificate then
      .sat (liftAssignment offset visible (certificateEdges g certificate))
    else .invalidCertificate
  | .failure rows =>
    if failureCheck N g rows then .unsat else .invalidCertificate

def matchAt (backend : Matcher r h) (offset : Nat) (visible : Assignment)
    (adj : Fin r → List (Fin h)) (guards : Fin r → Clause) : Outcome :=
  let bits := guardValues visible guards
  let g := bits.get
  convertResult (finishMatching offset visible (fun i => (adj i).toFinset) g (backend adj g))

theorem matchAt_eq_cached (backend : Matcher r h)
    (agrees : ∀ adj g, backend adj g = MatchingCached.solve adj g)
    (offset : Nat) (F : CNF) (adj : Fin r → List (Fin h))
    (guards : Fin r → Clause) (T : Finset Nat) :
    matchAt backend offset (state (support F) T) adj guards =
      Cached.useMatching offset F adj guards T := by
  simp only [matchAt, Cached.useMatching, guardValues_lookup, agrees]
  cases MatchingCached.solve adj (fun i => Clause.eval (state (support F) T) (guards i)) <;> rfl

/-- Validate the constructor inputs and retained fragment, then build one
support set for both the retained solver and the visible assignment. Only a
satisfiable retained instance needs guard bits. -/
def solveWith (backend : Matcher r h) (offset : Nat) (F : CNF)
    (adj : Fin r → List (Fin h)) (guards : Fin r → Clause) : Outcome :=
  if inputCheck offset F guards then
    if dualHornCheck F then
      let domain := support F
      match SparseDualHornAlgorithm.solve domain F with
      | none => .unsat
      | some T => matchAt backend offset (state domain T) adj guards
    else .unsupported
  else .unsupported

theorem solveWith_eq_cached (backend : Matcher r h)
    (agrees : ∀ adj g, backend adj g = MatchingCached.solve adj g)
    (offset : Nat) (F : CNF) (adj : Fin r → List (Fin h)) (guards : Fin r → Clause) :
    solveWith backend offset F adj guards = Cached.solve offset F adj guards := by
  by_cases inputs : inputCheck offset F guards = true
  · by_cases dual : dualHornCheck F = true
    · cases retained : SparseDualHornAlgorithm.solve (support F) F with
      | none => simp [solveWith, Cached.solve, checkedSolve, solveSparse, inputs, dual, retained]
      | some T =>
        simpa [solveWith, Cached.solve, checkedSolve, solveSparse, inputs, dual, retained] using
          matchAt_eq_cached backend agrees offset F adj guards T
    · simp [solveWith, Cached.solve, checkedSolve, inputs, dual]
  · simp [solveWith, Cached.solve, inputs]

def solve (offset : Nat) (F : CNF) (adj : Fin r → List (Fin h))
    (guards : Fin r → Clause) : Outcome :=
  solveWith MatchingCached.solve offset F adj guards

/-- Equality includes the returned assignment as a function over all IDs. -/
theorem solve_eq_cached (offset : Nat) (F : CNF) (adj : Fin r → List (Fin h))
    (guards : Fin r → Clause) : solve offset F adj guards = Cached.solve offset F adj guards :=
  solveWith_eq_cached MatchingCached.solve (fun _ _ => rfl) offset F adj guards

theorem solve_correct (offset : Nat) (F : CNF) (adj : Fin r → List (Fin h))
    (guards : Fin r → Clause) :
    AutomaticConstructor.Correct (encoded offset F adj guards) (solve offset F adj guards) := by
  rw [solve_eq_cached]
  exact Cached.solve_correct offset F adj guards

theorem solve_ne_inconclusive (offset : Nat) (F : CNF) (adj : Fin r → List (Fin h))
    (guards : Fin r → Clause) : solve offset F adj guards ≠ .inconclusive := by
  rw [solve_eq_cached]
  exact Cached.solve_ne_inconclusive offset F adj guards

theorem supported_solve_decisive (offset : Nat) (F : CNF) (adj : Fin r → List (Fin h))
    (guards : Fin r → Clause) (accepted : inputCheck offset F guards = true)
    (dual : dualHornCheck F = true) : Decisive (solve offset F adj guards) := by
  rw [solve_eq_cached]
  exact Cached.supported_solve_decisive offset F adj guards accepted dual

#print axioms guardValues_lookup
#print axioms matchAt_eq_cached
#print axioms solveWith_eq_cached
#print axioms solve_eq_cached
#print axioms solve_correct
#print axioms solve_ne_inconclusive
#print axioms supported_solve_decisive

end PEqualNP.Outside.AutomaticConstructor.GuardVector
