import RetainedScanCost

namespace PEqualNP.Outside.RetainedScanCost.Examples
open PEqualNP.Search

def chain : CNF := [[(0,false),(1,true)],[(1,false),(2,true)],[(2,false)]]
def contradiction : CNF := [[(0,false)],[(0,true)]]
def wide : CNF := [[(2^80,false)],[(2^80,true),(7,true)]]

example : (solveCounted ([] : CNF)).2 = 0 := by decide
example : (solveCounted ([[]] : CNF)).2 = 1 := by decide
example : (solveCounted contradiction).2 = 3 := by decide
example : (solveCounted chain).2 = 9 := by decide
example : (solveCounted wide).2 = 3 := by decide
example : (solveCounted chain).1 = some ∅ := by decide
example : (solveCounted contradiction).1 = none := by decide
example : (solveCounted wide).1 = some {7} := by decide

#eval [([] : CNF), [[]], contradiction, chain, wide].map (fun F =>
  ((solveCounted F).2, (encodeCNF F).length))
#eval (solveCounted chain).1.map Finset.card
#eval (solveCounted contradiction).1.map Finset.card
#eval (solveCounted wide).1.map Finset.card
end PEqualNP.Outside.RetainedScanCost.Examples
