import BoundedMatchingState

namespace PEqualNP.Outside.BoundedMatching
variable {r h : Nat}

/-- Result-erasing instrumentation: one key comparison per visited entry. -/
def lookupMeter [DecidableEq K] (key : K) : List (K × V) → Option V × Nat
  | [] => (none, 0)
  | (k, v) :: rest =>
      if key = k then (some v, 1)
      else let next := lookupMeter key rest; (next.1, next.2 + 1)

theorem lookupMeter_correct [DecidableEq K] (key : K) (table : List (K × V)) :
    (lookupMeter key table).1 = lookup key table ∧
    (lookupMeter key table).2 ≤ table.length := by
  induction table with
  | nil => exact ⟨rfl, Nat.le_refl 0⟩
  | cons entry rest ih =>
      rcases entry with ⟨k, v⟩
      by_cases same : key = k
      · simp [lookupMeter, lookup, same]
      · simp only [lookupMeter, lookup, ite_eq_right same, List.length_cons]
        exact ⟨ih.1, Nat.add_le_add_right ih.2 1⟩

/-- The direct reverse scan has the same bounded comparison behavior.
No historical matching state or list of all possible holes is traversed. -/
def ownerMeter : Table r h → Fin h → Option (Fin r) × Nat
  | [], _ => (none, 0)
  | (i, k) :: rest, hole =>
      if hole = k then (some i, 1)
      else let next := ownerMeter rest hole; (next.1, next.2 + 1)

theorem ownerMeter_correct (table : Table r h) (hole : Fin h) :
    (ownerMeter table hole).1 = owner table hole ∧
    (ownerMeter table hole).2 ≤ table.length := by
  induction table with
  | nil => exact ⟨rfl, Nat.le_refl 0⟩
  | cons entry rest ih =>
      rcases entry with ⟨i, k⟩
      by_cases same : hole = k
      · simp [ownerMeter, owner, same]
      · simp only [ownerMeter, owner, ite_eq_right same, List.length_cons]
        exact ⟨ih.1, Nat.add_le_add_right ih.2 1⟩

theorem row_comparisons_le_rows (table : Table r h) (good : WellFormed table) (i : Fin r) :
    (lookupMeter i table).2 ≤ r :=
  (lookupMeter_correct i table).2.trans (table_length_le_rows table good)

theorem owner_comparisons_le_rows (table : Table r h) (good : WellFormed table) (hole : Fin h) :
    (ownerMeter table hole).2 ≤ r :=
  (ownerMeter_correct table hole).2.trans (table_length_le_rows table good)

#print axioms lookupMeter_correct
#print axioms ownerMeter_correct
#print axioms row_comparisons_le_rows
#print axioms owner_comparisons_le_rows
end PEqualNP.Outside.BoundedMatching
