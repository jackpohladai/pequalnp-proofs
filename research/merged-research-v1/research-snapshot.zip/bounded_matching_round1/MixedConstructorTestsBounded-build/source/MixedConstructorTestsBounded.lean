import BoundedGuardVectorInput

namespace PEqualNP.Outside.MixedConstructorTestsBounded

open PEqualNP.Search
open PEqualNP.Outside.GuardedCNFEncoding
open PEqualNP.Outside.AutomaticConstructor

variable {r h : Nat}

/-- Independently spell out the public natural-number naming convention. -/
private def referenceEdge (offset : Nat) (i : Fin r) (k : Fin h) : Nat :=
  let a := i.val
  let b := k.val
  offset + (if a < b then b * b + a else a * a + a + b)

/-- Build row clauses from explicit edges, with just one conflict clause
per unordered pair of distinct rows sharing a hole. -/
private def referenceCNF (offset : Nat) (F : CNF)
    (adj : Fin r → List (Fin h)) (guards : Fin r → Clause) : CNF :=
  let rows := List.finRange r
  let rowClauses := rows.map fun i =>
    guards i ++ ((adj i).eraseDups.map fun k => (referenceEdge offset i k, true))
  let conflicts := rows.flatMap fun i =>
    (rows.filter fun j => decide (i.val < j.val)).flatMap fun j =>
      ((adj i).eraseDups.filter fun k => (adj j).contains k).map fun k =>
        [(referenceEdge offset i k, false), (referenceEdge offset j k, false)]
  F ++ rowClauses ++ conflicts

private def occurringIDs (F : CNF) : List Nat :=
  (F.flatMap fun clause => clause.map Prod.fst).eraseDups

private def valuations : List Nat → List (List (Nat × Bool))
  | [] => [[]]
  | id :: rest =>
    let smaller := valuations rest
    (smaller.map fun table => (id, false) :: table) ++
      (smaller.map fun table => (id, true) :: table)

private def tableAssignment (table : List (Nat × Bool)) (id : Nat) : Bool :=
  match table.find? (fun entry => entry.1 == id) with
  | some entry => entry.2
  | none => false

/-- Boolean evaluator independent of the constructor solver and its
retained and matching subroutines. -/
private def evaluate (assignment : Assignment) (F : CNF) : Bool :=
  F.all fun clause => clause.any fun (id, positive) =>
    if positive then assignment id else !assignment id

private def bruteSat (F : CNF) : Bool :=
  (valuations (occurringIDs F)).any fun table => evaluate (tableAssignment table) F

private def freshIDsOK (offset : Nat) (F : CNF) (guards : Fin r → Clause) : Bool :=
  let rows := List.finRange r
  let pairs := rows.flatMap fun i => (List.finRange h).map fun k => (i, k)
  let ids := pairs.map (freshEdge offset)
  let visible := occurringIDs (F ++ rows.map guards)
  ids.length == ids.eraseDups.length &&
    ids.all (fun id => decide (offset ≤ id)) &&
    visible.all (fun id => decide (id < offset)) &&
    pairs.all (fun (i, k) => freshEdge offset (i, k) == referenceEdge offset i k)

private inductive Verdict where
  | sat | unsat | unsupported | inconclusive
  deriving BEq

private structure Trial where
  assignments : Nat
  allAssignmentsAgree : Bool
  privateIDsSeparated : Bool
  expectedSat : Bool
  retainedUnsat : Bool
  verdict : Verdict
  satWitnessValid : Bool
  duplicateNeighborhood : Bool
  noRows : Bool
  noHoles : Bool

-- Keep the original oracle inputs and checks, but run the new public list-input wrapper.
private def solvePublic (offset : Nat) (F : CNF) (adj : Fin r → List (Fin h))
    (guards : Fin r → Clause) : Outcome :=
  PEqualNP.Outside.ExplicitConstructorInput.BoundedGuardVector.solve {
    offset := offset
    holeBound := h
    retained := F
    rows := (List.finRange r).map (fun i => ⟨(adj i).map Fin.val, guards i⟩)
  }

private def check (offset : Nat) (F : CNF) (adj : Fin r → List (Fin h))
    (guards : Fin r → Clause) : Trial :=
  let actual := encoded offset F adj guards
  let reference := referenceCNF offset F adj guards
  let table := (valuations (occurringIDs (actual ++ reference))).map fun bits =>
    (evaluate (tableAssignment bits) actual, evaluate (tableAssignment bits) reference)
  let expected := table.any Prod.snd
  let (verdict, witnessOK) := match solvePublic offset F adj guards with
    | .sat witness => (Verdict.sat,
        evaluate witness actual && evaluate witness reference && CNF.eval witness actual)
    | .unsat => (Verdict.unsat, false)
    | .unsupported => (Verdict.unsupported, false)
    | .inconclusive => (Verdict.inconclusive, false)
  {
    assignments := table.length
    allAssignmentsAgree := table.all (fun entry => entry.1 == entry.2)
    privateIDsSeparated := freshIDsOK (h := h) offset F guards
    expectedSat := expected
    retainedUnsat := !bruteSat F
    verdict := verdict
    satWitnessValid := witnessOK
    duplicateNeighborhood := (List.finRange r).any (fun i =>
      decide ((adj i).eraseDups.length < (adj i).length))
    noRows := r == 0
    noHoles := h == 0
  }

private def Trial.verdictAgrees (trial : Trial) : Bool :=
  if trial.expectedSat then trial.verdict == .sat && trial.satWitnessValid
  else trial.verdict == .unsat

private def Trial.passes (trial : Trial) : Bool :=
  trial.allAssignmentsAgree && trial.privateIDsSeparated && trial.verdictAgrees

private structure Counts where
  cases : Nat := 0
  assignments : Nat := 0
  encodingTruthTablesAgree : Nat := 0
  privateIDChecksPass : Nat := 0
  accepted : Nat := 0
  expectedSat : Nat := 0
  retainedUnsat : Nat := 0
  sat : Nat := 0
  unsat : Nat := 0
  unsupported : Nat := 0
  inconclusive : Nat := 0
  satWitnessesVerified : Nat := 0
  duplicateNeighborhoods : Nat := 0
  emptyRows : Nat := 0
  emptyHoles : Nat := 0
  deriving Repr

private def bit (b : Bool) : Nat := if b then 1 else 0

private def Counts.add (counts : Counts) (trial : Trial) : Counts :=
  {
    cases := counts.cases + 1
    assignments := counts.assignments + trial.assignments
    encodingTruthTablesAgree := counts.encodingTruthTablesAgree + bit trial.allAssignmentsAgree
    privateIDChecksPass := counts.privateIDChecksPass + bit trial.privateIDsSeparated
    accepted := counts.accepted + bit trial.passes
    expectedSat := counts.expectedSat + bit trial.expectedSat
    retainedUnsat := counts.retainedUnsat + bit trial.retainedUnsat
    sat := counts.sat + bit (trial.verdict == .sat)
    unsat := counts.unsat + bit (trial.verdict == .unsat)
    unsupported := counts.unsupported + bit (trial.verdict == .unsupported)
    inconclusive := counts.inconclusive + bit (trial.verdict == .inconclusive)
    satWitnessesVerified := counts.satWitnessesVerified + bit trial.satWitnessValid
    duplicateNeighborhoods := counts.duplicateNeighborhoods + bit trial.duplicateNeighborhood
    emptyRows := counts.emptyRows + bit trial.noRows
    emptyHoles := counts.emptyHoles + bit trial.noHoles
  }

private def leftVar : Nat := 0
private def rightVar : Nat := 4
private def absentVar : Nat := 9
private def offset : Nat := 11

private def retained : List CNF :=
  let x := leftVar
  let y := rightVar
  [
    [],
    [[]],
    [[(x, true)]],
    [[(x, false)]],
    [[(x, true)], [(x, false)]],
    [[(x, false), (y, true)], [(y, false)]],
    [[(x, false), (y, true)], [(y, false), (x, true)], [(x, true)]],
    [[(x, true), (y, true)], [(x, false)], [(y, false)]],
    [[(x, true), (y, true)], [(y, false)]],
    [[(x, false), (x, true)], [(y, true), (y, true)], [(y, true), (y, true)]],
    [[(x, false), (y, true), (y, true)], [(x, false)]],
    [[(y, false), (x, true)], [(x, false)], [(y, true)]]
  ]

private def guardOptions : List Clause :=
  [[], [(leftVar, true)], [(rightVar, true)], [(absentVar, true)],
    [(leftVar, true), (rightVar, true), (leftVar, true)]]

private def systematicCase (F : CNF) (r h edgeMask guardMask : Nat) : Trial :=
  let adj : Fin r → List (Fin h) := fun i =>
    let entries := (List.finRange h).filter (fun k => edgeMask.testBit (i.val * h + k.val))
    if (i.val + edgeMask + guardMask) % 3 = 0 then entries.reverse ++ entries else entries
  let g : Fin r → Clause := fun i =>
    guardOptions.getD (guardMask / guardOptions.length ^ i.val % guardOptions.length) []
  check offset F adj g

private def systematic : List Trial :=
  retained.flatMap fun F =>
    (List.range 3).flatMap fun r =>
      (List.range 3).flatMap fun h =>
        (List.range (2 ^ (r * h))).flatMap fun edgeMask =>
          (List.range (guardOptions.length ^ r)).map fun guardMask =>
            systematicCase F r h edgeMask guardMask

private def systemCounts : Counts :=
  systematic.foldl Counts.add {}

private def ladder (i : Fin 3) : List (Fin 3) :=
  if i = 0 then [0, 1] else if i = 1 then [1, 2] else [0]

private def hallSubset (i : Fin 3) : List (Fin 3) :=
  if i = 2 then [1, 2] else [0]

private def wideVar : Nat := 2 ^ 80

private def widePrivate : Bool :=
  let F : CNF := [[(wideVar, true)], [(7, false)]]
  let off := wideVar + 1
  let adj : Fin 2 → List (Fin 2) := fun i => if i = 0 then [0, 0] else [1, 1]
  let guards : Fin 2 → Clause := fun i => if i = 0 then [(wideVar, true)] else [(7, true)]
  let trial := check off F adj guards
  trial.passes && match solvePublic off F adj guards with
  | .sat witness =>
    witness wideVar && !witness 7 &&
      !witness (referenceEdge off (0 : Fin 2) (0 : Fin 2)) &&
      !witness (referenceEdge off (1 : Fin 2) (0 : Fin 2)) &&
      witness (referenceEdge off (1 : Fin 2) (1 : Fin 2))
  | _ => false

private def targeted : List Bool :=
  let alternating := check offset [[(leftVar, false), (rightVar, true)]] ladder (fun _ => [])
  let hall := check offset [] hallSubset (fun _ => [])
  let emptyInactive := check offset [] (fun (_ : Fin 1) => ([] : List (Fin 0)))
    (fun _ => [(absentVar, true)])
  [alternating.passes && alternating.verdict == .sat,
    hall.passes && hall.verdict == .unsat,
    emptyInactive.passes && emptyInactive.verdict == .sat,
    widePrivate]

private def rejects (F : CNF) (guard : Clause) : Bool :=
  match solvePublic offset F (fun (_ : Fin 1) => ([0] : List (Fin 1))) (fun _ => guard) with
  | .unsupported => true
  | _ => false

private def boundaryControls : List Bool :=
  [rejects [[(leftVar, false), (rightVar, false)]] [],
    rejects [] [(leftVar, false)],
    rejects [[(offset, true)]] [],
    rejects [] [(offset, true)]]

#eval systemCounts
#eval targeted
#eval boundaryControls

#guard
  let counts := systemCounts
  counts.cases == 6756 && counts.assignments == 135152 &&
    counts.accepted == counts.cases && counts.sat == 3482 &&
    counts.unsat == 3274 && counts.satWitnessesVerified == counts.sat &&
    counts.unsupported == 0 && counts.inconclusive == 0

#guard targeted == [true, true, true, true]
#guard boundaryControls == [true, true, true, true]

#print axioms systemCounts
#print axioms targeted
#print axioms boundaryControls

end PEqualNP.Outside.MixedConstructorTestsBounded
