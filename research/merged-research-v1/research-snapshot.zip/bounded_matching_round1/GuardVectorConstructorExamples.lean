import GuardVectorConstructor

namespace PEqualNP.Outside.AutomaticConstructor.GuardVector.Examples

open PEqualNP.Search
open PEqualNP.Outside.GuardedCNFEncoding
open PEqualNP.Outside.SparseDualHornAlgorithm

private def offset : Nat := 16

private def retained : CNF := [[(7, false)], [(7, true), (9, true)]]

private def guards (i : Fin 3) : Clause :=
  if i = 0 then [(7, true)]
  else if i = 1 then [(7, true), (13, true), (13, true)]
  else []

private def alternating (i : Fin 3) : List (Fin 2) :=
  if i = 0 then [0, 1] else if i = 1 then [] else [0]

private def deficient (i : Fin 3) : List (Fin 1) :=
  if i = 1 then [] else [0]

private def verdict : Outcome → String
  | .unsupported => "unsupported"
  | .inconclusive => "inconclusive"
  | .unsat => "unsat"
  | .sat _ => "sat"

private def actualBits : List Bool :=
  (guardValues (state (support retained) {9}) guards).toList

-- The inactive row has no neighbors. The last active row forces the first
-- row to move, and the lifted witness keeps inactive and unselected edges false.
private def alternatingWitnessOK : Bool :=
  match GuardVector.solve offset retained alternating guards with
  | .sat witness =>
    CNF.eval witness (encoded offset retained alternating guards) &&
      !witness 7 && witness 9 && witness 13 &&
      witness (freshEdge offset ((0 : Fin 3), (1 : Fin 2))) &&
      witness (freshEdge offset ((2 : Fin 3), (0 : Fin 2))) &&
      !witness (freshEdge offset ((0 : Fin 3), (0 : Fin 2))) &&
      !witness (freshEdge offset ((1 : Fin 3), (0 : Fin 2))) &&
      !witness (freshEdge offset ((2 : Fin 3), (1 : Fin 2)))
  | _ => false

private def zeroHole (_ : Fin 1) : List (Fin 0) := []

private def zeroRow (i : Fin 0) : List (Fin 0) := i.elim0

private def noGuards (i : Fin 0) : Clause := i.elim0

private def oneEdge (_ : Fin 1) : List (Fin 1) := [0]

private def outcomeExamples : List String :=
  [verdict (GuardVector.solve offset retained alternating guards),
   verdict (GuardVector.solve offset retained deficient guards),
   verdict (GuardVector.solve offset retained zeroHole (fun _ => [(13, true)])),
   verdict (GuardVector.solve offset retained zeroHole (fun _ => [(7, true)])),
   verdict (GuardVector.solve offset retained zeroRow noGuards),
   verdict (GuardVector.solve offset [[(7, true)], [(7, false)]] zeroRow noGuards),
   verdict (GuardVector.solve offset [[(7, false), (9, false)]] oneEdge (fun _ => [])),
   verdict (GuardVector.solve offset retained oneEdge (fun _ => [(7, false)])),
   verdict (GuardVector.solve offset retained oneEdge (fun _ => [(offset, true)]))]

#eval actualBits
#eval alternatingWitnessOK
#eval outcomeExamples

#guard actualBits == [false, true, false]
#guard alternatingWitnessOK
#guard outcomeExamples ==
  ["sat", "unsat", "sat", "unsat", "sat", "unsat", "unsupported", "unsupported", "unsupported"]

#print axioms actualBits
#print axioms alternatingWitnessOK
#print axioms outcomeExamples

end PEqualNP.Outside.AutomaticConstructor.GuardVector.Examples
