import GuardVectorConstructor
import BoundedMatchingLoop

namespace PEqualNP.Outside.AutomaticConstructor.BoundedGuardVector

open PEqualNP.Search
open PEqualNP.Outside.CertifiedConstructorSolver
open PEqualNP.Outside.SparseDualHornAlgorithm

variable {r h : Nat}

/-- Use the bounded association-list matching state with the precomputed
guard callback. -/
def solve (offset : Nat) (F : CNF) (adj : Fin r → List (Fin h))
    (guards : Fin r → Clause) : Outcome :=
  GuardVector.solveWith BoundedMatching.solve offset F adj guards

theorem solve_eq_cached (offset : Nat) (F : CNF) (adj : Fin r → List (Fin h))
    (guards : Fin r → Clause) : solve offset F adj guards = Cached.solve offset F adj guards :=
  GuardVector.solveWith_eq_cached BoundedMatching.solve BoundedMatching.solve_eq_cached
    offset F adj guards

theorem solve_correct (offset : Nat) (F : CNF) (adj : Fin r → List (Fin h))
    (guards : Fin r → Clause) :
    AutomaticConstructor.Correct (encoded offset F adj guards) (solve offset F adj guards) := by
  rw [solve_eq_cached]
  exact Cached.solve_correct offset F adj guards

theorem solve_ne_inconclusive (offset : Nat) (F : CNF) (adj : Fin r → List (Fin h))
    (guards : Fin r → Clause) : solve offset F adj guards ≠ .inconclusive := by
  rw [solve_eq_cached]
  exact Cached.solve_ne_inconclusive offset F adj guards

theorem supported_solve_decisive (offset : Nat) (F : CNF) (adj : Fin r → List (Fin h))
    (guards : Fin r → Clause) (accepted : inputCheck offset F guards = true)
    (dual : dualHornCheck F = true) : Decisive (solve offset F adj guards) := by
  rw [solve_eq_cached]
  exact Cached.supported_solve_decisive offset F adj guards accepted dual

#print axioms solve_eq_cached
#print axioms solve_correct
#print axioms solve_ne_inconclusive
#print axioms supported_solve_decisive

end PEqualNP.Outside.AutomaticConstructor.BoundedGuardVector
