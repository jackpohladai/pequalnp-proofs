import CheckedDualHorn

namespace PEqualNP.Outside.RetainedScanCost
open PEqualNP.Search
open PEqualNP.Outside.SparseDualHornAlgorithm

/-- Literal occurrences, including duplicates. -/
def occurrences (F : CNF) : Nat := (F.map List.length).sum

theorem literal_bits_lower (l : Literal) : 4 ≤ (encodeLiteral l).length := by
  simp only [encodeLiteral, List.length_append, List.length_cons, List.length_nil]
  omega

theorem clause_bits_lower (C : Clause) : 4 * C.length + 2 ≤ (encodeClause C).length := by
  induction C with
  | nil => simp [encodeClause]
  | cons l rest ih =>
      have hl := literal_bits_lower l
      have same : encodeClause (l :: rest) = encodeLiteral l ++ encodeClause rest := by
        simp [encodeClause, List.append_assoc]
      rw [same, List.length_append, List.length_cons]
      omega

theorem formula_bits_lower (F : CNF) :
    4 * occurrences F + 2 * F.length ≤ (encodeCNF F).length := by
  induction F with
  | nil => simp [occurrences, encodeCNF]
  | cons C rest ih =>
      have hc := clause_bits_lower C
      have same : encodeCNF (C :: rest) = encodeClause C ++ encodeCNF rest := rfl
      rw [same, List.length_append]
      simp only [occurrences, List.map_cons, List.sum_cons, List.length_cons] at *
      omega

theorem support_le_bits (F : CNF) : (support F).card ≤ (encodeCNF F).length := by
  have bound := support_card_le_literal_occurrences F
  have same : (F.flatMap (fun C => C.map Prod.fst)).length = occurrences F := by
    induction F with
    | nil => rfl
    | cons C rest ih => simp [occurrences, ih]
  rw [same] at bound
  have bits := formula_bits_lower F
  omega

theorem clauses_le_bits (F : CNF) : F.length ≤ (encodeCNF F).length := by
  have bits := formula_bits_lower F
  omega

/-- Count actual clause-predicate evaluations in a short-circuit search.
The internals of a clause evaluation are deliberately not charged here. -/
def scanBad (assignment : Assignment) : CNF → Option Clause × Nat
  | [] => (none, 0)
  | C :: rest =>
      if Clause.eval assignment C then
        let next := scanBad assignment rest
        (next.1, next.2 + 1)
      else (some C, 1)

theorem scanBad_result (assignment : Assignment) (F : CNF) :
    (scanBad assignment F).1 = F.find? (fun C => !Clause.eval assignment C) := by
  induction F with
  | nil => rfl
  | cons C rest ih =>
      cases evaluated : Clause.eval assignment C <;> simp [scanBad, evaluated, ih]

theorem scanBad_count (assignment : Assignment) (F : CNF) :
    (scanBad assignment F).2 ≤ F.length := by
  induction F with
  | nil => simp [scanBad]
  | cons C rest ih =>
      cases evaluated : Clause.eval assignment C <;> simp [scanBad, evaluated] <;> omega

theorem scanBad_none (assignment : Assignment) (F : CNF) :
    (scanBad assignment F).1 = none ↔ CNF.eval assignment F = true := by
  rw [scanBad_result]
  simp [List.find?_eq_none, CNF.eval, List.all_eq_true]

/-- Instrument the actual retained solver with clause evaluations only.
Negative-literal search, support/set operations, literal evaluation and
bit arithmetic are excluded, so this is not a full running-time model. -/
def runCounted (U : Finset Nat) (F : CNF) : Nat → Finset Nat → Option (Finset Nat) × Nat
  | 0, T =>
      let checked := scanBad (state U T) F
      (if checked.1 = none then some T else none, checked.2)
  | fuel + 1, T =>
      let checked := scanBad (state U T) F
      match checked.1 with
      | none => (some T, checked.2)
      | some C =>
          match C.find? (fun l => !l.2) with
          | none => (none, checked.2)
          | some l =>
              let next := runCounted U F fuel (T.erase l.1)
              (next.1, checked.2 + next.2)

theorem runCounted_result (U : Finset Nat) (F : CNF) (fuel : Nat) (T : Finset Nat) :
    (runCounted U F fuel T).1 = run U F fuel T := by
  induction fuel generalizing T with
  | zero =>
      by_cases h : (scanBad (state U T) F).1 = none
      · have he := (scanBad_none _ _).mp h
        simp [runCounted, run, h, he]
      · have he : CNF.eval (state U T) F ≠ true :=
          fun valid => h ((scanBad_none _ _).mpr valid)
        simp [runCounted, run, h, he]
  | succ fuel ih =>
      cases found : (scanBad (state U T) F).1 with
      | none =>
          have old : F.find? (fun C => !Clause.eval (state U T) C) = none :=
            (scanBad_result _ _).symm.trans found
          simp [runCounted, run, found, old]
      | some C =>
          have old : F.find? (fun C => !Clause.eval (state U T) C) = some C :=
            (scanBad_result _ _).symm.trans found
          cases negative : C.find? (fun l => !l.2) <;>
            simp [runCounted, run, found, old, negative, ih]

theorem runCounted_count (U : Finset Nat) (F : CNF) (fuel : Nat) (T : Finset Nat) :
    (runCounted U F fuel T).2 ≤ (fuel + 1) * F.length := by
  induction fuel generalizing T with
  | zero => simpa [runCounted] using scanBad_count (state U T) F
  | succ fuel ih =>
      have checked := scanBad_count (state U T) F
      cases found : (scanBad (state U T) F).1 with
      | none =>
          simp only [runCounted, found, Nat.add_mul, Nat.one_mul]
          omega
      | some C =>
          cases negative : C.find? (fun l => !l.2) with
          | none =>
              simp only [runCounted, found, negative, Nat.add_mul, Nat.one_mul]
              omega
          | some l =>
              have smaller := ih (T.erase l.1)
              simp only [Nat.add_mul, Nat.one_mul] at smaller
              simp only [runCounted, found, negative, Nat.add_mul, Nat.one_mul]
              omega

def solveCounted (F : CNF) : Option (Finset Nat) × Nat :=
  let U := support F
  runCounted U F U.card U

theorem solveCounted_result (F : CNF) : (solveCounted F).1 = solveSparse F :=
  runCounted_result _ _ _ _

/-- A quadratic bound in the project's actual binary encoding on this
one event count, NOT on the whole solver's primitive or bit operations. -/
theorem clause_evaluations_le_bits_square (F : CNF) :
    (solveCounted F).2 ≤ ((encodeCNF F).length + 1) * (encodeCNF F).length := by
  have counted := runCounted_count (support F) F (support F).card (support F)
  have left := support_le_bits F
  have right := clauses_le_bits F
  exact counted.trans (Nat.mul_le_mul (Nat.add_le_add_right left 1) right)

#print axioms formula_bits_lower
#print axioms solveCounted_result
#print axioms clause_evaluations_le_bits_square
end PEqualNP.Outside.RetainedScanCost
