import CachedMove
import Mathlib.Data.Fintype.Card

namespace PEqualNP.Outside.BoundedMatching
open PEqualNP.Outside.MatchingAugmentation
variable {r h : Nat}

abbrev Table (r h : Nat) := List (Fin r × Fin h)

def lookup [DecidableEq K] (key : K) : List (K × V) → Option V
  | [] => none
  | (k, v) :: rest => if key = k then some v else lookup key rest

def eraseKey [DecidableEq K] (key : K) (table : List (K × V)) : List (K × V) :=
  table.filter (fun entry => decide (entry.1 ≠ key))

theorem lookup_none_iff [DecidableEq K] (key : K) (table : List (K × V)) :
    lookup key table = none ↔ key ∉ table.map Prod.fst := by
  induction table with
  | nil => simp [lookup]
  | cons entry rest ih =>
      rcases entry with ⟨k, v⟩
      by_cases same : key = k <;> simp [lookup, same, ih]

theorem lookup_some_iff [DecidableEq K] (key : K) (value : V) (table : List (K × V))
    (unique : (table.map Prod.fst).Nodup) :
    lookup key table = some value ↔ (key, value) ∈ table := by
  induction table with
  | nil => simp [lookup]
  | cons entry rest ih =>
      rcases entry with ⟨k, v⟩
      have keys := List.nodup_cons.mp unique
      by_cases same : key = k
      · subst key
        have absent : ∀ w, (k, w) ∉ rest := by
          intro w member
          exact keys.1 (List.mem_map.mpr ⟨(k, w), member, rfl⟩)
        simp [lookup, absent, eq_comm]
      · simpa [lookup, same] using ih keys.2

theorem lookup_erase [DecidableEq K] (key erased : K) (table : List (K × V)) :
    lookup key (eraseKey erased table) = if key = erased then none else lookup key table := by
  induction table with
  | nil => simp [eraseKey, lookup]
  | cons entry rest ih =>
      rcases entry with ⟨k, v⟩
      by_cases ki : k = erased <;> by_cases kk : key = k <;>
        by_cases ke : key = erased <;> simp_all [eraseKey, lookup]

def rowMatch (table : Table r h) (i : Fin r) : Option (Fin h) := lookup i table

/-- Direct reverse-key scan: no swapped list is allocated at runtime. -/
def owner : Table r h → Fin h → Option (Fin r)
  | [], _ => none
  | (i, k) :: rest, hole => if hole = k then some i else owner rest hole

theorem owner_eq_swapped (table : Table r h) (hole : Fin h) :
    owner table hole = lookup hole (table.map Prod.swap) := by
  induction table with
  | nil => rfl
  | cons entry rest ih => cases entry; simp [owner, lookup, ih]

def WellFormed (table : Table r h) : Prop :=
  (table.map Prod.fst).Nodup ∧ (table.map Prod.snd).Nodup

theorem owner_some_iff (table : Table r h) (good : WellFormed table) (hole : Fin h)
    (i : Fin r) : owner table hole = some i ↔ (i, hole) ∈ table := by
  rw [owner_eq_swapped]
  have unique : ((table.map Prod.swap).map Prod.fst).Nodup := by
    simpa [List.map_map, Function.comp_def] using good.2
  rw [lookup_some_iff hole i (table.map Prod.swap) unique]
  constructor
  · intro member
    obtain ⟨⟨j, k⟩, original, equal⟩ := List.mem_map.mp member
    have same : j = i ∧ k = hole := ⟨congrArg Prod.snd equal, congrArg Prod.fst equal⟩
    simpa [same.1, same.2] using original
  · intro member
    exact List.mem_map.mpr ⟨(i, hole), member, rfl⟩

def toState (table : Table r h) : State r h := ⟨rowMatch table, owner table⟩
def empty : Table r h := []

theorem empty_wellFormed : WellFormed (empty : Table r h) := by simp [WellFormed, empty]
theorem empty_toState : toState (empty : Table r h) = MatchingAugmentation.empty := rfl

theorem toState_consistent (table : Table r h) (good : WellFormed table) :
    Consistent (toState table) := by
  intro i k
  change lookup i table = some k ↔ owner table k = some i
  rw [lookup_some_iff i k table good.1, owner_some_iff table good k i]

/-- Overwrite one row; previous entries for that row are removed. -/
def move (table : Table r h) (i : Fin r) (hole : Fin h) : Table r h :=
  (i, hole) :: eraseKey i table

theorem move_rowMatch (table : Table r h) (i j : Fin r) (hole : Fin h) :
    rowMatch (move table i hole) j = if j = i then some hole else rowMatch table j := by
  by_cases same : j = i <;> simp [rowMatch, move, lookup, lookup_erase, same]

theorem move_wellFormed (table : Table r h) (good : WellFormed table)
    (i : Fin r) (hole : Fin h) (free : owner table hole = none) :
    WellFormed (move table i hole) := by
  have subset : List.Sublist (eraseKey i table) table := List.filter_sublist
  constructor
  · apply List.nodup_cons.mpr
    constructor
    · intro member
      obtain ⟨entry, kept, same⟩ := List.mem_map.mp member
      have different := (List.mem_filter.mp kept).2
      simp only [decide_eq_true_eq] at different
      exact different same
    · exact (subset.map Prod.fst).nodup good.1
  · apply List.nodup_cons.mpr
    constructor
    · intro member
      obtain ⟨⟨j, k⟩, kept, same⟩ := List.mem_map.mp member
      have original := (List.mem_filter.mp kept).1
      have sameHole : k = hole := same
      have occupied : owner table hole = some j :=
        (owner_some_iff table good hole j).mpr (by simpa only [sameHole] using original)
      simp [free] at occupied
    · exact (subset.map Prod.snd).nodup good.2

theorem move_toState (table : Table r h) (good : WellFormed table) (i : Fin r)
    (hole : Fin h) (free : owner table hole = none) :
    toState (move table i hole) = MatchingAugmentation.move (toState table) i hole := by
  have original := toState_consistent table good
  have updated := toState_consistent (move table i hole) (move_wellFormed table good i hole free)
  have logical := move_consistent (toState table) original i hole free
  have rowsEqual : (toState (move table i hole)).rowMatch =
      (MatchingAugmentation.move (toState table) i hole).rowMatch := by
    funext j
    exact move_rowMatch table i j hole
  have ownersEqual : (toState (move table i hole)).owner =
      (MatchingAugmentation.move (toState table) i hole).owner := by
    funext k
    cases left : (toState (move table i hole)).owner k with
    | none =>
        cases right : (MatchingAugmentation.move (toState table) i hole).owner k with
        | none => rfl
        | some j =>
            have row := (logical j k).mpr right
            rw [← rowsEqual] at row
            have impossible := (updated j k).mp row
            simp [left] at impossible
    | some j =>
        have row := (updated j k).mpr left
        rw [rowsEqual] at row
        exact ((logical j k).mp row).symm
  cases a : toState (move table i hole)
  cases b : MatchingAugmentation.move (toState table) i hole
  simp_all

theorem move_toState_cached (table : Table r h) (good : WellFormed table) (i : Fin r)
    (hole : Fin h) (free : owner table hole = none) :
    toState (move table i hole) = moveCached (toState table) i hole := by
  rw [moveCached_eq_move]
  exact move_toState table good i hole free

theorem table_length_le_rows (table : Table r h) (good : WellFormed table) : table.length ≤ r := by
  simpa using good.1.length_le_card

#print axioms toState_consistent
#print axioms move_wellFormed
#print axioms move_toState
#print axioms table_length_le_rows
end PEqualNP.Outside.BoundedMatching
