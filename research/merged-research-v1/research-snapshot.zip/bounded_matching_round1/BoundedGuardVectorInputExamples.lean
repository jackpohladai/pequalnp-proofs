import BoundedGuardVectorInput

namespace PEqualNP.Outside.ExplicitConstructorInput.BoundedGuardVector.Examples

open PEqualNP.Search
open PEqualNP.Outside.AutomaticConstructor
open PEqualNP.Outside.GuardedCNFEncoding

private def makeInput (left right bound : Nat) : Input := {
  offset := 16
  holeBound := bound
  retained := [[(7, false)], [(7, true), (9, true)]]
  rows := [
    ⟨[left, right, left], [(7, true)]⟩,
    ⟨[], [(7, true), (13, true)]⟩,
    ⟨[left], []⟩
  ]
}

private def smallWitness : Bool :=
  let input := makeInput 0 1 2
  match BoundedGuardVector.solve input with
  | .sat witness => CNF.eval witness (formula input)
  | _ => false

private def wide : Nat := 2 ^ 80

private def wideLeft : Fin (wide + 2) :=
  ⟨wide, Nat.lt_succ_of_lt (Nat.lt_succ_self wide)⟩

private def wideRight : Fin (wide + 2) :=
  ⟨wide + 1, Nat.lt_succ_self (wide + 1)⟩

-- Evaluate only selected witness bits. The reference CNF would enumerate
-- the whole hole bound, which is deliberately huge in this fixture.
private def wideWitness : Bool :=
  match BoundedGuardVector.solve (makeInput wide (wide + 1) (wide + 2)) with
  | .sat witness =>
    !witness 7 && witness 9 && witness 13 &&
    witness (freshEdge 16 ((0 : Fin 3), wideRight)) &&
    witness (freshEdge 16 ((2 : Fin 3), wideLeft)) &&
    !witness (freshEdge 16 ((0 : Fin 3), wideLeft)) &&
    !witness (freshEdge 16 ((1 : Fin 3), wideRight))
  | _ => false

private def deficient : Bool :=
  match BoundedGuardVector.solve (makeInput 0 0 1) with
  | .unsat => true
  | _ => false

private def rejectsInvalidHole : Bool :=
  match BoundedGuardVector.solve (makeInput 0 2 2) with
  | .unsupported => true
  | _ => false

private def fixtureResults : List Bool :=
  [smallWitness, wideWitness, deficient, rejectsInvalidHole]

#eval fixtureResults
#guard fixtureResults == [true, true, true, true]
#print axioms fixtureResults

end PEqualNP.Outside.ExplicitConstructorInput.BoundedGuardVector.Examples
