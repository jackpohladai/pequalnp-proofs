import BoundedMatchingState
import CachedMatching
import RawMatchingCompleteness

namespace PEqualNP.Outside.BoundedMatching

open PEqualNP.Outside.MatchingAugmentation
open PEqualNP.Outside.MatchingCertificates
open PEqualNP.Outside.MatchingLoop
open PEqualNP.Outside.MatchingPaths

variable {r h : Nat}

/-- Replay directly on the bounded table. The functional view is used for
queries only, and never passed to the persistent closure update. -/
def augmentTable (N : Fin r → Finset (Fin h)) :
    List (Fin r) → Table r h → Fin h → Option (Table r h)
  | [], _, _ => none
  | i :: rest, table, k =>
      if (toState table).owner k = none ∧ k ∈ N i then
        let next := move table i k
        match (toState table).rowMatch i with
        | none => if rest = [] then some next else none
        | some previous => augmentTable N rest next previous
      else none

theorem augmentTable_refine (N : Fin r → Finset (Fin h)) (rows : List (Fin r))
    (table : Table r h) (hole : Fin h) (valid : WellFormed table) :
    (augmentTable N rows table hole).map toState = augmentRows N rows (toState table) hole ∧
      ∀ next, augmentTable N rows table hole = some next → WellFormed next := by
  induction rows generalizing table hole with
  | nil => simp [augmentTable, augmentRows]
  | cons i rest ih =>
      by_cases permitted : (toState table).owner hole = none ∧ hole ∈ N i
      · have moved := move_toState table valid i hole permitted.1
        have preserved := move_wellFormed table valid i hole permitted.1
        cases previous : (toState table).rowMatch i with
        | none =>
            by_cases last : rest = []
            · constructor
              · simp [augmentTable, augmentRows, permitted, previous, last, moved]
              · intro next returned
                have same : move table i hole = next := by
                  simpa [augmentTable, permitted, previous, last] using returned
                exact same ▸ preserved
            · simp [augmentTable, augmentRows, permitted, previous, last]
        | some earlier =>
            obtain ⟨refined, stillWellFormed⟩ := ih (move table i hole) earlier preserved
            constructor
            · simpa [augmentTable, augmentRows, permitted, previous, moved] using refined
            · simpa [augmentTable, permitted, previous] using stillWellFormed
      · simp [augmentTable, augmentRows, permitted]

theorem returned_augmentation_size_le_rows (N : Fin r → Finset (Fin h))
    (rows : List (Fin r)) (table next : Table r h) (hole : Fin h)
    (valid : WellFormed table) (returned : augmentTable N rows table hole = some next) :
    next.length ≤ r :=
  table_length_le_rows next ((augmentTable_refine N rows table hole valid).2 next returned)

def tryTablePath (N : Fin r → Finset (Fin h)) (g : Fin r → Bool)
    (table : Table r h) (root : Fin r) (hole : Fin h) (rows : List (Fin r)) :
    Option (Table r h) :=
  if rows.all (fun i => !g i) then
    match augmentTable N rows table hole with
    | none => none
    | some next => if ((toState next).rowMatch root).isSome then some next else none
  else none

theorem tryTablePath_refine (N : Fin r → Finset (Fin h)) (g : Fin r → Bool)
    (table : Table r h) (root : Fin r) (hole : Fin h) (rows : List (Fin r))
    (valid : WellFormed table) :
    (tryTablePath N g table root hole rows).map toState =
        tryPath N g (toState table) root hole rows ∧
      ∀ next, tryTablePath N g table root hole rows = some next → WellFormed next := by
  by_cases live : rows.all (fun i => !g i) = true
  · have refinement := augmentTable_refine N rows table hole valid
    cases replay : augmentTable N rows table hole with
    | none =>
        have abstractNone : augmentRows N rows (toState table) hole = none := by
          simpa [replay] using refinement.1.symm
        simp [tryTablePath, tryPath, live, replay, abstractNone]
    | some advanced =>
        have abstractSome :
            augmentRows N rows (toState table) hole = some (toState advanced) := by
          simpa [replay] using refinement.1.symm
        by_cases covered : ((toState advanced).rowMatch root).isSome = true
        · constructor
          · simp [tryTablePath, tryPath, live, replay, abstractSome, covered]
          · intro next returned
            have same : advanced = next := by
              simpa [tryTablePath, live, replay, covered] using returned
            exact same ▸ refinement.2 advanced replay
        · simp [tryTablePath, tryPath, live, replay, abstractSome, covered]
  · simp [tryTablePath, tryPath, live]

/-- The two existing searches read this table through a constant-size view.
All successful replay updates replace entries in the table. -/
def visitTable (N : Fin r → Finset (Fin h)) (g : Fin r → Bool)
    (propose : State r h → Fin r → Proposal r h) :
    List (Fin r) → Table r h → Result r h
  | [], table => .success (toState table).rowMatch
  | root :: todo, table =>
      if g root = false ∧ (toState table).rowMatch root = none then
        match propose (toState table) root with
        | .path hole rows =>
            match tryTablePath N g table root hole rows with
            | none => .inconclusive
            | some next => visitTable N g propose todo next
        | .cut rows => if failureCheck N g rows then .failure rows else .inconclusive
        | .inconclusive => .inconclusive
      else visitTable N g propose todo table

theorem visitTable_refine (N : Fin r → Finset (Fin h)) (g : Fin r → Bool)
    (propose : State r h → Fin r → Proposal r h) (todo : List (Fin r)) (table : Table r h)
    (valid : WellFormed table) :
    visitTable N g propose todo table = visit N g propose todo (toState table) := by
  induction todo generalizing table with
  | nil => rfl
  | cons root todo ih =>
      by_cases need : g root = false ∧ (toState table).rowMatch root = none
      · cases proposed : propose (toState table) root with
        | inconclusive => simp [visitTable, visit, need, proposed]
        | cut rows => simp [visitTable, visit, need, proposed]
        | path hole rows =>
            have refinement := tryTablePath_refine N g table root hole rows valid
            cases replay : tryTablePath N g table root hole rows with
            | none =>
                have abstractNone : tryPath N g (toState table) root hole rows = none := by
                  simpa [replay] using refinement.1.symm
                simp [visitTable, visit, need, proposed, replay, abstractNone]
            | some next =>
                have abstractSome :
                    tryPath N g (toState table) root hole rows = some (toState next) := by
                  simpa [replay] using refinement.1.symm
                simpa [visitTable, visit, need, proposed, replay, abstractSome] using
                  ih next (refinement.2 next replay)
      · simpa [visitTable, visit, need] using ih table valid

def solve (adj : Fin r → List (Fin h)) (g : Fin r → Bool) : Result r h :=
  visitTable (fun i => (adj i).toFinset) g
    (proposeFromBfs adj (fun state root => rawSearchPath adj state root r))
    (List.finRange r) empty

theorem solve_eq_raw (adj : Fin r → List (Fin h)) (g : Fin r → Bool) :
    solve adj g = RawMatchingPathComposition.solve adj g := by
  unfold solve RawMatchingPathComposition.solve solveFromBfs solveWith
  rw [visitTable_refine _ _ _ _ _ empty_wellFormed, empty_toState]

theorem solve_eq_cached (adj : Fin r → List (Fin h)) (g : Fin r → Bool) :
    solve adj g = MatchingCached.solve adj g :=
  (solve_eq_raw adj g).trans (MatchingCached.solve_eq_raw adj g).symm

theorem solve_accepted (adj : Fin r → List (Fin h)) (g : Fin r → Bool) :
    (solve adj g).Accepted (fun i => (adj i).toFinset) g := by
  rw [solve_eq_raw]
  exact RawMatchingPathComposition.solve_accepted adj g

theorem solve_sound (adj : Fin r → List (Fin h)) (g : Fin r → Bool) :
    (solve adj g).Correct (fun i => (adj i).toFinset) g := by
  rw [solve_eq_raw]
  exact RawMatchingPathComposition.solve_sound adj g

theorem solve_definite (adj : Fin r → List (Fin h)) (g : Fin r → Bool) :
    solve adj g ≠ .inconclusive := by
  rw [solve_eq_raw]
  exact RawMatchingPathComposition.solve_definite adj g

#print axioms augmentTable_refine
#print axioms returned_augmentation_size_le_rows
#print axioms tryTablePath_refine
#print axioms visitTable_refine
#print axioms solve_eq_cached
#print axioms solve_sound
#print axioms solve_definite

end PEqualNP.Outside.BoundedMatching
