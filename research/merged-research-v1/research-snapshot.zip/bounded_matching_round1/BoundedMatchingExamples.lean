import BoundedMatchingLoop

namespace PEqualNP.Outside.BoundedMatching.Examples

open PEqualNP.Outside.MatchingLoop

private def describe : Result r h → String × List (Option Nat)
  | .success cert => ("success", (List.finRange r).map (fun i => (cert i).map Fin.val))
  | .failure cut => ("failure", ((List.finRange r).filter (fun i => i ∈ cut)).map (fun i => some i.val))
  | .inconclusive => ("inconclusive", [])

private def diamond (i : Fin 4) : List (Fin 4) :=
  if i = 0 then [0, 1, 1, 2] else if i = 1 then [1, 2] else if i = 2 then [2, 3] else [0, 1]

private def properCut (i : Fin 6) : List (Fin 4) :=
  if i = 0 then [2] else if i = 1 then [0] else if i = 2 then [1] else
  if i = 3 then [0, 1] else if i = 4 then [3] else []

private def wide : Nat := 2 ^ 80
private def wideLeft : Fin (wide + 2) := ⟨wide, Nat.lt_succ_of_lt (Nat.lt_succ_self wide)⟩
private def wideRight : Fin (wide + 2) := ⟨wide + 1, Nat.lt_succ_self _⟩
private def wideAdjacency (i : Fin 2) : List (Fin (wide + 2)) :=
  if i = 0 then [wideLeft, wideRight] else [wideLeft]

example : describe (solve diamond (fun _ => false)) =
    ("success", [some 2, some 1, some 3, some 0]) := by decide
example : describe (solve properCut (fun i => i == 5)) =
    ("failure", [some 1, some 2, some 3]) := by decide
example : describe (solve wideAdjacency (fun _ => false)) =
    ("success", [some (wide + 1), some wide]) := by decide
example : describe (solve (fun (_ : Fin 2) => [wideLeft]) (fun _ => false)) =
    ("failure", [some 0, some 1]) := by decide
example : describe (solve (fun (_ : Fin 1) => ([] : List (Fin 0))) (fun _ => true)) =
    ("success", [none]) := by decide

#eval describe (solve diamond (fun _ => false))
#eval describe (solve properCut (fun i => i == 5))
#eval describe (solve wideAdjacency (fun _ => false))
#eval describe (solve (fun (_ : Fin 2) => [wideLeft]) (fun _ => false))

end PEqualNP.Outside.BoundedMatching.Examples
