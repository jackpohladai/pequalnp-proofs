import BoundedLookupCost

namespace PEqualNP.Outside.BoundedMatching.Examples

def start : Table 2 3 := [(0, 0), (1, 1)]
def changed := move start 0 2
def reassigned := move changed 1 0

theorem initial_wellFormed : WellFormed start := by unfold WellFormed; decide
theorem updated_wellFormed : WellFormed changed := by unfold WellFormed; decide
theorem overwrite_does_not_grow : changed.length = 2 ∧ reassigned.length = 2 := by decide
theorem old_hole_released : owner changed 0 = none ∧ rowMatch changed 0 = some 2 := by decide
theorem assigned_hole_owner : owner reassigned 0 = some 1 ∧ owner reassigned 2 = some 0 := by decide
theorem duplicate_hole_rejected : ¬ WellFormed ([(0, 0), (1, 0)] : Table 2 3) := by
  unfold WellFormed; decide
theorem exact_owner_comparisons :
    ownerMeter changed 0 = (none, 2) ∧ ownerMeter changed 2 = (some 0, 1) := by decide

def repeated : Table 1 2 :=
  (List.range 1000).foldl (fun table n => move table 0 ⟨n % 2, Nat.mod_lt _ (by decide)⟩) []

def wide : Nat := 2^80
def left : Fin (wide + 2) := ⟨wide, by omega⟩
def right : Fin (wide + 2) := ⟨wide + 1, by omega⟩
def sparse : Table 2 (wide + 2) := [(0, left), (1, right)]

theorem sparse_lookup : owner sparse right = some 1 ∧ rowMatch sparse 0 = some left := by decide

#eval (changed.map (fun p => (p.1.val, p.2.val)), reassigned.map (fun p => (p.1.val, p.2.val)))
#eval (repeated.length, (ownerMeter repeated 0).2, (ownerMeter repeated 1).2)
#eval ((owner sparse right).map Fin.val, (rowMatch sparse 0).map Fin.val)
#print axioms updated_wellFormed
#print axioms old_hole_released
#print axioms sparse_lookup
end PEqualNP.Outside.BoundedMatching.Examples
