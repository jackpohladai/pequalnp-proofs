import BoundedGuardVectorConstructor
import CachedExplicitInput

namespace PEqualNP.Outside.ExplicitConstructorInput.BoundedGuardVector

open PEqualNP.Outside.AutomaticConstructor

/-- Reject invalid hole IDs before building the typed adjacency and guard
arrays. The bounded matcher reads the prepared graph and guard Booleans. -/
def solve (input : Input) : Outcome :=
  if neighborCheck input then
    let adjTable := Cached.prepareAdjacency input
    let guardTable := Cached.prepareGuards input
    AutomaticConstructor.BoundedGuardVector.solve (r := input.rows.length) (h := input.holeBound)
      input.offset input.retained
      (Cached.fromArray adjTable (by simp [adjTable, Cached.prepareAdjacency]))
      (Cached.fromArray guardTable (by simp [guardTable, Cached.prepareGuards]))
  else .unsupported

theorem solve_eq_cached (input : Input) : solve input = Cached.solve input := by
  by_cases checked : neighborCheck input = true
  · simp [solve, Cached.solve, checked, AutomaticConstructor.BoundedGuardVector.solve_eq_cached]
  · simp [solve, Cached.solve, checked]

theorem solve_eq_original (input : Input) : solve input = ExplicitConstructorInput.solve input :=
  (solve_eq_cached input).trans (Cached.solve_eq_original input)

theorem solve_correct (input : Input) :
    AutomaticConstructor.Correct (formula input) (solve input) := by
  rw [solve_eq_original]
  exact ExplicitConstructorInput.solve_correct input

theorem solve_ne_inconclusive (input : Input) : solve input ≠ .inconclusive := by
  rw [solve_eq_original]
  exact ExplicitConstructorInput.solve_ne_inconclusive input

theorem supported_solve_decisive (input : Input)
    (supported : supportedCheck input = true) : Decisive (solve input) := by
  rw [solve_eq_original]
  exact ExplicitConstructorInput.supported_solve_decisive input supported

#print axioms solve_eq_cached
#print axioms solve_eq_original
#print axioms solve_correct
#print axioms solve_ne_inconclusive
#print axioms supported_solve_decisive

end PEqualNP.Outside.ExplicitConstructorInput.BoundedGuardVector
