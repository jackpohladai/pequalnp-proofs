import BoundedMatchingLoop

namespace PEqualNP.Outside.BoundedMatching.Benchmark

open PEqualNP.Outside.MatchingLoop

private def rowsCount (m : Nat) := 3*m+1
private def mkHole (m k : Nat) : Fin (rowsCount m) :=
  ⟨k % rowsCount m, Nat.mod_lt _ (by unfold rowsCount; omega)⟩

private def neighbors (m : Nat) (i : Fin (rowsCount m)) : List (Fin (rowsCount m)) :=
  if i.val = 0 then (List.range (m+1)).map (mkHole m)
  else if i.val ≤ m then [mkHole m i.val]
  else if i.val ≤ 2*m then [mkHole m i.val, mkHole m (i.val+m)]
  else [mkHole m 0, mkHole m (i.val-m)]

private def label : Result r h → String
  | .success _ => "success"
  | .failure _ => "failure"
  | .inconclusive => "inconclusive"

private def trial (m : Nat) : IO Unit := do
  let rows := ((List.finRange (rowsCount m)).map (neighbors m)).toArray
  let adj := fun (i : Fin (rowsCount m)) => rows[i.val]!
  let start ← IO.monoNanosNow
  let cached := label (MatchingCached.solve adj (fun _ => false))
  let middle ← IO.monoNanosNow
  let bounded := label (solve adj (fun _ => false))
  let finish ← IO.monoNanosNow
  if cached != "success" || bounded != "success" then
    throw (IO.userError s!"Unexpected outcome {m} {cached} {bounded}")
  IO.println s!"{m} {cached} {bounded} {middle - start} {finish - middle}"

#eval ([16, 32, 64] : List Nat).forM trial

end PEqualNP.Outside.BoundedMatching.Benchmark
