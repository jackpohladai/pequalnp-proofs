namespace EliminationIndependent
def allB : List Bool → Bool
  | [] => true
  | b :: bs => b && allB bs

def rowB (p : Bool) : List Bool → Bool
  | [] => true
  | n :: ns => (p || n) && rowB p ns

def pairB : List Bool → List Bool → Bool
  | [], _ => true
  | p :: ps, ns => rowB p ns && pairB ps ns

theorem or_and (p n r : Bool) : ((p || n) && (p || r)) = (p || (n && r)) := by decide +revert
theorem and_or (p n r : Bool) : ((p || r) && (n || r)) = ((p && n) || r) := by decide +revert

theorem rowB_eq (p : Bool) (ns : List Bool) : rowB p ns = (p || allB ns) := by
  induction ns with
  | nil => cases p <;> rfl
  | cons n ns ih =>
    simp only [rowB, allB, ih]
    exact or_and p n (allB ns)

theorem pairB_eq (ps ns : List Bool) : pairB ps ns = (allB ps || allB ns) := by
  induction ps with
  | nil => rfl
  | cons p ps ih =>
    simp only [pairB, allB, rowB_eq, ih]
    exact and_or p (allB ps) (allB ns)

def Original (r x : Bool) (ps ns : List Bool) : Bool := r && rowB x ps && rowB (!x) ns

theorem bool_projection (r p n : Bool) :
    (∃ x : Bool, (r && (x || p) && (!x || n)) = true) ↔
      (r && (p || n)) = true := by decide +revert

theorem exact_elimination (r : Bool) (ps ns : List Bool) :
    (∃ x : Bool, Original r x ps ns = true) ↔ (r && pairB ps ns) = true := by
  simpa only [Original, rowB_eq, pairB_eq] using bool_projection r (allB ps) (allB ns)

theorem bool_reconstruction (r p n : Bool) : (r && (p || n)) = true →
    (r && ((!p) || p) && (!(!p) || n)) = true := by decide +revert

theorem reconstruction (r : Bool) (ps ns : List Bool)
    (h : (r && pairB ps ns) = true) : Original r (!(allB ps)) ps ns = true := by
  simp only [pairB_eq] at h
  simpa only [Original, rowB_eq] using bool_reconstruction r (allB ps) (allB ns) h

#print axioms rowB_eq
#print axioms pairB_eq
#print axioms exact_elimination
#print axioms reconstruction
end EliminationIndependent
