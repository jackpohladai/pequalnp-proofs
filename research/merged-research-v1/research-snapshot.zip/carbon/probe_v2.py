from probe_mechanisms import brute_solve, AffineSystem, compile_2lincnf, tarjan_scc
from probe_hard import gen_php
import random

def fast_up_2lin(aff, clauses_list, adj_static=None):
    """Fast unit + binary linear propagation given current AffineSystem and binary clauses."""
    changed = True
    rem = clauses_list
    while changed and not aff.inconsistent:
        changed = False
        nxt = []
        for e1, e2 in rem:
            c1 = aff.canonical_lit(*e1)
            if c1[0] == 'CONST' and c1[1]:
                continue
            c2 = aff.canonical_lit(*e2)
            if c2[0] == 'CONST' and c2[1]:
                continue
            if c1[0] == 'CONST' and not c1[1]:
                if c2[0] == 'CONST':
                    aff.inconsistent = True
                    return []
                if aff.add_equation(c2[1], c2[2]):
                    changed = True
                if aff.inconsistent:
                    return []
                continue
            if c2[0] == 'CONST' and not c2[1]:
                if aff.add_equation(c1[1], c1[2]):
                    changed = True
                if aff.inconsistent:
                    return []
                continue
            _, m1, r1 = c1
            _, m2, r2 = c2
            if m1 == m2:
                if r1 == r2:
                    if aff.add_equation(m1, r1):
                        changed = True
                    if aff.inconsistent:
                        return []
                continue
            nxt.append(((m1, r1), (m2, r2)))
        rem = nxt
    return rem

def affine_hull_intersection(aff0, aff1, branch_mask):
    """Exact Affine Meet of two affine subspaces:
    S0 = {x : aff0 holds} (derived under branch_mask*x == 0)
    S1 = {x : aff1 holds} (derived under branch_mask*x == 1)
    Wait! In GF(2)^V:
    - S0 already includes branch_mask*x == 0, and S1 includes branch_mask*x == 1.
    - Every linear equation holding on S0 U S1 has the form:
      either L*x == c on BOTH S0 and S1,
      or L*x == c on S0 and L*x == c^1 on S1, which is (L ^ branch_mask)*x == c on BOTH S0 and S1!
    WAIT A SECOND! Look at that:
    Let H0 = { (m, r) : m*x == r holds on S0 } (an affine dual space in GF(2)^(V+1): vector (m, r)),
    and H1 = { (m, r) : m*x == r holds on S1 } (also a linear subspace of GF(2)^(V+1)!).
    Because (branch_mask, 0) in H0 and (branch_mask, 1) in H1:
    If L*x == c on S0 and L*x == c^1 on S1, then:
      (L, c) in H0  ==>  (L, c) ^ (branch_mask, 0) = (L ^ branch_mask, c) in H0!
      (L, c^1) in H1 ==> (L, c^1) ^ (branch_mask, 1) = (L ^ branch_mask, c) in H1!
    SO EVERY EQUATION VALID ON (S0 U S1) IS SIMPLY THE VECTOR-SPACE INTERSECTION H0 cap H1 IN GF(2)^(V+1)!!
    CHECK THAT!!
    Is the set of affine equations valid on S0 U S1 literally the linear subspace intersection H0 cap H1 in GF(2)^(V+1)?!
    YES!! Because:
    (m, r) in H0 iff m*x == r for all x in S0 (assuming S0 != empty).
    (m, r) in H1 iff m*x == r for all x in S1 (assuming S1 != empty).
    Therefore m*x == r for all x in S0 U S1 IFF (m, r) in H0 cap H1!!
    AND computing intersection of two RREF subspaces H0, H1 in GF(2)^(V+1) by Zassenhaus algorithm
    is EXACT, COMPLETE, AND O(dim * V) BIT OPERATIONS!!"""
    # Zassenhaus algorithm for H0 cap H1!
    # Represent vector (m, r) as integer (m << 1) | r!
    vecs0 = [((bm << 1) | br) for bm, br in aff0.basis.values()]
    vecs1 = [((bm << 1) | br) for bm, br in aff1.basis.values()]
    if not vecs0 or not vecs1:
        return []
    # Find max bit length L of (m<<1)|r
    max_len = max(max(v.bit_length() for v in vecs0), max(v.bit_length() for v in vecs1))
    shift = max_len + 1
    # Block matrix [ u | u ] for u in vecs0, and [ v | 0 ] for v in vecs1
    # Put upper-left block into row echelon; rows where left block becomes 0 have right block in H0 cap H1!
    pivots = {}
    inter_basis = []
    for u in vecs0:
        left = u
        right = u
        for p in sorted(pivots.keys(), reverse=True):
            if (left >> p) & 1:
                pl, pr = pivots[p]
                left ^= pl
                right ^= pr
        if left != 0:
            pivots[left.bit_length() - 1] = (left, right)
    for v in vecs1:
        left = v
        right = 0
        for p in sorted(pivots.keys(), reverse=True):
            if (left >> p) & 1:
                pl, pr = pivots[p]
                left ^= pl
                right ^= pr
        if left != 0:
            pivots[left.bit_length() - 1] = (left, right)
        elif right != 0:
            inter_basis.append((right >> 1, right & 1))
    return inter_basis

# Test on the 10-clause n=4 MUS and PHP(4,3), PHP(5,4)!
mus4 = [
  [2, -3, -4], [1, 2, -3], [1, -2, 4], [-2, -3, -4], [-1, -3, 4],
  [-1, -2, 3], [2, 3, -4], [1, 2, 3], [-1, 3, 4], [1, 3, -4]
]

def run_with_singleton_and_meet(nvars, clauses, do_meet=True):
    aff, bcl, tv = compile_2lincnf(nvars, clauses)
    rem = list(set(bcl))
    changed = True
    while changed and not aff.inconsistent:
        changed = False
        rem = fast_up_2lin(aff, rem)
        if aff.inconsistent:
            break
        # Add singleton masks 0..tv-1 to active_masks for Triad Closure!
        active_masks = {1 << v for v in range(tv) if v not in aff.basis}
        adj = {}
        clause_set = set()
        for (m1, r1), (m2, r2) in rem:
            a, b = sorted([(m1, r1), (m2, r2)])
            clause_set.add((a, b))
            active_masks.add(m1)
            active_masks.add(m2)
            for node in [(m1, r1), (m1, r1^1), (m2, r2), (m2, r2^1)]:
                adj.setdefault(node, [])
            adj[(m1, r1^1)].append((m2, r2))
            adj[(m2, r2^1)].append((m1, r1))
        rem = list(clause_set)
        sccs = tarjan_scc(adj)
        for comp in sccs:
            if len(comp) > 1:
                m0, r0 = comp[0]
                for m1, r1 in comp[1:]:
                    if m0 == m1 and r0 != r1:
                        aff.inconsistent = True
                        break
                    if aff.add_equation(m0 ^ m1, r0 ^ r1):
                        changed = True
            if aff.inconsistent:
                break
        if changed or aff.inconsistent:
            continue
        # Triad on clauses with singleton-augmented active_masks
        for (m1, r1), (m2, r2) in list(clause_set):
            m3 = m1 ^ m2
            if m3 in active_masks:
                r3 = 1 ^ r1 ^ r2
                for arm in [(m1, r1), (m2, r2)]:
                    if m3 != arm[0]:
                        pair = tuple(sorted([(m3, r3), arm]))
                        if pair not in clause_set:
                            clause_set.add(pair)
                            rem.append(pair)
                            changed = True
        if changed:
            continue
        if do_meet:
            # Probe each free original & aux variable (or active mask) with Zassenhaus Affine Meet!
            probe_masks = sorted(active_masks)
            for pm in probe_masks:
                cm = aff.canonical_lit(pm, 0)
                if cm[0] == 'CONST':
                    continue
                _, pm_red, _ = cm
                a0 = aff.copy()
                a0.add_equation(pm_red, 0)
                fast_up_2lin(a0, rem)
                if a0.inconsistent:
                    if aff.add_equation(pm_red, 1):
                        changed = True
                    break
                a1 = aff.copy()
                a1.add_equation(pm_red, 1)
                fast_up_2lin(a1, rem)
                if a1.inconsistent:
                    if aff.add_equation(pm_red, 0):
                        changed = True
                    break
                meet_eqs = affine_hull_intersection(a0, a1, pm_red)
                for mm, mr in meet_eqs:
                    if aff.add_equation(mm, mr):
                        changed = True
                if changed or aff.inconsistent:
                    break
    return aff, rem

aff_no_meet, rem_no_meet = run_with_singleton_and_meet(4, mus4, do_meet=False)
print("MUS4 with singleton masks only: inconsistent=", aff_no_meet.inconsistent, "rem=", len(rem_no_meet))
aff_meet, rem_meet = run_with_singleton_and_meet(4, mus4, do_meet=True)
print("MUS4 with Zassenhaus Affine Meet: inconsistent=", aff_meet.inconsistent, "rem=", len(rem_meet))

for p, h in [(3, 2), (4, 3), (5, 4)]:
    nv, cl = gen_php(p, h)
    a_m, r_m = run_with_singleton_and_meet(nv, cl, do_meet=True)
    print(f"PHP({p},{h}) with Zassenhaus Affine Meet: inconsistent={a_m.inconsistent}, pivots={len(a_m.basis)}, rem={len(r_m)}")
