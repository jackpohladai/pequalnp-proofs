from probe_mechanisms import brute_solve, verify_assignment, compile_2lincnf, run_2litc_fixpoint

# Shrink the n=4 counterexample to an irreducible minimal core where:
# (1) formula is UNSAT
# (2) 2-LITC does NOT detect inconsistency!
raw_clauses = [[2, -3, -1], [2, -4, -3], [-3, -1, 2], [1, 2, -3], [3, 2, 4], [-2, 1, 4], [-3, -2, -4], [4, -1, -3], [2, 3, 4], [3, -2, -1], [4, 1, 3], [2, 3, 4], [3, 2, -4], [-3, 1, 2], [3, 1, -2], [1, 3, 2], [1, -2, 4], [4, 3, -1], [3, -4, 1], [3, -2, -1], [-2, 3, 4]]

# Deduplicate clauses first
canon = []
seen = set()
for c in raw_clauses:
    t = tuple(sorted(set(c), key=lambda x: abs(x)))
    if t not in seen:
        seen.add(t)
        canon.append(list(t))

# Greedy MUS extraction
mus = list(canon)
i = 0
while i < len(mus):
    cand = mus[:i] + mus[i+1:]
    sat, _ = brute_solve(4, cand)
    if not sat:
        # Check if still undetected by 2-LITC
        aff, bcl, tv = compile_2lincnf(4, cand)
        run_2litc_fixpoint(aff, bcl, use_triads=True)
        if not aff.inconsistent:
            mus = cand
            continue
    i += 1

print(f"Minimal n=4 UNSAT counterexample to 2-LITC ({len(mus)} clauses):")
for c in mus:
    print(" ", c)

aff, bcl, tv = compile_2lincnf(4, mus)
rem = run_2litc_fixpoint(aff, bcl, use_triads=True)
print(f"After 2-LITC: inconsistent={aff.inconsistent}, pivots={len(aff.basis)}, rem_bin_clauses={len(rem)}, total_vars={tv}")
