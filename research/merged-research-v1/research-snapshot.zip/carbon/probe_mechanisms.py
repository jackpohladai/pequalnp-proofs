import itertools
import random

# Exhaustive ground truth oracle
def brute_solve(nvars, clauses):
    # Handle empty clause / empty formula
    for c in clauses:
        if len(c) == 0:
            return False, None
    if len(clauses) == 0:
        return True, [False] * nvars
    eff_n = max([nvars] + [abs(lit) for c in clauses for lit in c])
    for bits in itertools.product([False, True], repeat=eff_n):
        ok = True
        for c in clauses:
            c_ok = False
            for lit in c:
                v = abs(lit) - 1
                val = bits[v] if lit > 0 else (not bits[v])
                if val:
                    c_ok = True
                    break
            if not c_ok:
                ok = False
                break
        if ok:
            return True, list(bits[:eff_n])
    return False, None

def verify_assignment(clauses, assignment):
    for c in clauses:
        if not any((assignment[abs(lit)-1] if lit > 0 else not assignment[abs(lit)-1]) for lit in c):
            return False
    return True

# GF(2) RREF Affine System
# Variables 0 .. total_vars - 1.
# Pivots ordered by index: smaller index = eliminated first!
# Wait: if we want auxiliary vars eliminated FIRST so pure x-equations appear cleanly,
# we can give auxiliary vars higher bit positions and eliminate from MSB down!
# In Python int bitmask, bit i corresponds to var i.
# If x vars are 0 .. n-1, and aux w vars are n .. n+q-1, then MSB-down pivot selection
# (mask.bit_length() - 1) AUTOMATICALLY eliminates w vars (bits >= n) BEFORE x vars (bits < n)!
# Any row with pivot < n has NO bits >= n! Let's verify:
# If pivot p < n, mask < (1 << n), so NO w-bits are set in that row! Brilliant!

class AffineSystem:
    def __init__(self):
        self.basis = {}  # pivot_bit -> (mask, rhs_bit) in RREF!
        self.inconsistent = False
        self.ops = 0

    def copy(self):
        a = AffineSystem()
        a.basis = dict(self.basis)
        a.inconsistent = self.inconsistent
        a.ops = self.ops
        return a

    def reduce_form(self, mask, rhs):
        """Reduce equation (xor_{i in mask} v_i == rhs) modulo current RREF basis.
        Because basis is maintained in full RREF, we only need to XOR basis[p] for p in mask & pivots!
        Wait: iterating pivots in descending order works even if only row-echelon, and in full RREF any order works."""
        m = mask
        r = rhs & 1
        # Check bits in m that are pivots
        for p in sorted(self.basis.keys(), reverse=True):
            if (m >> p) & 1:
                bm, br = self.basis[p]
                self.ops += max(1, bm.bit_length())
                m ^= bm
                r ^= br
        return m, r

    def add_equation(self, mask, rhs):
        """Add equation xor_{i in mask} v_i == rhs. Returns True if new pivot added."""
        if self.inconsistent:
            return False
        m, r = self.reduce_form(mask, rhs)
        if m == 0:
            if r == 1:
                self.inconsistent = True
            return False
        p = m.bit_length() - 1
        # Eliminate p from all existing basis rows to maintain full RREF
        for kp in list(self.basis.keys()):
            bm, br = self.basis[kp]
            if (bm >> p) & 1:
                self.ops += max(1, max(bm.bit_length(), m.bit_length()))
                self.basis[kp] = (bm ^ m, br ^ r)
        self.basis[p] = (m, r)
        return True

    def canonical_lit(self, mask, rhs):
        """Represent truth-indicator of (xor_{i in mask} v_i == rhs).
        After reduction modulo basis:
        - if m == 0: constant True (if r == 0) or constant False (if r == 1)!
          Wait: check! xor_{i in emptyset} v_i = 0.
          So (0 == 0) is TRUE (r == 0), and (0 == 1) is FALSE (r == 1)!
        - if m != 0: canonical equation is (m, r) where m != 0, r in {0, 1}.
          Its negation is (m, r ^ 1)."""
        m, r = self.reduce_form(mask, rhs)
        if m == 0:
            return ('CONST', r == 0)
        return ('EQ', m, r)

def compile_2lincnf(nvars, clauses):
    """Compile arbitrary CNF into (AffineSystem, binary_lin_clauses, total_vars).
    Uses shared OR-gate table for 2-literal prefixes to maximize structural sharing."""
    aff = AffineSystem()
    bin_clauses = []  # list of ((m1, r1), (m2, r2))
    next_var = nvars
    or_gates = {}  # canonical pair of signed lits -> gate_var_idx

    def lit_to_eq(lit):
        v = abs(lit) - 1
        # lit > 0 means x_v == 1 -> (1<<v, 1); lit < 0 means x_v == 0 -> (1<<v, 0)
        return (1 << v, 1 if lit > 0 else 0)

    def get_or_gate(eq1, eq2):
        nonlocal next_var
        key = tuple(sorted([eq1, eq2]))
        if key in or_gates:
            return or_gates[key]
        w = next_var
        next_var += 1
        (m1, r1), (m2, r2) = key
        # Let a = indicator(eq1): m1*x == r1, i.e. a = 1 ^ m1*x ^ r1.
        # Wait! Let's check our OR-gate formula carefully for general eq1=(m1,r1), eq2=(m2,r2)!
        # Let A in {0,1} be truth value of eq1, B in {0,1} be truth value of eq2, W = x_w in {0,1}.
        # Note: A = 1 iff m1*x == r1, so m1*x = r1 ^ 1 ^ A => A ^ B = (m1^m2)*x ^ r1 ^ r2!
        # WAIT CHECK THAT!
        # Suppose eq1 is (x0 == 1): m1=1, r1=1 => A = x0.
        # Suppose eq2 is (x1 == 0): m2=2, r2=0 => B = 1 ^ x1.
        # Then A ^ B = x0 ^ 1 ^ x1.
        # When is A ^ B == 1? When (x0 ^ x1) == 0, i.e., r1 ^ r2 ^ 1 = 1 ^ 0 ^ 1 = 0!
        # Let's check generally!
        # A = 1 ^ (m1*x) ^ r1
        # B = 1 ^ (m2*x) ^ r2
        # A ^ B = (m1 ^ m2)*x ^ (r1 ^ r2)!
        # So:
        #   (A ^ B == 1)  <==>  ((m1 ^ m2)*x == (r1 ^ r2 ^ 1))
        #   (A ^ B == 0)  <==>  ((m1 ^ m2)*x == (r1 ^ r2))
        #   (W ^ A == 0)  <==>  W == A  <==>  x_w == 1 ^ (m1*x) ^ r1  <==>  ((1<<w) ^ m1)*x == (r1 ^ 1)
        #   (W == 1)      <==>  ((1<<w)*x == 1)
        # Let's verify ALL 4 combinations of (A, B) in {0,1}^2!
        # Recall E1: (A ^ B == 1) OR (W ^ A == 0)
        #        E2: (W == 1)     OR (A ^ B == 0)
        # - A=0, B=0: A^B=0, so E1 forces W^A=0 => W=0; E2 satisfied by A^B=0. Unique W=0!
        # - A=0, B=1: A^B=1, so E1 satisfied; E2 forces W=1. Unique W=1!
        # - A=1, B=0: A^B=1, so E1 satisfied; E2 forces W=1. Unique W=1!
        # - A=1, B=1: A^B=0, so E1 forces W^A=0 => W=1; E2 satisfied by A^B=0. Unique W=1!
        e1_arm1 = (m1 ^ m2, r1 ^ r2 ^ 1)
        e1_arm2 = ((1 << w) ^ m1, r1 ^ 1)
        e2_arm1 = (1 << w, 1)
        e2_arm2 = (m1 ^ m2, r1 ^ r2)
        bin_clauses.append((e1_arm1, e1_arm2))
        bin_clauses.append((e2_arm1, e2_arm2))
        w_eq = (1 << w, 1)
        or_gates[key] = w_eq
        return w_eq

    for raw_c in clauses:
        if len(raw_c) == 0:
            aff.inconsistent = True
            return aff, [], next_var
        # Deduplicate & check tautology
        s = set(raw_c)
        if any((-lit) in s for lit in s):
            continue
        lits = sorted(s, key=lambda x: (abs(x), x < 0))
        if len(lits) == 1:
            m, r = lit_to_eq(lits[0])
            aff.add_equation(m, r)
        elif len(lits) == 2:
            bin_clauses.append((lit_to_eq(lits[0]), lit_to_eq(lits[1])))
        else:
            cur = lit_to_eq(lits[0])
            for idx in range(1, len(lits) - 1):
                cur = get_or_gate(cur, lit_to_eq(lits[idx]))
            bin_clauses.append((cur, lit_to_eq(lits[-1])))

    return aff, bin_clauses, next_var

def tarjan_scc(adj):
    index_counter = [0]
    stack = []
    lowlink = {}
    index = {}
    on_stack = set()
    sccs = []

    def strongconnect(v):
        # Iterative Tarjan to avoid recursion limit
        work = [(v, 0)]
        index[v] = lowlink[v] = index_counter[0]
        index_counter[0] += 1
        stack.append(v)
        on_stack.add(v)
        while work:
            node, ni = work[-1]
            nbrs = adj.get(node, ())
            if ni < len(nbrs):
                work[-1] = (node, ni + 1)
                w = nbrs[ni]
                if w not in index:
                    index[w] = lowlink[w] = index_counter[0]
                    index_counter[0] += 1
                    stack.append(w)
                    on_stack.add(w)
                    work.append((w, 0))
                elif w in on_stack:
                    if index[w] < lowlink[node]:
                        lowlink[node] = index[w]
            else:
                work.pop()
                if lowlink[node] == index[node]:
                    comp = []
                    while True:
                        w = stack.pop()
                        on_stack.remove(w)
                        comp.append(w)
                        if w == node:
                            break
                    sccs.append(comp)
                if work:
                    parent = work[-1][0]
                    if lowlink[node] < lowlink[parent]:
                        lowlink[parent] = lowlink[node]

    for v in list(adj.keys()):
        if v not in index:
            strongconnect(v)
    return sccs

def run_2litc_fixpoint(aff, bin_clauses, use_triads=True):
    """Run coupled RREF + 2-Lin SCC + Triad Closure until fixpoint."""
    clauses = set(bin_clauses)
    changed = True
    while changed and not aff.inconsistent:
        changed = False
        new_clauses = set()
        for e1, e2 in clauses:
            c1 = aff.canonical_lit(*e1)
            c2 = aff.canonical_lit(*e2)
            if c1[0] == 'CONST':
                if c1[1]:
                    continue  # True
                else:
                    if c2[0] == 'CONST':
                        if not c2[1]:
                            aff.inconsistent = True
                            return clauses
                        continue
                    else:
                        if aff.add_equation(c2[1], c2[2]):
                            changed = True
                        if aff.inconsistent:
                            return clauses
                        continue
            if c2[0] == 'CONST':
                if c2[1]:
                    continue
                else:
                    if aff.add_equation(c1[1], c1[2]):
                        changed = True
                    if aff.inconsistent:
                        return clauses
                    continue
            _, m1, r1 = c1
            _, m2, r2 = c2
            if m1 == m2:
                if r1 == r2:
                    if aff.add_equation(m1, r1):
                        changed = True
                    if aff.inconsistent:
                        return clauses
                else:
                    # Tautology (e or ~e)
                    continue
            else:
                a, b = sorted([(m1, r1), (m2, r2)])
                new_clauses.add((a, b))
        clauses = new_clauses
        if changed or aff.inconsistent:
            continue

        # Build 2-Lin implication graph G_2
        # Nodes are (m, r); negation is (m, r^1)
        adj = {}
        active_masks = set()
        for (m1, r1), (m2, r2) in clauses:
            active_masks.add(m1)
            active_masks.add(m2)
            for node in [(m1, r1), (m1, r1^1), (m2, r2), (m2, r2^1)]:
                adj.setdefault(node, [])
            adj[(m1, r1^1)].append((m2, r2))
            adj[(m2, r2^1)].append((m1, r1))

        sccs = tarjan_scc(adj)
        comp_id = {}
        for idx, comp in enumerate(sccs):
            for node in comp:
                comp_id[node] = idx

        # Check contradictory SCC and multi-node SCC equivalences!
        for comp in sccs:
            if len(comp) > 1:
                m0, r0 = comp[0]
                for m1, r1 in comp[1:]:
                    if m0 == m1 and r0 != r1:
                        aff.inconsistent = True
                        return clauses
                    # Indicator equivalence: (m0*x == r0) <-> (m1*x == r1)
                    # <==> (m0 ^ m1)*x == (r0 ^ r1)
                    if aff.add_equation(m0 ^ m1, r0 ^ r1):
                        changed = True
                    if aff.inconsistent:
                        return clauses
        if changed:
            continue

        # DAG reachability in G_2 to catch e ->* ~e (failed literals in G_2!)
        # sccs from Tarjan are in reverse topological order (sink SCCs first, index 0 = sink)!
        num_sccs = len(sccs)
        dag_adj = [set() for _ in range(num_sccs)]
        for u, nbrs in adj.items():
            cu = comp_id[u]
            for v in nbrs:
                cv = comp_id[v]
                if cu != cv:
                    dag_adj[cu].add(cv)
        # Bitset reachability in topological order (0..num_sccs-1 are sinks first)
        reach = [1 << i for i in range(num_sccs)]
        for i in range(num_sccs):
            ri = reach[i]
            for j in dag_adj[i]:
                ri |= reach[j]
            reach[i] = ri
        for m in active_masks:
            c0 = comp_id[(m, 0)]
            c1 = comp_id[(m, 1)]
            if (reach[c0] >> c1) & 1:
                # (m, 0) ->* (m, 1), so (m, 1) is forced!
                if aff.add_equation(m, 1):
                    changed = True
            elif (reach[c1] >> c0) & 1:
                if aff.add_equation(m, 0):
                    changed = True
        if changed or aff.inconsistent:
            continue

        # Algebraic Triad Closure over active masks:
        # Whenever m1 ^ m2 == m3 with m3 in active_masks:
        # Recall indicator(m, r) = 1 ^ m*x ^ r.
        # Sum of indicators for (m1, r1), (m2, r2), (m3, r3) with m1^m2^m3 == 0 is:
        #   1 ^ r1 ^ r2 ^ r3.
        # Choose r3 = 1 ^ r1 ^ r2 so sum of indicators == 0 (mod 2).
        # If ((m1, r1) OR (m2, r2)) holds (which is true iff ~(m1, r1) ->* (m2, r2) in G_2!),
        # then ~(m3, r3) forces (m1, r1)==(m2, r2), hence BOTH == 1!
        # Thus we get binary clauses: ((m3, r3) OR (m1, r1)) and ((m3, r3) OR (m2, r2))!
        if use_triads:
            added_triad = False
            # Also check clauses directly + transitive implications!
            # Checking clauses directly is O(|clauses|): for each clause ((m1,r1),(m2,r2)),
            # m3 = m1 ^ m2. If m3 in active_masks:
            for (m1, r1), (m2, r2) in list(clauses):
                m3 = m1 ^ m2
                if m3 in active_masks:
                    r3 = 1 ^ r1 ^ r2
                    for arm in [(m1, r1), (m2, r2)]:
                        if m3 == arm[0]:
                            if r3 == arm[1]:
                                if aff.add_equation(m3, r3):
                                    changed = True
                        else:
                            pair = tuple(sorted([(m3, r3), arm]))
                            if pair not in clauses:
                                clauses.add(pair)
                                added_triad = True
            # What about transitive implications ~(m1, r1) ->* (m2, r2) in G_2 where m1^m2 in active_masks?
            masks_list = sorted(active_masks)
            for i in range(len(masks_list)):
                m1 = masks_list[i]
                for j in range(i + 1, len(masks_list)):
                    m2 = masks_list[j]
                    m3 = m1 ^ m2
                    if m3 in active_masks:
                        for r1 in (0, 1):
                            c_neg1 = comp_id[(m1, r1 ^ 1)]
                            for r2 in (0, 1):
                                c2 = comp_id[(m2, r2)]
                                if (reach[c_neg1] >> c2) & 1:
                                    # ((m1, r1) OR (m2, r2)) is implied by G_2!
                                    r3 = 1 ^ r1 ^ r2
                                    for arm in [(m1, r1), (m2, r2)]:
                                        pair = tuple(sorted([(m3, r3), arm]))
                                        if pair not in clauses:
                                            clauses.add(pair)
                                            added_triad = True
            if added_triad:
                changed = True

    return clauses

# Quick probe on all 256 subsets of 3-clauses on 3 vars, and random 3-SAT on 4, 5, 6 vars!
if __name__ == '__main__':
    # 1. Verify compilation + fixpoint never falsely declares UNSAT on SAT formulas!
    rng = random.Random(42)
    false_unsat = 0
    undetected_unsat = 0
    undetected_examples = []
    total_sat = 0
    total_unsat = 0

    for trial in range(1000):
        n = rng.randint(1, 5)
        m = rng.randint(0, 18)
        clauses = []
        for _ in range(m):
            k = rng.randint(1, 4)
            c = [rng.choice([-1, 1]) * rng.randint(1, n) for _ in range(k)]
            clauses.append(c)
        gt_sat, gt_asgn = brute_solve(n, clauses)
        aff, bclauses, tot_v = compile_2lincnf(n, clauses)
        rem_clauses = run_2litc_fixpoint(aff, bclauses, use_triads=True)
        if gt_sat:
            total_sat += 1
            if aff.inconsistent:
                false_unsat += 1
                print("SOUNDNESS BUG ON:", n, clauses)
                break
        else:
            total_unsat += 1
            if not aff.inconsistent:
                undetected_unsat += 1
                if len(undetected_examples) < 5:
                    undetected_examples.append((n, clauses, len(rem_clauses)))

    print(f"Random trials: SAT={total_sat}, UNSAT={total_unsat}, false_unsat={false_unsat}, undetected_unsat={undetected_unsat}")
    for ex in undetected_examples:
        print("Undetected UNSAT example:", ex)
