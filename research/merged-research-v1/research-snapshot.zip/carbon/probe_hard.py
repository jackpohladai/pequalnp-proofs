import itertools
import random
from probe_mechanisms import brute_solve, verify_assignment, compile_2lincnf, run_2litc_fixpoint

def gen_php(pigeons, holes):
    # x_{i,j} = (i * holes + j + 1) for i in 0..pigeons-1, j in 0..holes-1
    clauses = []
    # Each pigeon in at least one hole
    for i in range(pigeons):
        clauses.append([i * holes + j + 1 for j in range(holes)])
    # No two pigeons in same hole
    for j in range(holes):
        for i1 in range(pigeons):
            for i2 in range(i1 + 1, pigeons):
                clauses.append([-(i1 * holes + j + 1), -(i2 * holes + j + 1)])
    return pigeons * holes, clauses

def gen_complete_3cnf(n):
    # All 8 * C(n,3) 3-clauses -> UNSAT for n >= 3
    clauses = []
    for comb in itertools.combinations(range(1, n + 1), 3):
        for signs in itertools.product([-1, 1], repeat=3):
            clauses.append([s * v for s, v in zip(signs, comb)])
    return n, clauses

if __name__ == '__main__':
    # Test pure 3-CNFs on n = 3..10
    rng = random.Random(12345)
    for n in [3, 4, 5, 6, 7, 8, 9, 10]:
        sat_cnt = unsat_cnt = undet = false_u = 0
        first_undet = None
        for _ in range(300 if n <= 8 else 100):
            m = int(4.5 * n) + rng.randint(0, n)
            clauses = []
            for _ in range(m):
                vs = rng.sample(range(1, n + 1), 3)
                clauses.append([rng.choice([-1, 1]) * v for v in vs])
            gt_sat, _ = brute_solve(n, clauses)
            aff, bclauses, tot_v = compile_2lincnf(n, clauses)
            rem = run_2litc_fixpoint(aff, bclauses, use_triads=True)
            if gt_sat:
                sat_cnt += 1
                if aff.inconsistent:
                    false_u += 1
            else:
                unsat_cnt += 1
                if not aff.inconsistent:
                    undet += 1
                    if first_undet is None:
                        first_undet = (n, clauses, len(rem))
        print(f"Pure 3-CNF n={n}: SAT={sat_cnt}, UNSAT={unsat_cnt}, false_unsat={false_u}, undetected_unsat={undet}")
        if first_undet:
            print("  First undetected UNSAT:", first_undet[0], "m=", len(first_undet[1]), "rem_bin=", first_undet[2])
            if first_undet[0] <= 5:
                print("  Clauses:", first_undet[1])

    for p, h in [(3, 2), (4, 3), (5, 4)]:
        nv, cl = gen_php(p, h)
        aff, bcl, tv = compile_2lincnf(nv, cl)
        rem = run_2litc_fixpoint(aff, bcl, use_triads=True)
        print(f"PHP({p},{h}) (nvars={nv}, m={len(cl)}): inconsistent={aff.inconsistent}, rem={len(rem)}, pivots={len(aff.basis)}")
