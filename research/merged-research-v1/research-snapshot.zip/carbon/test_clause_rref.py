from probe_mechanisms import brute_solve, AffineSystem, tarjan_scc
from probe_v2 import affine_hull_intersection, mus4
from probe_hard import gen_php
import random

def canonicalize_lin_clause(aff, eqs):
    """Canonicalize a Linear Clause (list of (mask, rhs)) modulo RREF AffineSystem `aff`,
    AND apply Canonical Intra-Clause Pivot Reduction so each leading bit appears at most once!
     Wait: let's check!
    Suppose a clause has equations (m1, r1), (m2, r2), ...
    1. Reduce each (m, r) modulo aff:
       - m == 0, r == 0 -> equation is TRUE -> whole clause is TRUE (return None)
       - m == 0, r == 1 -> equation is FALSE -> drop equation
    2. Deduplicate identical (m, r); if (m, 0) and (m, 1) both appear -> tautology (return None)!
    3. EVEN BETTER: Intra-clause Gaussian/Leading-Bit Canonicalization!
       Remember our Theorem (Canonical x_v-Reduction of Linear Clauses):
       (x_v == l1) OR (x_v == l2)  <==>  (x_v == l1) OR (l1 ^ l2 == 1),
       i.e. (m1*x == r1) OR (m2*x == r2) where m1 and m2 share MSB v:
       m1*x == r1  <==>  x_v == (m1 ^ (1<<v))*x ^ r1
       m2*x == r2  <==>  x_v == (m2 ^ (1<<v))*x ^ r2
       So their disjunction is IDENTICALLY EQUIVALENT to:
         (m1*x == r1) OR ((m1 ^ m2)*x == (r1 ^ r2 ^ 1))!!
       WAIT A SECOND!!
       IF WE ITERATE THAT INSIDE ANY LINEAR CLAUSE (Echelonizing the equations of a single clause!),
       ALL EQUATIONS IN THE CLAUSE GET DISTINCT LEADING BITS (RREF INSIDE EACH CLAUSE)!!
       AND IF TWO EQUATIONS REDUCE TO m=0, r=0 ((m1^m2)==0 and (r1^r2^1)==0, i.e. m1==m2 and r1!=r2),
       IT AUTOMATICALLY DETECTS TAUTOLOGY; IF r1==r2, (0 == 1) DROPS OUT (DEDUPLICATES)!!
       WAIT A SECOND!! CHECK THAT!!
       Does echelonizing the equations INSIDE a single linear clause preserve EXACT truth table?!"""
    # LET'S VERIFY THIS INCREDIBLE ALGEBRAIC IDENTITY!
    # Claim: For ANY two equations E1: (m1*x == r1) and E2: (m2*x == r2) OVER GF(2):
    # Wait: earlier we proved:
    #   (x_v == l1) OR (x_v == l2)  <==>  (x_v == l1) OR (l1 ^ l2 == 1)
    # ONLY BECAUSE x_v in {0, 1} IS A SINGLE BIT — WAIT:
    # Let A = m1*x ^ r1 in {0, 1}, and B = m2*x ^ r2 in {0, 1}!
    # Notice E1 holds iff A == 0, and E2 holds iff B == 0!
    # DOES NOT EVEN DEPEND ON x_v!!
    # CHECK FOR ANY A, B IN {0, 1}:
    # LHS: (A == 0) OR (B == 0)
    # RHS: (A == 0) OR (A ^ B == 1)!!
    # TEST ALL 4 CASES OF (A, B) IN {0,1}^2:
    # - A=0, B=0: LHS = True;  RHS = (0==0) OR (0==1) = True!
    # - A=0, B=1: LHS = True;  RHS = (0==0) OR (1==1) = True!
    # - A=1, B=0: LHS = True;  RHS = (1==0) OR (1==1) = True!
    # - A=1, B=1: LHS = False; RHS = (1==0) OR (0==1) = False!
    # WHAT?!?!?!
    # OVER GF(2), FOR **ANY** TWO LINEAR EQUATIONS E1, E2 (EVEN WITHOUT A SHARED VARIABLE!),
    # (m1*x == r1) OR (m2*x == r2)  <==>  (m1*x == r1) OR ((m1 ^ m2)*x == (r1 ^ r2 ^ 1))!!
    pivs = {}  # msb -> (m, r)
    for m0, r0 in eqs:
        m, r = aff.reduce_form(m0, r0)
        while m != 0:
            p = m.bit_length() - 1
            if p not in pivs:
                pivs[p] = (m, r)
                break
            pm, pr = pivs[p]
            # Replace current (m, r) using (pm*x == pr) OR (m*x == r) <==> (pm*x == pr) OR ((pm^m)*x == pr^r^1)
            m ^= pm
            r ^= pr ^ 1
        else:
            # m == 0!
            if r == 0:
                # 0 == 0 is TRUE -> entire disjunction is TRUE!
                return None
            # r == 1 -> 0 == 1 is FALSE -> drop!
    # Also do upward elimination so every linear clause has a UNIQUE CANONICAL RREF NORMAL FORM?!
    # WAIT A SECOND!! CHECK UPWARD ELIMINATION TOO!!
    # If p1 > p2 are both pivots in `pivs`, replacing pivs[p1] = (m1, r1) with (m1 ^ m2, r1 ^ r2 ^ 1)
    # ALSO preserves (E1 OR E2) <==> (E1' OR E2)!!
    # THAT MEANS EVERY LINEAR CLAUSE OF WIDTH k IS EQUIVALENT TO A **UNIQUE** (k-DIMENSIONAL AFFINE COSUBSPACE) RREF BASIS!!
    keys = sorted(pivs.keys())
    for idx, p_low in enumerate(keys):
        ml, rl = pivs[p_low]
        for p_high in keys[idx + 1:]:
            mh, rh = pivs[p_high]
            if (mh >> p_low) & 1:
                pivs[p_high] = (mh ^ ml, rh ^ rl ^ 1)
    return tuple(pivs[p] for p in sorted(pivs.keys(), reverse=True))

# STOP AND TEST THAT RIGHT NOW AGAINST BRUTE FORCE ON 10,000 RANDOM LINEAR CLAUSES!!
rng = random.Random(999)
for _ in range(2000):
    n = 5
    aff = AffineSystem()
    # Add 1 random affine eq
    aff.add_equation(rng.randint(1, 31), rng.randint(0, 1))
    k = rng.randint(1, 5)
    eqs = [(rng.randint(0, 31), rng.randint(0, 1)) for _ in range(k)]
    canon = canonicalize_lin_clause(aff, eqs)
    for x in range(32):
        # Check if x satisfies aff
        if any(((bm & x).bit_count() & 1) != br for bm, br in aff.basis.values()):
            continue
        orig_val = any(((m & x).bit_count() & 1) == r for m, r in eqs)
        canon_val = True if canon is None else any(((m & x).bit_count() & 1) == r for m, r in canon)
        assert orig_val == canon_val, f"MISMATCH! eqs={eqs}, canon={canon}, x={x}"

print("2,000 random Linear Clause RREF Canonicalizations verified 100% IDENTICAL on all 2^5 points!!")
