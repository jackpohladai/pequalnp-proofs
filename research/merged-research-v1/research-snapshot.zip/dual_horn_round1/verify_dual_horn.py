"""Independent exhaustive/small finite semantic checks; no candidate imports."""
import hashlib
import itertools
import json
from pathlib import Path


def clause_value(clause, assignment):
    return any(bool((assignment >> (abs(literal)-1)) & 1) == (literal > 0)
               for literal in clause)


def formula_value(formula, assignment):
    return all(clause_value(clause, assignment) for clause in formula)


def leq(a, b):
    return (a & b) == a


def clauses(n):
    return [tuple(sign * (i+1) for i, sign in enumerate(signs) if sign)
            for signs in itertools.product((0, 1, -1), repeat=n)
            if sum(sign == -1 for sign in signs) <= 1]


def main():
    checked, satisfiable, join_checks = 0, 0, 0
    for n in range(4):
        options = clauses(n)
        families = (itertools.combinations(options, r) for r in
                    (range(len(options)+1) if n <= 2 else range(5)))
        for family in families:
            for formula in family:
                models = [a for a in range(1 << n) if formula_value(formula, a)]
                model_set = set(models)
                for a in models:
                    for b in models:
                        assert (a | b) in model_set
                        join_checks += 1
                if models:
                    greatest = 0
                    for a in models:
                        greatest |= a
                    assert greatest in model_set
                    assert all(leq(a, greatest) for a in models)
                    satisfiable += 1
                checked += 1
    guard_checks = 0
    for mask in range(8):
        guard = tuple(i+1 for i in range(3) if (mask >> i) & 1)
        for a in range(8):
            for b in range(8):
                if leq(a, b):
                    assert not clause_value(guard, a) or clause_value(guard, b)
                    guard_checks += 1
    # The two-negative clause excludes the OR of two of its models.
    assert clause_value((-1, -2), 1) and clause_value((-1, -2), 2)
    assert not clause_value((-1, -2), 3)
    print(json.dumps(dict(status='passed', source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                         dual_horn_formulas=checked, satisfiable_formulas=satisfiable,
                         model_pair_join_checks=join_checks, positive_guard_order_checks=guard_checks,
                         all_cnf_subsets_through_variables=2,
                         three_variable_cnf_max_clauses=4,
                         two_negative_counterexample_checked=True,
                         candidate_executed=False, runtime_proof=False, general_sat_claim=False)))


if __name__ == '__main__':
    main()
