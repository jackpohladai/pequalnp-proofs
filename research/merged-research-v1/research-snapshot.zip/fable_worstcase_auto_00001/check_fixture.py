from pathlib import Path
import sys,json,time
p=Path(__file__).resolve().parent;sys.path.insert(0,str(p.parent/'neon_antigravity_round4_review'))
from check_scc_and_growth import run_plus,models,variables
def emra(f,order):
 result=run_plus(f,order);result['max_states']=result['peak'];return result
s=time.time();data=json.loads((p/'structured-output.json').read_text());f=data.get('fixture')
if f is None:r={'status':'no_fixture','summary':'Fable returned a mathematical draft without a finite fixture. Its claims remain unverified.'}
else:
 cnf=f['formula'];order=f['order'];assert isinstance(cnf,list) and len(cnf)<=100 and all(isinstance(c,list) and len(c)<=12 and all(type(l)is int and 1<=abs(l)<=12 for l in c) for c in cnf)
 vs=variables(cnf);assert isinstance(order,list) and len(order)==len(set(order)) and sorted(order)==vs and all(type(v)is int for v in order)
 assert type(f['predicted_sat'])is bool and type(f['predicted_peak'])is int
 truth=bool(models(cnf,vs));observed=emra(cnf,order);match=observed['sat']==truth==f['predicted_sat'] and observed['max_states']==f['predicted_peak']
 r={'status':'fixture_predictions_match' if match else 'fixture_prediction_failed','summary':'Fable finite fixture '+('matched' if match else 'did not match')+' its predictions. This does not verify its general theorem.','oracle_sat':truth,'observed':observed,'predicted_sat':f['predicted_sat'],'predicted_peak':f['predicted_peak']}
r.update(elapsed_seconds=time.time()-s,general_polynomial_sat_proof=False,solver='scc_emra')
(p/'test-receipt.json').write_text(json.dumps(r,indent=2));print(json.dumps(r))
