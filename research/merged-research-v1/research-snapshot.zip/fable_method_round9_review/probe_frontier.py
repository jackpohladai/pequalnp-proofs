import sys,itertools as it,random,json,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'fable_synthesis_round8_review'))
from test_elim import *
rng=random.Random(261126);s=time.time();cases=0;hit=None;timeouts=False
for i in range(1500):
 n=6+i%4;cs=[tuple(z*v for z,v in zip(signs,vs)) for k in [2,3] for vs in it.combinations(range(1,n+1),k) for signs in it.product((-1,1),repeat=k)]
 f=rng.sample(cs,rng.randint(2*n,6*n));order=list(range(1,n+1));rng.shuffle(order)
 a=mra(f,order,True);g=canon(f)
 if g is None or not g or all(len(c)<=2 for c in g):plain_peak=0
 else:plain_peak=max([1]+[v['post_prune'] for v in a['layers']])
 e=emra(f,order);cases+=1
 if e['max_states']>plain_peak:
  hit={'formula':f,'order':order,'plain_peak':plain_peak,'emra':e};break
 if time.time()-s>35:timeouts=True;break
out={'tested_formulas':cases,'finite_counterexample':hit,'elapsed_seconds':time.time()-s,'time_budget_reached':timeouts,'scope':'Finite random frontier probe only; absence of a counterexample is not evidence of a universal bound.'}
Path(__file__).with_name('frontier-probe-receipt.json').write_text(json.dumps(out,indent=2));print(json.dumps(out))
