import sys,itertools as it,json,time,random
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'fable_synthesis_round8_review'))
from test_elim import *

def stream_trial(f,v,reverse=False):
 pos=sorted(c for c in f if v in c);neg=sorted(c for c in f if -v in c)
 pairs=it.product(list(reversed(pos)),list(reversed(neg))) if reverse else it.product(pos,neg)
 live={frozenset(c) for c in f if v not in c and -v not in c};peak=len(live)
 for c,d in pairs:
  r=(set(c)-{v})|(set(d)-{-v})
  if any(-x in r for x in r):continue
  r=frozenset(r)
  if any(s<=r for s in live):continue
  live={s for s in live if not r<s};live.add(r);peak=max(peak,len(live))
  if len(live)>len(f):return {'abort':True,'peak':peak,'formula':None}
 return {'abort':False,'peak':peak,'formula':canon([tuple(sorted(c)) for c in live])}

def all_sat(f):
 if f is None:return (False,0,1)
 if not variables(f):return (True,0,1)
 children=[g for v in variables(f) for g,ok,r in [attempt(f,v)] if ok]
 if not children:return (False,1,1)
 cs=[all_sat(g) for g in children];return all(c[0] for c in cs),sum(c[1] for c in cs),sum(c[2] for c in cs)

def main():
 start=time.time();f=canon([(1,2),(1,3),(-1,4),(-1,5),(-1,6),(2,4,6)])
 h,ok,r=attempt(f,1);rows=[stream_trial(f,1,rev) for rev in [False,True]];e=elim(h);a=reconstruct([(1,r['pos'],r['neg'])]+e['stack'])
 fixture={'original_models':len(models(f,list(range(1,7)))),'residual_models':len(models(h,list(range(2,7)))),'exact_accept':ok,'exact_counts':r,'stream_trials':rows,'continuation_order':[x['variable'] for x in e['steps']],'continuation_counts':[len(f),len(h)]+[x['clauses_after'] for x in e['steps']],'witness':a,'witness_valid':evaluates(f,a),'all_choices':all_sat(f)}
 regressions=[]
 for n in range(2,13):
  e=elim(family(n));g=canon(family(n));abort=0;mismatch=0
  for step in e['steps']:
   v=step['variable'];expected,ok,r=attempt(g,v);trial=stream_trial(g,v)
   abort+=trial['abort'];mismatch+=not trial['abort'] and trial['formula']!=expected;g=expected
  regressions.append({'n':n,'false_abort_on_exact_accepted_trace':abort,'accepted_residual_mismatches':mismatch})
 rng=random.Random(9262026);trials=0;accepted=0;false_rejections=0;mismatches=[];bounds=[];false_rejection_example=None
 for i in range(800):
  n=4+i%3;cs=[tuple(s*v for s,v in zip(signs,vs)) for vs in it.combinations(range(1,n+1),3) for signs in it.product((-1,1),repeat=3)]
  g=canon(rng.sample(cs,min(len(cs),rng.randint(n,6*n))))
  if g is None:continue
  for v in variables(g):
   exact,ok,r=attempt(g,v);z=stream_trial(g,v);trials+=1
   if z['peak']>len(g)+1:bounds.append((g,v))
   if z['abort']:
    false_rejections+=ok
    if ok and false_rejection_example is None:false_rejection_example={'formula':g,'variable':v,'stream_peak':z['peak'],'exact_clauses':len(exact or [()])}
   else:
    accepted+=1
    if exact!=z['formula']:mismatches.append((g,v,exact,z['formula']))
 out={'fixture':fixture,'family_regressions':regressions,'random_trials':trials,'stream_completed':accepted,'exact_accepted_but_stream_aborted':false_rejections,'accepted_residual_mismatches':len(mismatches),'live_count_bound_violations':len(bounds),'false_rejection_example':false_rejection_example,'counterexample':mismatches[:1],'elapsed_seconds':time.time()-start,'scope':'Streaming-trial component only, not a fully formalized solver or a polynomial total-state bound. Memory excludes parent input, reconstruction histories and Python object overhead.'}
 Path(__file__).with_name('test-receipt.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
if __name__=='__main__':main()
