"""Trusted automatic checker, copied beside a pinned ialh_target.py per job."""
import itertools as it
import hashlib
import json
from pathlib import Path
import time

from ialh_target import VERSION, run_counting, source_hash, variables
from check_scc_and_growth import run_plus


def oracle(formula, vs):
    for bits in it.product((False, True), repeat=len(vs)):
        values = dict(zip(vs, bits))
        if all(any(values[abs(l)] == (l > 0) for l in c) for c in formula):
            return True
    return False


def check(data):
    neon = 'verdict' in data
    if neon:
        assert data['verdict'] in ('growth_fixture', 'correctness_fixture', 'no_fixture')
    fixture = data if neon and data['verdict'] != 'no_fixture' else data.get('fixture')
    if fixture is None:
        return dict(status='no_fixture', summary='Mathematical proposal saved without a finite fixture; its claims remain unverified.')
    f, order = fixture['formula'], fixture['order']
    assert isinstance(f, list) and len(f) <= 200
    assert all(isinstance(c, list) and len(c) <= 12 and all(type(l) is int and 1 <= abs(l) <= 12 for l in c) for c in f)
    vs = variables(f)
    assert isinstance(order, list) and len(order) == len(set(order)) and sorted(order) == vs
    assert all(type(v) is int for v in order)
    truth = oracle(f, vs)
    began = time.monotonic()
    baseline = run_plus(f, order)
    baseline_seconds = time.monotonic() - began
    began = time.monotonic()
    observed = run_counting(f, order)
    updated_seconds = time.monotonic() - began
    if observed['sat'] != truth:
        status = 'confirmed_correctness_failure'
        summary = 'Implementation correctness failure: the updated solver disagrees with the exhaustive SAT oracle. Stop promotion of this implementation.'
    elif neon:
        confirmed = data['verdict'] == 'growth_fixture' and not truth and observed['peak'] >= 4
        status = 'confirmed_finite_growth_fixture' if confirmed else 'not_confirmed'
        summary = ('New counting solver still reaches at least four simultaneous states on this finite UNSAT fixture.' if confirmed
                   else 'The submitted fixture did not break the new counting solver under the requested criterion.')
        summary += ' This is a finite test, not a general complexity result.'
    else:
        assert type(fixture['predicted_sat']) is bool and type(fixture['predicted_peak']) is int
        match = fixture['predicted_sat'] == truth and fixture['predicted_peak'] == observed['peak']
        status = 'fixture_predictions_match' if match else 'fixture_prediction_failed'
        summary = 'Fable finite prediction ' + ('matched' if match else 'failed') + ' on the new counting solver; broader mathematical claims remain unverified.'
    return dict(status=status, summary=summary, oracle_sat=truth, observed=observed,
                baseline=baseline, baseline_seconds=baseline_seconds, updated_seconds=updated_seconds)


if __name__ == '__main__':
    folder = Path(__file__).resolve().parent
    manifest = json.loads((folder / 'implementation-target.json').read_text())
    assert source_hash() == manifest['source_sha256'], 'Pinned solver changed after assignment'
    for relative, digest in manifest['dependencies_sha256'].items():
        assert hashlib.sha256((folder.parent / relative).read_bytes()).hexdigest() == digest, 'Baseline dependency changed after assignment'
    start = time.monotonic()
    result = check(json.loads((folder / 'structured-output.json').read_text()))
    result.update(seconds=time.monotonic() - start, solver=VERSION, source_sha256=source_hash(),
                  general_polynomial_sat_proof=False, implementation_lean_verified=False)
    (folder / 'test-receipt.json').write_text(json.dumps(result, indent=2))
    print(json.dumps(result), flush=True)
