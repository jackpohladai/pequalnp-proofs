import Std.Tactic

namespace CompressionSoundness

-- The certificate rule does not assume that discovery is complete or efficient.
theorem equisat_of_projection {X Y : Type} (f : X → Bool) (g : Y → Bool)
    (project : X → Y) (lift : Y → X)
    (forward : ∀ x, f x = g (project x))
    (rightInverse : ∀ y, project (lift y) = y) :
    (∃ x, f x = true) ↔ (∃ y, g y = true) := by
  constructor
  · rintro ⟨x, hx⟩
    exact ⟨project x, (forward x).symm.trans hx⟩
  · rintro ⟨y, hy⟩
    refine ⟨lift y, ?_⟩
    rw [forward, rightInverse]
    exact hy

def certificateCheck {X Y : Type} [DecidableEq Y] (xs : List X) (ys : List Y)
    (f : X → Bool) (g : Y → Bool) (project : X → Y) (lift : Y → X) : Bool :=
  xs.all (fun x => decide (f x = g (project x))) &&
    ys.all (fun y => decide (project (lift y) = y))

theorem certificateCheck_sound {X Y : Type} [DecidableEq Y]
    (xs : List X) (ys : List Y)
    (completeX : ∀ x, x ∈ xs) (completeY : ∀ y, y ∈ ys)
    (f : X → Bool) (g : Y → Bool) (project : X → Y) (lift : Y → X)
    (checked : certificateCheck xs ys f g project lift = true) :
    (∃ x, f x = true) ↔ (∃ y, g y = true) := by
  have pair := Bool.and_eq_true_iff.mp checked
  apply equisat_of_projection f g project lift
  · intro x
    exact of_decide_eq_true ((List.all_eq_true.mp pair.1) x (completeX x))
  · intro y
    exact of_decide_eq_true ((List.all_eq_true.mp pair.2) y (completeY y))

-- A useful equivalent rule when assignments have irrelevant unused coordinates.
theorem equisat_of_two_maps {X Y : Type} (f : X → Bool) (g : Y → Bool)
    (project : X → Y) (lift : Y → X)
    (forward : ∀ x, f x = g (project x))
    (backward : ∀ y, f (lift y) = g y) :
    (∃ x, f x = true) ↔ (∃ y, g y = true) := by
  constructor
  · rintro ⟨x, hx⟩
    exact ⟨project x, (forward x).symm.trans hx⟩
  · rintro ⟨y, hy⟩
    exact ⟨lift y, (backward y).trans hy⟩

abbrev Assignment := Nat → Bool
abbrev Lit := Bool × Nat
abbrev Clause := List Lit
abbrev CNF := List Clause

def evalLit (l : Lit) (a : Assignment) : Bool := if l.1 then a l.2 else !(a l.2)

def evalClause : Clause → Assignment → Bool
  | [], _ => false
  | l :: ls, a => evalLit l a || evalClause ls a

def evalCNF : CNF → Assignment → Bool
  | [], _ => true
  | c :: cs, a => evalClause c a && evalCNF cs a

theorem evalCNF_append (xs ys : CNF) (a : Assignment) :
    evalCNF (xs ++ ys) a = (evalCNF xs a && evalCNF ys a) := by
  induction xs with
  | nil => simp [evalCNF]
  | cons c cs ih => simp [evalCNF, ih, Bool.and_assoc]

#print axioms equisat_of_projection
#print axioms certificateCheck_sound
#print axioms equisat_of_two_maps

end CompressionSoundness

namespace CompressionInstances
open CompressionSoundness
set_option maxRecDepth 100000
set_option maxHeartbeats 10000000
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false

def candidate_project (a : Assignment) : Assignment := fun i => match i with
  | 0 => ((a 0) ^^ ((a 1) ^^ false))
  | 1 => ((a 4) ^^ ((a 5) ^^ false))
  | 2 => ((a 6) ^^ ((a 7) ^^ false))
  | 3 => ((a 0) ^^ ((a 1) ^^ ((a 2) ^^ ((a 3) ^^ false))))
  | _ => false

def candidate_lift (a : Assignment) : Assignment := fun i => match i with
  | 0 => ((a 0) ^^ false)
  | 1 => false
  | 2 => ((a 0) ^^ ((a 3) ^^ false))
  | 3 => false
  | 4 => ((a 1) ^^ false)
  | 5 => false
  | 6 => ((a 2) ^^ false)
  | 7 => false
  | _ => false

def candidate_b0 : CNF := [[(false, 3), (false, 1), (true, 0), (true, 2)], [(false, 3), (false, 0), (true, 1), (true, 2)], [(false, 2), (false, 1), (true, 0), (true, 3)], [(false, 2), (false, 0), (true, 1), (true, 3)]]
def candidate_q0 : CNF := [[(false, 0), (true, 3)]]
theorem candidate_b0_table (b0 b1 b2 b3 : Bool) : (((!b3) || ((!b1) || (b0 || (b2 || false)))) && (((!b3) || ((!b0) || (b1 || (b2 || false)))) && (((!b2) || ((!b1) || (b0 || (b3 || false)))) && (((!b2) || ((!b0) || (b1 || (b3 || false)))) && true)))) = (((!(b0 ^^ (b1 ^^ false))) || ((b0 ^^ (b1 ^^ (b2 ^^ (b3 ^^ false)))) || false)) && true) := by
  decide +revert
theorem candidate_b0_correct (a : Assignment) : evalCNF candidate_b0 a = evalCNF candidate_q0 (candidate_project a) := by
  exact candidate_b0_table (a 0) (a 1) (a 2) (a 3)

def candidate_b1 : CNF := [[(false, 5), (false, 4), (false, 3), (false, 2), (false, 1), (false, 0)], [(false, 5), (false, 4), (false, 3), (false, 2), (true, 0), (true, 1)], [(false, 5), (false, 4), (false, 3), (false, 1), (true, 0), (true, 2)], [(false, 5), (false, 4), (false, 3), (false, 0), (true, 1), (true, 2)], [(false, 5), (false, 4), (false, 2), (false, 1), (true, 0), (true, 3)], [(false, 5), (false, 4), (false, 2), (false, 0), (true, 1), (true, 3)], [(false, 5), (false, 4), (false, 1), (false, 0), (true, 2), (true, 3)], [(false, 5), (false, 4), (true, 0), (true, 1), (true, 2), (true, 3)], [(false, 3), (false, 2), (false, 1), (false, 0), (true, 4), (true, 5)], [(false, 3), (false, 2), (true, 0), (true, 1), (true, 4), (true, 5)], [(false, 3), (false, 1), (true, 0), (true, 2), (true, 4), (true, 5)], [(false, 3), (false, 0), (true, 1), (true, 2), (true, 4), (true, 5)], [(false, 2), (false, 1), (true, 0), (true, 3), (true, 4), (true, 5)], [(false, 2), (false, 0), (true, 1), (true, 3), (true, 4), (true, 5)], [(false, 1), (false, 0), (true, 2), (true, 3), (true, 4), (true, 5)], [(true, 0), (true, 1), (true, 2), (true, 3), (true, 4), (true, 5)]]
def candidate_q1 : CNF := [[(true, 1), (true, 3)]]
theorem candidate_b1_table (b0 b1 b2 b3 b4 b5 : Bool) : (((!b5) || ((!b4) || ((!b3) || ((!b2) || ((!b1) || ((!b0) || false)))))) && (((!b5) || ((!b4) || ((!b3) || ((!b2) || (b0 || (b1 || false)))))) && (((!b5) || ((!b4) || ((!b3) || ((!b1) || (b0 || (b2 || false)))))) && (((!b5) || ((!b4) || ((!b3) || ((!b0) || (b1 || (b2 || false)))))) && (((!b5) || ((!b4) || ((!b2) || ((!b1) || (b0 || (b3 || false)))))) && (((!b5) || ((!b4) || ((!b2) || ((!b0) || (b1 || (b3 || false)))))) && (((!b5) || ((!b4) || ((!b1) || ((!b0) || (b2 || (b3 || false)))))) && (((!b5) || ((!b4) || (b0 || (b1 || (b2 || (b3 || false)))))) && (((!b3) || ((!b2) || ((!b1) || ((!b0) || (b4 || (b5 || false)))))) && (((!b3) || ((!b2) || (b0 || (b1 || (b4 || (b5 || false)))))) && (((!b3) || ((!b1) || (b0 || (b2 || (b4 || (b5 || false)))))) && (((!b3) || ((!b0) || (b1 || (b2 || (b4 || (b5 || false)))))) && (((!b2) || ((!b1) || (b0 || (b3 || (b4 || (b5 || false)))))) && (((!b2) || ((!b0) || (b1 || (b3 || (b4 || (b5 || false)))))) && (((!b1) || ((!b0) || (b2 || (b3 || (b4 || (b5 || false)))))) && ((b0 || (b1 || (b2 || (b3 || (b4 || (b5 || false)))))) && true)))))))))))))))) = (((b4 ^^ (b5 ^^ false)) || ((b0 ^^ (b1 ^^ (b2 ^^ (b3 ^^ false)))) || false)) && true) := by
  decide +revert
theorem candidate_b1_correct (a : Assignment) : evalCNF candidate_b1 a = evalCNF candidate_q1 (candidate_project a) := by
  exact candidate_b1_table (a 0) (a 1) (a 2) (a 3) (a 4) (a 5)

def candidate_b2 : CNF := [[(false, 7), (false, 6), (false, 3), (false, 2), (false, 1), (true, 0)], [(false, 7), (false, 6), (false, 3), (false, 2), (false, 0), (true, 1)], [(false, 7), (false, 6), (false, 3), (false, 1), (false, 0), (true, 2)], [(false, 7), (false, 6), (false, 3), (true, 0), (true, 1), (true, 2)], [(false, 7), (false, 6), (false, 2), (false, 1), (false, 0), (true, 3)], [(false, 7), (false, 6), (false, 2), (true, 0), (true, 1), (true, 3)], [(false, 7), (false, 6), (false, 1), (true, 0), (true, 2), (true, 3)], [(false, 7), (false, 6), (false, 0), (true, 1), (true, 2), (true, 3)], [(false, 3), (false, 2), (false, 1), (true, 0), (true, 6), (true, 7)], [(false, 3), (false, 2), (false, 0), (true, 1), (true, 6), (true, 7)], [(false, 3), (false, 1), (false, 0), (true, 2), (true, 6), (true, 7)], [(false, 3), (true, 0), (true, 1), (true, 2), (true, 6), (true, 7)], [(false, 2), (false, 1), (false, 0), (true, 3), (true, 6), (true, 7)], [(false, 2), (true, 0), (true, 1), (true, 3), (true, 6), (true, 7)], [(false, 1), (true, 0), (true, 2), (true, 3), (true, 6), (true, 7)], [(false, 0), (true, 1), (true, 2), (true, 3), (true, 6), (true, 7)]]
def candidate_q2 : CNF := [[(true, 2), (false, 3)]]
theorem candidate_b2_table (b0 b1 b2 b3 b4 b5 : Bool) : (((!b5) || ((!b4) || ((!b3) || ((!b2) || ((!b1) || (b0 || false)))))) && (((!b5) || ((!b4) || ((!b3) || ((!b2) || ((!b0) || (b1 || false)))))) && (((!b5) || ((!b4) || ((!b3) || ((!b1) || ((!b0) || (b2 || false)))))) && (((!b5) || ((!b4) || ((!b3) || (b0 || (b1 || (b2 || false)))))) && (((!b5) || ((!b4) || ((!b2) || ((!b1) || ((!b0) || (b3 || false)))))) && (((!b5) || ((!b4) || ((!b2) || (b0 || (b1 || (b3 || false)))))) && (((!b5) || ((!b4) || ((!b1) || (b0 || (b2 || (b3 || false)))))) && (((!b5) || ((!b4) || ((!b0) || (b1 || (b2 || (b3 || false)))))) && (((!b3) || ((!b2) || ((!b1) || (b0 || (b4 || (b5 || false)))))) && (((!b3) || ((!b2) || ((!b0) || (b1 || (b4 || (b5 || false)))))) && (((!b3) || ((!b1) || ((!b0) || (b2 || (b4 || (b5 || false)))))) && (((!b3) || (b0 || (b1 || (b2 || (b4 || (b5 || false)))))) && (((!b2) || ((!b1) || ((!b0) || (b3 || (b4 || (b5 || false)))))) && (((!b2) || (b0 || (b1 || (b3 || (b4 || (b5 || false)))))) && (((!b1) || (b0 || (b2 || (b3 || (b4 || (b5 || false)))))) && (((!b0) || (b1 || (b2 || (b3 || (b4 || (b5 || false)))))) && true)))))))))))))))) = (((b4 ^^ (b5 ^^ false)) || ((!(b0 ^^ (b1 ^^ (b2 ^^ (b3 ^^ false))))) || false)) && true) := by
  decide +revert
theorem candidate_b2_correct (a : Assignment) : evalCNF candidate_b2 a = evalCNF candidate_q2 (candidate_project a) := by
  exact candidate_b2_table (a 0) (a 1) (a 2) (a 3) (a 6) (a 7)

def candidate_b3 : CNF := [[(false, 5), (false, 1), (false, 0), (true, 4)], [(false, 5), (true, 0), (true, 1), (true, 4)], [(false, 4), (false, 1), (false, 0), (true, 5)], [(false, 4), (true, 0), (true, 1), (true, 5)]]
def candidate_q3 : CNF := [[(true, 0), (false, 1)]]
theorem candidate_b3_table (b0 b1 b2 b3 : Bool) : (((!b3) || ((!b1) || ((!b0) || (b2 || false)))) && (((!b3) || (b0 || (b1 || (b2 || false)))) && (((!b2) || ((!b1) || ((!b0) || (b3 || false)))) && (((!b2) || (b0 || (b1 || (b3 || false)))) && true)))) = (((b0 ^^ (b1 ^^ false)) || ((!(b2 ^^ (b3 ^^ false))) || false)) && true) := by
  decide +revert
theorem candidate_b3_correct (a : Assignment) : evalCNF candidate_b3 a = evalCNF candidate_q3 (candidate_project a) := by
  exact candidate_b3_table (a 0) (a 1) (a 4) (a 5)

def candidate_b4 : CNF := [[(false, 7), (false, 1), (true, 0), (true, 6)], [(false, 7), (false, 0), (true, 1), (true, 6)], [(false, 6), (false, 1), (true, 0), (true, 7)], [(false, 6), (false, 0), (true, 1), (true, 7)]]
def candidate_q4 : CNF := [[(false, 0), (false, 2)]]
theorem candidate_b4_table (b0 b1 b2 b3 : Bool) : (((!b3) || ((!b1) || (b0 || (b2 || false)))) && (((!b3) || ((!b0) || (b1 || (b2 || false)))) && (((!b2) || ((!b1) || (b0 || (b3 || false)))) && (((!b2) || ((!b0) || (b1 || (b3 || false)))) && true)))) = (((!(b0 ^^ (b1 ^^ false))) || ((!(b2 ^^ (b3 ^^ false))) || false)) && true) := by
  decide +revert
theorem candidate_b4_correct (a : Assignment) : evalCNF candidate_b4 a = evalCNF candidate_q4 (candidate_project a) := by
  exact candidate_b4_table (a 0) (a 1) (a 6) (a 7)

def candidate_b5 : CNF := [[(false, 7), (false, 5), (false, 4), (true, 6)], [(false, 7), (true, 4), (true, 5), (true, 6)], [(false, 6), (false, 5), (false, 4), (true, 7)], [(false, 6), (true, 4), (true, 5), (true, 7)]]
def candidate_q5 : CNF := [[(true, 1), (false, 2)]]
theorem candidate_b5_table (b0 b1 b2 b3 : Bool) : (((!b3) || ((!b1) || ((!b0) || (b2 || false)))) && (((!b3) || (b0 || (b1 || (b2 || false)))) && (((!b2) || ((!b1) || ((!b0) || (b3 || false)))) && (((!b2) || (b0 || (b1 || (b3 || false)))) && true)))) = (((b0 ^^ (b1 ^^ false)) || ((!(b2 ^^ (b3 ^^ false))) || false)) && true) := by
  decide +revert
theorem candidate_b5_correct (a : Assignment) : evalCNF candidate_b5 a = evalCNF candidate_q5 (candidate_project a) := by
  exact candidate_b5_table (a 4) (a 5) (a 6) (a 7)

def candidate_original : CNF := candidate_b0 ++ candidate_b1 ++ candidate_b2 ++ candidate_b3 ++ candidate_b4 ++ candidate_b5 ++ []
def candidate_quotient : CNF := candidate_q0 ++ candidate_q1 ++ candidate_q2 ++ candidate_q3 ++ candidate_q4 ++ candidate_q5 ++ []
theorem candidate_forward (a : Assignment) : evalCNF candidate_original a = evalCNF candidate_quotient (candidate_project a) := by
  simp only [candidate_original, candidate_quotient, evalCNF_append]
  rw [candidate_b0_correct, candidate_b1_correct, candidate_b2_correct, candidate_b3_correct, candidate_b4_correct, candidate_b5_correct]
  rfl

theorem candidate_inverse0_table (y0 y1 y2 y3 : Bool) : ((y0 ^^ false) ^^ (false ^^ false)) = y0 := by
  decide +revert
theorem candidate_inverse0 (a : Assignment) : candidate_project (candidate_lift a) 0 = a 0 := by
  exact candidate_inverse0_table (a 0) (a 1) (a 2) (a 3)

theorem candidate_inverse1_table (y0 y1 y2 y3 : Bool) : ((y1 ^^ false) ^^ (false ^^ false)) = y1 := by
  decide +revert
theorem candidate_inverse1 (a : Assignment) : candidate_project (candidate_lift a) 1 = a 1 := by
  exact candidate_inverse1_table (a 0) (a 1) (a 2) (a 3)

theorem candidate_inverse2_table (y0 y1 y2 y3 : Bool) : ((y2 ^^ false) ^^ (false ^^ false)) = y2 := by
  decide +revert
theorem candidate_inverse2 (a : Assignment) : candidate_project (candidate_lift a) 2 = a 2 := by
  exact candidate_inverse2_table (a 0) (a 1) (a 2) (a 3)

theorem candidate_inverse3_table (y0 y1 y2 y3 : Bool) : ((y0 ^^ false) ^^ (false ^^ ((y0 ^^ (y3 ^^ false)) ^^ (false ^^ false)))) = y3 := by
  decide +revert
theorem candidate_inverse3 (a : Assignment) : candidate_project (candidate_lift a) 3 = a 3 := by
  exact candidate_inverse3_table (a 0) (a 1) (a 2) (a 3)

theorem candidate_backward (a : Assignment) : evalCNF candidate_original (candidate_lift a) = evalCNF candidate_quotient a := by
  rw [candidate_forward]
  simp only [candidate_quotient, candidate_q0, candidate_q1, candidate_q2, candidate_q3, candidate_q4, candidate_q5, evalCNF_append, evalCNF, evalClause, evalLit, candidate_inverse0, candidate_inverse1, candidate_inverse2, candidate_inverse3]
theorem candidate_equisatisfiable : (∃ a, evalCNF candidate_original a = true) ↔ (∃ b, evalCNF candidate_quotient b = true) :=
  equisat_of_two_maps (evalCNF candidate_original) (evalCNF candidate_quotient) candidate_project candidate_lift candidate_forward candidate_backward
#print axioms candidate_forward
#print axioms candidate_backward
#print axioms candidate_equisatisfiable

end CompressionInstances
