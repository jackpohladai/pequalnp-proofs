"""Reviewer D: instance generators biased towards cardinality / degree-system structure.

Every generator takes a `random.Random` and returns (nvars, clauses) with clauses as lists of
signed non-zero ints. Nothing here imports the code under review.
"""
import itertools


# ----------------------------------------------------------------------------- group encodings
def parity_clauses(members, target):
    """All clauses over `members` expressing XOR(members) == target (target in {0,1})."""
    out = []
    k = len(members)
    for bits in range(1 << k):
        # the clause with negative set N forbids exactly the assignment "N true, rest false"
        if (bin(bits).count("1") & 1) != target:
            out.append([(-v if (bits >> i) & 1 else v) for i, v in enumerate(members)])
    return out


def group_clauses(kind, members, target=0):
    members = list(members)
    out = []
    if kind in ("L", "X") and members:
        out.append(list(members))
    if kind in ("U", "X"):
        for a, b in itertools.combinations(members, 2):
            out.append([-a, -b])
    if kind == "P" and members:
        out.extend(parity_clauses(members, target))
    return out


# ----------------------------------------------------------------------------- post-processing
def decorate(rng, n, clauses, flip_p=0.35, extra_unused=True):
    """Random polarity flips, random renaming into 1..nvars, shuffled clause/literal order."""
    flips = {v: (-1 if rng.random() < flip_p else 1) for v in range(1, n + 1)}
    nvars = n + (rng.randrange(0, 3) if extra_unused else 0)
    names = rng.sample(range(1, nvars + 1), n)
    ren = {v: names[v - 1] for v in range(1, n + 1)}
    out = []
    for c in clauses:
        d = [(1 if l > 0 else -1) * flips[abs(l)] * ren[abs(l)] for l in c]
        rng.shuffle(d)
        out.append(d)
    rng.shuffle(out)
    return nvars, out


# ----------------------------------------------------------------------------- degree systems
def degree_system_raw(rng, max_vars=11, weights="LLLUUUXXXPP", single_p=0.2, max_groups=6):
    """A random read-twice degree system in natural polarity (no decoration)."""
    g = rng.randrange(1, max_groups + 1)
    kinds = [rng.choice(weights) for _ in range(g)]
    n = rng.randrange(2, max_vars + 1)
    members = [[] for _ in range(g)]
    for x in range(1, n + 1):
        if g >= 2 and rng.random() >= single_p:
            a, b = rng.sample(range(g), 2)
            members[a].append(x)
            members[b].append(x)
        else:
            members[rng.randrange(g)].append(x)
    clauses = []
    for kind, mem in zip(kinds, members):
        if kind == "P" and len(mem) > 5:
            kind = rng.choice("LUX")
        clauses.extend(group_clauses(kind, mem, rng.randrange(2)))
    return n, clauses


def degree_system(rng, max_vars=11):
    n, clauses = degree_system_raw(rng, max_vars)
    return decorate(rng, n, clauses)


def graph_degree_system(rng, max_edges=11):
    """Variables = edges of a random multigraph-free graph; every vertex gets a random type.
    Covers perfect matching (all X), Tseitin (all P), PHP-like bipartite systems and mixtures."""
    nv = rng.randrange(2, 8)
    pairs = list(itertools.combinations(range(nv), 2))
    rng.shuffle(pairs)
    edges = pairs[: rng.randrange(1, min(len(pairs), max_edges) + 1)]
    mode = rng.choice(["mixed", "mixed", "allX", "allP", "LU", "XP"])
    clauses = []
    for v in range(nv):
        inc = [i + 1 for i, e in enumerate(edges) if v in e]
        if not inc:
            continue
        if mode == "allX":
            kind = "X"
        elif mode == "allP":
            kind = "P"
        elif mode == "LU":
            kind = rng.choice("LU")
        elif mode == "XP":
            kind = rng.choice("XP")
        else:
            kind = rng.choice("LUXP")
        if kind == "P" and len(inc) > 5:
            kind = "X"
        clauses.extend(group_clauses(kind, inc, rng.randrange(2)))
    return decorate(rng, len(edges), clauses)


def tight_degree_system(rng, max_edges=12):
    """Degree systems on graphs with minimum degree >= 2 (no unit clauses after encoding) and
    types chosen to make UNSAT frequent: mostly X / P vertices, some L / U."""
    for _ in range(200):
        nv = rng.randrange(3, 8)
        pairs = list(itertools.combinations(range(nv), 2))
        rng.shuffle(pairs)
        ne = rng.randrange(nv, min(len(pairs), max_edges) + 1) if nv <= min(len(pairs), max_edges) else 0
        edges = pairs[:ne]
        deg = [sum(1 for e in edges if v in e) for v in range(nv)]
        if ne and all(2 <= d <= 5 for d in deg):
            break
    else:
        return graph_degree_system(rng, max_edges)
    mode = rng.choice(["X", "XU", "XP", "P", "LU", "mixed", "mixed"])
    clauses = []
    for v in range(nv):
        inc = [i + 1 for i, e in enumerate(edges) if v in e]
        kind = {"X": "X", "XU": rng.choice("XXU"), "XP": rng.choice("XP"), "P": "P",
                "LU": rng.choice("LU"), "mixed": rng.choice("LUXXPP")}[mode]
        clauses.extend(group_clauses(kind, inc, rng.randrange(2)))
    return decorate(rng, len(edges), clauses)


def php(rng):
    """Pigeonhole-like bipartite system with random allowed-hole sets."""
    while True:
        p = rng.randrange(2, 6)
        h = rng.randrange(1, 5)
        cells = [(i, j) for i in range(p) for j in range(h) if rng.random() < 0.8]
        if 1 <= len(cells) <= 12:
            break
    idx = {c: k + 1 for k, c in enumerate(cells)}
    clauses = []
    pk = rng.choice("LX")
    hk = rng.choice("UUX")
    for i in range(p):
        mem = [idx[(i, j)] for j in range(h) if (i, j) in idx]
        clauses.extend(group_clauses(pk, mem))
    for j in range(h):
        mem = [idx[(i, j)] for i in range(p) if (i, j) in idx]
        clauses.extend(group_clauses(hk, mem))
    return decorate(rng, len(cells), clauses)


# ----------------------------------------------------------------------------- mutations
def mutate(rng, nvars, clauses, allow_raw=True):
    """Apply 1..3 random structural mutations (the result is in general NOT a degree system)."""
    clauses = [list(c) for c in clauses]
    variables = sorted({abs(l) for c in clauses for l in c}) or [1]
    nvars = max(nvars, 1)
    ops = ["drop", "add_random", "flip_lit", "weaken", "strengthen", "binary", "subclause",
           "merge_vars", "dup_perm", "unit", "wide_dup_var"]
    if allow_raw:
        ops += ["taut", "repeat_lit", "empty", "dup_exact"]
    for _ in range(rng.randrange(1, 4)):
        op = rng.choice(ops)
        if op == "drop" and clauses:
            clauses.pop(rng.randrange(len(clauses)))
        elif op == "add_random":
            k = rng.randrange(1, 5)
            vs = [rng.choice(variables) for _ in range(k)]
            c = sorted(set(vs))
            clauses.append([rng.choice((-1, 1)) * v for v in c])
        elif op == "flip_lit" and clauses:
            c = rng.choice(clauses)
            if c:
                i = rng.randrange(len(c))
                c[i] = -c[i]
        elif op == "weaken" and clauses:
            c = list(rng.choice(clauses))
            c.append(rng.choice((-1, 1)) * rng.choice(variables))
            clauses.append(c)
        elif op == "strengthen" and clauses:
            c = rng.choice(clauses)
            if len(c) >= 2:
                c.pop(rng.randrange(len(c)))
        elif op == "binary":
            a, b = rng.choice(variables), rng.choice(variables)
            clauses.append([rng.choice((-1, 1)) * a, rng.choice((-1, 1)) * b])
        elif op == "subclause" and clauses:
            c = rng.choice(clauses)
            if len(c) >= 3:
                k = rng.randrange(2, len(c))
                clauses.append(rng.sample(c, k))
        elif op == "merge_vars" and len(variables) >= 2:
            a, b = rng.sample(variables, 2)
            sg = rng.choice((-1, 1))
            clauses = [[(sg * (1 if l > 0 else -1) * a if abs(l) == b else l) for l in c]
                       for c in clauses]
        elif op == "dup_perm" and clauses:
            c = list(rng.choice(clauses))
            rng.shuffle(c)
            clauses.append(c)
        elif op == "dup_exact" and clauses:
            clauses.append(list(rng.choice(clauses)))
        elif op == "unit":
            clauses.append([rng.choice((-1, 1)) * rng.choice(variables)])
        elif op == "wide_dup_var" and clauses:
            c = rng.choice(clauses)
            if c:
                c.append(-c[rng.randrange(len(c))] if rng.random() < 0.3 else c[rng.randrange(len(c))])
        elif op == "taut":
            v = rng.choice(variables)
            extra = [rng.choice((-1, 1)) * rng.choice(variables) for _ in range(rng.randrange(0, 3))]
            c = [v, -v] + extra
            rng.shuffle(c)
            clauses.append(c)
        elif op == "repeat_lit" and clauses:
            c = rng.choice(clauses)
            if c:
                c.append(rng.choice(c))
        elif op == "empty":
            if rng.random() < 0.25:
                clauses.append([])
    rng.shuffle(clauses)
    return nvars, clauses


# ----------------------------------------------------------------------------- plain random CNF
def random_cnf(rng, max_vars=11):
    n = rng.randrange(1, max_vars + 1)
    m = rng.randrange(0, 4 * n + 2)
    kmax = rng.choice((2, 3, 3, 4))
    clauses = []
    for _ in range(m):
        k = rng.randrange(1, kmax + 1)
        vs = rng.sample(range(1, n + 1), min(k, n))
        clauses.append([rng.choice((-1, 1)) * v for v in vs])
    return n, clauses


def random_2cnf(rng, max_vars=11):
    n = rng.randrange(2, max_vars + 1)
    m = rng.randrange(1, 3 * n)
    clauses = []
    for _ in range(m):
        vs = rng.sample(range(1, n + 1), rng.choice((1, 2, 2, 2)))
        clauses.append([rng.choice((-1, 1)) * v for v in vs])
    return n, clauses


def random_horn(rng, max_vars=11):
    n = rng.randrange(1, max_vars + 1)
    m = rng.randrange(1, 3 * n + 2)
    dual = rng.random() < 0.5
    clauses = []
    for _ in range(m):
        k = rng.randrange(1, min(4, n) + 1)
        vs = rng.sample(range(1, n + 1), k)
        c = [-v for v in vs]
        if rng.random() < 0.7:
            c[0] = -c[0]
        if dual:
            c = [-l for l in c]
        rng.shuffle(c)
        clauses.append(c)
    return n, clauses


def raw_noise(rng, max_vars=9):
    """Raw interface stress: duplicates, repeated literals, tautologies, empty clause, unused
    variables, nvars = 0."""
    n = rng.randrange(0, max_vars + 1)
    clauses = []
    for _ in range(rng.randrange(0, 3 * n + 3)):
        if n == 0:
            clauses.append([])
            continue
        k = rng.choice((0, 1, 1, 2, 2, 2, 3, 3, 4)) if rng.random() < 0.15 else rng.choice((1, 2, 2, 3, 3, 4))
        c = [rng.choice((-1, 1)) * rng.randrange(1, n + 1) for _ in range(k)]
        clauses.append(c)
        if rng.random() < 0.1:
            d = list(c)
            rng.shuffle(d)
            clauses.append(d)
    if n == 0 and rng.random() < 0.5:
        clauses = []
    return n, clauses


# ----------------------------------------------------------------------------- normalisation
def normalise(clauses):
    """Reviewer's own normaliser: drop tautologies, repeated literals and duplicate clauses.
    Returns (list of tuples, has_empty_clause)."""
    out = []
    seen = set()
    has_empty = False
    for c in clauses:
        s = set(c)
        if any(-l in s for l in s):
            continue
        if not s:
            has_empty = True
            continue
        key = frozenset(s)
        if key in seen:
            continue
        seen.add(key)
        out.append(tuple(sorted(s, key=lambda l: (abs(l), l))))
    return out, has_empty


def components(clauses):
    """Variable-connected components of a clause list (reviewer's own union-find)."""
    parent = {}

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    for c in clauses:
        for l in c:
            parent.setdefault(abs(l), abs(l))
        for l in c[1:]:
            a, b = find(abs(c[0])), find(abs(l))
            if a != b:
                parent[a] = b
    groups = {}
    for c in clauses:
        groups.setdefault(find(abs(c[0])), []).append(c)
    return list(groups.values())
