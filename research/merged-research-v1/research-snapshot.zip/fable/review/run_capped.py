#!/usr/bin/env python3
"""Reviewer D helper: run one command with a hard wall-clock cap and log it with Python I/O.

Usage: python3 -B run_capped.py <log-name> <timeout-seconds> <cwd> <cmd> [args...]
Writes review/logs/<log-name>.log (stdout+stderr) and review/logs/<log-name>.meta.json.
Byte-code writing is disabled for the child so that importing other workers' modules does not
create .pyc files outside review/.
"""
import json
import os
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
LOGS = os.path.join(HERE, "logs")


def main():
    name, timeout, cwd = sys.argv[1], float(sys.argv[2]), sys.argv[3]
    cmd = sys.argv[4:]
    os.makedirs(LOGS, exist_ok=True)
    env = dict(os.environ)
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    t0 = time.time()
    status = "finished"
    try:
        proc = subprocess.run(cmd, cwd=cwd, env=env, stdout=subprocess.PIPE,
                              stderr=subprocess.STDOUT, timeout=timeout)
        out = proc.stdout.decode("utf-8", "replace")
        code = proc.returncode
    except subprocess.TimeoutExpired as exc:
        out = (exc.stdout or b"").decode("utf-8", "replace")
        code = None
        status = "timeout"
    wall = round(time.time() - t0, 2)
    meta = {"cmd": cmd, "cwd": cwd, "status": status, "exit_code": code, "wall_seconds": wall}
    sys.stdout.write(out)
    sys.stdout.write("\n[run_capped] " + json.dumps(meta) + "\n")
    sys.stdout.flush()
    # Python file I/O in this workspace fails intermittently with EPERM; retry the same call.
    for path, text in ((os.path.join(LOGS, name + ".log"), out),
                       (os.path.join(LOGS, name + ".meta.json"), json.dumps(meta, indent=1))):
        for attempt in range(6):
            try:
                with open(path, "w") as fh:
                    fh.write(text)
                break
            except PermissionError as exc:
                sys.stdout.write("[run_capped] write failed (%s), attempt %d\n" % (exc, attempt + 1))
                time.sleep(1.0)


if __name__ == "__main__":
    main()
