#!/usr/bin/env python3
"""Reviewer D: targeted attacks on fable/layers.py (hand cases + fault injection).

Usage: python3 -B attack_layers.py [seconds_for_fault_injection=18]
Writes results/attack_layers.json.
"""
import itertools
import json
import os
import random
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
FABLE = os.path.dirname(HERE)
sys.path.insert(0, HERE)
sys.path.insert(1, FABLE)

import gens      # noqa: E402
import oracle    # noqa: E402
import layers    # noqa: E402


def nv(clauses):
    return max([abs(l) for c in clauses for l in c] or [0])


def amo(vs):
    return [(-a, -b) for a, b in itertools.combinations(vs, 2)]


def describe(clauses, raw=False):
    """Oracle truth + answer of every entry point for one clause list."""
    n = nv(clauses)
    truth = oracle.is_sat(n, clauses)
    out = {"clauses": [list(c) for c in clauses], "oracle": "SAT" if truth else "UNSAT"}
    for name, fn in (("horn", layers.horn_layer), ("twosat", layers.twosat_layer),
                     ("cardinality", layers.cardinality_layer)):
        try:
            r = fn([tuple(c) for c in clauses])
        except Exception as exc:
            out[name] = "EXC " + type(exc).__name__
            continue
        if r is None:
            out[name] = None
        else:
            ok = True
            if r[0] == "SAT":
                try:
                    ok = oracle.satisfies(r[1], clauses)
                except KeyError:
                    ok = False
            out[name] = r[0] + ("" if ok else " (MODEL DOES NOT SATISFY)")
            if (r[0] == "SAT") != truth:
                out[name] += "  <<< WRONG"
    verdict, residual, values, log = layers.island_stage(n, [list(c) for c in clauses])
    if verdict == "UNSAT":
        out["island_stage"] = "UNSAT via %s" % (log["unsat"] if isinstance(log["unsat"], str) else log["unsat"]["layer"])
        if truth:
            out["island_stage"] += "  <<< WRONG"
    else:
        rsat = oracle.is_sat(n, residual)
        out["island_stage"] = "open: %d residual clauses, islands=%s" % (len(residual), log["islands"])
        if rsat != truth:
            out["island_stage"] += "  <<< NOT EQUISATISFIABLE"
        vtt = oracle.values_tt(n, values)
        if (oracle.formula_tt(n, residual) & vtt) & ~oracle.formula_tt(n, clauses):
            out["island_stage"] += "  <<< JOIN FAILS"
    return out


def hand_cases():
    cases = {}
    # (a) groups sharing two or more variables
    cases["X_X_share_two"] = [(1, 2, 3)] + amo([1, 2, 3]) + [(1, 2, 4)] + amo([1, 2, 4])
    cases["L_L_share_two"] = [(1, 2, 3), (1, 2, 4), (-3, -4)]
    cases["L_L_share_all_duplicate_as_permutation"] = [(1, 2, 3), (3, 2, 1), (-1, -2)]
    cases["P_P_share_two"] = gens.parity_clauses([1, 2, 3], 1) + gens.parity_clauses([1, 2, 4], 0)
    cases["P_P_share_all_contradictory"] = gens.parity_clauses([1, 2, 3], 1) + gens.parity_clauses([1, 2, 3], 0)
    cases["X_U_share_two"] = [(1, 2, 5)] + amo([1, 2, 5]) + amo([1, 2, 3]) + [(3, 4, 6)]
    # (b) positive clause that is a conflict clique inside a larger clique
    cases["pos_clique_inside_larger_clique"] = [(1, 2)] + amo([1, 2, 3]) + [(3, 4, 5)]
    cases["pos_clique_inside_larger_clique_forced"] = [(1, 2)] + amo([1, 2, 3]) + [(3, 4, 5), (-4, -5), (3, 4), (3, 5)]
    cases["two_nested_X"] = [(1, 2), (1, 2, 3)] + amo([1, 2, 3]) + [(3, 4, 5), (-4, -5)]
    # (c) variables in exactly one group
    cases["all_private"] = [(1, 2, 3)] + amo([4, 5, 6]) + [(4, 5, 6)]
    cases["private_in_P"] = gens.parity_clauses([1, 2, 3], 1) + gens.parity_clauses([4, 5, 6], 0)
    # (d) polarity-flipped variables: U triangle written positively, hanging off parity groups
    cases["flipped_U_triangle_on_parity"] = ([(1, 2), (2, 3), (1, 3)]
                                              + gens.parity_clauses([1, 4, 5], 1)
                                              + gens.parity_clauses([2, 6, 7], 0)
                                              + gens.parity_clauses([3, 8, 9], 1))
    cases["natural_U_triangle_on_parity"] = (amo([1, 2, 3])
                                              + gens.parity_clauses([1, 4, 5], 1)
                                              + gens.parity_clauses([2, 6, 7], 0)
                                              + gens.parity_clauses([3, 8, 9], 1))
    # (e) duplicated / subsumed clauses
    php32 = [(1, 2), (3, 4), (5, 6)] + amo([1, 3, 5]) + amo([2, 4, 6])
    php43 = [(1, 2, 3), (4, 5, 6), (7, 8, 9), (10, 11, 12)] + amo([1, 4, 7, 10]) + amo([2, 5, 8, 11]) + amo([3, 6, 9, 12])
    cases["php_4_3"] = php43
    cases["php_4_3_plus_subsumed"] = php43 + [(1, 2, 3, 4)]
    cases["php_4_3_plus_duplicate_perm"] = php43 + [(3, 2, 1)]
    cases["php_4_3_plus_redundant_pair"] = php43 + [(-1, -5)]
    cases["php_3_2_all_binary"] = php32
    # (f) components that are also 2-CNF / Horn (direct call to the cardinality layer)
    cases["two_cnf_xor_chain_unsat"] = [(1, 2), (-1, -2), (2, 3), (-2, -3), (1, 3), (-1, -3)]
    cases["horn_only_amo"] = amo([1, 2, 3, 4])
    cases["dual_horn_only_positive"] = [(1, 2, 3), (3, 4, 5)]
    # (g) unit clauses
    cases["unit_inside"] = [(1,), (1, 2, 3), (-2, -3)]
    cases["pseudo_unit_repeated_literal"] = [(1, 1), (1, 2, 3), (-2, -3)]
    cases["negative_pseudo_unit"] = [(-1, -1), (1, 2, 3), (-2, -3)]
    # recognisable per the DEFINITION of Section 6 but with an ambiguous X / (L + U) reading
    cases["L_ab_plus_U_abc_plus_L_cde"] = [(1, 2)] + amo([1, 2, 3]) + [(3, 4, 5)]
    # exactly-one on 2 vars in both polarities (equivalence cycle), plus a wide clause
    cases["equivalence_triangle_with_wide"] = [(1, -2), (-1, 2), (2, -3), (-2, 3), (1, 2, 3), (-1, -2, -3)]
    # perfect matching on K4 minus nothing (SAT), on a triangle (UNSAT), on K5 (UNSAT)
    def pm(nvert, edges):
        cl = []
        for v in range(nvert):
            inc = [i + 1 for i, e in enumerate(edges) if v in e]
            cl += [tuple(inc)] + amo(inc)
        return cl
    k4 = list(itertools.combinations(range(4), 2))
    k5 = list(itertools.combinations(range(5), 2))
    cases["perfect_matching_K4"] = pm(4, k4)
    cases["perfect_matching_K5"] = pm(5, k5)
    cases["perfect_matching_triangle"] = pm(3, [(0, 1), (1, 2), (0, 2)])
    # Tseitin on K4 with odd / even total charge
    cases["tseitin_K4_odd"] = sum((gens.parity_clauses([i + 1 for i, e in enumerate(k4) if v in e], 1 if v == 0 else 0)
                                   for v in range(4)), [])
    cases["tseitin_K4_even"] = sum((gens.parity_clauses([i + 1 for i, e in enumerate(k4) if v in e], 0)
                                    for v in range(4)), [])
    # precondition violations (documented contract: normalised, no empty clause)
    cases["RAW_empty_clause_only"] = [()]
    cases["RAW_empty_clause_plus_exactly_one"] = [(1, 2, 3)] + amo([1, 2, 3]) + [()]
    cases["RAW_tautology_inside"] = [(1, -1, 2), (1, 2, 3), (-2, -3)]
    return {k: describe(v) for k, v in cases.items()}


# ----------------------------------------------------------------------------- fault injection
def fault_injection(seconds, seed=777):
    """Replace the matching / barrier code by broken versions (in this process only) and check
    that UNSAT answers stay correct, as Section 6 ('What is trusted where') claims."""
    rng = random.Random(seed)
    real_mm = layers.max_matching
    real_tb = layers.tutte_berge_barrier

    def mm_drop_edge(n, adj, tick=layers._no_tick):
        m = real_mm(n, adj, tick)
        vs = [v for v in range(n) if m[v] != -1]
        if vs:
            v = rng.choice(vs)
            u = m[v]
            m[v] = -1
            m[u] = -1
        return m

    def mm_empty(n, adj, tick=layers._no_tick):
        return [-1] * n

    def mm_greedy(n, adj, tick=layers._no_tick):
        m = [-1] * n
        for v in range(n):
            if m[v] == -1:
                for u in adj[v]:
                    if m[u] == -1:
                        m[v] = u
                        m[u] = v
                        break
        return m

    def mm_garbage_perfect(n, adj, tick=layers._no_tick):
        # claims every vertex is matched to a random neighbour (not a matching at all)
        return [(rng.choice(adj[v]) if adj[v] else v) for v in range(n)]

    def tb_random(n, adj, match, tick=layers._no_tick, slow=False):
        return {v for v in range(n) if rng.random() < rng.choice((0.0, 0.1, 0.3, 0.6))}

    def tb_empty(n, adj, match, tick=layers._no_tick, slow=False):
        return set()

    def tb_all(n, adj, match, tick=layers._no_tick, slow=False):
        return set(range(n))

    faults = {
        "matching_drops_one_edge": (mm_drop_edge, real_tb),
        "matching_empty": (mm_empty, real_tb),
        "matching_greedy_only": (mm_greedy, real_tb),
        "matching_garbage_perfect": (mm_garbage_perfect, real_tb),
        "barrier_random_set": (real_mm, tb_random),
        "barrier_empty_set": (real_mm, tb_empty),
        "barrier_all_vertices": (real_mm, tb_all),
        "matching_drop_and_barrier_random": (mm_drop_edge, tb_random),
    }
    stats = {name: {"cases": 0, "layer_none": 0, "layer_sat": 0, "layer_unsat": 0,
                    "layer_wrong_unsat": 0, "layer_wrong_sat": 0, "layer_bad_model": 0,
                    "island_wrong_unsat": 0, "island_equisat_fail": 0, "island_join_fail": 0,
                    "exceptions": 0} for name in faults}
    examples = []
    t0 = time.time()
    names = list(faults)
    try:
        while time.time() - t0 < seconds:
            gen = rng.choice((gens.tight_degree_system, gens.tight_degree_system, gens.graph_degree_system,
                              gens.degree_system, gens.php))
            n, clauses = gen(rng)
            norm, has_empty = gens.normalise(clauses)
            if has_empty or not norm:
                continue
            truth = oracle.is_sat(n, norm)
            name = rng.choice(names)
            layers.max_matching, layers.tutte_berge_barrier = faults[name]
            st = stats[name]
            st["cases"] += 1
            try:
                r = layers.cardinality_layer(list(norm))
            except Exception:
                st["exceptions"] += 1
                r = None
            if r is None:
                st["layer_none"] += 1
            elif r[0] == "UNSAT":
                st["layer_unsat"] += 1
                if truth:
                    st["layer_wrong_unsat"] += 1
                    examples.append({"fault": name, "kind": "layer_wrong_unsat", "nvars": n, "clauses": [list(c) for c in norm]})
            else:
                st["layer_sat"] += 1
                if not truth:
                    st["layer_wrong_sat"] += 1
                else:
                    try:
                        if not oracle.satisfies(r[1], norm):
                            st["layer_bad_model"] += 1
                    except KeyError:
                        st["layer_bad_model"] += 1
            try:
                verdict, residual, values, log = layers.island_stage(n, [list(c) for c in clauses])
            except Exception:
                st["exceptions"] += 1
                continue
            tt = oracle.formula_tt(n, clauses)
            if verdict == "UNSAT":
                if tt:
                    st["island_wrong_unsat"] += 1
                    examples.append({"fault": name, "kind": "island_wrong_unsat", "nvars": n, "clauses": clauses})
            else:
                rtt = oracle.formula_tt(n, residual)
                if bool(rtt) != bool(tt):
                    st["island_equisat_fail"] += 1
                    examples.append({"fault": name, "kind": "island_equisat_fail", "nvars": n, "clauses": clauses})
                elif (rtt & oracle.values_tt(n, values)) & ~tt:
                    st["island_join_fail"] += 1
                    examples.append({"fault": name, "kind": "island_join_fail", "nvars": n, "clauses": clauses})
    finally:
        layers.max_matching, layers.tutte_berge_barrier = real_mm, real_tb
    return {"seconds": round(time.time() - t0, 2), "stats": stats, "examples": examples[:20]}


def main():
    seconds = float(sys.argv[1]) if len(sys.argv) > 1 else 18.0
    out = {"hand_cases": hand_cases()}
    wrong = {k: v for k, v in out["hand_cases"].items() if "<<<" in json.dumps(v)}
    out["hand_cases_with_wrong_or_broken_answers"] = sorted(wrong)
    out["fault_injection"] = fault_injection(seconds)
    os.makedirs(os.path.join(HERE, "results"), exist_ok=True)
    with open(os.path.join(HERE, "results", "attack_layers.json"), "w") as fh:
        json.dump(out, fh, indent=1)
    for k, v in out["hand_cases"].items():
        print("%-45s oracle=%-5s horn=%-6s twosat=%-6s card=%-28s island=%s"
              % (k, v["oracle"], v["horn"], v["twosat"], v["cardinality"], v["island_stage"]))
    print("WRONG/BROKEN hand cases:", out["hand_cases_with_wrong_or_broken_answers"])
    print(json.dumps(out["fault_injection"]["stats"], indent=1))
    print("fault-injection examples:", len(out["fault_injection"]["examples"]))


if __name__ == "__main__":
    main()
