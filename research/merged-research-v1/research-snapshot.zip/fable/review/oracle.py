"""Reviewer D: independent exhaustive SAT oracle (written from scratch for this review).

Truth-table oracle: the truth table of a formula over variables 1..n is a Python integer with
2**n bits; bit number `a` is the value of the formula under the assignment in which variable
i (1-based) is True iff bit (i-1) of `a` is set. Exhaustive, no search heuristics, no pruning.

`naive_sat` is a second, even simpler oracle (explicit loop over all assignments) used to
cross-check the truth-table code.
"""

_VAR_TT_CACHE = {}


def var_tt(n, i):
    """Truth table of variable i (1-based) over n variables."""
    key = (n, i)
    t = _VAR_TT_CACHE.get(key)
    if t is None:
        half = 1 << (i - 1)
        t = ((1 << half) - 1) << half                # 'half' zeros then 'half' ones
        length = 2 * half
        while length < (1 << n):                     # repeat the block by doubling
            t |= t << length
            length *= 2
        _VAR_TT_CACHE[key] = t
    return t


def full_tt(n):
    return (1 << (1 << n)) - 1


def clause_tt(n, clause):
    full = full_tt(n)
    t = 0
    for l in clause:
        v = abs(l)
        if v < 1 or v > n:
            raise ValueError("literal %r outside 1..%d" % (l, n))
        vt = var_tt(n, v)
        t |= vt if l > 0 else (full & ~vt)
    return t


def formula_tt(n, clauses):
    t = full_tt(n)
    for c in clauses:
        t &= clause_tt(n, c)
        if not t:
            return 0
    return t


def is_sat(n, clauses):
    return formula_tt(n, clauses) != 0


def first_model(n, clauses):
    """A model as a list of bools of length n, or None."""
    t = formula_tt(n, clauses)
    if not t:
        return None
    a = (t & -t).bit_length() - 1
    return [bool((a >> i) & 1) for i in range(n)]


def count_models(n, clauses):
    return bin(formula_tt(n, clauses)).count("1")


def satisfies(assignment, clauses):
    """assignment: list of bools indexed by var-1, or dict var -> bool."""
    if isinstance(assignment, dict):
        get = lambda v: assignment[v]
    else:
        get = lambda v: assignment[v - 1]
    return all(any(get(abs(l)) == (l > 0) for l in c) for c in clauses)


def naive_sat(n, clauses):
    for a in range(1 << n):
        ok = True
        for c in clauses:
            for l in c:
                if (((a >> (abs(l) - 1)) & 1) == 1) == (l > 0):
                    break
            else:
                ok = False
                break
        if ok:
            return True
    return False


def values_tt(n, values):
    """Truth table of the cube given by a dict var -> bool."""
    full = full_tt(n)
    t = full
    for v, b in values.items():
        vt = var_tt(n, v)
        t &= vt if b else (full & ~vt)
    return t


def self_test(rounds=400, seed=20261126):
    import random
    rng = random.Random(seed)
    for _ in range(rounds):
        n = rng.randrange(0, 8)
        clauses = []
        for _ in range(rng.randrange(0, 12)):
            k = rng.randrange(0, 4)
            clauses.append([rng.choice((-1, 1)) * rng.randrange(1, n + 1) for _ in range(k)] if n else [])
        a = is_sat(n, clauses)
        b = naive_sat(n, clauses)
        assert a == b, (n, clauses, a, b)
        m = first_model(n, clauses)
        assert (m is not None) == a
        if m is not None:
            assert satisfies(m, clauses)
    return rounds


if __name__ == "__main__":
    print("oracle self-test rounds:", self_test())
