#!/usr/bin/env python3
"""Reviewer D: re-compile one Lean file with `lake env lean <file>` (never `lake build`).

Usage: python3 run_lean.py <file.lean> <out-prefix> [timeout-seconds]

Sets exactly the three variables that $ROOT/work/lean-local-env.sh exports, uses the Lean
repository as cwd, captures stdout+stderr with Python (shell redirection is unreliable in this
workspace) and writes <out-prefix>.out and <out-prefix>.meta.json.
"""
import hashlib
import json
import os
import subprocess
import sys
import time

ROOT = "/Users/jackpohlad/Documents/Codex/2026-11-25/fetch-and-follow-the-instructions-at"
LEAN_REPO = os.path.join(ROOT, "work", "pequalnp-sparse", "lean")


def main():
    src = os.path.abspath(sys.argv[1])
    prefix = os.path.abspath(sys.argv[2])
    timeout = float(sys.argv[3]) if len(sys.argv) > 3 else 3000.0
    env = dict(os.environ)
    env["ELAN_HOME"] = os.path.join(ROOT, "work", "elan")
    env["XDG_CACHE_HOME"] = os.path.join(ROOT, "work", "lean-local-cache")
    env["PATH"] = os.path.join(ROOT, "work", "elan", "bin") + ":" + env.get("PATH", "")
    with open(src, "rb") as fh:
        sha = hashlib.sha256(fh.read()).hexdigest()
    t0 = time.time()
    status = "finished"
    try:
        proc = subprocess.run(["lake", "env", "lean", src], cwd=LEAN_REPO, env=env,
                              stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                              timeout=timeout)
        out = proc.stdout.decode("utf-8", "replace")
        code = proc.returncode
    except subprocess.TimeoutExpired as exc:
        out = (exc.stdout or b"").decode("utf-8", "replace")
        code = None
        status = "timeout"
    wall = time.time() - t0
    with open(prefix + ".out", "w") as fh:
        fh.write(out)
    lines = out.splitlines()
    meta = {
        "source": src,
        "source_sha256": sha,
        "command": "lake env lean " + src + "   (cwd " + LEAN_REPO + ")",
        "status": status,
        "exit_code": code,
        "wall_seconds": round(wall, 1),
        "output_lines": len(lines),
        "error_lines": sum(1 for l in lines if "error" in l.lower()),
        "warning_lines": sum(1 for l in lines if "warning" in l.lower()),
        "sorry_lines": sum(1 for l in lines if "sorry" in l.lower()),
    }
    with open(prefix + ".meta.json", "w") as fh:
        json.dump(meta, fh, indent=1)
    print(json.dumps(meta))


if __name__ == "__main__":
    main()
