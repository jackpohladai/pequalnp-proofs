import PEqualNP.Outside.L_alg001_projection
import PEqualNP.Outside.L_alg001_residual

/-!
Fable (local research, L-alg-001): an abstract exactness interface for projection engines.

Any representation of Boolean relations (syntactic AND/OR DAG, reduced ordered BDD, a list of
bucket factors, ...) together with ANY semantics-preserving normaliser decides SAT, provided
compiling and forgetting are exact. Also the semantic identities used by the miniscoping
repairs R1/R1b of `residual_dag.py` and by the bucket and affine steps of CFPE.

Semantic correctness only: no statement about representation size or running time, and no
refinement proof of any Python implementation.
-/

namespace PEqualNP.Outside.L_alg001_fable_engine

open PEqualNP.Search
open PEqualNP.Outside.L_alg001_projection

/-- `f` does not depend on the variable `x`. -/
def Independent (x : ℕ) (f : Relation) : Prop :=
  ∀ (σ : Assignment) (b : Bool), f (Function.update σ x b) = f σ

/-- Forgetting a variable a relation does not mention changes nothing. -/
theorem forget_of_independent (x : ℕ) (f : Relation) (h : Independent x f) :
    forget x f = f := by
  funext σ
  simp [forget, h σ]

/-- Existential projection distributes over disjunction (miniscoping, OR case). -/
theorem forget_or (x : ℕ) (f g : Relation) :
    forget x (fun σ => f σ || g σ) = fun σ => forget x f σ || forget x g σ := by
  funext σ
  simp only [forget]
  cases f (Function.update σ x false) <;> cases g (Function.update σ x false) <;>
    cases f (Function.update σ x true) <;> cases g (Function.update σ x true) <;> rfl

/-- A conjunct that does not mention `x` can be pulled out of the projection
(bucket elimination step; miniscoping, AND case). -/
theorem forget_and_of_independent (x : ℕ) (f g : Relation) (h : Independent x f) :
    forget x (fun σ => f σ && g σ) = fun σ => f σ && forget x g σ := by
  funext σ
  simp only [forget, h σ]
  cases f σ <;> simp

/-- A literal on `x` projects to true. -/
theorem forget_literal (x : ℕ) (v : Bool) :
    forget x (fun σ => σ x == v) = fun _ => true := by
  funext σ
  cases v <;> simp [forget]

/-- Eliminating a DEFINED variable: if `x` is constrained to equal `g` (which does not mention
`x`), projecting `x` away is substitution. This is the exact step behind unit propagation,
literal-equivalence substitution and dropping an echelon row whose pivot is `x`. -/
theorem forget_defined (x : ℕ) (g f : Relation) (hg : Independent x g) :
    forget x (fun σ => (σ x == g σ) && f σ) = fun σ => f (Function.update σ x (g σ)) := by
  funext σ
  simp only [forget, Function.update_self, hg σ]
  cases g σ <;> simp

/-- A defining constraint alone projects to true (an XOR row whose pivot occurs nowhere else). -/
theorem forget_definition (x : ℕ) (g : Relation) (hg : Independent x g) :
    forget x (fun σ => σ x == g σ) = fun _ => true := by
  funext σ
  simp only [forget, Function.update_self, hg σ]
  cases g σ <;> simp

/-- The run of an engine: forget the listed variables one by one, normalising after each. -/
theorem den_foldl {R : Type} (den : R → Relation) (forgetR : ℕ → R → R) (normalise : R → R)
    (hf : ∀ x r, den (forgetR x r) = forget x (den r))
    (hn : ∀ r, den (normalise r) = den r) (xs : List ℕ) (r : R) :
    den (xs.foldl (fun r x => normalise (forgetR x r)) r) = project xs (den r) := by
  induction xs generalizing r with
  | nil => rfl
  | cons x xs ih =>
    show den (xs.foldl (fun r x => normalise (forgetR x r)) (normalise (forgetR x r))) =
      project xs (forget x (den r))
    rw [ih, hn, hf]

end PEqualNP.Outside.L_alg001_fable_engine

/-- Any exact representation engine with any semantics-preserving normaliser decides SAT:
after forgetting every occurring variable, the value of the final representation at an
arbitrary assignment is the answer. Correctness only; nothing about size or time. -/
theorem PEqualNP.Outside.L_alg001_fable_engine :
    ∀ (R : Type) (den : R → PEqualNP.Search.Assignment → Bool)
      (compile : PEqualNP.Search.CNF → R) (forgetR : ℕ → R → R) (normalise : R → R),
      (∀ φ, den (compile φ) = fun σ => PEqualNP.Search.CNF.eval σ φ) →
      (∀ x r, den (forgetR x r) = fun σ =>
          den r (Function.update σ x false) || den r (Function.update σ x true)) →
      (∀ r, den (normalise r) = den r) →
      ∀ (φ : PEqualNP.Search.CNF) (xs : List ℕ),
        (∀ c ∈ φ, ∀ l ∈ c, l.1 ∈ xs) →
        ∀ σ : PEqualNP.Search.Assignment,
          den (xs.foldl (fun r x => normalise (forgetR x r)) (normalise (compile φ))) σ = true ↔
            PEqualNP.Search.Satisfiable φ := by
  intro R den compile forgetR normalise hc hf hn φ xs hcover σ
  have hf' : ∀ x r, den (forgetR x r) =
      PEqualNP.Outside.L_alg001_projection.forget x (den r) := by
    intro x r
    rw [hf x r]
    rfl
  rw [PEqualNP.Outside.L_alg001_fable_engine.den_foldl den forgetR normalise hf' hn, hn, hc]
  exact PEqualNP.Outside.L_alg001_projection.project_cnf_correct xs φ hcover σ

#print axioms PEqualNP.Outside.L_alg001_fable_engine
#print axioms PEqualNP.Outside.L_alg001_fable_engine.forget_defined
#print axioms PEqualNP.Outside.L_alg001_fable_engine.forget_and_of_independent
#print axioms PEqualNP.Outside.L_alg001_fable_engine.forget_or


/-! ## Reviewer D additions (not part of the reviewed file) -/

-- axioms of the engine theorems that the reviewed file does not print
#print axioms PEqualNP.Outside.L_alg001_fable_engine.forget_of_independent
#print axioms PEqualNP.Outside.L_alg001_fable_engine.forget_literal
#print axioms PEqualNP.Outside.L_alg001_fable_engine.forget_definition
#print axioms PEqualNP.Outside.L_alg001_fable_engine.den_foldl

-- exact statements as elaborated
#check @PEqualNP.Outside.L_alg001_fable_engine
#check @PEqualNP.Outside.L_alg001_fable_engine.forget_defined
#check @PEqualNP.Outside.L_alg001_fable_engine.forget_definition

namespace ReviewerD

open PEqualNP.Search PEqualNP.Outside.L_alg001_residual

/-- The interface `CorrectBitDecider` is inhabited classically in one line, with no algorithm:
the bare existence of a correct bit decider carries no computational content. -/
noncomputable def classicalDecider : CorrectBitDecider :=
  ⟨fun x => @decide (x ∈ SAT) (Classical.propDecidable _), fun x => by simp⟩

#print axioms classicalDecider

/-- `DegreeBound c d` does not depend on which correct decider `c` is named: it is a property
of the language SAT only. -/
theorem degreeBound_iff (c₁ c₂ : CorrectBitDecider) (d : ℕ) :
    Nonempty (DegreeBound c₁ d) ↔ Nonempty (DegreeBound c₂ d) := by
  have key : ∀ a b : CorrectBitDecider,
      Nonempty (DegreeBound a d) → Nonempty (DegreeBound b d) := by
    rintro ⟨ra, ha⟩ ⟨rb, hb⟩ ⟨h⟩
    have e : ra = rb := by
      funext x
      exact Bool.eq_iff_iff.mpr ((ha x).symm.trans (hb x))
    subst e
    exact ⟨⟨h.machine, h.scale, h.bound⟩⟩
  exact ⟨key c₁ c₂, key c₂ c₁⟩

#print axioms degreeBound_iff

end ReviewerD
