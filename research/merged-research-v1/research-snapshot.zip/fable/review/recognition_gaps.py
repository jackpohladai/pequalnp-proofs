#!/usr/bin/env python3
"""Reviewer D: completeness / cost claims about the read-twice degree island (layers.py).

1. Polarity-flip gap: a family that IS a read-twice degree system by the Definition of
   theory.md Section 6 and is decided by the island in its natural polarity, but is DECLINED
   after flipping the polarity of every variable (the claim under test: "under any renaming of
   variables and any flipping of polarities").
2. Other members of the defined class that the recogniser declines.
3. Decline rate on randomly generated degree systems (how often "sound, not complete" bites).
4. Stage-A cost: ticks of island_stage on a family where the polarity propagation of the
   degree layer is quadratic (the claim under test: "Stage A overhead on any input:
   O(N log N) ticks").

Usage: python3 -B recognition_gaps.py     -> results/recognition_gaps.json
"""
import hashlib
import itertools
import json
import os
import random
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
FABLE = os.path.dirname(HERE)
sys.path.insert(0, HERE)
sys.path.insert(1, FABLE)

import gens      # noqa: E402
import oracle    # noqa: E402
import layers    # noqa: E402


class Ticks:
    def __init__(self):
        self.total = 0
        self.by = {}

    def __call__(self, category, amount=1):
        self.total += amount
        self.by[category] = self.by.get(category, 0) + amount


def encoded_bits(clauses):
    """Length of the project's binary encoding (Defs/Search.lean: 2*bits(i)+4 per literal,
    2 per clause), with variable i >= 1."""
    return sum(sum(2 * abs(l).bit_length() + 4 for l in c) + 2 for c in clauses)


def stage(nvars, clauses):
    t = Ticks()
    t0 = time.time()
    verdict, residual, values, log = layers.island_stage(nvars, [list(c) for c in clauses], t)
    return {"verdict": verdict, "residual_clauses": len(residual), "islands": log["islands"],
            "unsat": (log["unsat"] if isinstance(log["unsat"], (str, type(None))) else log["unsat"]["layer"]),
            "ticks": t.total, "ticks_by_category": t.by, "seconds": round(time.time() - t0, 3)}


def parity_php(pigeons, holes, flip):
    """Pigeon i uses an ODD number of holes (P group, target 1), hole j holds at most one pigeon
    (U group). UNSAT when pigeons > holes. flip=True writes every variable negated."""
    var = lambda i, j: i * holes + j + 1
    clauses = []
    for i in range(pigeons):
        clauses += gens.parity_clauses([var(i, j) for j in range(holes)], 1)
    for j in range(holes):
        col = [var(i, j) for i in range(pigeons)]
        clauses += [[-a, -b] for a, b in itertools.combinations(col, 2)]
    if flip:
        clauses = [[-l for l in c] for c in clauses]
    return pigeons * holes, clauses


def polarity_flip_gap():
    rows = []
    for holes in (3, 4, 5, 6):
        for flip in (False, True):
            n, cl = parity_php(holes + 1, holes, flip)
            r = stage(n, cl)
            r.update({"family": "parity_php_%d_%d" % (holes + 1, holes), "all_polarities_flipped": flip,
                      "nvars": n, "clauses": len(cl)})
            if n <= 20:
                r["oracle"] = "SAT" if oracle.is_sat(n, cl) else "UNSAT"
            rows.append(r)
    return rows


def small_declined_members():
    amo = lambda vs: [[-a, -b] for a, b in itertools.combinations(vs, 2)]
    cases = {
        # groups by the Definition are listed in the key
        "U{1,2,3} written positively + P{1,4,5}=1 + P{2,6,7}=0 + P{3,8,9}=1  (lambda flipped on 1,2,3)":
            [[1, 2], [2, 3], [1, 3]] + gens.parity_clauses([1, 4, 5], 1)
            + gens.parity_clauses([2, 6, 7], 0) + gens.parity_clauses([3, 8, 9], 1),
        "X{1,2,5} + U{1,2,3} + L{3,4,6}":
            [[1, 2, 5]] + amo([1, 2, 5]) + amo([1, 2, 3]) + [[3, 4, 6]],
        "L{1,2} + U{1,2,3} + L{3,4,5}":
            [[1, 2]] + amo([1, 2, 3]) + [[3, 4, 5]],
        "L{1,2} + U{1,2,3} + L{3,4,5} + U{4,5} + L{3,4} + L{3,5}  (UNSAT)":
            [[1, 2]] + amo([1, 2, 3]) + [[3, 4, 5], [-4, -5], [3, 4], [3, 5]],
        "P{1,2,3}=1 + P{1,2,3}=0  (UNSAT)":
            gens.parity_clauses([1, 2, 3], 1) + gens.parity_clauses([1, 2, 3], 0),
    }
    out = {}
    for name, cl in cases.items():
        n = max(abs(l) for c in cl for l in c)
        r = stage(n, cl)
        r["oracle"] = "SAT" if oracle.is_sat(n, cl) else "UNSAT"
        r["clauses_list"] = cl
        out[name] = r
    return out


def decline_rates(seconds=8.0, seed=4242):
    rng = random.Random(seed)
    table = {"degree_system": gens.degree_system, "graph_degree_system": gens.graph_degree_system,
             "tight_degree_system": gens.tight_degree_system, "php": gens.php}
    stats = {k: {"cases": 0, "decided": 0, "left_open": 0} for k in table}
    examples = {}
    t0 = time.time()
    while time.time() - t0 < seconds:
        name = rng.choice(list(table))
        n, cl = table[name](rng)
        verdict, residual, values, log = layers.island_stage(n, [list(c) for c in cl])
        st = stats[name]
        st["cases"] += 1
        if verdict == "UNSAT" or not residual:
            st["decided"] += 1
        else:
            st["left_open"] += 1
            if name not in examples or len(cl) < len(examples[name]["clauses"]):
                examples[name] = {"nvars": n, "clauses": cl, "residual": [list(c) for c in residual]}
    return {"stats": stats, "smallest_open_example": examples}


def quadratic_stage_a():
    """x_0..x_B joined by positive binary clauses (x_i v x_{i+1}); the only polarity anchor is a
    wide clause on x_B (largest index). island_stage sorts the component by variable index, so
    each pass of the polarity propagation resolves one binary clause: Theta(B^2) ticks.
    Variant 'declined': x_B lies in three groups, so the layer returns None after that work.
    Variant 'answered': a valid degree system, the layer answers SAT."""
    rows = []
    for variant in ("declined", "answered"):
        for b in (125, 250, 500, 1000, 2000):
            x = lambda i: i + 1
            c, d, e, f = b + 2, b + 3, b + 4, b + 5
            cl = [[x(i), x(i + 1)] for i in range(b)]
            cl += [[x(b), c, d], [-c, -d]]
            if variant == "declined":
                cl += [[x(b), e, f], [-e, -f]]
            n = b + 5
            r = stage(n, cl)
            bits = encoded_bits(cl)
            r.update({"variant": variant, "B": b, "nvars": n, "clauses": len(cl), "encoded_bits_N": bits,
                      "ticks_over_N": round(r["ticks"] / bits, 2),
                      "ticks_over_NlogN": round(r["ticks"] / (bits * max(1, bits.bit_length())), 3)})
            rows.append(r)
            if r["seconds"] > 5:
                break
    return rows


def main():
    with open(layers.__file__, "rb") as fh:
        sha = hashlib.sha256(fh.read()).hexdigest()
    out = {"layers_sha256": sha}
    out["polarity_flip_gap"] = polarity_flip_gap()
    out["small_declined_members"] = small_declined_members()
    out["decline_rates"] = decline_rates()
    out["quadratic_stage_a"] = quadratic_stage_a()
    os.makedirs(os.path.join(HERE, "results"), exist_ok=True)
    for attempt in range(6):                 # file I/O here fails intermittently with EPERM
        try:
            with open(os.path.join(HERE, "results", "recognition_gaps.json"), "w") as fh:
                json.dump(out, fh, indent=1)
            break
        except PermissionError as exc:
            print("write failed (%s), attempt %d" % (exc, attempt + 1))
            time.sleep(1.0)
    print("layers sha256", sha)
    print("-- polarity flip gap")
    for r in out["polarity_flip_gap"]:
        print("  %-18s flipped=%-5s nvars=%-3d clauses=%-4d verdict=%-5s unsat_by=%-11s residual=%-4d oracle=%s"
              % (r["family"], r["all_polarities_flipped"], r["nvars"], r["clauses"], r["verdict"], r["unsat"],
                 r["residual_clauses"], r.get("oracle", "-")))
    print("-- small members of the defined class that the island declines")
    for k, r in out["small_declined_members"].items():
        print("  %-95s oracle=%-5s verdict=%-5s residual=%d islands=%s" % (k, r["oracle"], r["verdict"], r["residual_clauses"], r["islands"]))
    print("-- decline rates on generated degree systems")
    print("  ", json.dumps(out["decline_rates"]["stats"]))
    print("-- Stage A cost on the binary-chain family")
    for r in out["quadratic_stage_a"]:
        print("  %-9s B=%-5d N=%-7d ticks=%-9d ticks/N=%-8s ticks/(N log N)=%-7s residual=%-5d islands=%s sec=%s"
              % (r["variant"], r["B"], r["encoded_bits_N"], r["ticks"], r["ticks_over_N"], r["ticks_over_NlogN"],
                 r["residual_clauses"], r["islands"], r["seconds"]))


if __name__ == "__main__":
    main()
