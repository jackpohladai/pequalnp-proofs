#!/usr/bin/env python3
"""Reviewer D: independent checks of theory.md Section 0 (model J1..J6, facts F1..F3) and of
Theorem A, against the UNCHANGED native-search/residual_dag.py (imported read-only).

Parts (each time-boxed):
  model     a clean-room re-implementation of the J1..J6 model written from the TEXT of
            Section 0, run in lockstep with the real DAG on random CNFs / orders: canonical
            structure of the root after every forget and the set of all allocated nodes.
  facts     F1 (junction depends on the set only), F2 (idempotence of interned nodes),
            F3 (cofactor of a node not mentioning x is the node), checked on every node of
            the DAGs built along the way.
  width     reviewer's own induced-width computation for pi and the good order, and exact
            treewidth of the primal graph of W_k by brute force over all elimination orders
            (k = 1, 2, 3).
  theoremA  Claim(j) and the closed form 2^(k+1)+7k+7 under: the script's numbering, random
            renumberings, random clause / literal orders, random polarity flips; count of
            distinct and-nodes (claim (iii) says >= 2^k - 1).
Usage: python3 -B theoremA_attack.py <part> [seconds]   -> results/theoremA_<part>.json
"""
import itertools
import json
import os
import random
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT_ALG = os.path.dirname(os.path.dirname(HERE))
sys.path.insert(0, os.path.join(ROOT_ALG, "native-search"))
sys.setrecursionlimit(200000)
from residual_dag import DAG   # noqa: E402  (code under study, unchanged, imported read-only)


def save(name, obj):
    os.makedirs(os.path.join(HERE, "results"), exist_ok=True)
    print(json.dumps(obj)[:3000], flush=True)
    for attempt in range(6):
        try:
            with open(os.path.join(HERE, "results", name), "w") as fh:
                json.dump(obj, fh, indent=1)
            return
        except PermissionError as exc:
            print("write failed (%s), attempt %d" % (exc, attempt + 1), flush=True)
            time.sleep(1.0)


# ----------------------------------------------------------------------------- clean-room model
class Model:
    """Section 0 of theory.md, transcribed. Nodes are canonical nested tuples:
    ('const', b), ('lit', l), (op, frozenset(children))."""
    ZERO = ("const", 0)
    ONE = ("const", 1)

    def __init__(self):
        self.allocated = {self.ZERO, self.ONE}
        self.cof = {}

    def lit(self, l):
        node = ("lit", l)
        self.allocated.add(node)
        return node

    def junction(self, op, children):
        dual = "or" if op == "and" else "and"
        identity, absorbing = (self.ONE, self.ZERO) if op == "and" else (self.ZERO, self.ONE)
        children = set(children)
        # J1 flatten
        if absorbing in children:
            return absorbing
        flat = set()
        for c in children:
            if c == identity:
                continue
            if c[0] == op:
                flat |= set(c[1])
            else:
                flat.add(c)
        if not flat:
            return identity
        # J2 complementary literals
        lits = {c[1] for c in flat if c[0] == "lit"}
        if any(-x in lits for x in lits):
            return absorbing
        # J3 absorption, tested against the set before deletion
        before = set(flat)
        flat = {c for c in before if not (c[0] == dual and (set(c[1]) & before))}
        # J4 one child left
        if len(flat) == 1:
            return next(iter(flat))
        # J5 common factor (or only)
        if op == "or":
            fs = {c: (set(c[1]) if c[0] == "and" else {c}) for c in flat}
            common = set.intersection(*fs.values())
            if common:
                inner = self.junction("or", [self.junction("and", fs[c] - common) for c in flat])
                return self.junction("and", list(common) + [inner])
        # J6 intern
        node = (op, frozenset(flat))
        self.allocated.add(node)
        return node

    def cnf(self, clauses):
        return self.junction("and", [self.junction("or", [self.lit(l) for l in c]) for c in clauses])

    def cofactor(self, u, x, b):
        key = (u, x, b)
        if key in self.cof:
            return self.cof[key]
        if u[0] == "const":
            out = u
        elif u[0] == "lit":
            if abs(u[1]) == x:
                out = self.ONE if (b == (u[1] > 0)) else self.ZERO
            else:
                out = u
        else:
            out = self.junction(u[0], [self.cofactor(c, x, b) for c in u[1]])
        self.cof[key] = out
        return out

    def forget(self, u, x):
        return self.junction("or", [self.cofactor(u, x, False), self.cofactor(u, x, True)])


def canon(d, node, memo):
    """Canonical nested-tuple structure of a node of the real DAG."""
    if node in memo:
        return memo[node]
    kind, data = d.nodes[node]
    if kind == "const":
        out = ("const", 1 if data else 0)
    elif kind == "lit":
        out = ("lit", data)
    else:
        out = (kind, frozenset(canon(d, c, memo) for c in data))
    memo[node] = out
    return out


def random_cnf(rng):
    n = rng.randrange(1, 9)
    clauses = []
    for _ in range(rng.randrange(1, 3 * n + 2)):
        k = rng.randrange(1, min(4, n) + 1)
        vs = rng.sample(range(1, n + 1), k)
        clauses.append([v * rng.choice((-1, 1)) for v in vs])
    if rng.random() < 0.2 and clauses:               # repeated literal / tautology noise
        c = rng.choice(clauses)
        c.append(rng.choice(c) * rng.choice((1, 1, -1)))
    return n, clauses


def W(k, perm=None, flips=None):
    """W_k of Theorem A with the script's numbering, optionally renamed / polarity-flipped."""
    v, a, b = 1, 2, 3
    p = lambda i: 3 + i
    q = lambda i: 3 + k + i
    clauses = [[-v, a], [v, b]] + [[a, p(i), q(i)] for i in range(1, k + 1)]
    order = [v] + [p(i) for i in range(1, k + 1)] + [q(i) for i in range(1, k + 1)] + [a, b]
    good = [p(i) for i in range(1, k + 1)] + [q(i) for i in range(1, k + 1)] + [v, a, b]
    n = 3 + 2 * k
    if perm is None:
        perm = {x: x for x in range(1, n + 1)}
    if flips is None:
        flips = {x: 1 for x in range(1, n + 1)}
    f = lambda l: (1 if l > 0 else -1) * flips[abs(l)] * perm[abs(l)]
    return n, [[f(l) for l in c] for c in clauses], [perm[x] for x in order], [perm[x] for x in good], perm


def part_model(seconds):
    rng = random.Random(31337)
    t0 = time.time()
    st = {"formulas": 0, "forget_steps": 0, "root_mismatch": 0, "allocation_set_mismatch": 0,
          "answer_mismatch": 0, "nodes_compared": 0, "examples": []}
    families = []
    for k in range(1, 8):
        n, cl, bad, good, _ = W(k)
        families.append((n, cl, bad))
        families.append((n, cl, good))
    while time.time() - t0 < seconds:
        if families:
            n, clauses, order = families.pop()
        else:
            n, clauses = random_cnf(rng)
            order = list(range(1, n + 1))
            rng.shuffle(order)
        d = DAG()
        m = Model()
        root = d.cnf(clauses)
        mroot = m.cnf(clauses)
        memo = {}
        ok = canon(d, root, memo) == mroot
        for x in order:
            root = d.forget(root, x)
            mroot = m.forget(mroot, x)
            st["forget_steps"] += 1
            if canon(d, root, memo) != mroot:
                ok = False
        real_alloc = {canon(d, i, memo) for i in range(len(d.nodes))}
        st["formulas"] += 1
        st["nodes_compared"] += len(real_alloc)
        if not ok:
            st["root_mismatch"] += 1
            if len(st["examples"]) < 5:
                st["examples"].append({"kind": "root", "n": n, "clauses": clauses, "order": order})
        if real_alloc != m.allocated:
            st["allocation_set_mismatch"] += 1
            if len(st["examples"]) < 5:
                st["examples"].append({"kind": "alloc", "n": n, "clauses": clauses, "order": order,
                                       "real": len(real_alloc), "model": len(m.allocated)})
        if (root == 1) != (mroot == Model.ONE):
            st["answer_mismatch"] += 1
    st["seconds"] = round(time.time() - t0, 2)
    save("theoremA_model.json", st)


def part_facts(seconds):
    rng = random.Random(4711)
    t0 = time.time()
    st = {"dags": 0, "F1_calls": 0, "F1_violations": 0, "F2_nodes": 0, "F2_violations": 0,
          "F2_new_allocations": 0, "F3_checks": 0, "F3_violations": 0}

    def support(d, node, memo):
        if node in memo:
            return memo[node]
        kind, data = d.nodes[node]
        if kind == "const":
            out = frozenset()
        elif kind == "lit":
            out = frozenset([abs(data)])
        else:
            out = frozenset().union(*[support(d, c, memo) for c in data])
        memo[node] = out
        return out

    while time.time() - t0 < seconds:
        n, clauses = random_cnf(rng)
        order = list(range(1, n + 1))
        rng.shuffle(order)
        d = DAG()
        root = d.cnf(clauses)
        for x in order[: rng.randrange(0, n + 1)]:
            root = d.forget(root, x)
        st["dags"] += 1
        size = len(d.nodes)
        # F2: junction(op, S) of an interned node returns the node and allocates nothing
        for i in range(size):
            kind, data = d.nodes[i]
            if kind in ("and", "or"):
                before = len(d.nodes)
                r = d.junction(kind, list(data))
                st["F2_nodes"] += 1
                if r != i:
                    st["F2_violations"] += 1
                st["F2_new_allocations"] += len(d.nodes) - before
        # F3: cofactor by a variable that does not occur below a node
        memo = {}
        for i in range(size):
            sup = support(d, i, memo)
            for x in range(1, n + 2):
                if x not in sup:
                    for b in (False, True):
                        st["F3_checks"] += 1
                        if d.cofactor(i, x, b) != i:
                            st["F3_violations"] += 1
        # F1: junction on random child multisets, in two different orders / multiplicities
        ids = list(range(len(d.nodes)))
        for _ in range(20):
            ch = [rng.choice(ids) for _ in range(rng.randrange(1, 5))]
            op = rng.choice(("and", "or"))
            r1 = d.junction(op, list(ch))
            ch2 = ch + [rng.choice(ch) for _ in range(rng.randrange(0, 3))]
            rng.shuffle(ch2)
            r2 = d.junction(op, ch2)
            st["F1_calls"] += 1
            if r1 != r2:
                st["F1_violations"] += 1
    st["seconds"] = round(time.time() - t0, 2)
    save("theoremA_facts.json", st)


# ----------------------------------------------------------------------------- widths
def induced_width(clauses, order):
    adj = {}
    for c in clauses:
        vs = {abs(l) for l in c}
        for x in vs:
            adj.setdefault(x, set()).update(vs - {x})
    width = 0
    for x in order:
        nb = adj.pop(x, set())
        width = max(width, len(nb))
        for y in nb:
            adj[y].discard(x)
            adj[y].update(nb - {y})
    assert not adj, "order does not cover all variables"
    return width


def exact_treewidth(clauses):
    """min over ALL elimination orders (brute force with memoisation on the eliminated set)."""
    vs = sorted({abs(l) for c in clauses for l in c})
    index = {v: i for i, v in enumerate(vs)}
    base = [0] * len(vs)
    for c in clauses:
        ids = [index[abs(l)] for l in c]
        for i in ids:
            for j in ids:
                if i != j:
                    base[i] |= 1 << j
    full = (1 << len(vs)) - 1
    memo = {}

    def q(elim, v):
        # neighbours of v in the graph after eliminating `elim`: vertices reachable from v
        # through eliminated vertices only
        seen = 1 << v
        stack = [v]
        out = 0
        while stack:
            u = stack.pop()
            nb = base[u] & ~seen
            seen |= nb
            out |= nb & ~elim
            inner = nb & elim
            while inner:
                low = inner & -inner
                stack.append(low.bit_length() - 1)
                inner ^= low
        return bin(out & ~(1 << v)).count("1")

    def best(elim):
        if elim == full:
            return 0
        if elim in memo:
            return memo[elim]
        r = 10 ** 9
        for v in range(len(vs)):
            if not (elim >> v) & 1:
                r = min(r, max(q(elim, v), best(elim | (1 << v))))
        memo[elim] = r
        return r

    return best(0)


def part_width(seconds):
    rows = []
    for k in range(1, 15):
        n, cl, bad, good, _ = W(k)
        row = {"k": k, "n": n, "induced_width_pi": induced_width(cl, bad),
               "induced_width_good": induced_width(cl, good)}
        if k <= 4:
            row["exact_treewidth_bruteforce"] = exact_treewidth(cl)
        rows.append(row)
    save("theoremA_width.json", rows)


# ----------------------------------------------------------------------------- Theorem A
def run_W(k, perm=None, flips=None, shuffle=None, check_claim=True):
    n, clauses, bad, good, perm = W(k, perm, flips)
    if shuffle is not None:
        clauses = [list(c) for c in clauses]
        for c in clauses:
            shuffle.shuffle(c)
        shuffle.shuffle(clauses)
    d = DAG()
    root = d.cnf(clauses)
    arities = []
    claim_ok = True
    a_lit = None
    for step, x in enumerate(bad):
        root = d.forget(root, x)
        kind, data = d.nodes[root]
        if step <= k - 1:                          # after v, p_1..p_j with j = step
            j = step
            if kind != "or" or len(data) != 2 ** j + 1:
                claim_ok = False
            else:
                kinds = sorted(d.nodes[c][0] for c in data)
                if kinds != ["and"] * (2 ** j) + ["lit"]:
                    claim_ok = False
            arities.append(len(data) if kind in ("and", "or") else 0)
    and_nodes = sum(1 for kind, _ in d.nodes if kind == "and")
    return {"k": k, "answer_sat": root == 1, "allocated": len(d.nodes),
            "closed_form": 2 ** (k + 1) + 7 * k + 7, "and_nodes": and_nodes,
            "two_pow_k_minus_1": 2 ** k - 1, "claim_j_holds": claim_ok,
            "root_or_arity_after_v_p1_pj": arities}


def part_theoremA(seconds):
    rng = random.Random(20261126)
    t0 = time.time()
    out = {"plain": [], "variants": {"cases": 0, "closed_form_fail": 0, "claim_fail": 0,
                                     "unsat_answers": 0, "and_nodes_below_bound": 0, "examples": []}}
    for k in range(1, 16):
        if time.time() - t0 > seconds * 0.45:
            break
        t1 = time.time()
        r = run_W(k)
        r["seconds"] = round(time.time() - t1, 2)
        r.pop("root_or_arity_after_v_p1_pj") if k > 6 else None
        out["plain"].append(r)
    while time.time() - t0 < seconds:
        k = rng.randrange(1, 11)
        n = 3 + 2 * k
        names = rng.sample(range(1, n + 1 + rng.randrange(0, 4)), n)
        perm = {x: names[x - 1] for x in range(1, n + 1)}
        flips = {x: rng.choice((1, -1)) for x in range(1, n + 1)}
        r = run_W(k, perm, flips, shuffle=rng)
        v = out["variants"]
        v["cases"] += 1
        bad = False
        if r["allocated"] != r["closed_form"]:
            v["closed_form_fail"] += 1
            bad = True
        if not r["claim_j_holds"]:
            v["claim_fail"] += 1
            bad = True
        if not r["answer_sat"]:
            v["unsat_answers"] += 1
            bad = True
        if r["and_nodes"] < r["two_pow_k_minus_1"]:
            v["and_nodes_below_bound"] += 1
            bad = True
        if bad and len(v["examples"]) < 5:
            v["examples"].append({"k": k, "perm": perm, "flips": flips, "result": r})
    out["seconds"] = round(time.time() - t0, 2)
    save("theoremA_theoremA.json", out)


if __name__ == "__main__":
    part = sys.argv[1]
    seconds = float(sys.argv[2]) if len(sys.argv) > 2 else 20.0
    {"model": part_model, "facts": part_facts, "width": part_width, "theoremA": part_theoremA}[part](seconds)
