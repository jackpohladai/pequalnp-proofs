#!/usr/bin/env python3
"""Reviewer D: differential fuzz of fable/layers.py against the reviewer's own exhaustive oracle.

Usage: python3 -B fuzz_layers.py <seed> [seconds=24] [max_cases=1000000]

Per case:
  * `layers.island_stage` on the RAW clause list (duplicates, tautologies, empty clause allowed);
  * every layer directly on the reviewer-normalised formula and on each of its connected
    components (the documented precondition of the layers);
  * with --raw semantics always on: every layer directly on the raw tuples (precondition
    VIOLATED; failures there are recorded separately under 'raw_*').
Results: results/fuzz_layers_<seed>.json ; failing instances (minimised): counterexamples/.
"""
import json
import os
import random
import sys
import time
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
FABLE = os.path.dirname(HERE)
sys.path.insert(0, HERE)
sys.path.insert(1, FABLE)

import gens      # noqa: E402
import oracle    # noqa: E402
import layers    # noqa: E402  (code under review, imported read-only)

LAYER_FUNCS = (("horn", layers.horn_layer), ("twosat", layers.twosat_layer),
               ("cardinality", layers.cardinality_layer))


class Ticks:
    def __init__(self):
        self.total = 0

    def __call__(self, category, amount=1):
        self.total += amount


def island_failure(nvars, clauses):
    """Return a failure tag or None for one island_stage call."""
    try:
        verdict, residual, values, log = layers.island_stage(nvars, [list(c) for c in clauses], Ticks())
    except Exception:
        return "island_exception"
    tt = oracle.formula_tt(nvars, clauses)
    if verdict == "UNSAT":
        return "island_wrong_unsat" if tt else None
    if verdict is not None:
        return "island_bad_verdict"
    rvars = {abs(l) for c in residual for l in c}
    if rvars & set(values):
        return "island_overlap"
    if any(v < 1 or v > nvars for v in rvars) or any(v < 1 or v > nvars for v in values):
        return "island_var_range"
    if any(len(c) == 0 for c in residual):
        return "island_empty_residual_clause"
    rtt = oracle.formula_tt(nvars, residual)
    if bool(rtt) != bool(tt):
        return "island_equisat"
    vtt = oracle.values_tt(nvars, values)
    if (rtt & vtt) & ~tt:
        return "island_join"
    return None


def layer_failure(name, fn, nvars, clauses):
    """Return (tag or None, answer) for one direct layer call on `clauses` (tuples)."""
    try:
        r = fn([tuple(c) for c in clauses], Ticks())
    except Exception:
        return "exception", "exception"
    if r is None:
        return None, "none"
    verdict, payload = r
    sat = oracle.is_sat(nvars, clauses)
    if verdict == "UNSAT":
        return ("wrong_unsat" if sat else None), "unsat"
    if verdict == "SAT":
        if not sat:
            return "wrong_sat", "sat"
        try:
            ok = oracle.satisfies(payload, clauses)
        except KeyError:
            ok = False
        return (None if ok else "bad_model"), "sat"
    return "bad_verdict", "other"


def minimise(nvars, clauses, pred):
    """Greedy clause / literal deletion keeping pred(nvars, clauses) true."""
    cur = [list(c) for c in clauses]
    changed = True
    while changed:
        changed = False
        i = 0
        while i < len(cur):
            cand = cur[:i] + cur[i + 1:]
            if pred(nvars, cand):
                cur = cand
                changed = True
            else:
                i += 1
        for i in range(len(cur)):
            j = 0
            while j < len(cur[i]):
                cand = [list(c) for c in cur]
                cand[i].pop(j)
                if pred(nvars, cand):
                    cur = cand
                    changed = True
                else:
                    j += 1
    return cur


GENERATORS = (
    ("degree_system", 5, lambda rng: gens.degree_system(rng)),
    ("graph_degree_system", 5, lambda rng: gens.graph_degree_system(rng)),
    ("php", 2, lambda rng: gens.php(rng)),
    ("tight_degree_system", 6, lambda rng: gens.tight_degree_system(rng)),
    ("tight_mutated", 5, lambda rng: gens.mutate(rng, *gens.tight_degree_system(rng))),
    ("degree_mutated", 6, lambda rng: gens.mutate(rng, *gens.degree_system(rng))),
    ("graph_mutated", 5, lambda rng: gens.mutate(rng, *gens.graph_degree_system(rng))),
    ("php_mutated", 2, lambda rng: gens.mutate(rng, *gens.php(rng))),
    ("random_cnf", 3, lambda rng: gens.random_cnf(rng)),
    ("random_2cnf", 2, lambda rng: gens.random_2cnf(rng)),
    ("random_horn", 2, lambda rng: gens.random_horn(rng)),
    ("raw_noise", 2, lambda rng: gens.raw_noise(rng)),
)


def main():
    seed = int(sys.argv[1])
    seconds = float(sys.argv[2]) if len(sys.argv) > 2 else 24.0
    max_cases = int(sys.argv[3]) if len(sys.argv) > 3 else 10 ** 6
    rng = random.Random(seed)
    names = [g[0] for g in GENERATORS]
    weights = [g[1] for g in GENERATORS]
    table = {g[0]: g[2] for g in GENERATORS}
    import hashlib
    with open(layers.__file__, "rb") as fh:
        layers_sha = hashlib.sha256(fh.read()).hexdigest()
    stats = {"seed": seed, "layers_sha256_at_start": layers_sha, "cases": 0, "by_generator": {}, "island": {"unsat": 0, "open": 0,
             "fully_decided_sat": 0, "oracle_sat": 0, "oracle_unsat": 0},
             "layer_normalised": {}, "layer_component": {}, "layer_raw": {}, "failures": []}
    for scope in ("layer_normalised", "layer_component", "layer_raw"):
        for name, _ in LAYER_FUNCS:
            stats[scope][name] = {"none": 0, "sat": 0, "unsat": 0, "exception": 0, "other": 0, "calls": 0}
    t0 = time.time()
    os.makedirs(os.path.join(HERE, "results"), exist_ok=True)
    os.makedirs(os.path.join(HERE, "counterexamples"), exist_ok=True)

    def record(tag, scope, nvars, clauses, pred):
        try:
            small = minimise(nvars, clauses, pred)
        except Exception:
            small = clauses
        item = {"tag": tag, "scope": scope, "nvars": nvars, "clauses": clauses, "minimised": small,
                "case_index": stats["cases"], "seed": seed}
        stats["failures"].append(item)
        path = os.path.join(HERE, "counterexamples", "layers_%s_%s_seed%d_case%d.json"
                            % (scope, tag, seed, stats["cases"]))
        print("FAILURE " + json.dumps(item), flush=True)
        for attempt in range(3):
            try:
                with open(path, "w") as fh:
                    json.dump(item, fh, indent=1)
                break
            except PermissionError:
                time.sleep(0.5)

    while stats["cases"] < max_cases and time.time() - t0 < seconds:
        gname = rng.choices(names, weights)[0]
        nvars, clauses = table[gname](rng)
        stats["cases"] += 1
        stats["by_generator"][gname] = stats["by_generator"].get(gname, 0) + 1
        # ---- island_stage on the raw input
        tag = island_failure(nvars, clauses)
        sat = oracle.is_sat(nvars, clauses)
        stats["island"]["oracle_sat" if sat else "oracle_unsat"] += 1
        if tag:
            record(tag, "island", nvars, clauses, lambda n, cl, t=tag: island_failure(n, cl) == t)
        else:
            verdict, residual, values, log = layers.island_stage(nvars, [list(c) for c in clauses])
            isl = stats["island"]
            if verdict == "UNSAT":
                isl["unsat"] += 1
                why = log["unsat"]
                key = "unsat_by_" + (why if isinstance(why, str) else why["layer"])
                isl[key] = isl.get(key, 0) + 1
                if not isinstance(why, str) and why["layer"] == "cardinality":
                    bkey = "card_unsat_barrier_%s" % ("empty" if why["certificate"]["barrier_size"] == 0 else "nonempty")
                    isl[bkey] = isl.get(bkey, 0) + 1
            elif residual:
                isl["open"] += 1
            else:
                isl["fully_decided_sat"] += 1
            for lname, cnt in log["islands"].items():
                isl["sat_components_by_" + lname] = isl.get("sat_components_by_" + lname, 0) + cnt
        # ---- direct layer calls on the normalised formula and on its components
        norm, has_empty = gens.normalise(clauses)
        if not has_empty:
            for name, fn in LAYER_FUNCS:
                tag, ans = layer_failure(name, fn, nvars, norm)
                st = stats["layer_normalised"][name]
                st["calls"] += 1
                st[ans] += 1
                if tag:
                    record(name + "_" + tag, "layer_normalised", nvars, [list(c) for c in norm],
                           lambda n, cl, t=tag, f=fn, nm=name:
                           (not gens.normalise(cl)[1]) and [tuple(c) for c in cl] == gens.normalise(cl)[0]
                           and layer_failure(nm, f, n, cl)[0] == t)
            comps = gens.components(norm)
            if len(comps) > 1:
                for comp in comps:
                    for name, fn in LAYER_FUNCS:
                        tag, ans = layer_failure(name, fn, nvars, comp)
                        st = stats["layer_component"][name]
                        st["calls"] += 1
                        st[ans] += 1
                        if tag:
                            record(name + "_" + tag, "layer_component", nvars, [list(c) for c in comp],
                                   lambda n, cl, t=tag, f=fn, nm=name: layer_failure(nm, f, n, cl)[0] == t)
        # ---- direct layer calls on raw tuples (precondition violated on purpose)
        if clauses != [list(c) for c in norm]:
            for name, fn in LAYER_FUNCS:
                tag, ans = layer_failure(name, fn, nvars, clauses)
                st = stats["layer_raw"][name]
                st["calls"] += 1
                st[ans] += 1
                if tag and tag != "exception":
                    key = "raw_" + name + "_" + tag
                    if sum(1 for f in stats["failures"] if f["tag"] == key) < 3:
                        record(key, "layer_raw", nvars, clauses,
                               lambda n, cl, t=tag, f=fn, nm=name: layer_failure(nm, f, n, cl)[0] == t)
                    else:
                        stats["failures"].append({"tag": key, "scope": "layer_raw", "case_index": stats["cases"]})
    stats["wall_seconds"] = round(time.time() - t0, 2)
    with open(layers.__file__, "rb") as fh:
        stats["layers_sha256_at_end"] = hashlib.sha256(fh.read()).hexdigest()
    tags = {}
    for f in stats["failures"]:
        tags[f["tag"]] = tags.get(f["tag"], 0) + 1
    stats["failure_tags"] = tags
    brief = {k: stats[k] for k in ("seed", "layers_sha256_at_start", "cases", "wall_seconds", "island", "failure_tags")}
    brief["layer_normalised"] = stats["layer_normalised"]
    brief["layer_component"] = stats["layer_component"]
    brief["layer_raw"] = stats["layer_raw"]
    brief["by_generator"] = stats["by_generator"]
    print(json.dumps(brief), flush=True)
    # Python file I/O in this workspace fails intermittently with EPERM: retry the same call.
    for attempt in range(5):
        try:
            with open(os.path.join(HERE, "results", "fuzz_layers_%d.json" % seed), "w") as fh:
                json.dump(stats, fh, indent=1)
            break
        except PermissionError as exc:
            print("RESULT_WRITE_FAILED attempt %d: %s" % (attempt + 1, exc), flush=True)
            time.sleep(1.0)


if __name__ == "__main__":
    try:
        main()
    except Exception:
        traceback.print_exc()
        sys.exit(2)
