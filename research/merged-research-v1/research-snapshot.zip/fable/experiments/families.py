"""Deterministic instance families and INDEPENDENT reference answers for the CFPE
scaling study (project L-alg-001).  Standard library only; no candidate code is used.

Every generator returns (nvars, clauses, meta) where meta["expected"] is "SAT",
"UNSAT" or None (unknown by construction) and meta["expected_by"] says why.
"""
import itertools
import random


# ----------------------------------------------------------------------------- helpers

def xor_clauses(vs, parity):
    """CNF of XOR(vs) == parity: one clause per forbidden (wrong-parity) assignment."""
    out = []
    for bits in itertools.product((0, 1), repeat=len(vs)):
        if sum(bits) % 2 != parity:
            out.append(tuple(-v if b else v for v, b in zip(vs, bits)))
    return out


def rename_shuffle(nvars, clauses, seed):
    """Random variable renaming + clause shuffle + literal shuffle (seeded)."""
    rng = random.Random(seed)
    perm = list(range(1, nvars + 1))
    rng.shuffle(perm)
    out = []
    for c in clauses:
        d = [(perm[abs(l) - 1] if l > 0 else -perm[abs(l) - 1]) for l in c]
        rng.shuffle(d)
        out.append(tuple(d))
    rng.shuffle(out)
    return out, perm


def random_regular_graph(nv, deg, rng):
    """Simple connected deg-regular graph by the pairing model (rejection)."""
    assert nv * deg % 2 == 0
    while True:
        stubs = list(range(nv)) * deg
        rng.shuffle(stubs)
        edges = [tuple(sorted(stubs[i:i + 2])) for i in range(0, len(stubs), 2)]
        if any(a == b for a, b in edges) or len(set(edges)) != len(edges):
            continue
        adj = {v: [] for v in range(nv)}
        for a, b in edges:
            adj[a].append(b)
            adj[b].append(a)
        seen = {0}
        stack = [0]
        while stack:
            v = stack.pop()
            for u in adj[v]:
                if u not in seen:
                    seen.add(u)
                    stack.append(u)
        if len(seen) == nv:
            return sorted(edges)


def random_regular_by_matchings(nv, deg, rng):
    """Simple connected deg-regular graph as a union of deg random perfect matchings
    (used for deg > 3, where the pairing model almost never yields a simple graph)."""
    assert nv % 2 == 0 and deg < nv - 1
    while True:
        edges = set()
        ok = True
        for _ in range(deg):
            for _attempt in range(2000):
                perm = list(range(nv))
                rng.shuffle(perm)
                m = [tuple(sorted(perm[i:i + 2])) for i in range(0, nv, 2)]
                if not any(e in edges for e in m):
                    edges.update(m)
                    break
            else:
                ok = False
                break
        if not ok:
            continue
        adj = {v: [] for v in range(nv)}
        for a, b in edges:
            adj[a].append(b)
            adj[b].append(a)
        seen = {0}
        stack = [0]
        while stack:
            v = stack.pop()
            for u in adj[v]:
                if u not in seen:
                    seen.add(u)
                    stack.append(u)
        if len(seen) == nv:
            return sorted(edges)


def check_model(clauses, assignment):
    return all(any(bool(assignment[abs(l) - 1]) == (l > 0) for l in c) for c in clauses)


# ----------------------------------------------------------------------------- oracles

def gf2_consistent(nvars, equations):
    """Independent Gaussian elimination.  equations: list of (vars, parity)."""
    basis = {}                                   # highest bit -> (mask, parity)
    for vs, p in equations:
        m = 0
        for v in vs:
            m ^= 1 << v
        while m:
            top = m.bit_length() - 1
            r = basis.get(top)
            if r is None:
                basis[top] = (m, p)
                break
            m ^= r[0]
            p ^= r[1]
        else:
            if p:
                return False
    return True


def twosat(nvars, clauses):
    """Independent 2-SAT by iterative Kosaraju SCC.  Clauses of width 1 or 2."""
    n = 2 * nvars

    def idx(l):
        return 2 * (abs(l) - 1) + (0 if l > 0 else 1)

    adj = [[] for _ in range(n)]
    radj = [[] for _ in range(n)]
    for c in clauses:
        c = tuple(set(c))
        if len(c) == 1:
            a = b = c[0]
        elif len(c) == 2:
            a, b = c
        else:
            raise ValueError("not a 2-CNF")
        for x, y in ((-a, b), (-b, a)):
            adj[idx(x)].append(idx(y))
            radj[idx(y)].append(idx(x))
    order = []
    seen = [False] * n
    for s in range(n):
        if seen[s]:
            continue
        seen[s] = True
        stack = [(s, 0)]
        while stack:
            v, i = stack.pop()
            if i < len(adj[v]):
                stack.append((v, i + 1))
                u = adj[v][i]
                if not seen[u]:
                    seen[u] = True
                    stack.append((u, 0))
            else:
                order.append(v)
    comp = [-1] * n
    k = 0
    for s in reversed(order):
        if comp[s] != -1:
            continue
        comp[s] = k
        stack = [s]
        while stack:
            v = stack.pop()
            for u in radj[v]:
                if comp[u] == -1:
                    comp[u] = k
                    stack.append(u)
        k += 1
    return all(comp[2 * v] != comp[2 * v + 1] for v in range(nvars))


def hornsat(nvars, clauses):
    """Independent Horn-SAT: least model by forward chaining, then check."""
    true = [False] * (nvars + 1)
    changed = True
    while changed:
        changed = False
        for c in clauses:
            pos = [l for l in c if l > 0]
            if len(pos) > 1:
                raise ValueError("not Horn")
            if all(true[-l] for l in c if l < 0):
                if not pos:
                    return False
                if not true[pos[0]]:
                    true[pos[0]] = True
                    changed = True
    return True


def dpll(nvars, clauses, max_nodes=200000):
    """Independent DPLL with unit propagation (iterative).  Returns "SAT", "UNSAT" or
    None if the node limit is hit.  Used only to cross-check UNSAT claims."""
    clauses = [tuple(set(c)) for c in clauses]
    if any(len(c) == 0 for c in clauses):
        return "UNSAT"
    occ = {}
    for i, c in enumerate(clauses):
        for l in c:
            occ.setdefault(l, []).append(i)
    val = [0] * (nvars + 1)                      # 0 unassigned, 1 true, -1 false
    trail = []
    nodes = [0]

    def value(l):
        v = val[abs(l)]
        return v if l > 0 else -v

    def assign(l):
        """Assign and propagate; returns False on conflict."""
        queue = [l]
        while queue:
            x = queue.pop()
            vx = value(x)
            if vx == 1:
                continue
            if vx == -1:
                return False
            val[abs(x)] = 1 if x > 0 else -1
            trail.append(abs(x))
            for i in occ.get(-x, ()):
                free = None
                sat = False
                cnt = 0
                for m in clauses[i]:
                    vm = value(m)
                    if vm == 1:
                        sat = True
                        break
                    if vm == 0:
                        cnt += 1
                        free = m
                if sat:
                    continue
                if cnt == 0:
                    return False
                if cnt == 1:
                    queue.append(free)
        return True

    def undo(mark):
        while len(trail) > mark:
            val[trail.pop()] = 0

    for c in clauses:
        if len(c) == 1 and not assign(c[0]):
            return "UNSAT"
    stack = []                                    # (trail mark, literal to try next or None)
    while True:
        nodes[0] += 1
        if nodes[0] > max_nodes:
            return None
        # pick the unassigned variable in a shortest unsatisfied clause
        best = None
        best_len = 10 ** 9
        for c in clauses:
            cnt = 0
            sat = False
            pick = None
            for m in c:
                vm = value(m)
                if vm == 1:
                    sat = True
                    break
                if vm == 0:
                    cnt += 1
                    pick = m
            if not sat and cnt < best_len:
                best_len = cnt
                best = pick
                if cnt == 2:
                    break
        if best is None:
            return "SAT"
        mark = len(trail)
        stack.append((mark, -best))
        ok = assign(best)
        while not ok:
            while stack and stack[-1][1] is None:
                stack.pop()
            if not stack:
                return "UNSAT"
            mark, alt = stack.pop()
            undo(mark)
            stack.append((mark, None))
            ok = assign(alt)


# ----------------------------------------------------------------------------- S1 PHP

def php(h, pigeons=None, functional=False, onto=False):
    """Pigeonhole, var(i, k) = i*h + k + 1 (pigeon-major natural indices)."""
    p = h + 1 if pigeons is None else pigeons
    var = lambda i, k: i * h + k + 1
    clauses = [tuple(var(i, k) for k in range(h)) for i in range(p)]
    for k in range(h):
        for i in range(p):
            for j in range(i + 1, p):
                clauses.append((-var(i, k), -var(j, k)))
    if functional:
        for i in range(p):
            for k in range(h):
                for k2 in range(k + 1, h):
                    clauses.append((-var(i, k), -var(i, k2)))
    if onto:
        for k in range(h):
            clauses.append(tuple(var(i, k) for i in range(p)))
    meta = {"expected": "UNSAT" if p > h else "SAT",
            "expected_by": "pigeonhole principle (construction)"}
    return p * h, clauses, meta


def php_3cnf(h):
    """PHP(h+1, h) with every pigeon clause split into 3-clauses by a chain of fresh
    variables (standard equisatisfiable 3-CNF form)."""
    n, clauses, meta = php(h)
    out = []
    nxt = n
    for c in clauses:
        if len(c) <= 3:
            out.append(c)
            continue
        lits = list(c)
        nxt += 1
        out.append((lits[0], lits[1], nxt))
        for x in lits[2:-2]:
            out.append((-nxt, x, nxt + 1))
            nxt += 1
        out.append((-nxt, lits[-2], lits[-1]))
    return nxt, out, meta


# ----------------------------------------------------------------------------- S2 Tseitin

def tseitin_regular(nv, seed, odd=True, deg=3):
    rng = random.Random(seed)
    if deg == 3:
        edges = random_regular_graph(nv, deg, rng)
    else:
        edges = random_regular_by_matchings(nv, deg, rng)
    inc = [[] for _ in range(nv)]
    for i, (a, b) in enumerate(edges, 1):
        inc[a].append(i)
        inc[b].append(i)
    charge = [0] * nv
    if odd:
        charge[0] = 1
    clauses = []
    for v in range(nv):
        clauses += xor_clauses(inc[v], charge[v])
    meta = {"expected": "UNSAT" if odd else "SAT",
            "expected_by": "total charge parity on a connected graph (construction)",
            "edges": edges, "charge": charge}
    return len(edges), clauses, meta


def tseitin_plus_clauses(nv, seed, extra, odd):
    """Tseitin on a random cubic graph plus ``extra`` random 3-clauses on edge variables.
    Reference answer: enumerate the clause variables; with those edges fixed the parity
    system is consistent iff every component of the remaining graph has even charge."""
    ne, clauses, meta = tseitin_regular(nv, seed, odd)
    rng = random.Random(seed * 7919 + extra)
    added = []
    for _ in range(extra):
        vs = rng.sample(range(1, ne + 1), 3)
        added.append(tuple(v * rng.choice((1, -1)) for v in vs))
    edges = meta["edges"]
    charge = meta["charge"]
    cvars = sorted(set(abs(l) for c in added for l in c))
    expected = None
    if len(cvars) <= 18:
        expected = "UNSAT"
        fixed = set(cvars)
        adj = {v: [] for v in range(nv)}
        for i, (a, b) in enumerate(edges, 1):
            if i not in fixed:
                adj[a].append(b)
                adj[b].append(a)
        comp = [-1] * nv
        k = 0
        for s in range(nv):
            if comp[s] != -1:
                continue
            comp[s] = k
            stack = [s]
            while stack:
                v = stack.pop()
                for u in adj[v]:
                    if comp[u] == -1:
                        comp[u] = k
                        stack.append(u)
            k += 1
        for bits in itertools.product((0, 1), repeat=len(cvars)):
            a = dict(zip(cvars, bits))
            if not all(any(a[abs(l)] == (1 if l > 0 else 0) for l in c) for c in added):
                continue
            tot = [0] * k
            for v in range(nv):
                tot[comp[v]] ^= charge[v]
            for i in cvars:
                if a[i]:
                    x, y = edges[i - 1]
                    tot[comp[x]] ^= 1
                    tot[comp[y]] ^= 1
            if not any(tot):
                expected = "SAT"
                break
    meta = {"expected": expected,
            "expected_by": "enumeration of clause variables + component charge parity",
            "extra_clauses": added}
    return ne, clauses + added, meta


# ----------------------------------------------------------------------------- S3 3-XOR

def xor3(n, m, seed, planted):
    rng = random.Random(seed)
    sol = [rng.randrange(2) for _ in range(n + 1)]
    eqs = []
    clauses = []
    for _ in range(m):
        vs = rng.sample(range(1, n + 1), 3)
        p = (sol[vs[0]] ^ sol[vs[1]] ^ sol[vs[2]]) if planted else rng.randrange(2)
        eqs.append((vs, p))
        clauses += xor_clauses(vs, p)
    meta = {"expected": "SAT" if gf2_consistent(n, eqs) else "UNSAT",
            "expected_by": "independent GF(2) elimination on the generating equations"}
    return n, clauses, meta


def xork(n, m, seed, k, planted=True):
    """Random k-XOR system with m equations; for k > 6 the parity constraints are wider
    than the affine layer's detection window (64 clauses of width 7 per equation)."""
    rng = random.Random(seed)
    sol = [rng.randrange(2) for _ in range(n + 1)]
    eqs = []
    clauses = []
    for _ in range(m):
        vs = rng.sample(range(1, n + 1), k)
        p = 0
        for v in vs:
            p ^= sol[v]
        if not planted:
            p = rng.randrange(2)
        eqs.append((vs, p))
        clauses += xor_clauses(vs, p)
    meta = {"expected": "SAT" if gf2_consistent(n, eqs) else "UNSAT",
            "expected_by": "independent GF(2) elimination on the generating equations"}
    return n, clauses, meta


# ----------------------------------------------------------------------------- S4 mixed

def xorify(nvars, clauses):
    """Replace variable x by (a_x XOR b_x), a_x = 2x-1, b_x = 2x, and expand."""
    out = []
    for c in clauses:
        vs = [abs(l) for l in c]
        signs = [0 if l > 0 else 1 for l in c]           # literal false iff x == sign
        for bits in itertools.product((0, 1), repeat=len(c)):
            d = []
            for x, s, b in zip(vs, signs, bits):
                a_val, b_val = b, b ^ s                   # the falsifying pair (a, b)
                d.append(-(2 * x - 1) if a_val else (2 * x - 1))
                d.append(-(2 * x) if b_val else (2 * x))
            out.append(tuple(d))
    return 2 * nvars, out


def php_xor(h):
    n, clauses, meta = php(h)
    n2, c2 = xorify(n, clauses)
    return n2, c2, dict(meta, expected_by="XOR substitution preserves (un)satisfiability")


# ----------------------------------------------------------------------------- S5 random 3-CNF

def random_kcnf(n, ratio, seed, k=3):
    rng = random.Random(seed)
    m = int(round(ratio * n))
    clauses = [tuple(v * rng.choice((1, -1)) for v in rng.sample(range(1, n + 1), k))
               for _ in range(m)]
    return n, clauses, {"expected": None, "expected_by": None}


# ----------------------------------------------------------------------------- S6 easy classes

def selector(k):
    clauses = []
    for i in range(1, k + 1):
        clauses += [(i, k + i), (-i, 2 * k + i)]
    return 3 * k, clauses, {"expected": "SAT", "expected_by": "x=0, y=z=1 (construction)"}


def random_2cnf(n, ratio, seed):
    n, clauses, _ = random_kcnf(n, ratio, seed, k=2)
    return n, clauses, {"expected": "SAT" if twosat(n, clauses) else "UNSAT",
                        "expected_by": "independent SCC 2-SAT"}


def random_horn(n, ratio, seed, facts=None):
    """Random Horn 3-CNF: definite rules (-a -b c), goals (-a -b -c) and unit facts."""
    rng = random.Random(seed)
    m = int(round(ratio * n))
    clauses = []
    for _ in range(m):
        a, b, c = rng.sample(range(1, n + 1), 3)
        if rng.random() < 0.9:
            clauses.append((-a, -b, c))
        else:
            clauses.append((-a, -b, -c))
    for v in rng.sample(range(1, n + 1), facts if facts is not None else max(1, n // 20)):
        clauses.append((v,))
    return n, clauses, {"expected": "SAT" if hornsat(n, clauses) else "UNSAT",
                        "expected_by": "independent forward chaining"}


def random_horn_nofacts(n, ratio, seed):
    """Random Horn 3-CNF without unit clauses (always SAT by the all-false assignment),
    so unit propagation does nothing and the BDD phase gets the whole formula."""
    rng = random.Random(seed)
    m = int(round(ratio * n))
    clauses = []
    for _ in range(m):
        a, b, c = rng.sample(range(1, n + 1), 3)
        clauses.append((-a, -b, c) if rng.random() < 0.9 else (-a, -b, -c))
    return n, clauses, {"expected": "SAT", "expected_by": "all-false assignment (no positive unit)"}


# ----------------------------------------------------------------------------- extra obstacles

def chain_2cnf(n):
    """Implication chain x1 -> x2 -> ... -> xn plus (x1 or xn): trivially SAT 2-CNF."""
    clauses = [(-i, i + 1) for i in range(1, n)] + [(1, n)]
    return n, clauses, {"expected": "SAT", "expected_by": "all-true assignment"}


def tseitin_wide(nv, seed, deg=7):
    """Tseitin on a random deg-regular graph with deg > 6: parity constraints are wider
    than the affine layer's detection window."""
    return tseitin_regular(nv, seed, odd=True, deg=deg)


def mutilated_chessboard(n):
    """Domino tiling of the n x n board with two opposite corners removed (UNSAT)."""
    cells = [(r, c) for r in range(n) for c in range(n) if (r, c) not in ((0, 0), (n - 1, n - 1))]
    cellset = set(cells)
    edges = []
    for r, c in cells:
        for dr, dc in ((0, 1), (1, 0)):
            if (r + dr, c + dc) in cellset:
                edges.append(((r, c), (r + dr, c + dc)))
    inc = {cell: [] for cell in cells}
    for i, (a, b) in enumerate(edges, 1):
        inc[a].append(i)
        inc[b].append(i)
    clauses = []
    for cell in cells:
        vs = inc[cell]
        clauses.append(tuple(vs))
        for x, y in itertools.combinations(vs, 2):
            clauses.append((-x, -y))
    return len(edges), clauses, {"expected": "UNSAT", "expected_by": "colouring argument (construction)"}


def ordering_principle(n):
    """GT_n: a strict total order on n elements without a minimum (UNSAT, poly-size
    resolution refutations)."""
    var = {}
    k = 0
    for i in range(n):
        for j in range(n):
            if i != j:
                k += 1
                var[i, j] = k                               # x_ij: i < j
    clauses = []
    for i in range(n):
        for j in range(i + 1, n):
            clauses.append((var[i, j], var[j, i]))          # totality
            clauses.append((-var[i, j], -var[j, i]))        # antisymmetry
    for i in range(n):
        for j in range(n):
            for l in range(n):
                if len({i, j, l}) == 3:
                    clauses.append((-var[i, j], -var[j, l], var[i, l]))
    for j in range(n):
        clauses.append(tuple(var[i, j] for i in range(n) if i != j))   # j is not minimal
    return k, clauses, {"expected": "UNSAT", "expected_by": "finite strict orders have minima"}


def parity_chain_and(n, seed):
    """Random 3-XOR system (m = n, planted) with every variable also forced into one
    random 3-clause satisfied by the planted solution: affine + clauses on ALL variables."""
    rng = random.Random(seed)
    sol = [rng.randrange(2) for _ in range(n + 1)]
    clauses = []
    for _ in range(n // 2):
        vs = rng.sample(range(1, n + 1), 3)
        clauses += xor_clauses(vs, sol[vs[0]] ^ sol[vs[1]] ^ sol[vs[2]])
    for _ in range(n):
        vs = rng.sample(range(1, n + 1), 3)
        c = [v * rng.choice((1, -1)) for v in vs]
        if not any(sol[abs(l)] == (1 if l > 0 else 0) for l in c):
            c[0] = -c[0]
        clauses.append(tuple(c))
    return n, clauses, {"expected": "SAT", "expected_by": "planted assignment"}


FAMILIES = {
    "php": lambda size, seed: php(size),
    "fphp": lambda size, seed: php(size, functional=True),
    "ophp": lambda size, seed: php(size, onto=True),
    "ofphp": lambda size, seed: php(size, functional=True, onto=True),
    "php2": lambda size, seed: php(size, pigeons=2 * size),
    "php3cnf": lambda size, seed: php_3cnf(size),
    "phpxor": lambda size, seed: php_xor(size),
    "tseitin": lambda size, seed: tseitin_regular(size, seed, odd=True),
    "tseitin_sat": lambda size, seed: tseitin_regular(size, seed, odd=False),
    "tseitin7": lambda size, seed: tseitin_wide(size, seed, 7),
    "tseitin_c3": lambda size, seed: tseitin_plus_clauses(size, seed, 3, odd=False),
    "tseitin_c5": lambda size, seed: tseitin_plus_clauses(size, seed, 5, odd=False),
    "tseitin_c3_odd": lambda size, seed: tseitin_plus_clauses(size, seed, 3, odd=True),
    "xor3_planted": lambda size, seed: xor3(size, size, seed, planted=True),
    "xor7_planted": lambda size, seed: xork(size, size, seed, 7, planted=True),
    "xor6_planted": lambda size, seed: xork(size, size, seed, 6, planted=True),
    "xor3_random": lambda size, seed: xor3(size, size + 5, seed, planted=False),
    "r3_426": lambda size, seed: random_kcnf(size, 4.26, seed),
    "r3_300": lambda size, seed: random_kcnf(size, 3.0, seed),
    "selector": lambda size, seed: selector(size),
    "r2_090": lambda size, seed: random_2cnf(size, 0.9, seed),
    "r2_150": lambda size, seed: random_2cnf(size, 1.5, seed),
    "horn": lambda size, seed: random_horn(size, 3.0, seed),
    "horn_nofacts": lambda size, seed: random_horn_nofacts(size, 3.0, seed),
    "chain2": lambda size, seed: chain_2cnf(size),
    "chessboard": lambda size, seed: mutilated_chessboard(size),
    "ordering": lambda size, seed: ordering_principle(size),
    "xor_and": lambda size, seed: parity_chain_and(size, seed),
}


def make(family, size, seed=0, renamed=None):
    """Instance by name.  ``renamed`` = seed of a variable renaming + clause shuffle."""
    nvars, clauses, meta = FAMILIES[family](size, seed)
    meta = dict(meta)
    meta.pop("edges", None)
    meta.pop("charge", None)
    meta.pop("extra_clauses", None)
    if renamed is not None:
        clauses, _ = rename_shuffle(nvars, clauses, renamed)
    return nvars, [tuple(c) for c in clauses], meta
