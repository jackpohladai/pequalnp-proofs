# CFPE scaling tables (generated from experiments/scaling.jsonl)

1324 runs, 0 wrong answers.  Finite experiments. Fitted rates are empirical descriptions, not asymptotic claims; CAP/TIMEOUT rows are neither refutations nor lower bounds.
Limits per run: 30 s wall clock (solver deadline 20 s), 1.5 M BDD nodes (portfolio: 750 k per strategy), residual DAG 400 k nodes.  'TIMEOUT' = the wall-clock deadline was hit; compare the cpu and wall columns: the machine was heavily loaded by other jobs.

## Group C

### C.chessboard.cap50k

| board | nvars | N bits | solved/runs | status | ticks (median) | ticks (max) | BDD nodes (median) | largest bucket | residual vars | decided by | winner | cpu s (max) | wall s (max) | RSS MB |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 4 | 20 | 1538 | 1/1 | UNSAT | 12311 | 12311 | 295 | 17 | 14 | bdd_false | wide+mindeg | 0.025 | 0.36 | 26.9 |
| 6 | 56 | 5798 | 1/1 | UNSAT | 58196 | 58196 | 1748 | 47 | 50 | bdd_false | wide+mindeg | 0.032 | 0.251 | 27.6 |
| 8 | 108 | 13076 | 1/1 | UNSAT | 151025 | 151025 | 6681 | 163 | 102 | bdd_false | wide+mindeg | 0.054 | 0.912 | 27.6 |
| 10 | 176 | 23584 | 1/1 | UNSAT | 311668 | 311668 | 18700 | 525 | 170 | bdd_false | wide+mindeg | 0.099 | 0.992 | 29.6 |
| 12 | 260 | 37180 | 1/1 | UNSAT | 545436 | 545436 | 41880 | 997 | 254 | bdd_false | wide+mindeg | 0.172 | 1.89 | 33 |
| 14 | - | - | 0/1 | CAP | - | - | - | - | - | - | - | - | - | - |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^1.19 (R2 1.000, 5 sizes); exponential cost ~ 2^(0.6680 * board) (R2 0.959); nodes ~ N^1.56 (R2 0.996); nodes ~ 2^(0.8859 * board) (R2 0.976); local log-log slopes (cost vs N) between consecutive sizes: [1.17, 1.17, 1.23, 1.23].
Largest board solved by all runs: 12; by at least one run: 12; first board with a failure: 14; wrong answers: 0; UNSAT answers without an independent reference: 0.

### C.horn.cap50k

| n | nvars | N bits | solved/runs | status | ticks (median) | ticks (max) | BDD nodes (median) | largest bucket | residual vars | decided by | winner | cpu s (max) | wall s (max) | RSS MB |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 20 | 20 | 2198 | 5/5 | SAT | 23488 | 26138 | 1005 | 213 | 19 | bdd_sat | wide+mindeg | 0.032 | 0.672 | 27.2 |
| 25 | 25 | 2856 | 5/5 | SAT | 35507 | 40301 | 1901 | 334 | 24 | bdd_sat | wide+mindeg | 0.039 | 0.586 | 27.4 |
| 30 | 30 | 3504 | 5/5 | SAT | 74920 | 82551 | 9701 | 2045 | 29 | bdd_sat | wide+mindeg | 0.065 | 1.24 | 29.3 |
| 35 | 35 | 4244 | 5/5 | SAT | 168205 | 174074 | 28589 | 5600 | 34 | bdd_sat | wide+mindeg | 0.138 | 1.29 | 34.4 |
| 40 | 40 | 5040 | 5/5 | SAT | 140647 | 159777 | 21797 | 5574 | 38 | bdd_sat | wide+mindeg | 0.106 | 1.1 | 33.6 |
| 45 | 45 | 5762 | 2/5 | SAT + CAP | 1.68e+05 | 183857 | 2.51e+04 | 6061 | 42.5 | bdd_sat | wide+mindeg | 0.126 | 2.11 | 32 |
| 50 | 50 | 6550 | 1/5 | SAT + CAP | 242145 | 242145 | 44101 | 7516 | 48 | bdd_sat | wide+mindeg | 0.175 | 1.54 | 32.8 |
| 55 | - | - | 0/5 | CAP | - | - | - | - | - | - | - | - | - | - |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^2.51 (R2 0.919, 5 sizes); exponential cost ~ 2^(0.1482 * n) (R2 0.906); nodes ~ N^4.34 (R2 0.908); nodes ~ 2^(0.2558 * n) (R2 0.891); local log-log slopes (cost vs N) between consecutive sizes: [1.58, 3.65, 4.22, -1.04].
Largest n solved by all runs: 40; by at least one run: 50; first n with a failure: 45; wrong answers: 0; UNSAT answers without an independent reference: 0.

### C.horn_nofacts.cap50k

| n | nvars | N bits | solved/runs | status | ticks (median) | ticks (max) | BDD nodes (median) | largest bucket | residual vars | decided by | winner | cpu s (max) | wall s (max) | RSS MB |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 16 | 16 | 1636 | 5/5 | SAT | 19095 | 21187 | 911 | 115 | 16 | bdd_sat | wide+mindeg | 0.033 | 0.731 | 27.3 |
| 18 | 18 | 1914 | 5/5 | SAT | 23374 | 23581 | 1429 | 225 | 18 | bdd_sat | wide+mindeg | 0.032 | 0.515 | 27.3 |
| 20 | 20 | 2182 | 5/5 | SAT | 25742 | 30485 | 1626 | 412 | 20 | bdd_sat | wide+mindeg | 0.037 | 0.842 | 27.5 |
| 22 | 22 | 2448 | 5/5 | SAT | 36305 | 38203 | 2996 | 462 | 22 | bdd_sat | wide+mindeg | 0.04 | 0.408 | 27.6 |
| 24 | 24 | 2720 | 5/5 | SAT | 40726 | 59105 | 3178 | 513 | 24 | bdd_sat | wide+mindeg | 0.053 | 0.551 | 28 |
| 26 | 26 | 2972 | 5/5 | SAT | 48845 | 61985 | 4675 | 1184 | 26 | bdd_sat | wide+mindeg | 0.049 | 0.646 | 28.6 |
| 28 | 28 | 3218 | 5/5 | SAT | 58830 | 87857 | 6534 | 1997 | 28 | bdd_sat | wide+mindeg | 0.075 | 0.893 | 28.3 |
| 30 | 30 | 3490 | 5/5 | SAT | 83106 | 107831 | 11352 | 2904 | 30 | bdd_sat | wide+mindeg | 0.083 | 1.29 | 28.8 |
| 32 | 32 | 3766 | 5/5 | SAT | 132154 | 156667 | 21299 | 3810 | 32 | bdd_sat | wide+mindeg | 0.121 | 1.56 | 31.1 |
| 34 | 34 | 4078 | 5/5 | SAT | 83799 | 172478 | 11262 | 7293 | 34 | bdd_sat | wide+mindeg | 0.133 | 1.36 | 32.1 |
| 36 | 36 | 4386 | 4/5 | SAT + CAP | 2.15e+05 | 259659 | 42163 | 6298 | 36 | bdd_sat | wide+mindeg | 0.232 | 9.44 | 34.9 |
| 38 | 38 | 4718 | 3/5 | SAT + CAP | 185272 | 208474 | 31216 | 7959 | 38 | bdd_sat | wide+mindeg | 0.172 | 1.91 | 35.2 |
| 40 | 40 | 5014 | 3/5 | SAT + CAP | 202873 | 225896 | 34992 | 6557 | 40 | bdd_sat | wide+mindeg | 0.184 | 2.63 | 32.1 |
| 42 | 42 | 5259 | 2/5 | SAT + CAP | 243803 | 268552 | 4.32e+04 | 12525 | 42 | bdd_sat | wide+mindeg | 0.224 | 2.77 | 34.8 |
| 44 | - | - | 0/5 | CAP | - | - | - | - | - | - | - | - | - | - |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^2.00 (R2 0.917, 10 sizes); exponential cost ~ 2^(0.1440 * n) (R2 0.932); nodes ~ N^3.29 (R2 0.930); nodes ~ 2^(0.2360 * n) (R2 0.940); local log-log slopes (cost vs N) between consecutive sizes: [1.29, 0.74, 2.99, 1.09, 2.05, 2.34, 4.26, 6.09, -5.72].
Largest n solved by all runs: 34; by at least one run: 42; first n with a failure: 36; wrong answers: 0; UNSAT answers without an independent reference: 0.

### C.ordering.cap50k

| elements | nvars | N bits | solved/runs | status | ticks (median) | ticks (max) | BDD nodes (median) | largest bucket | residual vars | decided by | winner | cpu s (max) | wall s (max) | RSS MB |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 4 | 12 | 1178 | 1/1 | UNSAT | 4064 | 4064 | 109 | 11 | 6 | bdd_false | wide+mindeg | 0.022 | 0.205 | 27.1 |
| 5 | 20 | 2906 | 1/1 | UNSAT | 10582 | 10582 | 378 | 35 | 10 | bdd_false | wide+mindeg | 0.026 | 0.372 | 26.9 |
| 6 | 30 | 5832 | 1/1 | UNSAT | 25154 | 25154 | 1577 | 147 | 15 | bdd_false | wide+mindeg | 0.031 | 0.427 | 27.2 |
| 7 | 42 | 10562 | 1/1 | UNSAT | 63265 | 63265 | 6951 | 733 | 21 | bdd_false | wide+mindeg | 0.047 | 0.547 | 27.9 |
| 8 | 56 | 17222 | 1/1 | UNSAT | 172630 | 172630 | 29111 | 2583 | 28 | bdd_false | wide+mindeg | 0.103 | 1.27 | 31.4 |
| 9 | - | - | 0/1 | CAP | - | - | - | - | - | - | - | - | - | - |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^1.37 (R2 0.983, 5 sizes); exponential cost ~ 2^(1.3397 * elements) (R2 0.999); nodes ~ N^2.08 (R2 0.979); nodes ~ 2^(2.0323 * elements) (R2 0.999); local log-log slopes (cost vs N) between consecutive sizes: [1.06, 1.24, 1.55, 2.05].
Largest elements solved by all runs: 8; by at least one run: 8; first elements with a failure: 9; wrong answers: 0; UNSAT answers without an independent reference: 0.

### C.php.portfolio.cap50k

| h | nvars | N bits | solved/runs | status | ticks (median) | ticks (max) | BDD nodes (median) | largest bucket | residual vars | decided by | winner | cpu s (max) | wall s (max) | RSS MB |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 3 | 12 | 532 | 1/1 | UNSAT | 5848 | 5848 | 248 | 20 | 12 | bdd_false | wide+mindeg | 0.024 | 0.485 | 27 |
| 4 | 20 | 1230 | 1/1 | UNSAT | 16695 | 16695 | 1058 | 73 | 20 | bdd_false | wide+cross | 0.03 | 0.133 | 27 |
| 5 | 30 | 2370 | 1/1 | UNSAT | 35956 | 35956 | 2832 | 400 | 30 | bdd_false | wide+cross | 0.035 | 0.57 | 27.6 |
| 6 | 42 | 4172 | 1/1 | UNSAT | 70037 | 70037 | 6069 | 1432 | 42 | bdd_false | wide+cross | 0.046 | 0.562 | 28.2 |
| 7 | 56 | 6664 | 1/1 | UNSAT | 128281 | 128281 | 14554 | 4401 | 56 | bdd_false | wide+cross | 0.061 | 0.553 | 29.9 |
| 8 | 72 | 10098 | 1/1 | UNSAT | 185560 | 185560 | 13953 | 1250 | 72 | bdd_false | wide+cross | 0.083 | 1.17 | 29.6 |
| 9 | 90 | 14630 | 1/1 | UNSAT | 273193 | 273193 | 22627 | 1349 | 90 | bdd_false | wide+cross | 0.114 | 1.2 | 31.6 |
| 10 | 110 | 20262 | 1/1 | UNSAT | 414125 | 414125 | 34783 | 1736 | 110 | bdd_false | wide+cross | 0.151 | 0.897 | 34.6 |
| 11 | 132 | 27228 | 1/1 | UNSAT | 579632 | 579632 | 48866 | 1835 | 132 | bdd_false | wide+cross | 0.194 | 1.32 | 35.7 |
| 12 | - | - | 0/1 | CAP | - | - | - | - | - | - | - | - | - | - |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^1.16 (R2 0.999, 9 sizes); exponential cost ~ 2^(0.7946 * h) (R2 0.963); nodes ~ N^1.30 (R2 0.981); nodes ~ 2^(0.8801 * h) (R2 0.919); local log-log slopes (cost vs N) between consecutive sizes: [1.25, 1.17, 1.18, 1.29, 0.89, 1.04, 1.28, 1.14].
Largest h solved by all runs: 11; by at least one run: 11; first h with a failure: 12; wrong answers: 0; UNSAT answers without an independent reference: 0.

### C.php.wide+mindeg.cap50k

| h | nvars | N bits | solved/runs | status | ticks (median) | ticks (max) | BDD nodes (median) | largest bucket | residual vars | decided by | winner | cpu s (max) | wall s (max) | RSS MB |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 3 | 12 | 532 | 1/1 | UNSAT | 3198 | 3198 | 151 | 20 | 12 | bdd_false | wide+mindeg | 0.024 | 0.208 | 26.9 |
| 4 | 20 | 1230 | 1/1 | UNSAT | 9052 | 9052 | 663 | 73 | 20 | bdd_false | wide+mindeg | 0.025 | 0.036 | 27 |
| 5 | 30 | 2370 | 1/1 | UNSAT | 24253 | 24253 | 2688 | 400 | 30 | bdd_false | wide+mindeg | 0.037 | 0.453 | 27.3 |
| 6 | 42 | 4172 | 1/1 | UNSAT | 61564 | 61564 | 7128 | 1432 | 42 | bdd_false | wide+mindeg | 0.051 | 0.58 | 27.8 |
| 7 | 56 | 6664 | 1/1 | UNSAT | 161111 | 161111 | 26088 | 4401 | 56 | bdd_false | wide+mindeg | 0.109 | 1.12 | 32.2 |
| 8 | - | - | 0/1 | CAP | - | - | - | - | - | - | - | - | - | - |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^1.54 (R2 0.991, 5 sizes); exponential cost ~ 2^(1.4075 * h) (R2 1.000); nodes ~ N^2.01 (R2 0.995); nodes ~ 2^(1.8292 * h) (R2 0.995); local log-log slopes (cost vs N) between consecutive sizes: [1.24, 1.5, 1.65, 2.05].
Largest h solved by all runs: 7; by at least one run: 7; first h with a failure: 8; wrong answers: 0; UNSAT answers without an independent reference: 0.

### C.php3cnf.cap50k

| h | nvars | N bits | solved/runs | status | ticks (median) | ticks (max) | BDD nodes (median) | largest bucket | residual vars | decided by | winner | cpu s (max) | wall s (max) | RSS MB |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 4 | 25 | 1380 | 1/1 | UNSAT | 18624 | 18624 | 1195 | 73 | 25 | bdd_false | wide+mindeg | 0.028 | 0.187 | 27.2 |
| 6 | 63 | 4886 | 1/1 | UNSAT | 89285 | 89285 | 8264 | 1432 | 63 | bdd_false | wide+cross | 0.056 | 0.503 | 28.4 |
| 8 | 117 | 11808 | 1/1 | UNSAT | 240815 | 240815 | 22292 | 3944 | 117 | bdd_false | wide+cross | 0.108 | 1.02 | 31.5 |
| 10 | 187 | 23428 | 1/1 | UNSAT | 491833 | 491833 | 41874 | 1736 | 187 | bdd_false | wide+cross | 0.171 | 1.72 | 33.8 |
| 12 | - | - | 0/1 | CAP | - | - | - | - | - | - | - | - | - | - |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^1.16 (R2 0.999, 4 sizes); exponential cost ~ 2^(0.7800 * h) (R2 0.969); nodes ~ N^1.26 (R2 0.988); nodes ~ 2^(0.8412 * h) (R2 0.939); local log-log slopes (cost vs N) between consecutive sizes: [1.24, 1.12, 1.04].
Largest h solved by all runs: 10; by at least one run: 10; first h with a failure: 12; wrong answers: 0; UNSAT answers without an independent reference: 0.

### C.r2_0.9.cap50k

| n | nvars | N bits | solved/runs | status | ticks (median) | ticks (max) | BDD nodes (median) | largest bucket | residual vars | decided by | winner | cpu s (max) | wall s (max) | RSS MB |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 400 | 400 | 14798 | 3/3 | SAT | 115795 | 117323 | 1552 | 5 | 332 | bdd_sat | wide+mindeg | 0.047 | 0.693 | 27.7 |
| 800 | 800 | 32392 | 3/3 | SAT | 250896 | 255637 | 3119 | 5 | 672 | bdd_sat | wide+mindeg | 0.066 | 0.945 | 28.6 |
| 1600 | 1600 | 70370 | 3/3 | SAT | 540854 | 541690 | 6267 | 5 | 1328 | bdd_sat | wide+mindeg | 0.107 | 1.32 | 31.3 |
| 3200 | 3200 | 152672 | 3/3 | SAT | 1159615 | 1159971 | 12523 | 5 | 2681 | bdd_sat | wide+mindeg | 0.199 | 1.85 | 35.9 |
| 6400 | 6400 | 327924 | 3/3 | SAT | 2473429 | 2514167 | 25012 | 5 | 5359 | bdd_sat | wide+mindeg | 0.369 | 3.08 | 44.9 |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^0.99 (R2 1.000, 5 sizes); exponential cost ~ 2^(0.0007 * n) (R2 0.868); nodes ~ N^0.90 (R2 1.000); nodes ~ 2^(0.0006 * n) (R2 0.870); local log-log slopes (cost vs N) between consecutive sizes: [0.99, 0.99, 0.98, 0.99].
Largest n solved by all runs: 6400; by at least one run: 6400; first n with a failure: None; wrong answers: 0; UNSAT answers without an independent reference: 0.

### C.r2_1.5.cap50k

| n | nvars | N bits | solved/runs | status | ticks (median) | ticks (max) | BDD nodes (median) | largest bucket | residual vars | decided by | winner | cpu s (max) | wall s (max) | RSS MB |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 100 | 100 | 5006 | 5/5 | SAT,UNSAT | 45529 | 46578 | 814 | 12 | 95 | bdd_false,bdd_sat | wide+mindeg | 0.034 | 0.5 | 27.4 |
| 200 | 200 | 11132 | 5/5 | UNSAT | 100055 | 102852 | 1732 | 28 | 189 | bdd_false | wide+mindeg | 0.042 | 0.752 | 27.4 |
| 300 | 300 | 17706 | 5/5 | UNSAT | 155374 | 159571 | 2997 | 83 | 284 | bdd_false | wide+mindeg | 0.058 | 0.664 | 27.8 |
| 400 | 400 | 24598 | 5/5 | UNSAT | 223954 | 232973 | 3753 | 143 | 381 | bdd_false | wide+mindeg | 0.065 | 0.744 | 28.5 |
| 500 | 500 | 31556 | 5/5 | UNSAT | 286716 | 297737 | 5246 | 243 | 474 | bdd_false | wide+mindeg | 0.074 | 0.963 | 29.3 |
| 600 | 600 | 38916 | 5/5 | UNSAT | 362032 | 432431 | 9090 | 1450 | 571 | bdd_false | wide+mindeg | 0.129 | 1.46 | 30.8 |
| 700 | 700 | 46376 | 5/5 | UNSAT | 434291 | 446044 | 7395 | 256 | 667 | bdd_false | wide+mindeg | 0.102 | 1.45 | 28.2 |
| 800 | 800 | 53902 | 5/5 | UNSAT | 494883 | 580699 | 11606 | 1674 | 757 | bdd_false | wide+mindeg | 0.182 | 1.77 | 32.6 |
| 1000 | 1000 | 69032 | 4/5 | UNSAT + CAP | 704005 | 745658 | 2.6e+04 | 2555 | 945 | bdd_false | wide+mindeg | 0.275 | 10.6 | 32.4 |
| 1200 | 1200 | 84971 | 2/5 | UNSAT + CAP | 824310 | 827733 | 30976 | 3850 | 1.14e+03 | bdd_false | wide+mindeg | 0.221 | 2.81 | 34 |
| 1400 | 1400 | 101288 | 1/5 | UNSAT + CAP | 950199 | 950199 | 22231 | 1520 | 1336 | bdd_false | wide+mindeg | 0.198 | 2.51 | 32 |
| 1600 | - | - | 0/5 | CAP | - | - | - | - | - | - | - | - | - | - |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^1.01 (R2 1.000, 8 sizes); exponential cost ~ 2^(0.0046 * n) (R2 0.924); nodes ~ N^1.10 (R2 0.976); nodes ~ 2^(0.0051 * n) (R2 0.929); local log-log slopes (cost vs N) between consecutive sizes: [0.99, 0.95, 1.11, 0.99, 1.11, 1.04, 0.87].
Largest n solved by all runs: 800; by at least one run: 1400; first n with a failure: 1000; wrong answers: 0; UNSAT answers without an independent reference: 0.

### C.r3_3.00.cap50k

| n | nvars | N bits | solved/runs | status | ticks (median) | ticks (max) | BDD nodes (median) | largest bucket | residual vars | decided by | winner | cpu s (max) | wall s (max) | RSS MB |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 16 | 16 | 1650 | 5/5 | SAT | 21249 | 22529 | 1460 | 147 | 16 | bdd_sat | wide+cross,wide+mindeg | 0.031 | 0.919 | 27.2 |
| 20 | 20 | 2186 | 5/5 | SAT | 32799 | 34377 | 3269 | 427 | 20 | bdd_sat | wide+mindeg | 0.037 | 0.719 | 27.5 |
| 24 | 24 | 2680 | 5/5 | SAT | 47880 | 55678 | 5188 | 748 | 24 | bdd_sat | wide+cross,wide+mindeg | 0.051 | 0.881 | 28 |
| 28 | 28 | 3204 | 5/5 | SAT | 88279 | 96116 | 13136 | 2218 | 28 | bdd_sat | wide+cross,wide+mindeg | 0.078 | 1.41 | 30.1 |
| 32 | 32 | 3766 | 5/5 | SAT | 174417 | 236091 | 32789 | 6562 | 32 | bdd_sat | wide+cross,wide+mindeg | 0.171 | 1.61 | 35.5 |
| 36 | 36 | 4336 | 1/5 | SAT + CAP | 179956 | 179956 | 33940 | 4070 | 36 | bdd_sat | wide+mindeg | 0.136 | 1.48 | 31.7 |
| 40 | - | - | 0/5 | CAP | - | - | - | - | - | - | - | - | - | - |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^2.49 (R2 0.949, 5 sizes); exponential cost ~ 2^(0.1876 * n) (R2 0.985); nodes ~ N^3.67 (R2 0.963); nodes ~ 2^(0.2746 * n) (R2 0.988); local log-log slopes (cost vs N) between consecutive sizes: [1.54, 1.86, 3.43, 4.21].
Largest n solved by all runs: 32; by at least one run: 36; first n with a failure: 36; wrong answers: 0; UNSAT answers without an independent reference: 0.

### C.r3_4.26.cap50k

| n | nvars | N bits | solved/runs | status | ticks (median) | ticks (max) | BDD nodes (median) | largest bucket | residual vars | decided by | winner | cpu s (max) | wall s (max) | RSS MB |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 16 | 16 | 2342 | 5/5 | SAT,UNSAT | 31682 | 34045 | 1920 | 200 | 16 | bdd_false,bdd_sat | wide+mindeg | 0.037 | 0.495 | 27.4 |
| 18 | 18 | 2714 | 5/5 | SAT,UNSAT | 35669 | 37510 | 2221 | 188 | 18 | bdd_false,bdd_sat | wide+mindeg | 0.036 | 0.7 | 27.4 |
| 20 | 20 | 3092 | 5/5 | SAT,UNSAT | 47114 | 49967 | 4059 | 491 | 20 | bdd_false,bdd_sat | wide+cross,wide+mindeg | 0.042 | 0.822 | 27.8 |
| 22 | 22 | 3480 | 5/5 | SAT,UNSAT | 59859 | 66274 | 6040 | 793 | 22 | bdd_false,bdd_sat | wide+cross,wide+mindeg | 0.051 | 0.647 | 28.9 |
| 24 | 24 | 3826 | 5/5 | SAT,UNSAT | 74508 | 80815 | 9224 | 1177 | 24 | bdd_false,bdd_sat | wide+cross,wide+mindeg | 0.062 | 1.02 | 29.2 |
| 26 | 26 | 4226 | 5/5 | SAT,UNSAT | 78627 | 90726 | 9219 | 1233 | 26 | bdd_false,bdd_sat | wide+cross,wide+mindeg | 0.061 | 0.599 | 29.5 |
| 28 | 28 | 4556 | 5/5 | SAT,UNSAT | 109246 | 123545 | 16243 | 2471 | 28 | bdd_false,bdd_sat | wide+cross,wide+mindeg | 0.088 | 1.47 | 30.9 |
| 30 | 30 | 4956 | 5/5 | SAT | 159396 | 205271 | 23454 | 3765 | 30 | bdd_sat | wide+mindeg | 0.148 | 1.98 | 31.3 |
| 32 | 32 | 5329 | 4/5 | SAT,UNSAT + CAP | 185113 | 206126 | 3.05e+04 | 10459 | 32 | bdd_false,bdd_sat | wide+cross,wide+mindeg | 0.147 | 2.73 | 32.2 |
| 34 | 34 | 5786 | 3/5 | SAT,UNSAT + CAP | 209566 | 251628 | 37258 | 7083 | 34 | bdd_false,bdd_sat | wide+cross,wide+mindeg | 0.185 | 2.39 | 33.7 |
| 36 | 36 | 6158 | 1/5 | SAT + CAP | 245988 | 245988 | 38636 | 7865 | 36 | bdd_sat | wide+mindeg | 0.18 | 1.8 | 32.9 |
| 38 | 38 | 6572 | 1/5 | SAT + CAP | 263339 | 263339 | 47813 | 9354 | 38 | bdd_sat | wide+cross | 0.199 | 2.67 | 34.7 |
| 40 | - | - | 0/5 | CAP | - | - | - | - | - | - | - | - | - | - |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^2.06 (R2 0.954, 8 sizes); exponential cost ~ 2^(0.1603 * n) (R2 0.980); nodes ~ N^3.39 (R2 0.972); nodes ~ 2^(0.2606 * n) (R2 0.980); local log-log slopes (cost vs N) between consecutive sizes: [0.8, 2.13, 2.03, 2.31, 0.54, 4.37, 4.49].
Largest n solved by all runs: 30; by at least one run: 38; first n with a failure: 32; wrong answers: 0; UNSAT answers without an independent reference: 0.

### C.tseitin_deg7.cap50k

| vertices | nvars | N bits | solved/runs | status | ticks (median) | ticks (max) | BDD nodes (median) | largest bucket | residual vars | decided by | winner | cpu s (max) | wall s (max) | RSS MB |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 10 | 35 | 58368 | 2/2 | UNSAT | 601652 | 602287 | 9526 | 77 | 35 | bdd_false | wide+mindeg | 0.095 | 2.15 | 28.2 |
| 12 | 42 | 72960 | 2/2 | UNSAT | 7.21e+05 | 721711 | 11208 | 83 | 42 | bdd_false | wide+mindeg | 0.115 | 5.74 | 30.3 |
| 14 | 49 | 87552 | 2/2 | UNSAT | 8.42e+05 | 842982 | 13523 | 103 | 49 | bdd_false | wide+mindeg | 0.128 | 1.74 | 30.9 |
| 16 | 56 | 102144 | 2/2 | UNSAT | 1034786 | 1035789 | 15143 | 115 | 56 | bdd_false | wide+mindeg | 0.132 | 1.96 | 31.6 |
| 18 | 63 | 116736 | 2/2 | UNSAT | 1.16e+06 | 1162224 | 15818 | 123 | 63 | bdd_false | wide+mindeg | 0.14 | 1.56 | 32 |
| 20 | 70 | 133120 | 2/2 | UNSAT | 1.31e+06 | 1306303 | 17973 | 135 | 70 | bdd_false | wide+mindeg | 0.146 | 1.85 | 31.5 |
| 24 | 84 | 165888 | 2/2 | UNSAT | 1567710 | 1567835 | 21703 | 145 | 84 | bdd_false | wide+mindeg | 0.2 | 3.5 | 32.4 |
| 30 | 105 | 215040 | 2/2 | UNSAT | 1960253 | 1960422 | 27203 | 181 | 105 | bdd_false | wide+mindeg | 0.245 | 2.65 | 33.7 |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^0.93 (R2 0.997, 8 sizes); exponential cost ~ 2^(0.0852 * vertices) (R2 0.960); nodes ~ N^0.79 (R2 0.995); nodes ~ 2^(0.0735 * vertices) (R2 0.973); local log-log slopes (cost vs N) between consecutive sizes: [0.81, 0.85, 1.33, 0.87, 0.89, 0.83, 0.86].
Largest vertices solved by all runs: 30; by at least one run: 30; first vertices with a failure: None; wrong answers: 0; UNSAT answers without an independent reference: 0.

### C.xor7_planted.cap50k

| n | nvars | N bits | solved/runs | status | ticks (median) | ticks (max) | BDD nodes (median) | largest bucket | residual vars | decided by | winner | cpu s (max) | wall s (max) | RSS MB |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 10 | 10 | 45440 | 5/5 | SAT | 611879 | 614516 | 6405 | 77 | 10 | bdd_sat | wide+mindeg | 0.079 | 1.15 | 29.4 |
| 12 | 12 | 56832 | 5/5 | SAT | 743373 | 744804 | 10320 | 125 | 12 | bdd_sat | wide+mindeg | 0.089 | 1.87 | 29.7 |
| 14 | 14 | 67328 | 5/5 | SAT | 877034 | 887469 | 14899 | 317 | 14 | bdd_sat | wide+mindeg | 0.111 | 1.6 | 30.2 |
| 16 | 16 | 78592 | 5/5 | SAT | 1087109 | 1097101 | 19418 | 413 | 16 | bdd_sat | wide+mindeg | 0.126 | 2.2 | 32 |
| 18 | 18 | 92544 | 5/5 | SAT | 1235830 | 1255634 | 23527 | 509 | 18 | bdd_sat | wide+mindeg | 0.148 | 3.16 | 31.5 |
| 20 | 20 | 105344 | 5/5 | SAT | 1392516 | 1405187 | 31231 | 769 | 20 | bdd_sat | wide+mindeg | 0.182 | 3.24 | 34.1 |
| 22 | 22 | 119168 | 4/5 | SAT + CAP | 1538942 | 1561926 | 4.06e+04 | 1277 | 22 | bdd_sat | wide+mindeg | 0.2 | 3.69 | 36 |
| 24 | 24 | 130624 | 4/5 | SAT + CAP | 1.67e+06 | 1691811 | 30473 | 1533 | 24 | bdd_sat | wide+mindeg | 0.204 | 2.9 | 36.2 |
| 26 | 26 | 144768 | 1/5 | SAT + CAP | 1836250 | 1836250 | 46197 | 1093 | 26 | bdd_sat | wide+mindeg | 0.24 | 4.26 | 33 |
| 28 | - | - | 0/5 | CAP | - | - | - | - | - | - | - | - | - | - |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^1.00 (R2 0.995, 6 sizes); exponential cost ~ 2^(0.1206 * n) (R2 0.991); nodes ~ N^1.84 (R2 0.992); nodes ~ 2^(0.2197 * n) (R2 0.976); local log-log slopes (cost vs N) between consecutive sizes: [0.87, 0.98, 1.39, 0.78, 0.92].
Largest n solved by all runs: 20; by at least one run: 26; first n with a failure: 22; wrong answers: 0; UNSAT answers without an independent reference: 0.

### C.xor_and.cap50k

| n | nvars | N bits | solved/runs | status | ticks (median) | ticks (max) | BDD nodes (median) | largest bucket | residual vars | decided by | winner | cpu s (max) | wall s (max) | RSS MB |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 20 | 20 | 2216 | 3/3 | SAT | 8435 | 11730 | 285 | 61 | 13 | bdd_sat | wide+mindeg | 0.027 | 0.703 | 27.1 |
| 30 | 30 | 3592 | 3/3 | SAT | 21822 | 26132 | 1810 | 435 | 26 | bdd_sat | wide+mindeg | 0.033 | 1.07 | 27.2 |
| 40 | 40 | 5044 | 3/3 | SAT | 49524 | 55090 | 7012 | 1812 | 36 | bdd_sat | wide+mindeg | 0.055 | 0.648 | 27.5 |
| 50 | 50 | 6489 | 2/3 | SAT + CAP | 156277 | 198630 | 30025 | 7907 | 48 | bdd_sat | wide+mindeg | 0.148 | 1.45 | 32.4 |
| 60 | 60 | 7942 | 3/3 | SAT | 176610 | 234820 | 39362 | 9056 | 54 | bdd_sat | wide+mindeg | 0.179 | 2.75 | 31.7 |
| 70 | - | - | 0/3 | CAP | - | - | - | - | - | - | - | - | - | - |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^2.38 (R2 0.992, 4 sizes); exponential cost ~ 2^(0.1084 * n) (R2 0.990); nodes ~ N^3.87 (R2 1.000); nodes ~ 2^(0.1732 * n) (R2 0.965); local log-log slopes (cost vs N) between consecutive sizes: [1.97, 2.41, 2.8].
Largest n solved by all runs: 60; by at least one run: 60; first n with a failure: 50; wrong answers: 0; UNSAT answers without an independent reference: 0.

## Group S1

### S1.php.natural.bfs+mindeg

| h | nvars | N bits | solved/runs | status | ticks (median) | ticks (max) | BDD nodes (median) | largest bucket | residual vars | decided by | winner | cpu s (max) | wall s (max) | RSS MB |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 3 | 12 | 532 | 1/1 | UNSAT | 2436 | 2436 | 140 | 20 | 12 | bdd_false | bfs+mindeg | 0.022 | 0.242 | 26.8 |
| 4 | 20 | 1230 | 1/1 | UNSAT | 6942 | 6942 | 532 | 77 | 20 | bdd_false | bfs+mindeg | 0.026 | 0.4 | 26.8 |
| 5 | 30 | 2370 | 1/1 | UNSAT | 19278 | 19278 | 2317 | 517 | 30 | bdd_false | bfs+mindeg | 0.029 | 0.692 | 27.3 |
| 6 | 42 | 4172 | 1/1 | UNSAT | 53998 | 53998 | 7191 | 1802 | 42 | bdd_false | bfs+mindeg | 0.049 | 0.623 | 28.1 |
| 7 | 56 | 6664 | 1/1 | UNSAT | 150247 | 150247 | 26110 | 6594 | 56 | bdd_false | bfs+mindeg | 0.101 | 1.11 | 31.2 |
| 8 | 72 | 10098 | 1/1 | UNSAT | 1124758 | 1124758 | 290933 | 29556 | 72 | bdd_false | bfs+mindeg | 0.741 | 6.77 | 76.9 |
| 9 | 90 | 14630 | 1/1 | UNSAT | 2166276 | 2166276 | 404443 | 88676 | 90 | bdd_false | bfs+mindeg | 1.38 | 14.2 | 105 |
| 10 | - | - | 0/1 | TIMEOUT | - | - | - | - | - | - | - | - | - | - |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^2.09 (R2 0.953, 7 sizes); exponential cost ~ 2^(1.6797 * h) (R2 0.988); nodes ~ N^2.51 (R2 0.964); nodes ~ 2^(2.0062 * h) (R2 0.986); local log-log slopes (cost vs N) between consecutive sizes: [1.25, 1.56, 1.82, 2.19, 4.84, 1.77].
Largest h solved by all runs: 9; by at least one run: 9; first h with a failure: 10; wrong answers: 0; UNSAT answers without an independent reference: 0.

### S1.php.natural.force+mindeg

| h | nvars | N bits | solved/runs | status | ticks (median) | ticks (max) | BDD nodes (median) | largest bucket | residual vars | decided by | winner | cpu s (max) | wall s (max) | RSS MB |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 3 | 12 | 532 | 1/1 | UNSAT | 3774 | 3774 | 151 | 20 | 12 | bdd_false | force+mindeg | 0.021 | 0.35 | 26.9 |
| 4 | 20 | 1230 | 1/1 | UNSAT | 13226 | 13226 | 472 | 104 | 20 | bdd_false | force+mindeg | 0.024 | 0.331 | 26.8 |
| 5 | 30 | 2370 | 1/1 | UNSAT | 29251 | 29251 | 1268 | 396 | 30 | bdd_false | force+mindeg | 0.028 | 0.516 | 27.2 |
| 6 | 42 | 4172 | 1/1 | UNSAT | 92627 | 92627 | 12621 | 2121 | 42 | bdd_false | force+mindeg | 0.065 | 1.03 | 27.2 |
| 7 | 56 | 6664 | 1/1 | UNSAT | 248132 | 248132 | 21500 | 9845 | 56 | bdd_false | force+mindeg | 0.137 | 1.18 | 32.6 |
| 8 | 72 | 10098 | 1/1 | UNSAT | 1285484 | 1285484 | 132815 | 43386 | 72 | bdd_false | force+mindeg | 0.799 | 8.99 | 55.4 |
| 9 | 90 | 14630 | 1/1 | UNSAT | 3353762 | 3353762 | 349809 | 139479 | 90 | bdd_false | force+mindeg | 2.02 | 20.5 | 95.8 |
| 10 | - | - | 0/1 | TIMEOUT | - | - | - | - | - | - | - | - | - | - |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^2.03 (R2 0.962, 7 sizes); exponential cost ~ 2^(1.6313 * h) (R2 0.994); nodes ~ N^2.41 (R2 0.967); nodes ~ 2^(1.9246 * h) (R2 0.988); local log-log slopes (cost vs N) between consecutive sizes: [1.5, 1.21, 2.04, 2.1, 3.96, 2.59].
Largest h solved by all runs: 9; by at least one run: 9; first h with a failure: 10; wrong answers: 0; UNSAT answers without an independent reference: 0.

### S1.php.natural.index+level

| h | nvars | N bits | solved/runs | status | ticks (median) | ticks (max) | BDD nodes (median) | largest bucket | residual vars | decided by | winner | cpu s (max) | wall s (max) | RSS MB |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 3 | 12 | 532 | 1/1 | UNSAT | 1676 | 1676 | 132 | 30 | 12 | bdd_false | index+level | 0.022 | 0.323 | 25.8 |
| 4 | 20 | 1230 | 1/1 | UNSAT | 5317 | 5317 | 511 | 133 | 20 | bdd_false | index+level | 0.024 | 0.479 | 25.6 |
| 5 | 30 | 2370 | 1/1 | UNSAT | 17994 | 17994 | 2024 | 505 | 30 | bdd_false | index+level | 0.029 | 0.741 | 25.6 |
| 6 | 42 | 4172 | 1/1 | UNSAT | 65184 | 65184 | 7882 | 1684 | 42 | bdd_false | index+level | 0.061 | 1.75 | 24.4 |
| 7 | 56 | 6664 | 1/1 | UNSAT | 234977 | 234977 | 29152 | 5057 | 56 | bdd_false | index+level | 0.141 | 1.38 | 33.1 |
| 8 | 72 | 10098 | 1/1 | UNSAT | 817388 | 817388 | 101477 | 14205 | 72 | bdd_false | index+level | 0.512 | 4.56 | 53.5 |
| 9 | 90 | 14630 | 1/1 | UNSAT | 2701887 | 2701887 | 333700 | 37939 | 90 | bdd_false | index+level | 1.83 | 19 | 109 |
| 10 | - | - | 0/1 | TIMEOUT | - | - | - | - | - | - | - | - | - | - |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^2.24 (R2 0.977, 7 sizes); exponential cost ~ 2^(1.7928 * h) (R2 1.000); nodes ~ N^2.38 (R2 0.986); nodes ~ 2^(1.8938 * h) (R2 0.999); local log-log slopes (cost vs N) between consecutive sizes: [1.38, 1.86, 2.28, 2.74, 3.0, 3.22].
Largest h solved by all runs: 9; by at least one run: 9; first h with a failure: 10; wrong answers: 0; UNSAT answers without an independent reference: 0.

### S1.php.natural.portfolio

| h | nvars | N bits | solved/runs | status | ticks (median) | ticks (max) | BDD nodes (median) | largest bucket | residual vars | decided by | winner | cpu s (max) | wall s (max) | RSS MB |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 3 | 12 | 532 | 1/1 | UNSAT | 5848 | 5848 | 248 | 20 | 12 | bdd_false | wide+mindeg | 0.021 | 0.103 | 26.8 |
| 4 | 20 | 1230 | 1/1 | UNSAT | 16695 | 16695 | 1058 | 73 | 20 | bdd_false | wide+cross | 0.026 | 0.578 | 27 |
| 5 | 30 | 2370 | 1/1 | UNSAT | 35956 | 35956 | 2832 | 400 | 30 | bdd_false | wide+cross | 0.037 | 0.416 | 27.6 |
| 6 | 42 | 4172 | 1/1 | UNSAT | 70037 | 70037 | 6069 | 1432 | 42 | bdd_false | wide+cross | 0.045 | 0.47 | 27.9 |
| 7 | 56 | 6664 | 1/1 | UNSAT | 128281 | 128281 | 14554 | 4401 | 56 | bdd_false | wide+cross | 0.067 | 0.427 | 29.8 |
| 8 | 72 | 10098 | 1/1 | UNSAT | 185560 | 185560 | 13953 | 1250 | 72 | bdd_false | wide+cross | 0.077 | 1.3 | 27.9 |
| 9 | 90 | 14630 | 1/1 | UNSAT | 273193 | 273193 | 22627 | 1349 | 90 | bdd_false | wide+cross | 0.102 | 0.88 | 32 |
| 10 | 110 | 20262 | 1/1 | UNSAT | 414030 | 414030 | 34783 | 1736 | 110 | bdd_false | wide+cross | 0.143 | 2 | 32.4 |
| 11 | 132 | 27228 | 1/1 | UNSAT | 586835 | 586835 | 50109 | 1835 | 132 | bdd_false | wide+cross | 0.189 | 1.29 | 37.4 |
| 12 | 156 | 36036 | 1/1 | UNSAT | 801522 | 801522 | 69985 | 2222 | 156 | bdd_false | wide+cross | 0.282 | 3.65 | 37.6 |
| 13 | 182 | 46438 | 1/1 | UNSAT | 1123321 | 1123321 | 108072 | 3273 | 182 | bdd_false | wide+cross | 0.374 | 2.02 | 51 |
| 14 | 210 | 58560 | 1/1 | UNSAT | 1478410 | 1478410 | 137263 | 12272 | 210 | bdd_false | wide+cross | 0.478 | 3.58 | 55.2 |
| 15 | 240 | 72528 | 1/1 | UNSAT | 1974828 | 1974828 | 220605 | 55164 | 240 | bdd_false | wide+cross | 0.718 | 6.1 | 68.7 |
| 16 | 272 | 89046 | 1/1 | UNSAT | 2561562 | 2561562 | 267958 | 3194 | 272 | bdd_false | wide+cross | 0.873 | 10.8 | 78.6 |
| 17 | 306 | 108342 | 1/1 | UNSAT | 3244294 | 3244294 | 300770 | 5649 | 306 | bdd_false | wide+cross | 1.02 | 11.2 | 77.8 |
| 18 | 342 | 130074 | 1/1 | UNSAT | 4097201 | 4097201 | 415776 | 17824 | 342 | bdd_false | wide+cross | 1.33 | 12.3 | 97.4 |
| 19 | 380 | 154380 | 1/1 | UNSAT | 5085588 | 5085588 | 496377 | 94297 | 380 | bdd_false | wide+cross | 1.73 | 16.6 | 119 |
| 20 | 420 | 181398 | 1/1 | UNSAT | 6405449 | 6405449 | 731075 | 231983 | 420 | bdd_false | wide+cross | 2.16 | 20.5 | 162 |
| 21 | - | - | 0/1 | TIMEOUT | - | - | - | - | - | - | - | - | - | - |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^1.18 (R2 0.999, 18 sizes); exponential cost ~ 2^(0.5416 * h) (R2 0.952); nodes ~ N^1.29 (R2 0.994); nodes ~ 2^(0.5868 * h) (R2 0.934); local log-log slopes (cost vs N) between consecutive sizes: [1.25, 1.17, 1.18, 1.29, 0.89, 1.04, 1.28, 1.18, 1.11, 1.33, 1.18, 1.35, 1.27, 1.2, 1.28, 1.26, 1.43].
Largest h solved by all runs: 20; by at least one run: 20; first h with a failure: 21; wrong answers: 0; UNSAT answers without an independent reference: 0.

### S1.php.natural.residual_dag

| h | nvars | N bits | solved/runs | status | DAG nodes (median) | DAG nodes (max) | cpu s (max) | wall s (max) |
|---|---|---|---|---|---|---|---|---|
| 3 | 12 | 532 | 1/1 | UNSAT | 194 | 194 | 0.009 | 0.262 |
| 4 | 20 | 1230 | 1/1 | UNSAT | 725 | 725 | 0.024 | 0.22 |
| 5 | 30 | 2370 | 1/1 | UNSAT | 2717 | 2717 | 0.066 | 0.704 |
| 6 | 42 | 4172 | 1/1 | UNSAT | 10071 | 10071 | 0.263 | 3.98 |
| 7 | 56 | 6664 | 1/1 | UNSAT | 35985 | 35985 | 1.06 | 10.3 |
| 8 | - | - | 0/1 | TIMEOUT | - | - | - | - |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^2.06 (R2 0.989, 5 sizes); exponential cost ~ 2^(1.8866 * h) (R2 1.000); local log-log slopes (cost vs N) between consecutive sizes: [1.57, 2.01, 2.32, 2.72].
Largest h solved by all runs: 7; by at least one run: 7; first h with a failure: 8; wrong answers: 0; UNSAT answers without an independent reference: 0.

### S1.php.natural.wide+cross

| h | nvars | N bits | solved/runs | status | ticks (median) | ticks (max) | BDD nodes (median) | largest bucket | residual vars | decided by | winner | cpu s (max) | wall s (max) | RSS MB |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 4 | 20 | 1230 | 1/1 | UNSAT | 8988 | 8988 | 397 | 43 | 20 | bdd_false | wide+cross | 0.023 | 0.127 | 27 |
| 6 | 42 | 4172 | 1/1 | UNSAT | 35649 | 35649 | 1873 | 126 | 42 | bdd_false | wide+cross | 0.031 | 0.499 | 27.5 |
| 8 | 72 | 10098 | 1/1 | UNSAT | 96320 | 96320 | 6072 | 284 | 72 | bdd_false | wide+cross | 0.041 | 0.502 | 28.1 |
| 10 | 110 | 20262 | 1/1 | UNSAT | 216729 | 216729 | 15738 | 535 | 110 | bdd_false | wide+cross | 0.072 | 0.407 | 30 |
| 12 | 156 | 36036 | 1/1 | UNSAT | 415555 | 415555 | 35071 | 892 | 156 | bdd_false | wide+cross | 0.137 | 0.9 | 33.8 |
| 14 | 210 | 58560 | 1/1 | UNSAT | 764722 | 764722 | 70047 | 1394 | 210 | bdd_false | wide+cross | 0.256 | 2.19 | 37.7 |
| 16 | 272 | 89046 | 1/1 | UNSAT | 1316969 | 1316969 | 128738 | 2051 | 272 | bdd_false | wide+cross | 0.422 | 3.4 | 50.2 |
| 18 | 342 | 130074 | 1/1 | UNSAT | 2088302 | 2088302 | 221632 | 2874 | 342 | bdd_false | wide+cross | 0.716 | 5.58 | 80.2 |
| 20 | 420 | 181398 | 1/1 | UNSAT | 3266488 | 3266488 | 361953 | 3912 | 420 | bdd_false | wide+cross | 1.2 | 10.5 | 82 |
| 22 | - | - | 0/1 | TIMEOUT | - | - | - | - | - | - | - | - | - | - |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^1.18 (R2 0.999, 9 sizes); exponential cost ~ 2^(0.5084 * h) (R2 0.965); nodes ~ N^1.37 (R2 0.999); nodes ~ 2^(0.5913 * h) (R2 0.965); local log-log slopes (cost vs N) between consecutive sizes: [1.13, 1.12, 1.16, 1.13, 1.26, 1.3, 1.22, 1.35].
Largest h solved by all runs: 20; by at least one run: 20; first h with a failure: 22; wrong answers: 0; UNSAT answers without an independent reference: 0.

### S1.php.natural.wide+mindeg

| h | nvars | N bits | solved/runs | status | ticks (median) | ticks (max) | BDD nodes (median) | largest bucket | residual vars | decided by | winner | cpu s (max) | wall s (max) | RSS MB |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 3 | 12 | 532 | 1/1 | UNSAT | 3198 | 3198 | 151 | 20 | 12 | bdd_false | wide+mindeg | 0.022 | 0.041 | 27 |
| 4 | 20 | 1230 | 1/1 | UNSAT | 9052 | 9052 | 663 | 73 | 20 | bdd_false | wide+mindeg | 0.022 | 0.031 | 27 |
| 5 | 30 | 2370 | 1/1 | UNSAT | 24253 | 24253 | 2688 | 400 | 30 | bdd_false | wide+mindeg | 0.032 | 0.336 | 27.5 |
| 6 | 42 | 4172 | 1/1 | UNSAT | 61564 | 61564 | 7128 | 1432 | 42 | bdd_false | wide+mindeg | 0.051 | 0.703 | 28.4 |
| 7 | 56 | 6664 | 1/1 | UNSAT | 161111 | 161111 | 26088 | 4401 | 56 | bdd_false | wide+mindeg | 0.103 | 0.846 | 32.2 |
| 8 | 72 | 10098 | 1/1 | UNSAT | 566061 | 566061 | 117155 | 14353 | 72 | bdd_false | wide+mindeg | 0.366 | 3.3 | 45.6 |
| 9 | 90 | 14630 | 1/1 | UNSAT | 2214735 | 2214735 | 424808 | 74092 | 90 | bdd_false | wide+mindeg | 1.36 | 10.4 | 103 |
| 10 | - | - | 0/1 | TIMEOUT | - | - | - | - | - | - | - | - | - | - |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^1.91 (R2 0.960, 7 sizes); exponential cost ~ 2^(1.5347 * h) (R2 0.995); nodes ~ N^2.35 (R2 0.978); nodes ~ 2^(1.8780 * h) (R2 0.998); local log-log slopes (cost vs N) between consecutive sizes: [1.24, 1.5, 1.65, 2.05, 3.02, 3.68].
Largest h solved by all runs: 9; by at least one run: 9; first h with a failure: 10; wrong answers: 0; UNSAT answers without an independent reference: 0.

### S1.php.natural.wide+minfac

| h | nvars | N bits | solved/runs | status | ticks (median) | ticks (max) | BDD nodes (median) | largest bucket | residual vars | decided by | winner | cpu s (max) | wall s (max) | RSS MB |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 4 | 20 | 1230 | 1/1 | UNSAT | 8726 | 8726 | 397 | 43 | 20 | bdd_false | wide+minfac | 0.023 | 0.067 | 27 |
| 6 | 42 | 4172 | 1/1 | UNSAT | 39137 | 39137 | 1873 | 126 | 42 | bdd_false | wide+minfac | 0.035 | 0.364 | 27.3 |
| 8 | 72 | 10098 | 1/1 | UNSAT | 141754 | 141754 | 6072 | 284 | 72 | bdd_false | wide+minfac | 0.058 | 0.987 | 28.2 |
| 10 | 110 | 20262 | 1/1 | UNSAT | 364476 | 364476 | 15738 | 535 | 110 | bdd_false | wide+minfac | 0.103 | 0.938 | 29.2 |
| 12 | 156 | 36036 | 1/1 | UNSAT | 944745 | 944745 | 35071 | 892 | 156 | bdd_false | wide+minfac | 0.213 | 2.18 | 33.6 |
| 14 | 210 | 58560 | 1/1 | UNSAT | 2206382 | 2206382 | 70047 | 1394 | 210 | bdd_false | wide+minfac | 0.389 | 3.41 | 41.6 |
| 16 | 272 | 89046 | 1/1 | UNSAT | 4681051 | 4681051 | 128738 | 2051 | 272 | bdd_false | wide+minfac | 0.761 | 6.8 | 52.4 |
| 18 | 342 | 130074 | 1/1 | UNSAT | 9142915 | 9142915 | 221632 | 2874 | 342 | bdd_false | wide+minfac | 1.28 | 10.6 | 66.4 |
| 20 | - | - | 0/1 | TIMEOUT | - | - | - | - | - | - | - | - | - | - |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^1.50 (R2 0.995, 8 sizes); exponential cost ~ 2^(0.7024 * h) (R2 0.983); nodes ~ N^1.36 (R2 0.999); nodes ~ 2^(0.6317 * h) (R2 0.969); local log-log slopes (cost vs N) between consecutive sizes: [1.23, 1.46, 1.36, 1.65, 1.75, 1.79, 1.77].
Largest h solved by all runs: 18; by at least one run: 18; first h with a failure: 20; wrong answers: 0; UNSAT answers without an independent reference: 0.

### S1.php.renamed.portfolio

| h | nvars | N bits | solved/runs | status | ticks (median) | ticks (max) | BDD nodes (median) | largest bucket | residual vars | decided by | winner | cpu s (max) | wall s (max) | RSS MB |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 4 | 20 | 1230 | 5/5 | UNSAT | 16876 | 17122 | 1063 | 145 | 20 | bdd_false | wide+cross,wide+mindeg | 0.029 | 0.414 | 27.1 |
| 6 | 42 | 4172 | 5/5 | UNSAT | 70006 | 70747 | 6211 | 1766 | 42 | bdd_false | wide+cross | 0.05 | 0.887 | 28.2 |
| 8 | 72 | 10098 | 5/5 | UNSAT | 208348 | 215941 | 19439 | 7073 | 72 | bdd_false | wide+cross | 0.105 | 1.94 | 32.6 |
| 10 | 110 | 20262 | 5/5 | UNSAT | 428220 | 428895 | 38666 | 2158 | 110 | bdd_false | wide+cross | 0.164 | 1.71 | 35.3 |
| 12 | 156 | 36036 | 5/5 | UNSAT | 824433 | 828426 | 79694 | 2687 | 156 | bdd_false | wide+cross | 0.307 | 5 | 40.5 |
| 14 | 210 | 58560 | 5/5 | UNSAT | 1517649 | 1532989 | 154380 | 15666 | 210 | bdd_false | wide+cross | 0.522 | 6.47 | 55.1 |
| 16 | 272 | 89046 | 5/5 | UNSAT | 2617947 | 2635177 | 261387 | 4089 | 272 | bdd_false | wide+cross | 0.895 | 12.2 | 78.9 |
| 18 | 342 | 130074 | 4/5 | UNSAT + TIMEOUT | 4163133 | 4167754 | 4.59e+05 | 32783 | 342 | bdd_false | wide+cross | 1.54 | 20.3 | 114 |
| 20 | - | - | 0/5 | TIMEOUT | - | - | - | - | - | - | - | - | - | - |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^1.17 (R2 1.000, 7 sizes); exponential cost ~ 2^(0.5838 * h) (R2 0.967); nodes ~ N^1.26 (R2 0.998); nodes ~ 2^(0.6274 * h) (R2 0.954); local log-log slopes (cost vs N) between consecutive sizes: [1.16, 1.23, 1.03, 1.14, 1.26, 1.3].
Largest h solved by all runs: 16; by at least one run: 18; first h with a failure: 18; wrong answers: 0; UNSAT answers without an independent reference: 0.

### S1.php.renamed.wide+cross

| h | nvars | N bits | solved/runs | status | ticks (median) | ticks (max) | BDD nodes (median) | largest bucket | residual vars | decided by | winner | cpu s (max) | wall s (max) | RSS MB |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 4 | 20 | 1230 | 5/5 | UNSAT | 9148 | 9184 | 439 | 52 | 20 | bdd_false | wide+cross | 0.023 | 0.232 | 27.1 |
| 8 | 72 | 10098 | 5/5 | UNSAT | 98626 | 98641 | 6630 | 314 | 72 | bdd_false | wide+cross | 0.046 | 0.946 | 28.4 |
| 12 | 156 | 36036 | 5/5 | UNSAT | 425703 | 426842 | 37492 | 961 | 156 | bdd_false | wide+cross | 0.152 | 1.42 | 34.9 |
| 16 | 272 | 89046 | 5/5 | UNSAT | 1347296 | 1348352 | 135577 | 2161 | 272 | bdd_false | wide+cross | 0.489 | 7.75 | 53.9 |
| 20 | 420 | 181398 | 5/5 | UNSAT | 3338324 | 3341729 | 378601 | 4087 | 420 | bdd_false | wide+cross | 1.25 | 14.1 | 93.9 |
| 24 | - | - | 0/5 | TIMEOUT | - | - | - | - | - | - | - | - | - | - |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^1.18 (R2 0.999, 5 sizes); exponential cost ~ 2^(0.5199 * h) (R2 0.963); nodes ~ N^1.35 (R2 0.999); nodes ~ 2^(0.5965 * h) (R2 0.961); local log-log slopes (cost vs N) between consecutive sizes: [1.13, 1.15, 1.27, 1.28].
Largest h solved by all runs: 20; by at least one run: 20; first h with a failure: 24; wrong answers: 0; UNSAT answers without an independent reference: 0.

### S1.php.renamed.wide+mindeg

| h | nvars | N bits | solved/runs | status | ticks (median) | ticks (max) | BDD nodes (median) | largest bucket | residual vars | decided by | winner | cpu s (max) | wall s (max) | RSS MB |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 4 | 20 | 1230 | 2/2 | UNSAT | 9.26e+03 | 9491 | 666 | 145 | 20 | bdd_false | wide+mindeg | 0.026 | 0.291 | 27.1 |
| 6 | 42 | 4172 | 2/2 | UNSAT | 6.23e+04 | 66361 | 6776 | 1740 | 42 | bdd_false | wide+mindeg | 0.051 | 0.776 | 28.3 |
| 8 | 72 | 10098 | 2/2 | UNSAT | 9.01e+05 | 973161 | 172431 | 30232 | 72 | bdd_false | wide+mindeg | 0.654 | 5.88 | 60 |
| 10 | - | - | 0/2 | TIMEOUT | - | - | - | - | - | - | - | - | - | - |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^2.14 (R2 0.965, 3 sizes); exponential cost ~ 2^(1.6513 * h) (R2 0.991); nodes ~ N^2.59 (R2 0.965); nodes ~ 2^(2.0043 * h) (R2 0.991); local log-log slopes (cost vs N) between consecutive sizes: [1.56, 3.02].
Largest h solved by all runs: 8; by at least one run: 8; first h with a failure: 10; wrong answers: 0; UNSAT answers without an independent reference: 0.

## Group S1x

### S1x.fphp.natural.portfolio

| h | nvars | N bits | solved/runs | status | ticks (median) | ticks (max) | BDD nodes (median) | largest bucket | residual vars | decided by | winner | cpu s (max) | wall s (max) | RSS MB |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 4 | 20 | 1974 | 1/1 | UNSAT | 24942 | 24942 | 1111 | 76 | 20 | bdd_false | wide+mindeg | 0.028 | 0.284 | 25.8 |
| 6 | 42 | 7172 | 1/1 | UNSAT | 107300 | 107300 | 7711 | 1034 | 42 | bdd_false | wide+cross | 0.049 | 0.36 | 26 |
| 8 | 72 | 17994 | 1/1 | UNSAT | 319408 | 319408 | 24670 | 4678 | 72 | bdd_false | wide+cross | 0.101 | 1.29 | 30.1 |
| 10 | 110 | 36912 | 1/1 | UNSAT | 694682 | 694682 | 61398 | 1948 | 110 | bdd_false | wide+cross | 0.183 | 1.96 | 39 |
| 12 | 156 | 66638 | 1/1 | UNSAT | 1252908 | 1252908 | 90894 | 2486 | 156 | bdd_false | wide+cross | 0.318 | 3.04 | 42.5 |
| 14 | 210 | 109468 | 1/1 | UNSAT | 2294750 | 2294750 | 178522 | 14998 | 210 | bdd_false | wide+cross | 0.558 | 7.27 | 55.8 |
| 16 | 272 | 167826 | 1/1 | UNSAT | 3808140 | 3808140 | 270184 | 3562 | 272 | bdd_false | wide+cross | 0.85 | 8.03 | 76.8 |
| 18 | 342 | 246728 | 1/1 | UNSAT | 5950393 | 5950393 | 450420 | 29740 | 342 | bdd_false | wide+cross | 1.36 | 11.4 | 110 |
| 20 | - | - | 0/1 | TIMEOUT | - | - | - | - | - | - | - | - | - | - |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^1.13 (R2 1.000, 8 sizes); exponential cost ~ 2^(0.5382 * h) (R2 0.957); nodes ~ N^1.21 (R2 0.993); nodes ~ 2^(0.5680 * h) (R2 0.925); local log-log slopes (cost vs N) between consecutive sizes: [1.13, 1.19, 1.08, 1.0, 1.22, 1.19, 1.16].
Largest h solved by all runs: 18; by at least one run: 18; first h with a failure: 20; wrong answers: 0; UNSAT answers without an independent reference: 0.

### S1x.fphp.renamed.portfolio

| h | nvars | N bits | solved/runs | status | ticks (median) | ticks (max) | BDD nodes (median) | largest bucket | residual vars | decided by | winner | cpu s (max) | wall s (max) | RSS MB |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 4 | 20 | 1974 | 2/2 | UNSAT | 2.52e+04 | 25508 | 1151 | 145 | 20 | bdd_false | wide+mindeg | 0.025 | 0.244 | 27.2 |
| 8 | 72 | 17994 | 2/2 | UNSAT | 340208 | 344039 | 30715 | 9358 | 72 | bdd_false | wide+cross | 0.115 | 1.62 | 32.7 |
| 12 | 156 | 66638 | 2/2 | UNSAT | 1275037 | 1279704 | 9.94e+04 | 2784 | 156 | bdd_false | wide+cross | 0.342 | 4.78 | 45.7 |
| 16 | 272 | 167826 | 2/2 | UNSAT | 3853901 | 3855884 | 280324 | 4313 | 272 | bdd_false | wide+cross | 0.902 | 7.9 | 78.7 |
| 20 | - | - | 0/2 | TIMEOUT | - | - | - | - | - | - | - | - | - | - |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^1.12 (R2 0.999, 4 sizes); exponential cost ~ 2^(0.5919 * h) (R2 0.956); nodes ~ N^1.23 (R2 0.988); nodes ~ 2^(0.6370 * h) (R2 0.914); local log-log slopes (cost vs N) between consecutive sizes: [1.18, 1.01, 1.2].
Largest h solved by all runs: 16; by at least one run: 16; first h with a failure: 20; wrong answers: 0; UNSAT answers without an independent reference: 0.

### S1x.ofphp.natural.portfolio

| h | nvars | N bits | solved/runs | status | ticks (median) | ticks (max) | BDD nodes (median) | largest bucket | residual vars | decided by | winner | cpu s (max) | wall s (max) | RSS MB |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 4 | 20 | 2210 | 1/1 | UNSAT | 27443 | 27443 | 1196 | 137 | 20 | bdd_false | wide+mindeg | 0.029 | 0.394 | 27 |
| 6 | 42 | 7742 | 1/1 | UNSAT | 119172 | 119172 | 10640 | 3729 | 42 | bdd_false | wide+cross | 0.061 | 0.656 | 27.3 |
| 8 | 72 | 19066 | 1/1 | UNSAT | 321545 | 321545 | 21315 | 2132 | 72 | bdd_false | wide+cross | 0.094 | 1.25 | 26.1 |
| 10 | 110 | 38672 | 1/1 | UNSAT | 712217 | 712217 | 51781 | 2974 | 110 | bdd_false | wide+cross | 0.18 | 1.5 | 33.2 |
| 12 | 156 | 69288 | 1/1 | UNSAT | 1332531 | 1332531 | 99365 | 3818 | 156 | bdd_false | wide+cross | 0.331 | 2.23 | 42 |
| 14 | 210 | 113202 | 1/1 | UNSAT | 2393428 | 2393428 | 191520 | 4662 | 210 | bdd_false | wide+cross | 0.571 | 5.58 | 56.8 |
| 16 | 272 | 172838 | 1/1 | UNSAT | 4027833 | 4027833 | 295521 | 5506 | 272 | bdd_false | wide+cross | 0.968 | 12.3 | 75.9 |
| 18 | - | - | 0/1 | TIMEOUT | - | - | - | - | - | - | - | - | - | - |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^1.13 (R2 1.000, 7 sizes); exponential cost ~ 2^(0.5768 * h) (R2 0.965); nodes ~ N^1.22 (R2 0.989); nodes ~ 2^(0.6144 * h) (R2 0.934); local log-log slopes (cost vs N) between consecutive sizes: [1.17, 1.1, 1.12, 1.07, 1.19, 1.23].
Largest h solved by all runs: 16; by at least one run: 16; first h with a failure: 18; wrong answers: 0; UNSAT answers without an independent reference: 0.

### S1x.ophp.natural.portfolio

| h | nvars | N bits | solved/runs | status | ticks (median) | ticks (max) | BDD nodes (median) | largest bucket | residual vars | decided by | winner | cpu s (max) | wall s (max) | RSS MB |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 4 | 20 | 1466 | 1/1 | UNSAT | 18091 | 18091 | 908 | 104 | 20 | bdd_false | wide+mindeg | 0.023 | 0.331 | 26.9 |
| 6 | 42 | 4742 | 1/1 | UNSAT | 74860 | 74860 | 6362 | 2121 | 42 | bdd_false | wide+cross | 0.039 | 0.783 | 26.3 |
| 8 | 72 | 11170 | 1/1 | UNSAT | 189714 | 189714 | 14048 | 1156 | 72 | bdd_false | wide+cross | 0.071 | 1.26 | 27.2 |
| 10 | 110 | 22022 | 1/1 | UNSAT | 421716 | 421716 | 35385 | 1598 | 110 | bdd_false | wide+cross | 0.132 | 2.09 | 28.8 |
| 12 | 156 | 38686 | 1/1 | UNSAT | 808357 | 808357 | 72716 | 2177 | 156 | bdd_false | wide+cross | 0.249 | 4.33 | 31.9 |
| 14 | 210 | 62294 | 1/1 | UNSAT | 1526781 | 1526781 | 149313 | 19797 | 210 | bdd_false | wide+cross | 0.471 | 5.8 | 53.4 |
| 16 | 272 | 94058 | 1/1 | UNSAT | 2552707 | 2552707 | 256426 | 3141 | 272 | bdd_false | wide+cross | 0.716 | 6.75 | 70.7 |
| 18 | 342 | 136630 | 1/1 | UNSAT | 4086043 | 4086043 | 381488 | 48062 | 342 | bdd_false | wide+cross | 1.18 | 10 | 97.5 |
| 20 | - | - | 0/1 | TIMEOUT | - | - | - | - | - | - | - | - | - | - |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^1.19 (R2 0.999, 8 sizes); exponential cost ~ 2^(0.5367 * h) (R2 0.968); nodes ~ N^1.31 (R2 0.996); nodes ~ 2^(0.5889 * h) (R2 0.953); local log-log slopes (cost vs N) between consecutive sizes: [1.21, 1.09, 1.18, 1.15, 1.33, 1.25, 1.26].
Largest h solved by all runs: 18; by at least one run: 18; first h with a failure: 20; wrong answers: 0; UNSAT answers without an independent reference: 0.

### S1x.ophp.renamed.portfolio

| h | nvars | N bits | solved/runs | status | ticks (median) | ticks (max) | BDD nodes (median) | largest bucket | residual vars | decided by | winner | cpu s (max) | wall s (max) | RSS MB |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 4 | 20 | 1466 | 2/2 | UNSAT | 18085 | 18119 | 905 | 105 | 20 | bdd_false | wide+mindeg | 0.024 | 0.604 | 26.7 |
| 8 | 72 | 11170 | 2/2 | UNSAT | 2.03e+05 | 210909 | 1.8e+04 | 3753 | 72 | bdd_false | wide+cross | 0.088 | 1 | 29.9 |
| 12 | 156 | 38686 | 2/2 | UNSAT | 8.32e+05 | 838471 | 80194 | 3267 | 156 | bdd_false | wide+cross | 0.274 | 4.09 | 41.3 |
| 16 | 272 | 94058 | 2/2 | UNSAT | 2620083 | 2621528 | 267528 | 4913 | 272 | bdd_false | wide+cross | 0.763 | 7.28 | 75 |
| 20 | - | - | 0/2 | TIMEOUT | - | - | - | - | - | - | - | - | - | - |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^1.19 (R2 1.000, 4 sizes); exponential cost ~ 2^(0.5893 * h) (R2 0.969); nodes ~ N^1.36 (R2 0.998); nodes ~ 2^(0.6695 * h) (R2 0.952); local log-log slopes (cost vs N) between consecutive sizes: [1.19, 1.14, 1.29].
Largest h solved by all runs: 16; by at least one run: 16; first h with a failure: 20; wrong answers: 0; UNSAT answers without an independent reference: 0.

### S1x.php2.natural.portfolio

| h | nvars | N bits | solved/runs | status | ticks (median) | ticks (max) | BDD nodes (median) | largest bucket | residual vars | decided by | winner | cpu s (max) | wall s (max) | RSS MB |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 4 | 32 | 3424 | 1/1 | UNSAT | 48658 | 48658 | 3170 | 236 | 32 | bdd_false | wide+cross | 0.036 | 0.668 | 27.9 |
| 6 | 72 | 13488 | 1/1 | UNSAT | 227682 | 227682 | 14967 | 1905 | 72 | bdd_false | wide+cross | 0.084 | 1.6 | 26.2 |
| 8 | 128 | 35008 | 1/1 | UNSAT | 683449 | 683449 | 49429 | 3159 | 128 | bdd_false | wide+cross | 0.195 | 2.15 | 34.7 |
| 10 | 200 | 73960 | 1/1 | UNSAT | 1635293 | 1635293 | 113761 | 4413 | 200 | bdd_false | wide+cross | 0.417 | 4.54 | 44.2 |
| 12 | 288 | 134640 | 1/1 | UNSAT | 3419170 | 3419170 | 249519 | 7125 | 288 | bdd_false | wide+cross | 1.01 | 16.2 | 65.3 |
| 14 | - | - | 0/1 | TIMEOUT | - | - | - | - | - | - | - | - | - | - |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^1.16 (R2 1.000, 5 sizes); exponential cost ~ 2^(0.7557 * h) (R2 0.978); nodes ~ N^1.19 (R2 1.000); nodes ~ 2^(0.7762 * h) (R2 0.977); local log-log slopes (cost vs N) between consecutive sizes: [1.13, 1.15, 1.17, 1.23].
Largest h solved by all runs: 12; by at least one run: 12; first h with a failure: 14; wrong answers: 0; UNSAT answers without an independent reference: 0.

### S1x.php3cnf.natural.portfolio

| h | nvars | N bits | solved/runs | status | ticks (median) | ticks (max) | BDD nodes (median) | largest bucket | residual vars | decided by | winner | cpu s (max) | wall s (max) | RSS MB |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 4 | 25 | 1380 | 1/1 | UNSAT | 18624 | 18624 | 1195 | 73 | 25 | bdd_false | wide+mindeg | 0.029 | 1.28 | 25.1 |
| 6 | 63 | 4886 | 1/1 | UNSAT | 89285 | 89285 | 8264 | 1432 | 63 | bdd_false | wide+cross | 0.058 | 0.864 | 26.8 |
| 8 | 117 | 11808 | 1/1 | UNSAT | 240815 | 240815 | 22292 | 3944 | 117 | bdd_false | wide+cross | 0.091 | 1.5 | 29 |
| 10 | 187 | 23428 | 1/1 | UNSAT | 491693 | 491693 | 41874 | 1736 | 187 | bdd_false | wide+cross | 0.166 | 1.77 | 33.5 |
| 12 | 273 | 41022 | 1/1 | UNSAT | 911638 | 911638 | 72746 | 2222 | 273 | bdd_false | wide+cross | 0.333 | 8.42 | 31.7 |
| 14 | 375 | 65970 | 1/1 | UNSAT | 1488467 | 1488467 | 118673 | 2708 | 375 | bdd_false | wide+cross | 0.435 | 5.21 | 40.5 |
| 16 | 493 | 99212 | 1/1 | UNSAT | 2374098 | 2374098 | 179829 | 3194 | 493 | bdd_false | wide+cross | 0.689 | 8.64 | 54.6 |
| 18 | 627 | 143648 | 1/1 | UNSAT | 3502045 | 3502045 | 264195 | 3680 | 627 | bdd_false | wide+cross | 0.971 | 11.6 | 74.7 |
| 20 | 777 | 198884 | 1/1 | UNSAT | 5126771 | 5126771 | 376036 | 4166 | 777 | bdd_false | wide+cross | 1.35 | 18.1 | 95.5 |
| 22 | 943 | 265952 | 1/1 | UNSAT | 6980622 | 6980622 | 518069 | 4652 | 943 | bdd_false | wide+cross | 1.74 | 17.4 | 126 |
| 24 | - | - | 0/1 | TIMEOUT | - | - | - | - | - | - | - | - | - | - |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^1.11 (R2 0.999, 10 sizes); exponential cost ~ 2^(0.4384 * h) (R2 0.937); nodes ~ N^1.10 (R2 0.993); nodes ~ 2^(0.4310 * h) (R2 0.912); local log-log slopes (cost vs N) between consecutive sizes: [1.24, 1.12, 1.04, 1.1, 1.03, 1.14, 1.05, 1.17, 1.06].
Largest h solved by all runs: 22; by at least one run: 22; first h with a failure: 24; wrong answers: 0; UNSAT answers without an independent reference: 0.

### S1x.php3cnf.renamed.portfolio

| h | nvars | N bits | solved/runs | status | ticks (median) | ticks (max) | BDD nodes (median) | largest bucket | residual vars | decided by | winner | cpu s (max) | wall s (max) | RSS MB |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 4 | 25 | 1389 | 2/2 | UNSAT | 18390 | 18794 | 1.11e+03 | 112 | 25 | bdd_false | wide+mindeg | 0.03 | 1.05 | 25.6 |
| 6 | 63 | 5026 | 2/2 | UNSAT | 107119 | 126641 | 10876 | 1854 | 63 | bdd_false | wide+cross,wide+mindeg | 0.071 | 1.06 | 27.2 |
| 8 | 117 | 12494 | 2/2 | UNSAT | 324556 | 415417 | 44534 | 9246 | 117 | bdd_false | wide+cross | 0.235 | 5.19 | 29.4 |
| 10 | 187 | 25120 | 2/2 | UNSAT | 9.91e+05 | 1076353 | 1.93e+05 | 95045 | 187 | bdd_false | wide+cross | 0.605 | 7.35 | 60.9 |
| 12 | 273 | 43882 | 2/2 | UNSAT | 2406417 | 3000399 | 382365 | 176273 | 273 | bdd_false | wide+cross | 1.56 | 16.7 | 127 |
| 14 | - | - | 0/2 | TIMEOUT | - | - | - | - | - | - | - | - | - | - |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^1.40 (R2 0.998, 5 sizes); exponential cost ~ 2^(0.8636 * h) (R2 0.983); nodes ~ N^1.71 (R2 0.998); nodes ~ 2^(1.0500 * h) (R2 0.966); local log-log slopes (cost vs N) between consecutive sizes: [1.37, 1.22, 1.6, 1.59].
Largest h solved by all runs: 12; by at least one run: 12; first h with a failure: 14; wrong answers: 0; UNSAT answers without an independent reference: 0.

## Group S2

### S2.tseitin.natural

| vertices | nvars | N bits | solved/runs | status | ticks (median) | ticks (max) | BDD nodes (median) | largest bucket | residual vars | decided by | winner | cpu s (max) | wall s (max) | RSS MB |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 50 | 75 | 9280 | 3/3 | UNSAT | 5868 | 5887 | 0 | 0 | 0 | affine_inconsistent | None | 0.026 | 1.07 | 25.1 |
| 100 | 150 | 20848 | 3/3 | UNSAT | 12967 | 12979 | 0 | 0 | 0 | affine_inconsistent | None | 0.026 | 0.589 | 26.1 |
| 200 | 300 | 46368 | 3/3 | UNSAT | 29667 | 29835 | 0 | 0 | 0 | affine_inconsistent | None | 0.028 | 0.496 | 25.4 |
| 400 | 600 | 102192 | 3/3 | UNSAT | 73636 | 73895 | 0 | 0 | 0 | affine_inconsistent | None | 0.037 | 1.1 | 25.9 |
| 800 | 1200 | 223424 | 3/3 | UNSAT | 198606 | 198877 | 0 | 0 | 0 | affine_inconsistent | None | 0.052 | 1.56 | 26.7 |
| 1600 | 2400 | 485072 | 3/3 | UNSAT | 597026 | 597382 | 0 | 0 | 0 | affine_inconsistent | None | 0.088 | 2.6 | 27.9 |
| 3200 | 4800 | 1046752 | 3/3 | UNSAT | 1958737 | 1963540 | 0 | 0 | 0 | affine_inconsistent | None | 0.152 | 2.32 | 35.5 |
| 6400 | 9600 | 2246896 | 3/3 | UNSAT | 6992929 | 7004154 | 0 | 0 | 0 | affine_inconsistent | None | 0.348 | 6.27 | 56 |
| 12800 | 19200 | 4800768 | 2/3 | UNSAT + TIMEOUT | 26123897 | 26132919 | 0 | 0 | 0 | affine_inconsistent | None | 0.801 | 15.7 | 102 |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^1.28 (R2 0.991, 8 sizes); exponential cost ~ 2^(0.0014 * vertices) (R2 0.791); local log-log slopes (cost vs N) between consecutive sizes: [0.98, 1.04, 1.15, 1.27, 1.42, 1.54, 1.67].
Largest vertices solved by all runs: 6400; by at least one run: 12800; first vertices with a failure: 12800; wrong answers: 0; UNSAT answers without an independent reference: 0.

### S2.tseitin.residual_dag

| vertices | nvars | N bits | solved/runs | status | DAG nodes (median) | DAG nodes (max) | cpu s (max) | wall s (max) |
|---|---|---|---|---|---|---|---|---|
| 10 | 15 | 1344 | 1/1 | UNSAT | 287 | 287 | 0.013 | 0.134 |
| 16 | 24 | 2400 | 1/1 | UNSAT | 600 | 600 | 0.026 | 0.266 |
| 20 | 30 | 3104 | 1/1 | UNSAT | 795 | 795 | 0.036 | 0.583 |
| 24 | 36 | 3888 | 1/1 | UNSAT | 797 | 797 | 0.044 | 0.757 |
| 30 | 45 | 5088 | 1/1 | UNSAT | 1235 | 1235 | 0.073 | 0.732 |
| 40 | 60 | 7088 | 1/1 | UNSAT | 1674 | 1674 | 0.131 | 1.93 |
| 60 | 90 | 11520 | 1/1 | UNSAT | 3787 | 3787 | 0.26 | 2.02 |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^1.14 (R2 0.980, 7 sizes); exponential cost ~ 2^(0.0677 * vertices) (R2 0.946); local log-log slopes (cost vs N) between consecutive sizes: [1.27, 1.09, 0.01, 1.63, 0.92, 1.68].
Largest vertices solved by all runs: 60; by at least one run: 60; first vertices with a failure: None; wrong answers: 0; UNSAT answers without an independent reference: 0.

### S2.tseitin.shuffled

| vertices | nvars | N bits | solved/runs | status | ticks (median) | ticks (max) | BDD nodes (median) | largest bucket | residual vars | decided by | winner | cpu s (max) | wall s (max) | RSS MB |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 50 | 75 | 9280 | 4/4 | UNSAT | 5.87e+03 | 5899 | 0 | 0 | 0 | affine_inconsistent | None | 0.025 | 1.08 | 25 |
| 100 | 150 | 20848 | 4/4 | UNSAT | 13093 | 13098 | 0 | 0 | 0 | affine_inconsistent | None | 0.027 | 1.26 | 25.2 |
| 200 | 300 | 46368 | 4/4 | UNSAT | 30303 | 30370 | 0 | 0 | 0 | affine_inconsistent | None | 0.028 | 0.901 | 27.4 |
| 400 | 600 | 102192 | 4/4 | UNSAT | 75863 | 76066 | 0 | 0 | 0 | affine_inconsistent | None | 0.042 | 1.95 | 25.7 |
| 800 | 1200 | 223424 | 4/4 | UNSAT | 206980 | 207277 | 0 | 0 | 0 | affine_inconsistent | None | 0.054 | 1.2 | 26.9 |
| 1600 | 2400 | 485072 | 4/4 | UNSAT | 6.29e+05 | 631202 | 0 | 0 | 0 | affine_inconsistent | None | 0.082 | 1.04 | 30.4 |
| 3200 | 4800 | 1046752 | 4/4 | UNSAT | 2096443 | 2101884 | 0 | 0 | 0 | affine_inconsistent | None | 0.175 | 2.85 | 36.7 |
| 6400 | 9600 | 2246896 | 4/4 | UNSAT | 7.53e+06 | 7536792 | 0 | 0 | 0 | affine_inconsistent | None | 0.474 | 14 | 53.2 |
| 12800 | 19200 | 4800768 | 4/4 | UNSAT | 28315264 | 28339329 | 0 | 0 | 0 | affine_inconsistent | None | 0.91 | 12.8 | 106 |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^1.36 (R2 0.990, 9 sizes); exponential cost ~ 2^(0.0009 * vertices) (R2 0.751); local log-log slopes (cost vs N) between consecutive sizes: [0.99, 1.05, 1.16, 1.28, 1.43, 1.56, 1.67, 1.74].
Largest vertices solved by all runs: 12800; by at least one run: 12800; first vertices with a failure: None; wrong answers: 0; UNSAT answers without an independent reference: 0.

### S2.tseitin_sat.natural

| vertices | nvars | N bits | solved/runs | status | ticks (median) | ticks (max) | BDD nodes (median) | largest bucket | residual vars | decided by | winner | cpu s (max) | wall s (max) | RSS MB |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 50 | 75 | 9280 | 2/2 | SAT | 9863 | 9935 | 0 | 0 | 0 | affine_sat | None | 0.029 | 1.78 | 25.8 |
| 100 | 150 | 20848 | 2/2 | SAT | 26246 | 26584 | 0 | 0 | 0 | affine_sat | None | 0.024 | 0.926 | 25.2 |
| 200 | 300 | 46368 | 2/2 | SAT | 76168 | 83074 | 0 | 0 | 0 | affine_sat | None | 0.029 | 0.977 | 25.2 |
| 400 | 600 | 102192 | 2/2 | SAT | 346630 | 351435 | 0 | 0 | 0 | affine_sat | None | 0.037 | 0.728 | 25.8 |
| 800 | 1200 | 223424 | 2/2 | SAT | 1555755 | 1633935 | 0 | 0 | 0 | affine_sat | None | 0.059 | 1.09 | 26.8 |
| 1600 | 2400 | 485072 | 2/2 | SAT | 1.09e+07 | 11125261 | 0 | 0 | 0 | affine_sat | None | 0.134 | 2.06 | 30.1 |
| 3200 | 4800 | 1046752 | 2/2 | SAT | 8.03e+07 | 85130434 | 0 | 0 | 0 | affine_sat | None | 0.557 | 13.2 | 36.7 |
| 6400 | - | - | 0/2 | TIMEOUT | - | - | - | - | - | - | - | - | - | - |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^1.91 (R2 0.981, 7 sizes); exponential cost ~ 2^(0.0038 * vertices) (R2 0.862); local log-log slopes (cost vs N) between consecutive sizes: [1.21, 1.33, 1.92, 1.92, 2.52, 2.59].
Largest vertices solved by all runs: 3200; by at least one run: 3200; first vertices with a failure: 6400; wrong answers: 0; UNSAT answers without an independent reference: 0.

## Group S3

### S3.xor3.planted

| n | nvars | N bits | solved/runs | status | ticks (median) | ticks (max) | BDD nodes (median) | largest bucket | residual vars | decided by | winner | cpu s (max) | wall s (max) | RSS MB |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 100 | 100 | 19312 | 3/3 | SAT | 25619 | 26763 | 0 | 0 | 0 | affine_sat | None | 0.026 | 0.667 | 25.9 |
| 200 | 200 | 43968 | 3/3 | SAT | 75292 | 79450 | 0 | 0 | 0 | affine_sat | None | 0.03 | 1.07 | 25.5 |
| 400 | 400 | 96872 | 3/3 | SAT | 305500 | 313194 | 0 | 0 | 0 | affine_sat | None | 0.043 | 1.26 | 25.8 |
| 800 | 800 | 212480 | 3/3 | SAT | 1457352 | 1545002 | 0 | 0 | 0 | affine_sat | None | 0.081 | 4.2 | 25.7 |
| 1600 | 1600 | 462920 | 3/3 | SAT | 7771507 | 8308313 | 0 | 0 | 0 | affine_sat | None | 0.175 | 6.09 | 28.7 |
| 3200 | 3200 | 1001832 | 3/3 | SAT | 51993656 | 54475335 | 0 | 0 | 0 | affine_sat | None | 0.498 | 13.7 | 32 |
| 6400 | - | - | 0/3 | TIMEOUT | - | - | - | - | - | - | - | - | - | - |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^1.94 (R2 0.990, 6 sizes); exponential cost ~ 2^(0.0033 * n) (R2 0.879); local log-log slopes (cost vs N) between consecutive sizes: [1.31, 1.77, 1.99, 2.15, 2.46].
Largest n solved by all runs: 3200; by at least one run: 3200; first n with a failure: 6400; wrong answers: 0; UNSAT answers without an independent reference: 0.

### S3.xor3.planted.residual_dag

| n | nvars | N bits | solved/runs | status | DAG nodes (median) | DAG nodes (max) | cpu s (max) | wall s (max) |
|---|---|---|---|---|---|---|---|---|
| 10 | 10 | 1272 | 1/1 | SAT | 195 | 195 | 0.011 | 0.053 |
| 14 | 14 | 1880 | 1/1 | SAT | 282 | 282 | 0.016 | 0.328 |
| 18 | 18 | 2640 | 1/1 | SAT | 451 | 451 | 0.032 | 2.79 |
| 22 | 22 | 3352 | 1/1 | SAT | 737 | 737 | 0.031 | 0.865 |
| 26 | 26 | 4104 | 1/1 | SAT | 798 | 798 | 0.047 | 1.41 |
| 30 | 30 | 4800 | 1/1 | SAT | 1695 | 1695 | 0.069 | 1.79 |
| 40 | 40 | 6744 | 1/1 | SAT | 4841 | 4841 | 0.149 | 1.85 |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^1.84 (R2 0.923, 7 sizes); exponential cost ~ 2^(0.1539 * n) (R2 0.988); local log-log slopes (cost vs N) between consecutive sizes: [0.94, 1.38, 2.06, 0.39, 4.81, 3.09].
Largest n solved by all runs: 40; by at least one run: 40; first n with a failure: None; wrong answers: 0; UNSAT answers without an independent reference: 0.

### S3.xor3.random_n+5

| n | nvars | N bits | solved/runs | status | ticks (median) | ticks (max) | BDD nodes (median) | largest bucket | residual vars | decided by | winner | cpu s (max) | wall s (max) | RSS MB |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 100 | 100 | 20616 | 3/3 | UNSAT | 14904 | 14978 | 0 | 0 | 0 | affine_inconsistent | None | 0.026 | 0.88 | 27 |
| 200 | 200 | 44888 | 3/3 | UNSAT | 39658 | 42741 | 0 | 0 | 0 | affine_inconsistent | None | 0.033 | 1.66 | 25.3 |
| 400 | 400 | 98024 | 3/3 | UNSAT | 134665 | 148133 | 0 | 0 | 0 | affine_inconsistent | None | 0.043 | 2.12 | 25.2 |
| 800 | 800 | 214088 | 3/3 | UNSAT | 592697 | 604135 | 0 | 0 | 0 | affine_inconsistent | None | 0.066 | 1.96 | 26.6 |
| 1600 | 1600 | 464760 | 3/3 | UNSAT | 3167745 | 3532575 | 0 | 0 | 0 | affine_inconsistent | None | 0.102 | 1.44 | 31.9 |
| 3200 | 3200 | 1004240 | 3/3 | UNSAT | 20784896 | 22530318 | 0 | 0 | 0 | affine_inconsistent | None | 0.299 | 5.33 | 31.1 |
| 6400 | 6400 | 2161208 | 3/3 | UNSAT | 127464934 | 134888275 | 0 | 0 | 0 | affine_inconsistent | None | 0.896 | 14.2 | 49.7 |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^1.97 (R2 0.988, 7 sizes); exponential cost ~ 2^(0.0019 * n) (R2 0.842); local log-log slopes (cost vs N) between consecutive sizes: [1.26, 1.57, 1.9, 2.16, 2.44, 2.37].
Largest n solved by all runs: 6400; by at least one run: 6400; first n with a failure: None; wrong answers: 0; UNSAT answers without an independent reference: 0.

## Group S4

### S4.phpxor.natural

| h | nvars | N bits | solved/runs | status | ticks (median) | ticks (max) | BDD nodes (median) | largest bucket | residual vars | decided by | winner | cpu s (max) | wall s (max) | RSS MB |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 3 | 24 | 5888 | 1/1 | UNSAT | 55434 | 55434 | 1373 | 58 | 24 | bdd_false | wide+mindeg | 0.026 | 0.292 | 25.5 |
| 4 | 40 | 17312 | 1/1 | UNSAT | 164859 | 164859 | 4485 | 217 | 40 | bdd_false | wide+mindeg | 0.036 | 0.537 | 28.1 |
| 5 | 60 | 44976 | 1/1 | UNSAT | 442481 | 442481 | 14136 | 1192 | 60 | bdd_false | wide+mindeg | 0.08 | 0.236 | 30.6 |
| 6 | 84 | 113840 | 1/1 | UNSAT | 1169718 | 1169718 | 35292 | 4266 | 84 | bdd_false | wide+mindeg | 0.189 | 2.59 | 28.2 |
| 7 | 112 | 280672 | 1/1 | UNSAT | 2981647 | 2981647 | 109723 | 13195 | 112 | bdd_false | wide+mindeg | 0.442 | 6.89 | 37.8 |
| 8 | 144 | 694080 | 1/1 | UNSAT | 7986050 | 7986050 | 378601 | 42981 | 144 | bdd_false | wide+cross | 1.4 | 13.5 | 96.9 |
| 9 | - | - | 0/1 | TIMEOUT | - | - | - | - | - | - | - | - | - | - |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^1.04 (R2 1.000, 6 sizes); exponential cost ~ 2^(1.4224 * h) (R2 1.000); nodes ~ N^1.16 (R2 0.998); nodes ~ 2^(1.5913 * h) (R2 0.999); local log-log slopes (cost vs N) between consecutive sizes: [1.01, 1.03, 1.05, 1.04, 1.09].
Largest h solved by all runs: 8; by at least one run: 8; first h with a failure: 9; wrong answers: 0; UNSAT answers without an independent reference: 0.

### S4.phpxor.natural.residual_dag

| h | nvars | N bits | solved/runs | status | DAG nodes (median) | DAG nodes (max) | cpu s (max) | wall s (max) |
|---|---|---|---|---|---|---|---|---|
| 2 | 12 | 1536 | 1/1 | UNSAT | 178 | 178 | 0.009 | 0.056 |
| 3 | 24 | 5888 | 1/1 | UNSAT | 571 | 571 | 0.031 | 0.359 |
| 4 | 40 | 17312 | 1/1 | UNSAT | 1745 | 1745 | 0.11 | 0.918 |
| 5 | 60 | 44976 | 1/1 | UNSAT | 5757 | 5757 | 0.417 | 3.53 |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^1.02 (R2 0.993, 4 sizes); exponential cost ~ 2^(1.6658 * h) (R2 1.000); local log-log slopes (cost vs N) between consecutive sizes: [0.87, 1.04, 1.25].
Largest h solved by all runs: 5; by at least one run: 5; first h with a failure: None; wrong answers: 0; UNSAT answers without an independent reference: 0.

### S4.phpxor.natural.wide+cross

| h | nvars | N bits | solved/runs | status | ticks (median) | ticks (max) | BDD nodes (median) | largest bucket | residual vars | decided by | winner | cpu s (max) | wall s (max) | RSS MB |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 3 | 24 | 5888 | 1/1 | UNSAT | 35635 | 35635 | 797 | 60 | 24 | bdd_false | wide+cross | 0.03 | 0.726 | 24.5 |
| 4 | 40 | 17312 | 1/1 | UNSAT | 103621 | 103621 | 2167 | 129 | 40 | bdd_false | wide+cross | 0.034 | 1.29 | 25.6 |
| 5 | 60 | 44976 | 1/1 | UNSAT | 268918 | 268918 | 5002 | 231 | 60 | bdd_false | wide+cross | 0.048 | 0.504 | 27.2 |
| 6 | 84 | 113840 | 1/1 | UNSAT | 670632 | 670632 | 10485 | 378 | 84 | bdd_false | wide+cross | 0.086 | 1.17 | 28.2 |
| 7 | 112 | 280672 | 1/1 | UNSAT | 1657128 | 1657128 | 20750 | 591 | 112 | bdd_false | wide+cross | 0.156 | 2.64 | 25.6 |
| 8 | 144 | 694080 | 1/1 | UNSAT | 4181063 | 4181063 | 39808 | 852 | 144 | bdd_false | wide+cross | 0.35 | 5.56 | 31.1 |
| 9 | 180 | 1715568 | 1/1 | UNSAT | 10394046 | 10394046 | 75497 | 1179 | 180 | bdd_false | wide+cross | 0.764 | 5.89 | 45.4 |
| 10 | - | - | 0/1 | TIMEOUT | - | - | - | - | - | - | - | - | - | - |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^1.00 (R2 1.000, 7 sizes); exponential cost ~ 2^(1.3520 * h) (R2 0.999); nodes ~ N^0.80 (R2 0.997); nodes ~ 2^(1.0767 * h) (R2 0.993); local log-log slopes (cost vs N) between consecutive sizes: [0.99, 1.0, 0.98, 1.0, 1.02, 1.01].
Largest h solved by all runs: 9; by at least one run: 9; first h with a failure: 10; wrong answers: 0; UNSAT answers without an independent reference: 0.

### S4.phpxor.renamed

| h | nvars | N bits | solved/runs | status | ticks (median) | ticks (max) | BDD nodes (median) | largest bucket | residual vars | decided by | winner | cpu s (max) | wall s (max) | RSS MB |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 3 | 24 | 5888 | 3/3 | UNSAT | 55851 | 55931 | 1484 | 76 | 24 | bdd_false | wide+mindeg | 0.037 | 1.21 | 27.5 |
| 4 | 40 | 17312 | 3/3 | UNSAT | 169429 | 170535 | 5315 | 633 | 40 | bdd_false | wide+mindeg | 0.059 | 3.09 | 28.2 |
| 5 | 60 | 44976 | 3/3 | UNSAT | 461380 | 461759 | 18220 | 2422 | 60 | bdd_false | wide+mindeg | 0.098 | 1.95 | 29.5 |
| 6 | 84 | 113840 | 3/3 | UNSAT | 1352636 | 1368759 | 84165 | 15540 | 84 | bdd_false | wide+cross,wide+mindeg | 0.322 | 3.4 | 43.6 |
| 7 | 112 | 280672 | 3/3 | UNSAT | 3430699 | 3440021 | 241119 | 42590 | 112 | bdd_false | wide+cross | 0.785 | 12.4 | 69.4 |
| 8 | - | - | 0/3 | TIMEOUT | - | - | - | - | - | - | - | - | - | - |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^1.07 (R2 1.000, 5 sizes); exponential cost ~ 2^(1.4879 * h) (R2 0.999); nodes ~ N^1.35 (R2 0.997); nodes ~ 2^(1.8673 * h) (R2 0.998); local log-log slopes (cost vs N) between consecutive sizes: [1.03, 1.05, 1.16, 1.03].
Largest h solved by all runs: 7; by at least one run: 7; first h with a failure: 8; wrong answers: 0; UNSAT answers without an independent reference: 0.

### S4.tseitin+3clauses.even

| vertices | nvars | N bits | solved/runs | status | ticks (median) | ticks (max) | BDD nodes (median) | largest bucket | residual vars | decided by | winner | cpu s (max) | wall s (max) | RSS MB |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 50 | 75 | 9410 | 3/3 | SAT | 11208 | 11209 | 18 | 3 | 9 | bdd_sat | wide+mindeg | 0.025 | 0.657 | 26.5 |
| 100 | 150 | 20996 | 3/3 | SAT | 28921 | 29146 | 18 | 3 | 9 | bdd_sat | wide+mindeg | 0.026 | 0.662 | 27 |
| 200 | 300 | 46534 | 3/3 | SAT | 78854 | 89696 | 18 | 3 | 9 | bdd_sat | wide+mindeg | 0.031 | 0.531 | 27.1 |
| 400 | 600 | 102376 | 3/3 | SAT | 364683 | 374605 | 18 | 3 | 9 | bdd_sat | wide+mindeg | 0.041 | 1.24 | 25.8 |
| 800 | 1200 | 223626 | 3/3 | SAT | 1649453 | 1718405 | 18 | 3 | 9 | bdd_sat | wide+mindeg | 0.066 | 1.03 | 28.9 |
| 1600 | 2400 | 485290 | 3/3 | SAT | 11088377 | 11456506 | 18 | 3 | 9 | bdd_sat | wide+mindeg | 0.143 | 2.09 | 30.9 |
| 3200 | 4800 | 1046996 | 2/3 | SAT + TIMEOUT | 8.16e+07 | 86423062 | 18 | 3 | 9 | bdd_sat | wide+mindeg | 0.623 | 13.3 | 34.5 |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^1.74 (R2 0.981, 6 sizes); exponential cost ~ 2^(0.0060 * vertices) (R2 0.903); nodes ~ N^-0.00 (R2 0.000); nodes ~ 2^(0.0000 * vertices) (R2 1.000); local log-log slopes (cost vs N) between consecutive sizes: [1.18, 1.26, 1.94, 1.93, 2.46].
Largest vertices solved by all runs: 1600; by at least one run: 3200; first vertices with a failure: 3200; wrong answers: 0; UNSAT answers without an independent reference: 0.

### S4.tseitin+3clauses.odd

| vertices | nvars | N bits | solved/runs | status | ticks (median) | ticks (max) | BDD nodes (median) | largest bucket | residual vars | decided by | winner | cpu s (max) | wall s (max) | RSS MB |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 50 | 75 | 9420 | 2/2 | UNSAT | 5.95e+03 | 5956 | 0 | 0 | 0 | affine_inconsistent | None | 0.024 | 0.386 | 26.9 |
| 100 | 150 | 21005 | 2/2 | UNSAT | 1.3e+04 | 13051 | 0 | 0 | 0 | affine_inconsistent | None | 0.029 | 0.273 | 27 |
| 200 | 300 | 46542 | 2/2 | UNSAT | 2.98e+04 | 29910 | 0 | 0 | 0 | affine_inconsistent | None | 0.027 | 0.522 | 27.1 |
| 400 | 600 | 102384 | 2/2 | UNSAT | 7.38e+04 | 73973 | 0 | 0 | 0 | affine_inconsistent | None | 0.034 | 0.843 | 26.1 |
| 800 | 1200 | 223633 | 2/2 | UNSAT | 198704 | 198958 | 0 | 0 | 0 | affine_inconsistent | None | 0.047 | 1.14 | 27.5 |
| 1600 | 2400 | 485298 | 2/2 | UNSAT | 596763 | 597466 | 0 | 0 | 0 | affine_inconsistent | None | 0.076 | 0.64 | 30.8 |
| 3200 | 4800 | 1046996 | 2/2 | UNSAT | 1960339 | 1963627 | 0 | 0 | 0 | affine_inconsistent | None | 0.209 | 8.9 | 31.1 |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^1.22 (R2 0.993, 7 sizes); exponential cost ~ 2^(0.0024 * vertices) (R2 0.829); local log-log slopes (cost vs N) between consecutive sizes: [0.98, 1.04, 1.15, 1.27, 1.42, 1.55].
Largest vertices solved by all runs: 3200; by at least one run: 3200; first vertices with a failure: None; wrong answers: 0; UNSAT answers without an independent reference: 0.

### S4.tseitin+3clauses.residual_dag

| vertices | nvars | N bits | solved/runs | status | DAG nodes (median) | DAG nodes (max) | cpu s (max) | wall s (max) |
|---|---|---|---|---|---|---|---|---|
| 10 | 15 | 1442 | 1/1 | SAT | 401 | 401 | 0.016 | 0.197 |
| 16 | 24 | 2504 | 1/1 | SAT | 1060 | 1060 | 0.036 | 1.28 |
| 20 | 30 | 3214 | 1/1 | SAT | 1893 | 1893 | 0.061 | 0.398 |
| 24 | 36 | 4004 | 1/1 | SAT | 911 | 911 | 0.044 | 0.36 |
| 30 | 45 | 5208 | 1/1 | SAT | 4463 | 4463 | 0.144 | 1.34 |
| 40 | 60 | 7216 | 1/1 | SAT | 7805 | 7805 | 0.317 | 4.6 |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^1.77 (R2 0.838, 6 sizes); exponential cost ~ 2^(0.1373 * vertices) (R2 0.858); local log-log slopes (cost vs N) between consecutive sizes: [1.76, 2.32, -3.33, 6.04, 1.71].
Largest vertices solved by all runs: 40; by at least one run: 40; first vertices with a failure: None; wrong answers: 0; UNSAT answers without an independent reference: 0.

### S4.tseitin+5clauses.even

| vertices | nvars | N bits | solved/runs | status | ticks (median) | ticks (max) | BDD nodes (median) | largest bucket | residual vars | decided by | winner | cpu s (max) | wall s (max) | RSS MB |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 50 | 75 | 9518 | 3/3 | SAT | 11748 | 11939 | 30 | 5 | 14 | bdd_sat | wide+mindeg | 0.024 | 0.468 | 26.9 |
| 100 | 150 | 21112 | 3/3 | SAT | 29468 | 29631 | 30 | 3 | 14 | bdd_sat | wide+mindeg | 0.026 | 0.506 | 27.2 |
| 200 | 300 | 46662 | 3/3 | SAT | 79385 | 90147 | 30 | 3 | 15 | bdd_sat | wide+mindeg | 0.03 | 0.655 | 26.1 |
| 400 | 600 | 102518 | 3/3 | SAT | 365231 | 374990 | 30 | 3 | 15 | bdd_sat | wide+mindeg | 0.043 | 0.811 | 27.6 |
| 800 | 1200 | 223780 | 3/3 | SAT | 1649997 | 1718833 | 30 | 3 | 15 | bdd_sat | wide+mindeg | 0.07 | 0.915 | 27.5 |
| 1600 | 2400 | 485458 | 3/3 | SAT | 11088614 | 11457415 | 30 | 3 | 15 | bdd_sat | wide+mindeg | 0.196 | 12.2 | 27.6 |
| 3200 | 4800 | 1047168 | 3/3 | SAT | 81869200 | 86422260 | 30 | 3 | 15 | bdd_sat | wide+mindeg | 0.653 | 14.6 | 31.1 |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^1.89 (R2 0.979, 7 sizes); exponential cost ~ 2^(0.0038 * vertices) (R2 0.866); nodes ~ N^0.00 (R2 1.000); nodes ~ 2^(0.0000 * vertices) (R2 1.000); local log-log slopes (cost vs N) between consecutive sizes: [1.15, 1.25, 1.94, 1.93, 2.46, 2.6].
Largest vertices solved by all runs: 3200; by at least one run: 3200; first vertices with a failure: None; wrong answers: 0; UNSAT answers without an independent reference: 0.

## Group S5

### S5.r3_3.00

| n | nvars | N bits | solved/runs | status | ticks (median) | ticks (max) | BDD nodes (median) | largest bucket | residual vars | decided by | winner | cpu s (max) | wall s (max) | RSS MB |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 20 | 20 | 2186 | 5/5 | SAT | 32799 | 34377 | 3269 | 427 | 20 | bdd_sat | wide+mindeg | 0.04 | 1.39 | 25.5 |
| 25 | 25 | 2828 | 5/5 | SAT | 52320 | 57253 | 6042 | 1132 | 25 | bdd_sat | wide+mindeg | 0.057 | 2.25 | 26.4 |
| 30 | 30 | 3472 | 5/5 | SAT | 117502 | 130605 | 18808 | 4837 | 30 | bdd_sat | wide+mindeg | 0.118 | 2.85 | 28.5 |
| 35 | 35 | 4220 | 5/5 | SAT | 217004 | 343888 | 42618 | 13174 | 35 | bdd_sat | wide+mindeg | 0.285 | 6.42 | 31.5 |
| 40 | 40 | 4984 | 5/5 | SAT | 716833 | 836709 | 142272 | 18041 | 40 | bdd_sat | wide+mindeg | 0.758 | 12.1 | 60.7 |
| 45 | 45 | 5696 | 1/5 | SAT + TIMEOUT | 1212852 | 1212852 | 273405 | 59682 | 45 | bdd_sat | wide+mindeg | 1.11 | 15.6 | 74.7 |
| 50 | - | - | 0/5 | TIMEOUT | - | - | - | - | - | - | - | - | - | - |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^3.64 (R2 0.947, 5 sizes); exponential cost ~ 2^(0.2190 * n) (R2 0.976); nodes ~ N^4.58 (R2 0.970); nodes ~ 2^(0.2741 * n) (R2 0.990); local log-log slopes (cost vs N) between consecutive sizes: [1.81, 3.94, 3.14, 7.18].
Largest n solved by all runs: 40; by at least one run: 45; first n with a failure: 45; wrong answers: 0; UNSAT answers without an independent reference: 0.

### S5.r3_3.00.residual_dag

| n | nvars | N bits | solved/runs | status | DAG nodes (median) | DAG nodes (max) | cpu s (max) | wall s (max) |
|---|---|---|---|---|---|---|---|---|
| 10 | 10 | 951 | 2/2 | SAT | 220 | 256 | 0.009 | 0.578 |
| 15 | 15 | 1501 | 2/2 | SAT | 1145 | 1579 | 0.039 | 1.04 |
| 20 | 20 | 2165 | 2/2 | SAT | 3.95e+03 | 4609 | 0.087 | 2.08 |
| 25 | 25 | 2832 | 2/2 | SAT | 10477 | 15801 | 0.269 | 5.72 |
| 30 | 30 | 3458 | 2/2 | SAT | 39692 | 49811 | 0.919 | 19.3 |
| 35 | 35 | 4220 | 1/2 | SAT | 61214 | 61214 | 0.966 | 11 |
| 40 | - | - | 0/2 | TIMEOUT | - | - | - | - |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^3.86 (R2 0.987, 5 sizes); exponential cost ~ 2^(0.3636 * n) (R2 0.993); local log-log slopes (cost vs N) between consecutive sizes: [3.61, 3.38, 3.63, 6.67].
Largest n solved by all runs: 30; by at least one run: 35; first n with a failure: 35; wrong answers: 0; UNSAT answers without an independent reference: 0.

### S5.r3_4.26

| n | nvars | N bits | solved/runs | status | ticks (median) | ticks (max) | BDD nodes (median) | largest bucket | residual vars | decided by | winner | cpu s (max) | wall s (max) | RSS MB |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 20 | 20 | 3092 | 5/5 | SAT,UNSAT | 47114 | 49967 | 4059 | 491 | 20 | bdd_false,bdd_sat | wide+cross,wide+mindeg | 0.038 | 0.898 | 27.8 |
| 25 | 25 | 4022 | 5/5 | SAT,UNSAT | 78271 | 80317 | 9726 | 1014 | 25 | bdd_false,bdd_sat | wide+cross,wide+mindeg | 0.076 | 2.4 | 27.1 |
| 30 | 30 | 4956 | 5/5 | SAT | 159309 | 205182 | 23454 | 3765 | 30 | bdd_sat | wide+mindeg | 0.174 | 4.72 | 28.7 |
| 35 | 35 | 5988 | 5/5 | SAT,UNSAT | 296868 | 448433 | 57555 | 15769 | 35 | bdd_false,bdd_sat | wide+cross,wide+mindeg | 0.392 | 7.23 | 40.9 |
| 40 | 40 | 7048 | 5/5 | SAT,UNSAT | 1042441 | 1214689 | 229641 | 31319 | 40 | bdd_false,bdd_sat | wide+mindeg | 1.15 | 18 | 78.4 |
| 45 | - | - | 0/5 | TIMEOUT | - | - | - | - | - | - | - | - | - | - |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^3.60 (R2 0.935, 5 sizes); exponential cost ~ 2^(0.2172 * n) (R2 0.970); nodes ~ N^4.74 (R2 0.966); nodes ~ 2^(0.2842 * n) (R2 0.990); local log-log slopes (cost vs N) between consecutive sizes: [1.93, 3.4, 3.29, 7.71].
Largest n solved by all runs: 40; by at least one run: 40; first n with a failure: 45; wrong answers: 0; UNSAT answers without an independent reference: 0.

### S5.r3_4.26.residual_dag

| n | nvars | N bits | solved/runs | status | DAG nodes (median) | DAG nodes (max) | cpu s (max) | wall s (max) |
|---|---|---|---|---|---|---|---|---|
| 10 | 10 | 1357 | 2/2 | SAT | 261 | 269 | 0.013 | 0.675 |
| 15 | 15 | 2141 | 2/2 | SAT,UNSAT | 879 | 1040 | 0.025 | 0.317 |
| 20 | 20 | 3085 | 2/2 | SAT,UNSAT | 3.73e+03 | 3819 | 0.07 | 1.72 |
| 25 | 25 | 4014 | 2/2 | SAT,UNSAT | 4.96e+03 | 6097 | 0.114 | 2.37 |
| 30 | 30 | 4946 | 2/2 | SAT | 16637 | 23442 | 0.426 | 7.56 |
| 35 | - | - | 0/2 | TIMEOUT | - | - | - | - |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^3.10 (R2 0.979, 5 sizes); exponential cost ~ 2^(0.2897 * n) (R2 0.969); local log-log slopes (cost vs N) between consecutive sizes: [2.66, 3.96, 1.08, 5.79].
Largest n solved by all runs: 30; by at least one run: 30; first n with a failure: 35; wrong answers: 0; UNSAT answers without an independent reference: 0.

### S5.r3_4.26.wide+mindeg

| n | nvars | N bits | solved/runs | status | ticks (median) | ticks (max) | BDD nodes (median) | largest bucket | residual vars | decided by | winner | cpu s (max) | wall s (max) | RSS MB |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 20 | 20 | 3110 | 3/3 | SAT,UNSAT | 26535 | 26984 | 2423 | 491 | 20 | bdd_false,bdd_sat | wide+mindeg | 0.037 | 1.21 | 25.6 |
| 25 | 25 | 4022 | 3/3 | SAT,UNSAT | 42815 | 44925 | 5973 | 770 | 25 | bdd_false,bdd_sat | wide+mindeg | 0.053 | 1.8 | 24.8 |
| 30 | 30 | 4956 | 3/3 | SAT | 79624 | 98830 | 12439 | 1938 | 30 | bdd_sat | wide+mindeg | 0.091 | 1.52 | 28.3 |
| 35 | 35 | 5968 | 3/3 | SAT,UNSAT | 206484 | 208303 | 42360 | 10112 | 35 | bdd_false,bdd_sat | wide+mindeg | 0.198 | 3.66 | 29.1 |
| 40 | 40 | 7058 | 3/3 | SAT,UNSAT | 587169 | 596650 | 120923 | 23497 | 40 | bdd_false,bdd_sat | wide+mindeg | 0.657 | 11.9 | 47.9 |
| 45 | 45 | 8126 | 1/3 | SAT + TIMEOUT | 1443839 | 1443839 | 314986 | 73289 | 45 | bdd_sat | wide+mindeg | 1.54 | 17.6 | 89 |
| 50 | - | - | 0/3 | TIMEOUT | - | - | - | - | - | - | - | - | - | - |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^3.74 (R2 0.942, 5 sizes); exponential cost ~ 2^(0.2241 * n) (R2 0.975); nodes ~ N^4.75 (R2 0.975); nodes ~ 2^(0.2822 * n) (R2 0.993); local log-log slopes (cost vs N) between consecutive sizes: [1.86, 2.97, 5.13, 6.23].
Largest n solved by all runs: 40; by at least one run: 45; first n with a failure: 45; wrong answers: 0; UNSAT answers without an independent reference: 0.

## Group S6

### S6.horn

| n | nvars | N bits | solved/runs | status | ticks (median) | ticks (max) | BDD nodes (median) | largest bucket | residual vars | decided by | winner | cpu s (max) | wall s (max) | RSS MB |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 20 | 20 | 2198 | 5/5 | SAT | 23488 | 26138 | 1005 | 213 | 19 | bdd_sat | wide+mindeg | 0.041 | 2.2 | 25.5 |
| 30 | 30 | 3504 | 5/5 | SAT | 74920 | 82551 | 9701 | 2045 | 29 | bdd_sat | wide+mindeg | 0.084 | 2.2 | 26 |
| 40 | 40 | 5040 | 5/5 | SAT | 140647 | 159774 | 21797 | 5574 | 38 | bdd_sat | wide+mindeg | 0.132 | 3.9 | 28.3 |
| 50 | 50 | 6530 | 5/5 | SAT | 601279 | 1503920 | 126078 | 61482 | 48 | bdd_sat | wide+mindeg | 1.26 | 8.53 | 112 |
| 60 | 60 | 8002 | 1/5 | SAT + TIMEOUT | 884072 | 884072 | 190982 | 26412 | 56 | bdd_sat | wide+mindeg | 0.815 | 8.12 | 71.3 |
| 70 | - | - | 0/5 | TIMEOUT | - | - | - | - | - | - | - | - | - | - |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^2.78 (R2 0.948, 4 sizes); exponential cost ~ 2^(0.1494 * n) (R2 0.979); nodes ~ N^4.19 (R2 0.973); nodes ~ 2^(0.2208 * n) (R2 0.971); local log-log slopes (cost vs N) between consecutive sizes: [2.49, 1.73, 5.61].
Largest n solved by all runs: 50; by at least one run: 60; first n with a failure: 60; wrong answers: 0; UNSAT answers without an independent reference: 0.

### S6.horn_nofacts

| n | nvars | N bits | solved/runs | status | ticks (median) | ticks (max) | BDD nodes (median) | largest bucket | residual vars | decided by | winner | cpu s (max) | wall s (max) | RSS MB |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 20 | 20 | 2182 | 5/5 | SAT | 25742 | 30485 | 1626 | 412 | 20 | bdd_sat | wide+mindeg | 0.047 | 1.36 | 25.5 |
| 25 | 25 | 2844 | 5/5 | SAT | 42867 | 54559 | 3884 | 657 | 25 | bdd_sat | wide+mindeg | 0.052 | 1.39 | 26.1 |
| 30 | 30 | 3490 | 5/5 | SAT | 83106 | 107831 | 11352 | 2904 | 30 | bdd_sat | wide+mindeg | 0.094 | 2.97 | 28.9 |
| 35 | 35 | 4228 | 5/5 | SAT | 118434 | 238610 | 19369 | 7328 | 35 | bdd_sat | wide+mindeg | 0.192 | 2.36 | 36.4 |
| 40 | 40 | 5004 | 5/5 | SAT | 244615 | 510809 | 47825 | 14650 | 40 | bdd_sat | wide+mindeg | 0.469 | 7.23 | 44.9 |
| 45 | 45 | 5752 | 5/5 | SAT | 701480 | 1565736 | 153665 | 32269 | 45 | bdd_sat | wide+mindeg | 1.46 | 14.7 | 97.8 |
| 50 | 50 | 6475 | 2/5 | SAT + TIMEOUT | 673709 | 860931 | 1.42e+05 | 56051 | 50 | bdd_sat | wide+mindeg | 0.791 | 13.5 | 56.9 |
| 55 | - | - | 0/5 | TIMEOUT | - | - | - | - | - | - | - | - | - | - |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^3.21 (R2 0.941, 6 sizes); exponential cost ~ 2^(0.1822 * n) (R2 0.976); nodes ~ N^4.51 (R2 0.977); nodes ~ 2^(0.2540 * n) (R2 0.993); local log-log slopes (cost vs N) between consecutive sizes: [1.92, 3.23, 1.85, 4.3, 7.56].
Largest n solved by all runs: 45; by at least one run: 50; first n with a failure: 50; wrong answers: 0; UNSAT answers without an independent reference: 0.

### S6.horn_nofacts.residual_dag

| n | nvars | N bits | solved/runs | status | DAG nodes (median) | DAG nodes (max) | cpu s (max) | wall s (max) |
|---|---|---|---|---|---|---|---|---|
| 10 | 10 | 955 | 2/2 | SAT | 192 | 211 | 0.011 | 0.403 |
| 15 | 15 | 1532 | 2/2 | SAT | 743 | 773 | 0.027 | 1.02 |
| 20 | 20 | 2192 | 2/2 | SAT | 2.28e+03 | 2494 | 0.051 | 0.507 |
| 25 | 25 | 2830 | 2/2 | SAT | 7.39e+03 | 10807 | 0.238 | 1.93 |
| 30 | 30 | 3457 | 2/2 | SAT | 72590 | 98776 | 1.77 | 17.5 |
| 35 | 35 | 4210 | 1/2 | SAT | 63224 | 63224 | 1.12 | 9.99 |
| 40 | - | - | 0/2 | TIMEOUT | - | - | - | - |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^4.24 (R2 0.916, 5 sizes); exponential cost ~ 2^(0.4088 * n) (R2 0.978); local log-log slopes (cost vs N) between consecutive sizes: [2.86, 3.13, 4.6, 11.41].
Largest n solved by all runs: 30; by at least one run: 35; first n with a failure: 35; wrong answers: 0; UNSAT answers without an independent reference: 0.

### S6.r2_0.9

| n | nvars | N bits | solved/runs | status | ticks (median) | ticks (max) | BDD nodes (median) | largest bucket | residual vars | decided by | winner | cpu s (max) | wall s (max) | RSS MB |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 100 | 100 | 2986 | 3/3 | SAT | 24045 | 24049 | 382 | 4 | 83 | bdd_sat | wide+mindeg | 0.03 | 0.613 | 26 |
| 200 | 200 | 6710 | 3/3 | SAT | 52761 | 52872 | 767 | 5 | 166 | bdd_sat | wide+mindeg | 0.035 | 0.466 | 27 |
| 400 | 400 | 14798 | 3/3 | SAT | 115795 | 117323 | 1552 | 5 | 332 | bdd_sat | wide+mindeg | 0.045 | 0.635 | 27.5 |
| 800 | 800 | 32392 | 3/3 | SAT | 250896 | 255637 | 3119 | 5 | 672 | bdd_sat | wide+mindeg | 0.072 | 1.62 | 27.2 |
| 1600 | 1600 | 70370 | 3/3 | SAT | 540854 | 541690 | 6267 | 5 | 1328 | bdd_sat | wide+mindeg | 0.125 | 2.93 | 28.6 |
| 3200 | 3200 | 152672 | 3/3 | SAT | 1159615 | 1159971 | 12523 | 5 | 2681 | bdd_sat | wide+mindeg | 0.223 | 4.02 | 32 |
| 6400 | 6400 | 327924 | 3/3 | SAT | 2473429 | 2514167 | 25012 | 5 | 5359 | bdd_sat | wide+mindeg | 0.457 | 8.25 | 33.2 |
| 12800 | 12800 | 701454 | 2/3 | SAT + TIMEOUT | 5.3e+06 | 5343021 | 5.03e+04 | 5 | 10627 | bdd_sat | wide+mindeg | 1.01 | 22.4 | 54.2 |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^0.99 (R2 1.000, 7 sizes); exponential cost ~ 2^(0.0009 * n) (R2 0.765); nodes ~ N^0.89 (R2 1.000); nodes ~ 2^(0.0008 * n) (R2 0.768); local log-log slopes (cost vs N) between consecutive sizes: [0.97, 0.99, 0.99, 0.99, 0.98, 0.99].
Largest n solved by all runs: 6400; by at least one run: 12800; first n with a failure: 12800; wrong answers: 0; UNSAT answers without an independent reference: 0.

### S6.r2_0.9.residual_dag

| n | nvars | N bits | solved/runs | status | DAG nodes (median) | DAG nodes (max) | cpu s (max) | wall s (max) |
|---|---|---|---|---|---|---|---|---|
| 20 | 20 | 450 | 1/1 | SAT | 89 | 89 | 0.009 | 0.017 |
| 40 | 40 | 1050 | 1/1 | SAT | 249 | 249 | 0.024 | 0.487 |
| 80 | 80 | 2332 | 1/1 | SAT | 465 | 465 | 0.059 | 0.819 |
| 160 | 160 | 5212 | 1/1 | SAT | 8088 | 8088 | 0.729 | 14.2 |
| 320 | - | - | 0/1 | TIMEOUT | - | - | - | - |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^1.73 (R2 0.890, 4 sizes); exponential cost ~ 2^(0.0446 * n) (R2 0.982); local log-log slopes (cost vs N) between consecutive sizes: [1.21, 0.78, 3.55].
Largest n solved by all runs: 160; by at least one run: 160; first n with a failure: 320; wrong answers: 0; UNSAT answers without an independent reference: 0.

### S6.r2_1.5

| n | nvars | N bits | solved/runs | status | ticks (median) | ticks (max) | BDD nodes (median) | largest bucket | residual vars | decided by | winner | cpu s (max) | wall s (max) | RSS MB |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 100 | 100 | 5006 | 5/5 | SAT,UNSAT | 45529 | 46578 | 814 | 12 | 95 | bdd_false,bdd_sat | wide+mindeg | 0.033 | 0.717 | 27.2 |
| 200 | 200 | 11132 | 5/5 | UNSAT | 100055 | 102852 | 1732 | 28 | 189 | bdd_false | wide+mindeg | 0.048 | 1.3 | 27.3 |
| 400 | 400 | 24598 | 5/5 | UNSAT | 223954 | 232973 | 3753 | 143 | 381 | bdd_false | wide+mindeg | 0.072 | 1.81 | 26.6 |
| 600 | 600 | 38916 | 5/5 | UNSAT | 362032 | 432431 | 9090 | 1450 | 571 | bdd_false | wide+mindeg | 0.152 | 2 | 28.6 |
| 800 | 800 | 53902 | 5/5 | UNSAT | 494883 | 580698 | 11606 | 1674 | 757 | bdd_false | wide+mindeg | 0.188 | 2.88 | 33.9 |
| 1000 | 1000 | 68944 | 5/5 | UNSAT | 732811 | 904058 | 29600 | 8268 | 945 | bdd_false | wide+mindeg | 0.437 | 10.4 | 34.1 |
| 1200 | 1200 | 84926 | 5/5 | UNSAT | 1003512 | 1213792 | 67182 | 17569 | 1139 | bdd_false | wide+mindeg | 0.527 | 14.9 | 44.4 |
| 1400 | 1400 | 101227 | 4/5 | UNSAT + TIMEOUT | 2121154 | 2858597 | 2.37e+05 | 45071 | 1.33e+03 | bdd_false | wide+mindeg | 1.85 | 14.2 | 141 |
| 1600 | 1600 | 117298 | 1/5 | UNSAT + TIMEOUT | 2066193 | 2066193 | 229353 | 25711 | 1528 | bdd_false | wide+mindeg | 0.972 | 16.5 | 68.8 |
| 2000 | 2000 | 149688 | 2/5 | UNSAT + TIMEOUT | 1.5e+06 | 1760737 | 7.22e+04 | 11534 | 1.9e+03 | bdd_false | wide+mindeg | 0.606 | 4.6 | 57.6 |
| 2400 | 2400 | 184337 | 2/5 | UNSAT + TIMEOUT | 1837323 | 2101052 | 7.94e+04 | 10258 | 2280 | bdd_false | wide+mindeg | 0.706 | 3.1 | 64.4 |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^1.07 (R2 0.995, 7 sizes); exponential cost ~ 2^(0.0038 * n) (R2 0.932); nodes ~ N^1.45 (R2 0.931); nodes ~ 2^(0.0054 * n) (R2 0.984); local log-log slopes (cost vs N) between consecutive sizes: [0.99, 1.02, 1.05, 0.96, 1.59, 1.51].
Largest n solved by all runs: 1200; by at least one run: 2400; first n with a failure: 1400; wrong answers: 0; UNSAT answers without an independent reference: 0.

### S6.r2_1.5.residual_dag

| n | nvars | N bits | solved/runs | status | DAG nodes (median) | DAG nodes (max) | cpu s (max) | wall s (max) |
|---|---|---|---|---|---|---|---|---|
| 20 | 20 | 764 | 1/1 | SAT | 473 | 473 | 0.016 | 0.314 |
| 40 | 40 | 1720 | 1/1 | SAT | 310 | 310 | 0.025 | 0.485 |
| 80 | 80 | 3880 | 1/1 | UNSAT | 3030 | 3030 | 0.178 | 4.34 |
| 160 | - | - | 0/1 | TIMEOUT | - | - | - | - |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^1.14 (R2 0.587, 3 sizes); exponential cost ~ 2^(0.0500 * n) (R2 0.763); local log-log slopes (cost vs N) between consecutive sizes: [-0.52, 2.8].
Largest n solved by all runs: 80; by at least one run: 80; first n with a failure: 160; wrong answers: 0; UNSAT answers without an independent reference: 0.

### S6.selector

| k | nvars | N bits | solved/runs | status | ticks (median) | ticks (max) | BDD nodes (median) | largest bucket | residual vars | decided by | winner | cpu s (max) | wall s (max) | RSS MB |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 10 | 30 | 506 | 1/1 | SAT | 4192 | 4192 | 82 | 3 | 30 | bdd_sat | wide+mindeg | 0.026 | 0.576 | 24.7 |
| 100 | 300 | 7556 | 1/1 | SAT | 59322 | 59322 | 802 | 3 | 300 | bdd_sat | wide+mindeg | 0.039 | 1.44 | 24 |
| 1000 | 3000 | 101808 | 1/1 | SAT | 758022 | 758022 | 8002 | 3 | 3000 | bdd_sat | wide+mindeg | 0.123 | 3.79 | 27.7 |
| 4000 | 12000 | 471096 | 1/1 | SAT | 3472022 | 3472022 | 32002 | 3 | 12000 | bdd_sat | wide+mindeg | 0.485 | 8.63 | 39.7 |
| 16000 | - | - | 0/1 | TIMEOUT | - | - | - | - | - | - | - | - | - | - |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^0.98 (R2 1.000, 4 sizes); exponential cost ~ 2^(0.0019 * k) (R2 0.688); nodes ~ N^0.87 (R2 1.000); nodes ~ 2^(0.0017 * k) (R2 0.698); local log-log slopes (cost vs N) between consecutive sizes: [0.98, 0.98, 0.99].
Largest k solved by all runs: 4000; by at least one run: 4000; first k with a failure: 16000; wrong answers: 0; UNSAT answers without an independent reference: 0.

### S6.selector.residual_dag

| k | nvars | N bits | solved/runs | status | DAG nodes (median) | DAG nodes (max) | cpu s (max) | wall s (max) |
|---|---|---|---|---|---|---|---|---|
| 10 | 30 | 506 | 1/1 | SAT | 122 | 122 | 0.011 | 0.167 |
| 100 | 300 | 7556 | 1/1 | SAT | 1202 | 1202 | 0.349 | 8.11 |
| 1000 | - | - | 0/1 | TIMEOUT | - | - | - | - |

Fits over sizes where every run was solved (empirical, finite range): not enough points.
Largest k solved by all runs: 100; by at least one run: 100; first k with a failure: 1000; wrong answers: 0; UNSAT answers without an independent reference: 0.

## Group X

### X.chain2

| n | nvars | N bits | solved/runs | status | ticks (median) | ticks (max) | BDD nodes (median) | largest bucket | residual vars | decided by | winner | cpu s (max) | wall s (max) | RSS MB |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 100 | 100 | 3320 | 1/1 | SAT | 26075 | 26075 | 408 | 3 | 100 | bdd_sat | wide+mindeg | 0.027 | 1.11 | 25.6 |
| 1000 | 1000 | 45948 | 1/1 | SAT | 341075 | 341075 | 4008 | 3 | 1000 | bdd_sat | wide+mindeg | 0.072 | 1 | 27.4 |
| 10000 | 10000 | 594524 | 1/1 | SAT | 4490075 | 4490075 | 40008 | 3 | 10000 | bdd_sat | wide+mindeg | 0.595 | 11.3 | 41.8 |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^0.99 (R2 1.000, 3 sizes); exponential cost ~ 2^(0.0006 * n) (R2 0.818); nodes ~ N^0.88 (R2 1.000); nodes ~ 2^(0.0005 * n) (R2 0.819); local log-log slopes (cost vs N) between consecutive sizes: [0.98, 1.01].
Largest n solved by all runs: 10000; by at least one run: 10000; first n with a failure: None; wrong answers: 0; UNSAT answers without an independent reference: 0.

### X.chessboard

| board | nvars | N bits | solved/runs | status | ticks (median) | ticks (max) | BDD nodes (median) | largest bucket | residual vars | decided by | winner | cpu s (max) | wall s (max) | RSS MB |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 4 | 20 | 1538 | 1/1 | UNSAT | 12311 | 12311 | 295 | 17 | 14 | bdd_false | wide+mindeg | 0.022 | 0.387 | 27 |
| 6 | 56 | 5798 | 1/1 | UNSAT | 58196 | 58196 | 1748 | 47 | 50 | bdd_false | wide+mindeg | 0.035 | 0.34 | 27.4 |
| 8 | 108 | 13076 | 1/1 | UNSAT | 151025 | 151025 | 6681 | 163 | 102 | bdd_false | wide+mindeg | 0.059 | 0.542 | 28.5 |
| 10 | 176 | 23584 | 1/1 | UNSAT | 311668 | 311668 | 18700 | 525 | 170 | bdd_false | wide+mindeg | 0.111 | 0.499 | 30.9 |
| 12 | 260 | 37180 | 1/1 | UNSAT | 545435 | 545435 | 41880 | 997 | 254 | bdd_false | wide+mindeg | 0.184 | 0.936 | 36.8 |
| 14 | 360 | 54904 | 1/1 | UNSAT | 910465 | 910465 | 76844 | 3247 | 354 | bdd_false | wide+mindeg | 0.317 | 1.39 | 44.4 |
| 16 | 476 | 75620 | 1/1 | UNSAT | 1763423 | 1763423 | 208672 | 8332 | 470 | bdd_false | wide+cross | 0.852 | 11.2 | 63.2 |
| 18 | 608 | 100640 | 1/1 | UNSAT | 2494088 | 2494088 | 321025 | 14273 | 602 | bdd_false | wide+cross | 1.32 | 11.2 | 104 |
| 20 | 756 | 129518 | 1/1 | UNSAT | 3462984 | 3462984 | 485623 | 24374 | 750 | bdd_false | wide+cross | 1.81 | 15 | 123 |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^1.28 (R2 0.996, 9 sizes); exponential cost ~ 2^(0.4787 * board) (R2 0.950); nodes ~ N^1.71 (R2 0.992); nodes ~ 2^(0.6439 * board) (R2 0.958); local log-log slopes (cost vs N) between consecutive sizes: [1.17, 1.17, 1.23, 1.23, 1.31, 2.06, 1.21, 1.3].
Largest board solved by all runs: 20; by at least one run: 20; first board with a failure: None; wrong answers: 0; UNSAT answers without an independent reference: 0.

### X.chessboard.renamed

| board | nvars | N bits | solved/runs | status | ticks (median) | ticks (max) | BDD nodes (median) | largest bucket | residual vars | decided by | winner | cpu s (max) | wall s (max) | RSS MB |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 4 | 20 | 1536 | 1/1 | UNSAT | 12286 | 12286 | 292 | 13 | 14 | bdd_false | wide+mindeg | 0.028 | 0.396 | 26.9 |
| 6 | 56 | 5760 | 1/1 | UNSAT | 57580 | 57580 | 1687 | 50 | 50 | bdd_false | wide+mindeg | 0.028 | 0.34 | 26 |
| 8 | 108 | 12982 | 1/1 | UNSAT | 154726 | 154726 | 7563 | 226 | 102 | bdd_false | wide+mindeg | 0.064 | 0.936 | 26.7 |
| 10 | 176 | 23538 | 1/1 | UNSAT | 340027 | 340027 | 26204 | 995 | 170 | bdd_false | wide+mindeg | 0.137 | 2.45 | 30.9 |
| 12 | 260 | 37060 | 1/1 | UNSAT | 527598 | 527598 | 38117 | 502 | 254 | bdd_false | wide+mindeg | 0.199 | 2.55 | 33.1 |
| 14 | 360 | 54738 | 1/1 | UNSAT | 987134 | 987134 | 105887 | 4356 | 354 | bdd_false | wide+mindeg | 0.447 | 5.46 | 45.9 |
| 16 | 476 | 75364 | 1/1 | UNSAT | 1346837 | 1346837 | 137083 | 3914 | 470 | bdd_false | wide+mindeg | 0.56 | 4.91 | 58.1 |
| 18 | 608 | 100394 | 1/1 | UNSAT | 2578286 | 2578286 | 409116 | 18198 | 602 | bdd_false | wide+cross | 1.42 | 9.03 | 108 |
| 20 | - | - | 0/1 | TIMEOUT | - | - | - | - | - | - | - | - | - | - |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^1.25 (R2 0.997, 8 sizes); exponential cost ~ 2^(0.5083 * board) (R2 0.947); nodes ~ N^1.70 (R2 0.989); nodes ~ 2^(0.6955 * board) (R2 0.952); local log-log slopes (cost vs N) between consecutive sizes: [1.17, 1.22, 1.32, 0.97, 1.61, 0.97, 2.26].
Largest board solved by all runs: 18; by at least one run: 18; first board with a failure: 20; wrong answers: 0; UNSAT answers without an independent reference: 0.

### X.ordering

| elements | nvars | N bits | solved/runs | status | ticks (median) | ticks (max) | BDD nodes (median) | largest bucket | residual vars | decided by | winner | cpu s (max) | wall s (max) | RSS MB |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 4 | 12 | 1178 | 1/1 | UNSAT | 4064 | 4064 | 109 | 11 | 6 | bdd_false | wide+mindeg | 0.022 | 0.226 | 26.9 |
| 5 | 20 | 2906 | 1/1 | UNSAT | 10582 | 10582 | 378 | 35 | 10 | bdd_false | wide+mindeg | 0.025 | 0.263 | 27 |
| 6 | 30 | 5832 | 1/1 | UNSAT | 25154 | 25154 | 1577 | 147 | 15 | bdd_false | wide+mindeg | 0.029 | 0.324 | 27.4 |
| 7 | 42 | 10562 | 1/1 | UNSAT | 63265 | 63265 | 6951 | 733 | 21 | bdd_false | wide+mindeg | 0.057 | 1 | 25.8 |
| 8 | 56 | 17222 | 1/1 | UNSAT | 172122 | 172122 | 29111 | 2583 | 28 | bdd_false | wide+mindeg | 0.115 | 0.758 | 34 |
| 9 | 72 | 26514 | 1/1 | UNSAT | 662608 | 662608 | 140062 | 20775 | 36 | bdd_false | wide+cross | 0.476 | 4.53 | 56.6 |
| 10 | - | - | 0/1 | TIMEOUT | - | - | - | - | - | - | - | - | - | - |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^1.57 (R2 0.960, 6 sizes); exponential cost ~ 2^(1.4328 * elements) (R2 0.994); nodes ~ N^2.29 (R2 0.972); nodes ~ 2^(2.0737 * elements) (R2 0.999); local log-log slopes (cost vs N) between consecutive sizes: [1.06, 1.24, 1.55, 2.05, 3.12].
Largest elements solved by all runs: 9; by at least one run: 9; first elements with a failure: 10; wrong answers: 0; UNSAT answers without an independent reference: 0.

### X.tseitin_deg7

| vertices | nvars | N bits | solved/runs | status | ticks (median) | ticks (max) | BDD nodes (median) | largest bucket | residual vars | decided by | winner | cpu s (max) | wall s (max) | RSS MB |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 10 | 35 | 58368 | 2/2 | UNSAT | 601652 | 602287 | 9526 | 77 | 35 | bdd_false | wide+mindeg | 0.088 | 1.85 | 29.8 |
| 12 | 42 | 72960 | 2/2 | UNSAT | 7.21e+05 | 721711 | 11208 | 83 | 42 | bdd_false | wide+mindeg | 0.1 | 0.978 | 30.1 |
| 14 | 49 | 87552 | 2/2 | UNSAT | 8.42e+05 | 842982 | 13523 | 103 | 49 | bdd_false | wide+mindeg | 0.127 | 1.06 | 31 |
| 16 | 56 | 102144 | 2/2 | UNSAT | 1034786 | 1035789 | 15143 | 115 | 56 | bdd_false | wide+mindeg | 0.136 | 1.19 | 31.3 |
| 18 | 63 | 116736 | 2/2 | UNSAT | 1.16e+06 | 1162224 | 15818 | 123 | 63 | bdd_false | wide+mindeg | 0.152 | 1.34 | 31.7 |
| 20 | 70 | 133120 | 2/2 | UNSAT | 1.31e+06 | 1306303 | 17973 | 135 | 70 | bdd_false | wide+mindeg | 0.17 | 1.58 | 32 |
| 24 | 84 | 165888 | 2/2 | UNSAT | 1567710 | 1567835 | 21703 | 145 | 84 | bdd_false | wide+mindeg | 0.192 | 1.71 | 34.3 |
| 30 | 105 | 215040 | 2/2 | UNSAT | 1960253 | 1960422 | 27203 | 181 | 105 | bdd_false | wide+mindeg | 0.229 | 2.01 | 36 |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^0.93 (R2 0.997, 8 sizes); exponential cost ~ 2^(0.0852 * vertices) (R2 0.960); nodes ~ N^0.79 (R2 0.995); nodes ~ 2^(0.0735 * vertices) (R2 0.973); local log-log slopes (cost vs N) between consecutive sizes: [0.81, 0.85, 1.33, 0.87, 0.89, 0.83, 0.86].
Largest vertices solved by all runs: 30; by at least one run: 30; first vertices with a failure: None; wrong answers: 0; UNSAT answers without an independent reference: 0.

### X.xor6_planted

| n | nvars | N bits | solved/runs | status | ticks (median) | ticks (max) | BDD nodes (median) | largest bucket | residual vars | decided by | winner | cpu s (max) | wall s (max) | RSS MB |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 10 | 10 | 19648 | 3/3 | SAT | 16106 | 16143 | 0 | 0 | 0 | affine_sat | None | 0.028 | 0.358 | 27.3 |
| 20 | 20 | 45440 | 3/3 | SAT | 33366 | 33406 | 0 | 0 | 0 | affine_sat | None | 0.033 | 0.961 | 27.5 |
| 40 | 40 | 103424 | 3/3 | SAT | 69218 | 69324 | 0 | 0 | 0 | affine_sat | None | 0.041 | 0.55 | 27.8 |
| 80 | 80 | 237312 | 3/3 | SAT | 154854 | 154941 | 0 | 0 | 0 | affine_sat | None | 0.059 | 0.634 | 29.7 |
| 160 | 160 | 532224 | 3/3 | SAT | 367972 | 369716 | 0 | 0 | 0 | affine_sat | None | 0.091 | 2.23 | 31.3 |
| 320 | 320 | 1181056 | 3/3 | SAT | 1123474 | 1128965 | 0 | 0 | 0 | affine_sat | None | 0.17 | 2.3 | 38.3 |
| 640 | 640 | 2604288 | 3/3 | SAT | 4880064 | 4916281 | 0 | 0 | 0 | affine_sat | None | 0.39 | 4.79 | 54.2 |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^1.13 (R2 0.979, 7 sizes); exponential cost ~ 2^(0.0118 * n) (R2 0.873); local log-log slopes (cost vs N) between consecutive sizes: [0.87, 0.89, 0.97, 1.07, 1.4, 1.86].
Largest n solved by all runs: 640; by at least one run: 640; first n with a failure: None; wrong answers: 0; UNSAT answers without an independent reference: 0.

### X.xor7_planted

| n | nvars | N bits | solved/runs | status | ticks (median) | ticks (max) | BDD nodes (median) | largest bucket | residual vars | decided by | winner | cpu s (max) | wall s (max) | RSS MB |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 10 | 10 | 45952 | 3/3 | SAT | 611879 | 613397 | 6360 | 61 | 10 | bdd_sat | wide+mindeg | 0.094 | 0.956 | 29.4 |
| 12 | 12 | 57344 | 3/3 | SAT | 743373 | 743546 | 9919 | 125 | 12 | bdd_sat | wide+mindeg | 0.111 | 1.19 | 29.8 |
| 14 | 14 | 67840 | 3/3 | SAT | 877034 | 887341 | 14899 | 317 | 14 | bdd_sat | wide+mindeg | 0.141 | 1.68 | 31.6 |
| 16 | 16 | 80128 | 3/3 | SAT | 1087109 | 1091484 | 19418 | 285 | 16 | bdd_sat | wide+mindeg | 0.145 | 3.31 | 30.5 |
| 18 | 18 | 93952 | 3/3 | SAT | 1233398 | 1235830 | 19880 | 509 | 18 | bdd_sat | wide+mindeg | 0.166 | 1.86 | 34.3 |
| 20 | 20 | 105344 | 3/3 | SAT | 1393920 | 1405184 | 31231 | 769 | 20 | bdd_sat | wide+mindeg | 0.207 | 2.63 | 34 |
| 22 | 22 | 119424 | 3/3 | SAT | 1543998 | 1653483 | 43099 | 2621 | 22 | bdd_sat | wide+mindeg | 0.322 | 2.83 | 43 |
| 24 | 24 | 131072 | 3/3 | SAT | 1727225 | 1749715 | 61015 | 2045 | 24 | bdd_sat | wide+mindeg | 0.284 | 2.97 | 40.4 |
| 26 | 26 | 144512 | 3/3 | SAT | 1890787 | 2098542 | 71016 | 5341 | 26 | bdd_sat | wide+mindeg | 0.526 | 6.96 | 50 |
| 28 | 28 | 157312 | 3/3 | SAT | 2014344 | 2054793 | 59946 | 2237 | 28 | bdd_sat | wide+mindeg | 0.337 | 3.31 | 43.6 |
| 30 | 30 | 170240 | 3/3 | SAT | 2234404 | 2248038 | 75587 | 4349 | 30 | bdd_sat | wide+mindeg | 0.437 | 4.65 | 51.8 |
| 32 | 32 | 183168 | 3/3 | SAT | 2611023 | 2683101 | 100647 | 9469 | 32 | bdd_sat | wide+mindeg | 0.563 | 5.29 | 57 |
| 34 | 34 | 198016 | 3/3 | SAT | 2823419 | 2922154 | 139397 | 24573 | 34 | bdd_sat | wide+mindeg | 0.633 | 8.35 | 49.5 |
| 36 | 36 | 211072 | 3/3 | SAT | 3101392 | 3112048 | 137426 | 33277 | 36 | bdd_sat | wide+mindeg | 0.702 | 9.06 | 63.5 |
| 38 | 38 | 227456 | 3/3 | SAT | 3614907 | 4252590 | 229494 | 97277 | 38 | bdd_sat | wide+mindeg | 1.72 | 20.4 | 123 |
| 40 | 40 | 240000 | 3/3 | SAT | 4071553 | 4328784 | 291866 | 70717 | 40 | bdd_sat | wide+mindeg | 1.45 | 14.8 | 121 |
| 42 | 42 | 255744 | 1/3 | SAT + TIMEOUT | 5270128 | 5270128 | 526715 | 163837 | 42 | bdd_sat | wide+mindeg | 1.73 | 20.1 | 150 |
| 44 | 44 | 270720 | 2/3 | SAT + TIMEOUT | 4.92e+06 | 5424459 | 401357 | 112125 | 44 | bdd_sat | wide+mindeg | 2.07 | 19.5 | 168 |
| 46 | - | - | 0/3 | TIMEOUT | - | - | - | - | - | - | - | - | - | - |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^1.10 (R2 0.988, 16 sizes); exponential cost ~ 2^(0.0848 * n) (R2 0.987); nodes ~ N^2.16 (R2 0.973); nodes ~ 2^(0.1669 * n) (R2 0.974); local log-log slopes (cost vs N) between consecutive sizes: [0.88, 0.98, 1.29, 0.79, 1.07, 0.82, 1.2, 0.93, 0.75, 1.31, 2.13, 1.0, 1.47, 2.05, 2.22].
Largest n solved by all runs: 40; by at least one run: 44; first n with a failure: 42; wrong answers: 0; UNSAT answers without an independent reference: 0.

### X.xor7_planted.residual_dag

| n | nvars | N bits | solved/runs | status | DAG nodes (median) | DAG nodes (max) | cpu s (max) | wall s (max) |
|---|---|---|---|---|---|---|---|---|
| 8 | 8 | 33664 | 1/1 | SAT | 935 | 935 | 0.033 | 0.229 |
| 10 | 10 | 45440 | 1/1 | SAT | 2249 | 2249 | 0.085 | 0.789 |
| 12 | 12 | 57344 | 1/1 | SAT | 3172 | 3172 | 0.143 | 0.998 |
| 14 | 14 | 67840 | 1/1 | SAT | 5495 | 5495 | 0.262 | 3.36 |
| 16 | 16 | 80640 | 1/1 | SAT | 8927 | 8927 | 0.454 | 4.83 |
| 18 | 18 | 93952 | 1/1 | SAT | 11048 | 11048 | 0.468 | 6.51 |
| 20 | 20 | 105344 | 1/1 | SAT | 75698 | 75698 | 2.02 | 19.6 |
| 22 | - | - | 0/1 | TIMEOUT | - | - | - | - |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^3.20 (R2 0.866, 7 sizes); exponential cost ~ 2^(0.4483 * n) (R2 0.917); local log-log slopes (cost vs N) between consecutive sizes: [2.93, 1.48, 3.27, 2.81, 1.4, 16.82].
Largest n solved by all runs: 20; by at least one run: 20; first n with a failure: 22; wrong answers: 0; UNSAT answers without an independent reference: 0.

### X.xor_and

| n | nvars | N bits | solved/runs | status | ticks (median) | ticks (max) | BDD nodes (median) | largest bucket | residual vars | decided by | winner | cpu s (max) | wall s (max) | RSS MB |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 20 | 20 | 2216 | 3/3 | SAT | 8435 | 11730 | 285 | 61 | 13 | bdd_sat | wide+mindeg | 0.029 | 1.17 | 25.5 |
| 30 | 30 | 3592 | 3/3 | SAT | 21822 | 26132 | 1810 | 435 | 26 | bdd_sat | wide+mindeg | 0.035 | 1.01 | 27.3 |
| 40 | 40 | 5044 | 3/3 | SAT | 49524 | 55090 | 7012 | 1812 | 36 | bdd_sat | wide+mindeg | 0.049 | 1.53 | 28.2 |
| 50 | 50 | 6418 | 3/3 | SAT | 198477 | 356525 | 37070 | 9725 | 46 | bdd_sat | wide+mindeg | 0.28 | 4.51 | 35 |
| 60 | 60 | 7942 | 3/3 | SAT | 204523 | 256374 | 40927 | 12376 | 54 | bdd_sat | wide+mindeg | 0.216 | 4.71 | 29.1 |
| 70 | 70 | 9495 | 2/3 | SAT + TIMEOUT | 6.16e+05 | 860301 | 1.41e+05 | 28705 | 63.5 | bdd_sat | wide+mindeg | 0.863 | 19.1 | 57.6 |
| 80 | 80 | 11208 | 2/3 | SAT + TIMEOUT | 5.65e+05 | 927008 | 113822 | 45729 | 72.5 | bdd_sat | wide+mindeg | 0.833 | 17 | 58.1 |
| 90 | 90 | 13098 | 1/3 | SAT + TIMEOUT | 3562536 | 3562536 | 863149 | 134874 | 83 | bdd_sat | wide+mindeg | 3.36 | 14.7 | 210 |
| 100 | - | - | 0/3 | TIMEOUT | - | - | - | - | - | - | - | - | - | - |

Fits over sizes where every run was solved (empirical, finite range): power law cost ~ N^2.70 (R2 0.954, 5 sizes); exponential cost ~ 2^(0.1238 * n) (R2 0.953); nodes ~ N^4.14 (R2 0.979); nodes ~ 2^(0.1869 * n) (R2 0.947); local log-log slopes (cost vs N) between consecutive sizes: [1.97, 2.41, 5.76, 0.14].
Largest n solved by all runs: 60; by at least one run: 90; first n with a failure: 70; wrong answers: 0; UNSAT answers without an independent reference: 0.

