#!/usr/bin/env python3
"""Run ONE instance of a family through CFPE (or the unchanged residual DAG) and print
one JSON record.  This is the exact reproduction command quoted in the report.

  python3 experiments/run_one.py --family php --size 9
  python3 experiments/run_one.py --family php --size 9 --renamed 3
  python3 experiments/run_one.py --family r3_426 --size 40 --seed 1 --strategy wide+mindeg
  python3 experiments/run_one.py --family php --size 5 --solver residual_dag

Honesty rules implemented here: a SAT answer counts only if this file's own evaluator
accepts the assignment on the ORIGINAL clauses; an UNSAT answer is compared with the
family's independent reference (construction / GF(2) / SCC / forward chaining / DPLL);
UNKNOWN (node cap, deadline, budget) is recorded as CAP / TIMEOUT / BUDGET and is never
treated as an answer.
"""
import argparse
import importlib.util
import json
import os
import resource
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
import families  # noqa: E402


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def run_cfpe(args, nvars, clauses):
    mod = load(args.candidate, "cfpe_candidate")
    strategy = None if args.strategy == "portfolio" else args.strategy
    if args.bound_degree:
        res = mod.solve_capped(nvars, clauses, C=args.bound_constant, d=args.bound_degree,
                               node_cap=args.node_cap, time_limit=args.time_limit, strategy=strategy)
    else:
        res = mod.solve(nvars, clauses, None, node_cap=args.node_cap, time_limit=args.time_limit,
                        strategy=strategy)
    ops = res["operations"]
    rec = {"status": res["status"], "reason": res.get("reason"),
           "ticks": ops["total_ticks"], "categories": ops["categories"],
           "bdd_nodes_total": ops["bdd_nodes_total"], "bdd_nodes_peak": ops["bdd_nodes_peak"],
           "bdd_largest_bucket": ops["bdd_largest_bucket"],
           "bdd_largest_factor": ops["bdd_largest_factor"],
           "bit_cost_upper": ops["bit_cost_upper"], "decided_by": ops["decided_by"],
           "winning_strategy": ops["strategy"], "attempts": ops["attempts"],
           "residual_vars": ops["residual_vars"], "residual_clauses": ops["residual_clauses"],
           "residual_xor_rows": ops["residual_xor_rows"], "N_bits": ops["encoded_bits_N"]}
    if args.bound_degree:
        rec["budget_maximum"] = res["budget_maximum"]
        rec["within_budget"] = res["within_budget"]
    return rec, res.get("assignment")


def run_residual_dag(args, nvars, clauses):
    """The UNCHANGED native-search/residual_dag.py, natural variable order, node cap."""
    sys.setrecursionlimit(200000)
    path = os.path.join(os.path.dirname(os.path.dirname(ROOT)), "alg001", "native-search", "residual_dag.py")
    if not os.path.exists(path):
        path = os.path.join(os.path.dirname(ROOT), "native-search", "residual_dag.py")
    native = load(path, "native_residual_dag")
    cap = args.dag_node_cap
    deadline = time.monotonic() + args.time_limit

    class Stop(Exception):
        pass

    class CappedDAG(native.DAG):
        calls = 0

        def junction(self, op, children):
            CappedDAG.calls += 1
            if CappedDAG.calls & 127 == 0:
                if len(self.nodes) > cap:
                    raise Stop("node_cap")
                if time.monotonic() > deadline:
                    raise Stop("deadline")
            return native.DAG.junction(self, op, children)

    dag = CappedDAG()
    status, reason = "UNKNOWN", None
    try:
        root = dag.cnf(clauses)
        for v in range(1, nvars + 1):
            root = dag.forget(root, v)
            if root in (0, 1):
                break
        if root in (0, 1):
            status = "SAT" if root == 1 else "UNSAT"
        else:
            reason = "nonconstant_root"
    except Stop as exc:
        reason = str(exc)
    except RecursionError:
        reason = "recursion_limit"
    rec = {"status": status, "reason": reason, "dag_nodes": len(dag.nodes),
           "junction_calls": CappedDAG.calls, "cofactor_cache": len(dag.cofactor_cache)}
    return rec, None


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--family", required=True, choices=sorted(families.FAMILIES))
    ap.add_argument("--size", type=int, required=True)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--renamed", type=int, default=None, help="seed of a renaming + clause shuffle")
    ap.add_argument("--solver", default="cfpe", choices=("cfpe", "residual_dag"))
    ap.add_argument("--strategy", default="portfolio")
    ap.add_argument("--candidate", default=os.path.join(ROOT, "candidate.py"))
    ap.add_argument("--node-cap", type=int, default=1500000)
    ap.add_argument("--dag-node-cap", type=int, default=400000)
    ap.add_argument("--time-limit", type=float, default=20.0)
    ap.add_argument("--bound-degree", type=int, default=0)
    ap.add_argument("--bound-constant", type=float, default=1.0)
    ap.add_argument("--dpll-nodes", type=int, default=20000)
    ap.add_argument("--series", default=None, help="label copied into the record")
    args = ap.parse_args()

    t_gen = time.monotonic()
    nvars, clauses, meta = families.make(args.family, args.size, args.seed, args.renamed)
    gen_seconds = time.monotonic() - t_gen
    rec = {"family": args.family, "size": args.size, "seed": args.seed, "renamed": args.renamed,
           "solver": args.solver, "strategy": args.strategy if args.solver == "cfpe" else "natural",
           "series": args.series, "nvars": nvars, "nclauses": len(clauses),
           "literals": sum(len(c) for c in clauses),
           "N_bits": sum(4 + 2 * abs(l).bit_length() for c in clauses for l in c) + 2 * len(clauses),
           "expected": meta["expected"], "expected_by": meta["expected_by"],
           "gen_seconds": round(gen_seconds, 3), "node_cap": args.node_cap, "time_limit": args.time_limit}
    cpu0 = time.process_time()
    wall0 = time.monotonic()
    if args.solver == "cfpe":
        out, assignment = run_cfpe(args, nvars, clauses)
    else:
        out, assignment = run_residual_dag(args, nvars, clauses)
    rec.update(out)
    if args.solver == "cfpe":
        import hashlib
        with open(args.candidate, "rb") as fh:
            rec["candidate_sha256"] = hashlib.sha256(fh.read()).hexdigest()
    rec["cpu_seconds"] = round(time.process_time() - cpu0, 3)
    rec["wall_seconds"] = round(time.monotonic() - wall0, 3)
    rec["max_rss_mb"] = round(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 2 ** 20, 1)

    status = rec["status"]
    verdict = None
    if status == "SAT":
        if args.solver == "cfpe":
            ok = isinstance(assignment, list) and len(assignment) == nvars and \
                families.check_model(clauses, assignment)
            rec["witness_verified"] = bool(ok)
            verdict = "ok" if ok else "WRONG"
        else:
            verdict = "ok" if meta["expected"] in (None, "SAT") else "WRONG"
        if meta["expected"] == "UNSAT":
            verdict = "WRONG"
    elif status == "UNSAT":
        expected = meta["expected"]
        if expected is None and nvars <= 400 and args.dpll_nodes > 0:
            expected = families.dpll(nvars, clauses, args.dpll_nodes)
            rec["expected"] = expected
            rec["expected_by"] = "independent DPLL (node limit %d)" % args.dpll_nodes
        verdict = "ok" if expected == "UNSAT" else ("unverified" if expected is None else "WRONG")
    else:
        reason = rec.get("reason") or ""
        verdict = {"node_cap": "CAP", "deadline": "TIMEOUT"}.get(
            reason, "BUDGET" if reason.startswith("budget") else "UNKNOWN:" + reason)
    rec["verdict"] = verdict
    print(json.dumps(rec, sort_keys=True))
    return 0 if verdict != "WRONG" else 1


if __name__ == "__main__":
    sys.exit(main())
