import sys, time, random, json, resource
sys.path.insert(0, '/Users/jackpohlad/Documents/Codex/2026-11-25/fetch-and-follow-the-instructions-at/work/alg001/fable')
import candidate as c

def r3(n, ratio, seed):
    rng = random.Random(seed)
    m = round(ratio * n)
    return n, [tuple(v * rng.choice((1, -1)) for v in rng.sample(range(1, n + 1), 3)) for _ in range(m)]

if __name__ == '__main__':
    strategies = sys.argv[1].split(',')
    ns = [int(x) for x in sys.argv[2].split(',')]
    ratio = float(sys.argv[3])
    cap = int(sys.argv[4]) if len(sys.argv) > 4 else 1500000
    for n in ns:
        nv, cl = r3(n, ratio, 1000 + n)
        for s in strategies:
            t0 = time.process_time(); w0 = time.monotonic()
            r = c.solve(nv, cl, None, strategy=None if s == 'portfolio' else s, time_limit=25, node_cap=cap)
            o = r['operations']
            print(json.dumps(dict(n=n, strat=s, status=r['status'], reason=r.get('reason'), ticks=o['total_ticks'],
                  nodes=o['bdd_nodes_total'], bucket=o['bdd_largest_bucket'], cpu=round(time.process_time() - t0, 2),
                  wall=round(time.monotonic() - w0, 2), rss_mb=round(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 2**20, 1),
                  att=[(a['strategy'], a['result'], a['nodes'], a['ticks']) for a in o['attempts']])), flush=True)
