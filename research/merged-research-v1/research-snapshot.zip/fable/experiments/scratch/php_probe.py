import sys, time, random, json
sys.path.insert(0, '/Users/jackpohlad/Documents/Codex/2026-11-25/fetch-and-follow-the-instructions-at/work/alg001/fable')
import candidate as c

def php(h, p=None):
    p = h + 1 if p is None else p
    var = lambda i, k: i * h + k + 1
    cl = [tuple(var(i, k) for k in range(h)) for i in range(p)]
    for k in range(h):
        for i in range(p):
            for j in range(i + 1, p):
                cl.append((-var(i, k), -var(j, k)))
    return p * h, cl, var

def rename(n, cl, seed):
    rng = random.Random(seed)
    perm = list(range(1, n + 1)); rng.shuffle(perm)
    out = [tuple(rng.sample([(perm[abs(l) - 1] if l > 0 else -perm[abs(l) - 1]) for l in c_], len(c_))) for c_ in cl]
    rng.shuffle(out)
    return out, perm

if __name__ == '__main__':
    strategies = sys.argv[1].split(',')
    hs = [int(x) for x in sys.argv[2].split(',')]
    seed = int(sys.argv[3]) if len(sys.argv) > 3 else None
    for h in hs:
        n, cl, var = php(h)
        if seed is not None:
            cl, perm = rename(n, cl, seed)
        for s in strategies:
            t0 = time.process_time(); w0 = time.monotonic()
            if s == 'oracle':
                # row-major BDD order, column-major elimination (natural indices only)
                strat = (('static', [var(i, k) for i in range(h + 1) for k in range(h)]),
                         ('static', [var(i, k) for k in range(h) for i in range(h + 1)]))
            elif s == 'portfolio':
                strat = None
            else:
                strat = s
            r = c.solve(n, cl, None, strategy=strat, time_limit=25, node_cap=1500000)
            o = r['operations']
            print(json.dumps(dict(h=h, strat=s, status=r['status'], reason=r.get('reason'), ticks=o['total_ticks'],
                  nodes=o['bdd_nodes_total'], bucket=o['bdd_largest_bucket'], cpu=round(time.process_time() - t0, 2),
                  wall=round(time.monotonic() - w0, 2))), flush=True)
