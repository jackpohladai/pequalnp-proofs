import sys, time, random, json
sys.path.insert(0, '/Users/jackpohlad/Documents/Codex/2026-11-25/fetch-and-follow-the-instructions-at/work/alg001/fable')
import candidate as c

def php(h, p=None, functional=False, onto=False):
    p = h + 1 if p is None else p
    var = lambda i, k: i * h + k + 1
    cl = [tuple(var(i, k) for k in range(h)) for i in range(p)]
    for k in range(h):
        for i in range(p):
            for j in range(i + 1, p):
                cl.append((-var(i, k), -var(j, k)))
    if functional:
        for i in range(p):
            for k in range(h):
                for k2 in range(k + 1, h):
                    cl.append((-var(i, k), -var(i, k2)))
    if onto:
        for k in range(h):
            cl.append(tuple(var(i, k) for i in range(p)))
    return p * h, cl

def rename(n, cl, seed):
    rng = random.Random(seed)
    perm = list(range(1, n + 1)); rng.shuffle(perm)
    out = [tuple(rng.sample([(perm[abs(l) - 1] if l > 0 else -perm[abs(l) - 1]) for l in c_], len(c_))) for c_ in cl]
    rng.shuffle(out)
    return out

if __name__ == '__main__':
    variant = sys.argv[1]
    strategies = sys.argv[2].split(',')
    hs = [int(x) for x in sys.argv[3].split(',')]
    seed = int(sys.argv[4]) if len(sys.argv) > 4 else None
    for h in hs:
        kw = dict(functional='f' in variant, onto='o' in variant)
        p = h + 1
        if '2' in variant: p = 2 * h
        n, cl = php(h, p, **kw)
        if seed is not None:
            cl = rename(n, cl, seed)
        for s in strategies:
            t0 = time.process_time(); w0 = time.monotonic()
            r = c.solve(n, cl, None, strategy=None if s == 'portfolio' else s, time_limit=20, node_cap=400000)
            o = r['operations']
            print(json.dumps(dict(variant=variant, h=h, p=p, strat=s, status=r['status'], reason=r.get('reason'), ticks=o['total_ticks'],
                  nodes=o['bdd_nodes_total'], bucket=o['bdd_largest_bucket'], cpu=round(time.process_time() - t0, 2),
                  wall=round(time.monotonic() - w0, 2))), flush=True)
