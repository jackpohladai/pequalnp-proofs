#!/usr/bin/env python3
"""Render experiments/scaling.json as Markdown tables (experiments/scaling_tables.md).

  python3 experiments/make_tables.py            # rebuild scaling.json from the JSONL first
  python3 experiments/make_tables.py --print    # also print to stdout

Pure presentation: every number comes from scaling.jsonl; nothing is recomputed by hand.
"""
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import run_scaling  # noqa: E402


def fmt(x):
    if x is None:
        return "-"
    if isinstance(x, float):
        if x == int(x) and abs(x) < 1e15:
            return str(int(x))
        return "%.3g" % x
    return str(x)


def series_table(label, s):
    out = ["### %s" % label, ""]
    unit = s.get("size_unit") or "size"
    if s["cost_measure"] == "ticks":
        head = [unit, "nvars", "N bits", "solved/runs", "status", "ticks (median)", "ticks (max)",
                "BDD nodes (median)", "largest bucket", "residual vars", "decided by", "winner",
                "cpu s (max)", "wall s (max)", "RSS MB"]
        out.append("| " + " | ".join(head) + " |")
        out.append("|" + "---|" * len(head))
        for r in s["table"]:
            if r["solved"]:
                row = [r["size"], r.get("nvars"), r.get("N_bits_median"), "%d/%d" % (r["solved"], r["runs"]),
                       ",".join(r["statuses"]), r.get("cost_median"), r.get("cost_max"), r.get("nodes_median"),
                       r.get("largest_bucket_max"), r.get("residual_vars_median"),
                       ",".join(r.get("decided_by", [])), ",".join(r.get("winners", [])),
                       r.get("cpu_seconds_max"), r.get("wall_seconds_max"), r.get("max_rss_mb")]
                if r["solved"] < r["runs"]:
                    row[4] += " + " + ",".join(v for v in r["verdicts"] if v not in ("ok",))
            else:
                row = [r["size"], "-", "-", "0/%d" % r["runs"], ",".join(r["verdicts"])] + ["-"] * 10
            out.append("| " + " | ".join(fmt(x) for x in row) + " |")
    else:
        head = [unit, "nvars", "N bits", "solved/runs", "status", "DAG nodes (median)", "DAG nodes (max)",
                "cpu s (max)", "wall s (max)"]
        out.append("| " + " | ".join(head) + " |")
        out.append("|" + "---|" * len(head))
        for r in s["table"]:
            if r["solved"]:
                row = [r["size"], r.get("nvars"), r.get("N_bits_median"), "%d/%d" % (r["solved"], r["runs"]),
                       ",".join(r["statuses"]), r.get("cost_median"), r.get("cost_max"),
                       r.get("cpu_seconds_max"), r.get("wall_seconds_max")]
            else:
                row = [r["size"], "-", "-", "0/%d" % r["runs"], ",".join(r["verdicts"]), "-", "-", "-", "-"]
            out.append("| " + " | ".join(fmt(x) for x in row) + " |")
    fit = s.get("fit") or {}
    lines = []
    if "power_law_in_N" in fit:
        f = fit["power_law_in_N"]
        lines.append("power law cost ~ N^%.2f (R2 %.3f, %d sizes)" % (f["exponent"], f["r2"], f["points"]))
    if "exponential_in_size" in fit:
        f = fit["exponential_in_size"]
        lines.append("exponential cost ~ 2^(%.4f * %s) (R2 %.3f)" % (f["log2_growth_per_unit"], unit, f["r2"]))
    if "nodes_power_law_in_N" in fit:
        f = fit["nodes_power_law_in_N"]
        lines.append("nodes ~ N^%.2f (R2 %.3f)" % (f["exponent"], f["r2"]))
    if "nodes_exponential_in_size" in fit:
        f = fit["nodes_exponential_in_size"]
        lines.append("nodes ~ 2^(%.4f * %s) (R2 %.3f)" % (f["log2_growth_per_unit"], unit, f["r2"]))
    if fit.get("local_loglog_slopes"):
        lines.append("local log-log slopes (cost vs N) between consecutive sizes: %s" % fit["local_loglog_slopes"])
    out.append("")
    out.append("Fits over sizes where every run was solved (empirical, finite range): "
               + ("; ".join(lines) if lines else "not enough points") + ".")
    out.append("Largest %s solved by all runs: %s; by at least one run: %s; first %s with a failure: %s; "
               "wrong answers: %d; UNSAT answers without an independent reference: %d." % (
                   unit, s["largest_size_solved_all_seeds"], s["largest_size_solved_any_seed"], unit,
                   s["first_size_with_a_failure"], s["wrong_answers"], s["unverified_unsat"]))
    out.append("")
    return "\n".join(out)


def main():
    data = run_scaling.summarise()
    groups = {}
    for label, s in data["series"].items():
        groups.setdefault(s.get("group") or "?", []).append((label, s))
    parts = ["# CFPE scaling tables (generated from experiments/scaling.jsonl)", "",
             "%d runs, %d wrong answers.  %s" % (data["total_runs"], data["wrong_answers"], data["warning"]),
             "Limits per run: 30 s wall clock (solver deadline 20 s), 1.5 M BDD nodes (portfolio: 750 k per "
             "strategy), residual DAG 400 k nodes.  'TIMEOUT' = the wall-clock deadline was hit; compare the "
             "cpu and wall columns: the machine was heavily loaded by other jobs.", ""]
    for g in sorted(groups):
        parts.append("## Group %s" % g)
        parts.append("")
        for label, s in sorted(groups[g]):
            parts.append(series_table(label, s))
    text = "\n".join(parts) + "\n"
    path = os.path.join(HERE, "scaling_tables.md")
    for attempt in range(5):
        try:
            with open(path, "w") as fh:
                fh.write(text)
            break
        except OSError:
            import time
            time.sleep(1)
    if "--print" in sys.argv:
        print(text)
    else:
        print("wrote %s (%d series, %d runs)" % (path, len(data["series"]), data["total_runs"]))
    return 0


if __name__ == "__main__":
    sys.exit(main())
