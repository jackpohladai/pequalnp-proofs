#!/usr/bin/env python3
"""Scaling campaign for CFPE (S1..S6 + obstacle search + residual-DAG comparison).

Every run is ONE subprocess of experiments/run_one.py with a 30 s wall-clock timeout
(the solver itself gets a 20 s deadline and a 1.5 M BDD-node cap).  Results are appended
to experiments/scaling.jsonl as they arrive; ``--summarise`` rebuilds
experiments/scaling.json (per-series tables and fitted growth rates).

  python3 experiments/run_scaling.py --plan all --jobs 6
  python3 experiments/run_scaling.py --plan S1 --jobs 6
  python3 experiments/run_scaling.py --summarise

A series is escalated in size until the first run that does not return a verified
answer (CAP / TIMEOUT); with several seeds per size the series stops when ALL seeds of
a size fail.  Fits are empirical descriptions of finite data, not asymptotic claims.
"""
import argparse
import concurrent.futures
import json
import math
import os
import subprocess
import sys
import threading
import time

HERE = os.path.dirname(os.path.abspath(__file__))
RUN_ONE = os.path.join(HERE, "run_one.py")
JSONL = os.path.join(HERE, "scaling.jsonl")
OUT = os.path.join(HERE, "scaling.json")
LOCK = threading.Lock()


def S(label, family, sizes, seeds=(0,), renamed=(None,), strategy="portfolio", solver="cfpe",
      group="", unit="size", extra=()):
    return {"label": label, "family": family, "sizes": list(sizes), "seeds": list(seeds),
            "renamed": list(renamed), "strategy": strategy, "solver": solver, "group": group,
            "unit": unit, "extra": list(extra)}


REN5 = (11, 12, 13, 14, 15)
CAP50 = ("--node-cap", "50000")
PLAN = [
    # ---------------- S1 pigeonhole
    S("S1.php.natural.portfolio", "php", range(3, 31), group="S1", unit="h"),
    S("S1.php.renamed.portfolio", "php", range(4, 31, 2), renamed=REN5, group="S1", unit="h"),
    S("S1.php.natural.wide+cross", "php", range(4, 41, 2), strategy="wide+cross", group="S1", unit="h"),
    S("S1.php.renamed.wide+cross", "php", range(4, 41, 4), renamed=REN5, strategy="wide+cross", group="S1", unit="h"),
    S("S1.php.natural.wide+mindeg", "php", range(3, 16), strategy="wide+mindeg", group="S1", unit="h"),
    S("S1.php.renamed.wide+mindeg", "php", range(4, 16, 2), renamed=REN5[:2], strategy="wide+mindeg", group="S1", unit="h"),
    S("S1.php.natural.wide+minfac", "php", range(4, 25, 2), strategy="wide+minfac", group="S1", unit="h"),
    S("S1.php.natural.index+level", "php", range(3, 16), strategy="index+level", group="S1", unit="h"),
    S("S1.php.natural.bfs+mindeg", "php", range(3, 16), strategy="bfs+mindeg", group="S1", unit="h"),
    S("S1.php.natural.force+mindeg", "php", range(3, 16), strategy="force+mindeg", group="S1", unit="h"),
    S("S1.php.natural.residual_dag", "php", range(3, 12), solver="residual_dag", group="S1", unit="h"),
    S("S1x.fphp.natural.portfolio", "fphp", range(4, 25, 2), group="S1x", unit="h"),
    S("S1x.fphp.renamed.portfolio", "fphp", range(4, 25, 4), renamed=REN5[:2], group="S1x", unit="h"),
    S("S1x.ophp.natural.portfolio", "ophp", range(4, 25, 2), group="S1x", unit="h"),
    S("S1x.ophp.renamed.portfolio", "ophp", range(4, 25, 4), renamed=REN5[:2], group="S1x", unit="h"),
    S("S1x.ofphp.natural.portfolio", "ofphp", range(4, 25, 2), group="S1x", unit="h"),
    S("S1x.php2.natural.portfolio", "php2", range(4, 21, 2), group="S1x", unit="h"),
    S("S1x.php3cnf.natural.portfolio", "php3cnf", range(4, 25, 2), group="S1x", unit="h"),
    S("S1x.php3cnf.renamed.portfolio", "php3cnf", range(4, 25, 2), renamed=REN5[:2], group="S1x", unit="h"),
    S("S1x.php3cnf.natural.wide+cross", "php3cnf", range(4, 31, 2), strategy="wide+cross", group="S1x", unit="h"),
    S("S1x.php3cnf.renamed.wide+cross", "php3cnf", range(4, 31), renamed=REN5, strategy="wide+cross", group="S1x", unit="h"),
    S("S1x.php3cnf.renamed.wide+mindeg", "php3cnf", range(4, 16), renamed=REN5[:2], strategy="wide+mindeg", group="S1x", unit="h"),
    S("S1x.php3cnf.renamed.wide+cross.cap50k", "php3cnf", range(4, 31), renamed=REN5, strategy="wide+cross", group="S1x", unit="h", extra=CAP50),
    # ---------------- S2 Tseitin on random cubic graphs (odd charge)
    S("S2.tseitin.natural", "tseitin", (50, 100, 200, 400, 800, 1600, 3200, 6400, 12800), seeds=(1, 2, 3), group="S2", unit="vertices"),
    S("S2.tseitin.shuffled", "tseitin", (50, 100, 200, 400, 800, 1600, 3200, 6400, 12800), seeds=(1, 2), renamed=(21, 22), group="S2", unit="vertices"),
    S("S2.tseitin_sat.natural", "tseitin_sat", (50, 100, 200, 400, 800, 1600, 3200, 6400), seeds=(1, 2), group="S2", unit="vertices"),
    S("S2.tseitin.residual_dag", "tseitin", (10, 16, 20, 24, 30, 40, 60), seeds=(1,), solver="residual_dag", group="S2", unit="vertices"),
    # ---------------- S3 random 3-XOR
    S("S3.xor3.planted", "xor3_planted", (100, 200, 400, 800, 1600, 3200, 6400), seeds=(1, 2, 3), group="S3", unit="n"),
    S("S3.xor3.random_n+5", "xor3_random", (100, 200, 400, 800, 1600, 3200, 6400), seeds=(1, 2, 3), group="S3", unit="n"),
    S("S3.xor3.planted.residual_dag", "xor3_planted", (10, 14, 18, 22, 26, 30, 40), seeds=(1,), solver="residual_dag", group="S3", unit="n"),
    # ---------------- S4 mixed
    S("S4.phpxor.natural", "phpxor", range(3, 11), group="S4", unit="h"),
    S("S4.phpxor.renamed", "phpxor", range(3, 11), renamed=REN5[:3], group="S4", unit="h"),
    S("S4.phpxor.natural.wide+cross", "phpxor", range(3, 11), strategy="wide+cross", group="S4", unit="h"),
    S("S4.phpxor.natural.residual_dag", "phpxor", range(2, 6), solver="residual_dag", group="S4", unit="h"),
    S("S4.tseitin+3clauses.even", "tseitin_c3", (50, 100, 200, 400, 800, 1600, 3200), seeds=(1, 2, 3), group="S4", unit="vertices"),
    S("S4.tseitin+5clauses.even", "tseitin_c5", (50, 100, 200, 400, 800, 1600, 3200), seeds=(1, 2, 3), group="S4", unit="vertices"),
    S("S4.tseitin+3clauses.odd", "tseitin_c3_odd", (50, 100, 200, 400, 800, 1600, 3200), seeds=(1, 2), group="S4", unit="vertices"),
    S("S4.tseitin+3clauses.residual_dag", "tseitin_c3", (10, 16, 20, 24, 30, 40), seeds=(1,), solver="residual_dag", group="S4", unit="vertices"),
    # ---------------- S5 random 3-CNF
    S("S5.r3_4.26", "r3_426", range(20, 121, 5), seeds=(1, 2, 3, 4, 5), group="S5", unit="n"),
    S("S5.r3_3.00", "r3_300", range(20, 121, 5), seeds=(1, 2, 3, 4, 5), group="S5", unit="n"),
    S("S5.r3_4.26.wide+mindeg", "r3_426", range(20, 121, 5), seeds=(1, 2, 3), strategy="wide+mindeg", group="S5", unit="n"),
    S("S5.r3_4.26.residual_dag", "r3_426", range(10, 61, 5), seeds=(1, 2), solver="residual_dag", group="S5", unit="n"),
    S("S5.r3_3.00.residual_dag", "r3_300", range(10, 61, 5), seeds=(1, 2), solver="residual_dag", group="S5", unit="n"),
    # ---------------- S6 easy classes
    S("S6.selector", "selector", (10, 100, 1000, 4000, 16000), group="S6", unit="k"),
    S("S6.selector.residual_dag", "selector", (10, 100, 1000, 4000), solver="residual_dag", group="S6", unit="k"),
    S("S6.r2_0.9", "r2_090", (100, 200, 400, 800, 1600, 3200, 6400, 12800), seeds=(1, 2, 3), group="S6", unit="n"),
    S("S6.r2_1.5", "r2_150", (100, 200, 400, 600, 800, 1000, 1200, 1400, 1600, 2000, 2400), seeds=(1, 2, 3, 4, 5), group="S6", unit="n"),
    S("S6.r2_0.9.residual_dag", "r2_090", (20, 40, 80, 160, 320), seeds=(1,), solver="residual_dag", group="S6", unit="n"),
    S("S6.r2_1.5.residual_dag", "r2_150", (20, 40, 80, 160, 320), seeds=(1,), solver="residual_dag", group="S6", unit="n"),
    S("S6.horn", "horn", range(20, 121, 10), seeds=(1, 2, 3, 4, 5), group="S6", unit="n"),
    S("S6.horn_nofacts", "horn_nofacts", range(20, 101, 5), seeds=(1, 2, 3, 4, 5), group="S6", unit="n"),
    S("S6.horn_nofacts.residual_dag", "horn_nofacts", range(10, 51, 5), seeds=(1, 2), solver="residual_dag", group="S6", unit="n"),
    # ---------------- obstacle search
    S("X.chessboard", "chessboard", range(4, 21, 2), group="X", unit="board"),
    S("X.chessboard.renamed", "chessboard", range(4, 21, 2), renamed=(31,), group="X", unit="board"),
    S("X.ordering", "ordering", range(4, 21), group="X", unit="elements"),
    S("X.tseitin_deg7", "tseitin7", (10, 12, 14, 16, 18, 20, 24, 30), seeds=(1, 2), group="X", unit="vertices"),
    S("X.xor_and", "xor_and", range(20, 121, 10), seeds=(1, 2, 3), group="X", unit="n"),
    S("X.xor7_planted", "xor7_planted", range(10, 61, 2), seeds=(1, 2, 3), group="X", unit="n"),
    S("X.xor6_planted", "xor6_planted", (10, 20, 40, 80, 160, 320, 640), seeds=(1, 2, 3), group="X", unit="n"),
    S("X.xor7_planted.residual_dag", "xor7_planted", range(8, 31, 2), seeds=(1,), solver="residual_dag", group="X", unit="n"),
    S("X.chain2", "chain2", (100, 1000, 10000), group="X", unit="n"),
    # ---------------- load-independent thresholds: a small node cap (25 k per strategy)
    # is reached within a fraction of a CPU second, so CAP (not the wall clock) decides
    S("C.r3_4.26.cap50k", "r3_426", range(16, 81, 2), seeds=(1, 2, 3, 4, 5), group="C", unit="n", extra=CAP50),
    S("C.r3_3.00.cap50k", "r3_300", range(16, 121, 4), seeds=(1, 2, 3, 4, 5), group="C", unit="n", extra=CAP50),
    S("C.horn_nofacts.cap50k", "horn_nofacts", range(16, 81, 2), seeds=(1, 2, 3, 4, 5), group="C", unit="n", extra=CAP50),
    S("C.horn.cap50k", "horn", range(20, 121, 5), seeds=(1, 2, 3, 4, 5), group="C", unit="n", extra=CAP50),
    S("C.r2_1.5.cap50k", "r2_150", (100, 200, 300, 400, 500, 600, 700, 800, 1000, 1200, 1400, 1600, 2000), seeds=(1, 2, 3, 4, 5), group="C", unit="n", extra=CAP50),
    S("C.r2_0.9.cap50k", "r2_090", (400, 800, 1600, 3200, 6400), seeds=(1, 2, 3), group="C", unit="n", extra=CAP50),
    S("C.php.wide+mindeg.cap50k", "php", range(3, 13), strategy="wide+mindeg", group="C", unit="h", extra=CAP50),
    S("C.php.portfolio.cap50k", "php", range(3, 21), group="C", unit="h", extra=CAP50),
    S("C.php3cnf.cap50k", "php3cnf", range(4, 21, 2), group="C", unit="h", extra=CAP50),
    S("C.chessboard.cap50k", "chessboard", range(4, 21, 2), group="C", unit="board", extra=CAP50),
    S("C.ordering.cap50k", "ordering", range(4, 21), group="C", unit="elements", extra=CAP50),
    S("C.tseitin_deg7.cap50k", "tseitin7", (10, 12, 14, 16, 18, 20, 24, 30), seeds=(1, 2), group="C", unit="vertices", extra=CAP50),
    S("C.xor_and.cap50k", "xor_and", range(20, 121, 10), seeds=(1, 2, 3), group="C", unit="n", extra=CAP50),
    S("C.xor7_planted.cap50k", "xor7_planted", range(10, 61, 2), seeds=(1, 2, 3, 4, 5), group="C", unit="n", extra=CAP50),
]


def already_done():
    done = {}
    if os.path.exists(JSONL):
        with open(JSONL) as fh:
            for line in fh:
                line = line.strip()
                if line:
                    r = json.loads(line)
                    done[(r.get("series"), r["size"], r["seed"], r["renamed"])] = r
    return done


def run_single(series, size, seed, renamed, timeout):
    cmd = [sys.executable, RUN_ONE, "--family", series["family"], "--size", str(size),
           "--seed", str(seed), "--solver", series["solver"], "--strategy", series["strategy"],
           "--series", series["label"]] + series["extra"]
    if renamed is not None:
        cmd += ["--renamed", str(renamed)]
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
    t0 = time.monotonic()
    try:
        proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout, env=env)
        line = proc.stdout.decode().strip().splitlines()
        rec = json.loads(line[-1]) if line else None
        if rec is None:
            rec = {"verdict": "CRASH", "stderr": proc.stderr.decode(errors="replace")[-1500:]}
    except subprocess.TimeoutExpired:
        rec = {"verdict": "TIMEOUT", "status": "UNKNOWN", "reason": "subprocess 30 s wall limit"}
    base = {"series": series["label"], "family": series["family"], "size": size, "seed": seed,
            "renamed": renamed, "solver": series["solver"], "strategy": series["strategy"]}
    for k, v in base.items():
        rec.setdefault(k, v)
    rec["harness_wall_seconds"] = round(time.monotonic() - t0, 2)
    rec["command"] = "python3 experiments/run_one.py " + " ".join(cmd[2:])
    line = json.dumps(rec, sort_keys=True)
    with LOCK:
        # The workspace sandbox occasionally refuses a write; retry, and always echo
        # the record to stdout so that no measurement is lost.
        for attempt in range(5):
            try:
                with open(JSONL, "a") as fh:
                    fh.write(line + "\n")
                break
            except OSError as exc:
                print("WRITE-RETRY %d %r" % (attempt, exc), flush=True)
                time.sleep(1.0)
        else:
            print("RECORD-NOT-SAVED " + line, flush=True)
    return rec


def run_series(series, done, timeout, verbose=True):
    for size in series["sizes"]:
        ok_any = False
        for seed in series["seeds"]:
            for ren in series["renamed"]:
                key = (series["label"], size, seed, ren)
                rec = done.get(key)
                if rec is None:
                    rec = run_single(series, size, seed, ren, timeout)
                    if verbose:
                        with LOCK:
                            print("%-34s size=%-6s seed=%s ren=%s -> %-8s ticks=%s nodes=%s cpu=%s wall=%s" % (
                                series["label"], size, seed, ren, rec.get("verdict"), rec.get("ticks"),
                                rec.get("bdd_nodes_total", rec.get("dag_nodes")), rec.get("cpu_seconds"),
                                rec.get("wall_seconds")), flush=True)
                if rec.get("verdict") in ("ok", "unverified"):
                    ok_any = True
                if rec.get("verdict") == "WRONG":
                    with LOCK:
                        print("!!! WRONG ANSWER: %s" % json.dumps(rec)[:600], flush=True)
        if not ok_any:
            break


# ------------------------------------------------------------------ summary and fits

def linfit(xs, ys):
    n = len(xs)
    if n < 3:
        return None
    mx = sum(xs) / n
    my = sum(ys) / n
    sxx = sum((x - mx) ** 2 for x in xs)
    if sxx == 0:
        return None
    b = sum((x - mx) * (y - my) for x, y in zip(xs, ys)) / sxx
    a = my - b * mx
    ss_res = sum((y - (a + b * x)) ** 2 for x, y in zip(xs, ys))
    ss_tot = sum((y - my) ** 2 for y in ys)
    r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else 1.0
    return {"slope": round(b, 4), "intercept": round(a, 4), "r2": round(r2, 4), "points": n}


def median(v):
    v = sorted(v)
    return v[len(v) // 2] if len(v) % 2 else 0.5 * (v[len(v) // 2 - 1] + v[len(v) // 2])


def summarise():
    runs = list(already_done().values())
    by = {}
    for r in runs:
        by.setdefault(r.get("series"), []).append(r)
    plan = {s["label"]: s for s in PLAN}
    series_out = {}
    for label, rs in sorted(by.items(), key=lambda kv: str(kv[0])):
        meta = plan.get(label, {})
        cost_key = "ticks" if rs[0].get("solver", "cfpe") == "cfpe" else "dag_nodes"
        sizes = sorted(set(r["size"] for r in rs))
        table = []
        for size in sizes:
            group = [r for r in rs if r["size"] == size]
            ok = [r for r in group if r.get("verdict") in ("ok", "unverified")]
            row = {"size": size, "runs": len(group), "solved": len(ok),
                   "verdicts": sorted(set(str(r.get("verdict")) for r in group)),
                   "statuses": sorted(set(str(r.get("status")) for r in ok))}
            if ok:
                row["N_bits_median"] = median([r["N_bits"] for r in ok])
                row["nvars"] = ok[0].get("nvars")
                row["cost_median"] = median([r[cost_key] for r in ok])
                row["cost_max"] = max(r[cost_key] for r in ok)
                if cost_key == "ticks":
                    row["nodes_median"] = median([r["bdd_nodes_total"] for r in ok])
                    row["largest_bucket_max"] = max(r["bdd_largest_bucket"] for r in ok)
                    row["residual_vars_median"] = median([r["residual_vars"] for r in ok])
                    row["decided_by"] = sorted(set(str(r.get("decided_by")) for r in ok))
                    row["winners"] = sorted(set(str(r.get("winning_strategy")) for r in ok))
                row["cpu_seconds_max"] = max(r.get("cpu_seconds", 0) for r in ok)
                row["wall_seconds_max"] = max(r.get("wall_seconds", 0) for r in ok)
                row["max_rss_mb"] = max(r.get("max_rss_mb", 0) for r in ok)
            table.append(row)
        full = [row for row in table if row["solved"] == row["runs"] and row.get("cost_median", 0) > 0]
        fit = {}
        if len(full) >= 3:
            xs_size = [float(row["size"]) for row in full]
            xs_logn = [math.log(row["N_bits_median"]) for row in full]
            ys = [math.log(row["cost_median"]) for row in full]
            pw = linfit(xs_logn, ys)
            ex = linfit(xs_size, [y / math.log(2) for y in ys])
            if pw:
                fit["power_law_in_N"] = {"exponent": pw["slope"], "r2": pw["r2"], "points": pw["points"]}
            if ex:
                fit["exponential_in_size"] = {"log2_growth_per_unit": ex["slope"], "r2": ex["r2"],
                                              "points": ex["points"]}
            # local log-log slopes between consecutive fully solved sizes
            loc = []
            for a, b in zip(full, full[1:]):
                dn = math.log(b["N_bits_median"]) - math.log(a["N_bits_median"])
                if dn > 0:
                    loc.append(round((math.log(b["cost_median"]) - math.log(a["cost_median"])) / dn, 2))
            fit["local_loglog_slopes"] = loc
            if cost_key == "ticks" and any(row.get("nodes_median", 0) > 0 for row in full):
                nz = [row for row in full if row.get("nodes_median", 0) > 0]
                if len(nz) >= 3:
                    exn = linfit([float(r["size"]) for r in nz], [math.log2(r["nodes_median"]) for r in nz])
                    pwn = linfit([math.log(r["N_bits_median"]) for r in nz], [math.log(r["nodes_median"]) for r in nz])
                    if exn:
                        fit["nodes_exponential_in_size"] = {"log2_growth_per_unit": exn["slope"], "r2": exn["r2"]}
                    if pwn:
                        fit["nodes_power_law_in_N"] = {"exponent": pwn["slope"], "r2": pwn["r2"]}
        solved_sizes = [row["size"] for row in table if row["solved"] > 0]
        all_solved = [row["size"] for row in table if row["solved"] == row["runs"]]
        failed = [row["size"] for row in table if row["solved"] < row["runs"]]
        series_out[str(label)] = {
            "family": rs[0].get("family"), "solver": rs[0].get("solver"), "strategy": rs[0].get("strategy"),
            "group": meta.get("group"), "size_unit": meta.get("unit"), "cost_measure": cost_key,
            "largest_size_solved_any_seed": max(solved_sizes) if solved_sizes else None,
            "largest_size_solved_all_seeds": max(all_solved) if all_solved else None,
            "first_size_with_a_failure": min(failed) if failed else None,
            "wrong_answers": sum(1 for r in rs if r.get("verdict") == "WRONG"),
            "unverified_unsat": sum(1 for r in rs if r.get("verdict") == "unverified"),
            "fit": fit, "table": table,
        }
    out = {
        "format": "cfpe-scaling-v1",
        "warning": "Finite experiments. Fitted rates are empirical descriptions, not asymptotic "
                   "claims; CAP/TIMEOUT rows are neither refutations nor lower bounds.",
        "limits": {"wall_seconds_per_run": 30, "solver_deadline_seconds": 20, "bdd_node_cap": 1500000,
                   "residual_dag_node_cap": 400000},
        "total_runs": len(runs),
        "wrong_answers": sum(1 for r in runs if r.get("verdict") == "WRONG"),
        "series": series_out,
        "runs": sorted(runs, key=lambda r: (str(r.get("series")), r["size"], r["seed"], str(r["renamed"]))),
    }
    text = json.dumps(out, indent=1, sort_keys=True) + "\n"
    for attempt in range(40):      # the workspace sandbox sometimes refuses a write
        try:
            with open(OUT, "w") as fh:
                fh.write(text)
            break
        except OSError:
            time.sleep(1.5)
    return out


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--plan", default=None, help="'all', a group (S1, S1x, S2, ..., X) or a label prefix")
    ap.add_argument("--jobs", type=int, default=6)
    ap.add_argument("--timeout", type=float, default=30.0)
    ap.add_argument("--summarise", action="store_true")
    ap.add_argument("--list", action="store_true")
    args = ap.parse_args()
    if args.list:
        for s in PLAN:
            print(s["label"], s["family"], s["sizes"], s["seeds"], s["renamed"], s["strategy"], s["solver"])
        return 0
    if args.plan:
        chosen = [s for s in PLAN if args.plan == "all" or s["group"] == args.plan
                  or s["label"].startswith(args.plan)]
        done = already_done()
        with concurrent.futures.ThreadPoolExecutor(max_workers=args.jobs) as pool:
            list(pool.map(lambda s: run_series(s, done, args.timeout), chosen))
    out = summarise()
    print(json.dumps({"total_runs": out["total_runs"], "wrong_answers": out["wrong_answers"],
                      "series": len(out["series"])}))
    return 0 if out["wrong_answers"] == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
