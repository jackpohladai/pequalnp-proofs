"""E8 (stretch): a REPAIRED subclass of the candidate.  The original
native-search/residual_dag.py is not modified; this file only subclasses it.

Added rule (exact, both dual forms), applied in `junction` right after the
original single-node absorption and before common-factor extraction:

    OR  context:  AND(X) | AND(X u Y) = AND(X)     (drop the superset AND child)
    AND context:  OR(X)  & OR(X u Y)  = OR(X)      (drop the superset OR child)

i.e. among the children of the dual kind, only the inclusion-minimal child sets
are kept.  Soundness: a dropped child always has a retained inclusion-minimal
subset child, and in an OR (resp. AND) the superset conjunction (resp.
disjunction) implies (resp. is implied by) the subset one.

Everything else in `junction` is copied verbatim from the original so that the
effect of the single added rule can be measured in isolation.
"""
from harness import DAG, CapMixin


class RepairedDAG(DAG):
    def __init__(self):
        super().__init__()
        self.subsumed = 0          # number of children removed by the added rule

    def _subset_subsume(self, flat, dual):
        nodes = self.nodes
        cands = [(len(nodes[c][1]), c) for c in flat if nodes[c][0] == dual]
        if len(cands) < 2:
            return flat
        cands.sort()
        if cands[0][0] == cands[-1][0]:
            return flat            # equal sizes: distinct nodes cannot be nested
        index = {}                 # watched element -> kept child sets containing it
        removed = None
        for size, c in cands:
            s = nodes[c][1]
            sset = None
            hit = False
            for e in s:
                bucket = index.get(e)
                if bucket:
                    if sset is None:
                        sset = set(s)
                    for tsize, t in bucket:
                        if tsize < size and sset.issuperset(t):
                            hit = True
                            break
                    if hit:
                        break
            if hit:
                if removed is None:
                    removed = set()
                removed.add(c)
            else:
                watch = min(s, key=lambda e: len(index.get(e, ())))
                index.setdefault(watch, []).append((size, s))
        if removed:
            self.subsumed += len(removed)
            return flat - removed
        return flat

    def junction(self, op, children):
        identity, absorbing = (1, 0) if op == 'and' else (0, 1)
        flat = set()
        for child in children:
            if child == absorbing:
                return absorbing
            if child == identity:
                continue
            kind, data = self.nodes[child]
            flat.update(data if kind == op else (child,))
        if not flat:
            return identity
        lits = {self.nodes[c][1] for c in flat if self.nodes[c][0] == 'lit'}
        if any(-x in lits for x in lits):
            return absorbing
        # Absorption: A AND (A OR B) = A, and its dual.            (original)
        dual = 'or' if op == 'and' else 'and'
        flat = {c for c in flat if not (
            self.nodes[c][0] == dual and set(self.nodes[c][1]) & flat)}
        # Subset subsumption among dual-kind children.              (ADDED)
        flat = self._subset_subsume(flat, dual)
        if len(flat) == 1:
            return next(iter(flat))
        # Common conjunction factor extraction across OR alternatives. (original)
        if op == 'or':
            factors = [set(self.nodes[c][1]) if self.nodes[c][0] == 'and'
                       else {c} for c in flat]
            common = set.intersection(*factors)
            if common:
                self.factor_steps += 1
                residuals = [self.junction('and', fs - common) for fs in factors]
                return self.junction('and', [*common, self.junction('or', residuals)])
        return self.put((op, tuple(sorted(flat))))


class CappedRepairedDAG(CapMixin, RepairedDAG):
    """RepairedDAG + the same abort checks used for the original."""
