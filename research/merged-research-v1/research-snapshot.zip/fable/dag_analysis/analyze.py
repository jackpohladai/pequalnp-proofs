#!/usr/bin/env python3
"""Turn results/E*.json into tables and fitted growth rates.

    python3 analyze.py            # writes results/tables.md and results/summary.json

All fits are ordinary least squares on completed runs only and are EMPIRICAL
descriptions of a finite range; they prove nothing asymptotic.
  power law   ln(alloc) = a + b ln(x)        -> exponent b
  exponential log2(alloc) = c + r x          -> rate r (bits per unit of x)
A size enters a fit only if EVERY run of that series at that size completed
(otherwise the mean over survivors would be biased low).
"""
import json
import math
import statistics
import sys
from collections import defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
RESULTS = HERE / 'results'
DONE = ('SAT', 'UNSAT')


# ------------------------------------------------------------------ fits ----
def linfit(xs, ys):
    n = len(xs)
    if n < 2:
        return None
    mx, my = sum(xs) / n, sum(ys) / n
    sxx = sum((x - mx) ** 2 for x in xs)
    if sxx == 0:
        return None
    sxy = sum((x - mx) * (y - my) for x, y in zip(xs, ys))
    slope = sxy / sxx
    icpt = my - slope * mx
    ss_tot = sum((y - my) ** 2 for y in ys)
    ss_res = sum((y - (icpt + slope * x)) ** 2 for x, y in zip(xs, ys))
    r2 = 1.0 if ss_tot == 0 else 1 - ss_res / ss_tot
    return slope, icpt, r2


def fits(points):
    """points: list of (x, y) with y > 0, sorted by x.  Returns dict of fits."""
    pts = [(x, y) for x, y in points if y and y > 0 and x > 0]
    out = dict(points=len(pts))
    if len(pts) < 3:
        return out
    xs, ys = [p[0] for p in pts], [p[1] for p in pts]
    pw = linfit([math.log(x) for x in xs], [math.log(y) for y in ys])
    ex = linfit(xs, [math.log2(y) for y in ys])
    if pw:
        out.update(power_exponent=round(pw[0], 3), power_r2=round(pw[2], 4))
    if ex:
        out.update(exp_rate_bits=round(ex[0], 4), exp_r2=round(ex[2], 4))
    loc = []
    for (x0, y0), (x1, y1) in zip(pts, pts[1:]):
        if x1 > x0:
            loc.append(round(math.log(y1 / y0) / math.log(x1 / x0), 2))
    out['local_exponents'] = loc
    if len(pts) >= 4:
        tail = pts[-4:]
        tp = linfit([math.log(x) for x, _ in tail], [math.log(y) for _, y in tail])
        te = linfit([x for x, _ in tail], [math.log2(y) for _, y in tail])
        if tp:
            out['tail_power_exponent'] = round(tp[0], 3)
        if te:
            out['tail_exp_rate_bits'] = round(te[0], 4)
    if pw and ex:
        out['better_fit'] = 'power' if pw[2] >= ex[2] else 'exponential'
    return out


def gmean(vals):
    vals = [v for v in vals if v and v > 0]
    return math.exp(sum(math.log(v) for v in vals) / len(vals)) if vals else None


LIST_KEYS = ('runs', 'batches', 'searches', 'census', 'validation', 'expect', 'skipped', 'notes',
             'greedy_orders')


def load(name):
    """Merge results/<name>.json with partial reruns results/<name>.<tag>.json and the
    supplement results/<name>b.json.  For the same (family, params, order, dag) run
    recorded more than once, a completed record wins over a capped one."""
    paths = sorted(RESULTS.glob(f'{name}.json')) + sorted(RESULTS.glob(f'{name}.*.json')) + \
        sorted(RESULTS.glob(f'{name}b.json')) + sorted(RESULTS.glob(f'{name}b.*.json'))
    paths = [p for p in paths if not p.name.endswith('.tmp')]
    if not paths:
        return None
    merged = None
    for p in paths:
        try:
            d = json.loads(p.read_text())
        except Exception as e:
            print('could not read', p, e)
            continue
        if merged is None:
            merged = d
            merged['meta'] = dict(d['meta'], files=[p.name])
            for k in LIST_KEYS:
                merged.setdefault(k, [])
            continue
        merged['meta']['files'].append(p.name)
        for k in LIST_KEYS:
            merged[k] += d.get(k, [])
    if merged is None:
        return None
    best = {}
    order = []
    for r in merged['runs']:
        key = json.dumps([r.get('family'), r.get('params'), r.get('order'),
                          r.get('dag') or 'original'], sort_keys=True)
        if key not in best:
            best[key] = r
            order.append(key)
        elif best[key].get('result') not in DONE and r.get('result') in DONE:
            best[key] = r
    merged['runs'] = [best[k] for k in order]
    return merged


def fmt(v, nd=0):
    if v is None:
        return '-'
    if isinstance(v, float):
        return f'{v:.{nd}f}' if nd else f'{v:.0f}'
    return str(v)


def table(headers, rows):
    out = ['| ' + ' | '.join(headers) + ' |', '|' + '|'.join('---' for _ in headers) + '|']
    for r in rows:
        out.append('| ' + ' | '.join(str(c) for c in r) + ' |')
    return '\n'.join(out)


def order_group(label):
    if label.startswith('shuffle'):
        return 'shuffle'
    if label.startswith('random'):
        return 'random'
    return label


def fixed_key(p, size_key):
    return json.dumps({k: v for k, v in p.items() if k not in (size_key, 'seed', 'sat')},
                      sort_keys=True)


def series_table(runs, family, size_key, xkey='n', dag='original', groups=None):
    """Aggregate runs of one family into series keyed by (fixed params, order group).
    Returns {series: {size: dict(x, N, vals=[alloc...], total, done, caps={reason: k})}}"""
    out = defaultdict(lambda: defaultdict(lambda: dict(vals=[], total=0, done=0, caps=defaultdict(int),
                                                       xs=[], Ns=[], cache=[], refs=[], secs=[])))
    for r in runs:
        if r.get('family') != family or (r.get('dag') or 'original') != dag:
            continue
        g = order_group(r['order'])
        if groups and g not in groups:
            continue
        key = (fixed_key(r['params'], size_key), g)
        cell = out[key][r['params'][size_key]]
        cell['total'] += 1
        if r.get('n') is not None:
            cell['xs'].append(r[xkey] if xkey in r else r['n'])
            cell['Ns'].append(r.get('N'))
        if r.get('result') in DONE:
            cell['done'] += 1
            cell['vals'].append(r['alloc'])
            cell['cache'].append(r.get('cofactor_cache'))
            cell['refs'].append(r.get('child_refs'))
            cell['secs'].append(r.get('cpu_seconds'))
        else:
            cell['caps'][str(r.get('cap_reason') or r.get('result'))] += 1
    return out


def series_fit(cells, xkey='n'):
    """cells: {size: cell}.  Uses only fully completed sizes."""
    pts, ptsN, pts_cache = [], [], []
    for size in sorted(cells):
        c = cells[size]
        if c['total'] and c['done'] == c['total'] and c['xs']:
            x = sum(c['xs']) / len(c['xs'])
            pts.append((x, gmean(c['vals'])))
            if all(c['Ns']):
                ptsN.append((sum(c['Ns']) / len(c['Ns']), gmean(c['vals'])))
            if all(c['cache']):
                pts_cache.append((x, gmean(c['cache'])))
    return pts, ptsN, pts_cache


def describe_series(name, cells):
    pts, ptsN, pts_cache = series_fit(cells)
    f = fits(pts)
    fN = fits(ptsN)
    fc = fits(pts_cache)
    largest = pts[-1] if pts else (None, None)
    capped = {}
    for size in sorted(cells):
        c = cells[size]
        if c['done'] < c['total']:
            capped[size] = dict(done=c['done'], total=c['total'], caps=dict(c['caps']))
    return dict(series=name, sizes=[[x, round(y, 1)] for x, y in pts], fit_vs_n=f, fit_vs_N=fN,
                fit_cache_vs_n=fc, largest_complete_n=largest[0],
                alloc_at_largest=None if largest[1] is None else round(largest[1]),
                incomplete_sizes=capped)


def fit_row(label, d):
    f, fN = d['fit_vs_n'], d['fit_vs_N']
    inc = d['incomplete_sizes']
    first_cap = min(inc) if inc else None
    capinfo = '-'
    if first_cap is not None:
        c = inc[first_cap]
        capinfo = f"{first_cap}: {c['done']}/{c['total']} done ({', '.join(f'{k}x{v}' for k, v in c['caps'].items())})"
    return [label, f.get('points', 0), fmt(d['largest_complete_n']), fmt(d['alloc_at_largest']),
            fmt(f.get('power_exponent'), 2), fmt(f.get('tail_power_exponent'), 2),
            fmt(f.get('power_r2'), 3), fmt(f.get('exp_rate_bits'), 4),
            fmt(f.get('tail_exp_rate_bits'), 4), fmt(f.get('exp_r2'), 3),
            f.get('better_fit', '-'), fmt(fN.get('power_exponent'), 2), capinfo]


FIT_HEADERS = ['series / order', 'pts', 'largest complete n', 'alloc there (gmean)',
               'power exp b', 'tail b (last 4)', 'R2 pow', 'exp rate bits/var',
               'tail rate', 'R2 exp', 'better fit', 'power exp vs N', 'first incomplete size']


def agreement(runs):
    done = [r for r in runs if r.get('result') in DONE]
    ver = [r for r in done if r.get('agree') is not None]
    bad = [r for r in ver if r['agree'] is False]
    return dict(runs=len(runs), completed=len(done), verified=len(ver), disagreements=len(bad),
                unverified=len(done) - len(ver),
                capped=sum(1 for r in runs if r.get('result') == 'CAP'),
                other=sum(1 for r in runs if r.get('result') not in DONE + ('CAP',)),
                bad_examples=[dict(family=r['family'], params=r['params'], order=r['order'],
                                   result=r['result'], expected=r['expected']) for r in bad[:5]])


def cap_reasons(runs):
    c = defaultdict(int)
    for r in runs:
        if r.get('result') not in DONE:
            c[f"{r.get('result')}:{r.get('cap_reason')}"] += 1
    return dict(c)


ORDER_SORT = ['natural', 'reverse', 'pigeon_major', 'hole_major', 'x_then_a', 'a_then_x',
              'min_degree', 'min_fill', 'greedy_min', 'dfs', 'bfs', 'scc_topo', 'scc_topo_rev',
              'max_degree', 'greedy_max', 'tree_first', 'tree_first_bfs', 'shuffle', 'random']


def okey(g):
    return ORDER_SORT.index(g) if g in ORDER_SORT else 99


def generic_section(data, families, title, summary, md, size_keys, dag='original', xlabel='n'):
    """One fit table per (family, fixed params)."""
    runs = data['runs']
    for family in families:
        size_key = size_keys[family]
        st = series_table(runs, family, size_key, dag=dag)
        if not st:
            continue
        by_fixed = defaultdict(dict)
        for (fk, g), cells in st.items():
            by_fixed[fk][g] = cells
        for fk in sorted(by_fixed):
            rows = []
            for g in sorted(by_fixed[fk], key=okey):
                d = describe_series(f'{family} {fk} {g}', by_fixed[fk][g])
                summary.setdefault(title, {})[f'{family} {fk} {g}'] = d
                rows.append(fit_row(g, d))
            md.append(f'**{family} {fk}** (x = {xlabel}; gmean over instances/shuffles; '
                      f'fits use fully completed sizes only)\n')
            md.append(table(FIT_HEADERS, rows) + '\n')


def size_matrix(runs, family, size_key, fixed, groups, dag='original', agg='gmean'):
    """Rows = sizes, columns = order groups: aggregated alloc (or CAP counts)."""
    st = series_table(runs, family, size_key, dag=dag)
    cols = [g for g in sorted({g for (fk, g) in st if fk == fixed}, key=okey)
            if not groups or g in groups]
    sizes = sorted({s for (fk, g), cells in st.items() if fk == fixed for s in cells})
    rows = []
    for s in sizes:
        row = [s]
        nval = Nval = None
        for g in cols:
            c = st.get((fixed, g), {}).get(s)
            if not c or not c['total']:
                row.append('')
                continue
            if c['xs']:
                nval = round(sum(c['xs']) / len(c['xs']))
                if all(c['Ns']):
                    Nval = round(sum(c['Ns']) / len(c['Ns']))
            if c['done'] == c['total']:
                v = gmean(c['vals']) if agg == 'gmean' else min(c['vals'])
                row.append(f'{v:.0f}')
            elif c['done']:
                row.append(f">{gmean(c['vals']):.0f}* ({c['done']}/{c['total']})")
            else:
                row.append('CAP(' + ','.join(sorted(c['caps'])) + ')')
        rows.append([row[0], nval if nval is not None else '', Nval if Nval is not None else ''] + row[1:])
    return [size_key, 'n vars', 'N bits'] + cols, rows


# ------------------------------------------------------------------ E1 ----
def analyze_e1(summary, md):
    data = load('E1')
    if not data:
        return
    runs = data['runs']
    md.append('## E1 Tseitin\n')
    summary['E1'] = dict(agreement=agreement(runs), cap_reasons=cap_reasons(runs))
    md.append(f"Runs: {json.dumps(summary['E1']['agreement'])}; non-completions: "
              f"{json.dumps(summary['E1']['cap_reasons'])}\n")
    keys = dict(tseitin_regular='nv', tseitin_torus='a', tseitin_complete='m')
    for family in keys:
        st = series_table(runs, family, keys[family])
        for fk in sorted({fk for fk, _ in st}):
            h, rows = size_matrix(runs, family, keys[family], fk, None)
            md.append(f'**{family} {fk}: allocated nodes (gmean over 2 charges x 2 seeds '
                      f'[x 5 shuffles])**\n')
            md.append(table(h, rows) + '\n')
    generic_section(data, list(keys), 'E1_fits', summary, md, keys)
    # worst order per instance vs n
    worst = defaultdict(dict)
    for r in runs:
        if r.get('result') in DONE:
            k = (r['family'], fixed_key(r['params'], keys.get(r['family'], 'nv')))
            ik = json.dumps(r['params'], sort_keys=True)
            cur = worst[k].get(ik)
            if cur is None or r['alloc'] > cur[1]:
                worst[k][ik] = (r['n'], r['alloc'], r['order'], r['N'])
    rows = []
    for k in sorted(worst):
        pts = defaultdict(list)
        for n, a, o, N in worst[k].values():
            pts[n].append(a)
        p = sorted((n, max(v)) for n, v in pts.items())
        f = fits(p)
        summary['E1'].setdefault('worst_standard_order', {})[' '.join(k)] = dict(points=p, fit=f)
        rows.append([' '.join(k), len(p), p[-1][0], p[-1][1], fmt(f.get('power_exponent'), 2),
                     fmt(f.get('tail_power_exponent'), 2), fmt(f.get('exp_rate_bits'), 4),
                     f.get('better_fit', '-')])
    md.append('**Worst completed standard order per size (max over instances and all 13 orders)**\n')
    md.append(table(['family', 'pts', 'largest n', 'max alloc there', 'power exp', 'tail exp',
                     'exp rate', 'better fit'], rows) + '\n')
    # exhaustive / sampled batches
    groups = defaultdict(list)
    for b in data['batches']:
        groups[(b['family'], json.dumps(b['params'], sort_keys=True), b['orders_type'])].append(b)
    rows = []
    for k in sorted(groups):
        allocs = [a for b in groups[k] for a in b['allocs']]
        ok = [a for a in allocs if a is not None]
        res = defaultdict(int)
        for b in groups[k]:
            for kk, v in b['results'].items():
                res[kk] += v
        rows.append([k[0], k[1], 'ALL orders' if k[2] == 'perm_range' else 'random sample',
                     len(allocs), min(ok), statistics.median(ok), max(ok), json.dumps(dict(res)),
                     sum(b['disagreements'] for b in groups[k])])
        summary['E1'].setdefault('order_distributions', []).append(dict(
            family=k[0], params=json.loads(k[1]), kind=k[2], orders=len(allocs), min=min(ok),
            median=statistics.median(ok), max=max(ok), results=dict(res)))
    if rows:
        md.append('**Distribution of allocated nodes over orders (tiny graphs)**\n')
        md.append(table(['family', 'params', 'orders', '#', 'min', 'median', 'max', 'answers',
                         'disagreements'], rows) + '\n')
    # adversarial search
    finals = [n for n in data['notes'] if str(n.get('note', '')).startswith('search final')]
    rows = []
    pts_by_fam = defaultdict(list)
    std_worst = {}
    for k in worst:
        for ik, (n, a, o, N) in worst[k].items():
            std_worst[(k[0], ik)] = (a, o)
    for f in finals:
        inst_key = json.dumps(f['params'], sort_keys=True)
        ev = sum(s['evals'] for s in data['searches'] if s['family'] == f['family'] and s['params'] == f['params'])
        n = next((s['n'] for s in data['searches'] if s['family'] == f['family'] and s['params'] == f['params']), None)
        N = next((s['N'] for s in data['searches'] if s['family'] == f['family'] and s['params'] == f['params']), None)
        sw = std_worst.get((f['family'], inst_key))
        rows.append([f['family'], json.dumps(f['params']), n, N, f['best_val'], ev,
                     sw[0] if sw else '-', sw[1] if sw else '-',
                     fmt(f['best_val'] / n ** 2, 3) if n and f['best_val'] else '-'])
        fam = f['family'] + (f" d={f['params']['d']}" if 'd' in f['params'] else '')
        if n and f['best_val']:
            pts_by_fam[fam].append((n, f['best_val']))
    if rows:
        md.append('**Adversarial search for the WORST order (hill-climb maximising allocated nodes)**\n')
        md.append(table(['family', 'params', 'n', 'N', 'max alloc found', 'evaluations',
                         'worst standard order alloc', 'which', 'max/n^2'], rows) + '\n')
        rows = []
        for fam, p in sorted(pts_by_fam.items()):
            p.sort()
            f = fits(p)
            summary['E1'].setdefault('adversarial_fit', {})[fam] = dict(points=p, fit=f)
            rows.append([fam, json.dumps(p), fmt(f.get('power_exponent'), 2),
                         fmt(f.get('exp_rate_bits'), 4), fmt(f.get('power_r2'), 3),
                         fmt(f.get('exp_r2'), 3), f.get('better_fit', '-'),
                         json.dumps(f.get('local_exponents'))])
        md.append(table(['family', '(n, max alloc found)', 'power exp', 'exp rate bits/var',
                         'R2 pow', 'R2 exp', 'better', 'local exponents'], rows) + '\n')


# ------------------------------------------------------------------ E2 ----
def shuffle_best_median(runs, family, size_key, dag='original'):
    """Per instance: best and median over its shuffles (CAP = +inf)."""
    inst = defaultdict(list)
    for r in runs:
        if r.get('family') != family or (r.get('dag') or 'original') != dag:
            continue
        if order_group(r['order']) not in ('shuffle', 'random'):
            continue
        inst[json.dumps(r['params'], sort_keys=True)].append(r)
    out = defaultdict(lambda: defaultdict(lambda: dict(best=[], median=[], n=None, shuffles=[], done=[])))
    for ik, rs in inst.items():
        p = json.loads(ik)
        fk = fixed_key(p, size_key)
        vals = sorted(r['alloc'] if r.get('result') in DONE else math.inf for r in rs)
        cell = out[fk][p[size_key]]
        cell['n'] = next((r['n'] for r in rs if r.get('n')), None)
        cell['shuffles'].append(len(vals))
        cell['done'].append(sum(1 for v in vals if v < math.inf))
        cell['best'].append(vals[0])
        m = vals[(len(vals) - 1) // 2] if len(vals) % 2 else max(vals[len(vals) // 2 - 1], vals[len(vals) // 2])
        cell['median'].append(m)
    return out


def shuffle_rows(sbm, fk, summary_slot):
    rows = []
    pb, pm = [], []
    for size in sorted(sbm[fk]):
        c = sbm[fk][size]
        b = None if any(v == math.inf for v in c['best']) else gmean(c['best'])
        m = None if any(v == math.inf for v in c['median']) else gmean(c['median'])
        if b:
            pb.append((c['n'], b))
        if m:
            pm.append((c['n'], m))
        rows.append([size, c['n'], f"{sum(c['done'])}/{sum(c['shuffles'])}",
                     fmt(b) if b else 'CAP', fmt(m) if m else 'CAP'])
    fb, fm = fits(pb), fits(pm)
    summary_slot['shuffle_best'] = dict(points=[[x, round(y)] for x, y in pb], fit=fb)
    summary_slot['shuffle_median'] = dict(points=[[x, round(y)] for x, y in pm], fit=fm)
    return rows, fb, fm


def analyze_e2(summary, md):
    data = load('E2')
    if not data:
        return
    runs = data['runs']
    md.append('## E2 XOR systems\n')
    summary['E2'] = dict(agreement=agreement(runs), cap_reasons=cap_reasons(runs))
    md.append(f"Runs: {json.dumps(summary['E2']['agreement'])}; non-completions: "
              f"{json.dumps(summary['E2']['cap_reasons'])}\n")
    keys = dict(xor3='n', xor_two_occ='m_eq')
    for family in keys:
        st = series_table(runs, family, keys[family])
        sbm = shuffle_best_median(runs, family, keys[family])
        for fk in sorted({fk for fk, _ in st}):
            h, rows = size_matrix(runs, family, keys[family], fk,
                                  [g for g in ORDER_SORT if g != 'shuffle'])
            md.append(f'**{family} {fk}: allocated nodes, structured orders (gmean over instances)**\n')
            md.append(table(h, rows) + '\n')
            if fk in sbm:
                slot = summary['E2'].setdefault(f'{family} {fk}', {})
                rows, fb, fm = shuffle_rows(sbm, fk, slot)
                md.append(f'**{family} {fk}: 20 random shuffles per instance** (best / median per '
                          f'instance, then gmean over instances; CAP if any instance has it capped)\n')
                md.append(table([keys[family], 'n', 'shuffles completed', 'best of 20', 'median of 20'],
                                rows) + '\n')
                md.append(f"best-of-20 fit: {json.dumps(fb)}\n\nmedian-of-20 fit: {json.dumps(fm)}\n")
    generic_section(data, list(keys), 'E2_fits', summary, md, keys)


# ------------------------------------------------------------------ E3 ----
def analyze_e3(summary, md, name='E3', dag='original', title='## E3 PHP(h+1, h)\n'):
    data = load(name)
    if not data:
        return
    runs = [r for r in data['runs'] if r.get('family') == 'php' and (r.get('dag') or 'original') == dag]
    if not runs:
        return
    md.append(title)
    S = summary.setdefault(name + '_php', {})
    S['agreement'] = agreement(runs)
    S['cap_reasons'] = cap_reasons(runs)
    md.append(f"Runs: {json.dumps(S['agreement'])}; non-completions: {json.dumps(S['cap_reasons'])}\n")
    orders = sorted({order_group(r['order']) for r in runs if order_group(r['order']) != 'random'},
                    key=okey)
    hs = sorted({r['params']['h'] for r in runs})
    val = {}
    for r in runs:
        g = order_group(r['order'])
        if g == 'random':
            continue
        val[(r['params']['h'], g)] = r['alloc'] if r.get('result') in DONE else 'CAP:' + str(r.get('cap_reason'))
    # random orders: batches (h<=5) + single runs
    rnd = defaultdict(list)
    for b in data['batches']:
        if b['family'] == 'php' and b['orders_type'] == 'shuffles' and (b.get('dag') or 'original') == dag \
                and b['params'].get('excess', 1) == 1:
            rnd[b['params']['h']] += [a if a is not None else math.inf for a in b['allocs']]
    for r in runs:
        if order_group(r['order']) == 'random':
            rnd[r['params']['h']].append(r['alloc'] if r.get('result') in DONE else math.inf)
    finals = {n['params']['h']: n for n in data['notes']
              if str(n.get('note', '')).startswith('search final') and n.get('family') == 'php'
              and (n.get('dag') or 'original') == dag}
    rows = []
    best_pts = []
    series_pts = defaultdict(list)
    for h in hs:
        row = [h, h * (h + 1)]
        N = next((r['N'] for r in runs if r['params']['h'] == h and r.get('N')), None)
        row.append(N)
        cands = []
        for o in orders:
            v = val.get((h, o), '')
            row.append(v)
            if isinstance(v, int):
                cands.append(v)
                series_pts[o].append((h, v))
        rv = sorted(rnd.get(h, []))
        if rv:
            rmin = rv[0]
            rmed = rv[(len(rv) - 1) // 2] if len(rv) % 2 else max(rv[len(rv) // 2 - 1], rv[len(rv) // 2])
            row += [len(rv), 'CAP' if rmin == math.inf else rmin, 'CAP' if rmed == math.inf else rmed]
            if rmin < math.inf:
                cands.append(rmin)
                series_pts['random_min'].append((h, rmin))
            if rmed < math.inf:
                series_pts['random_median'].append((h, rmed))
        else:
            row += ['', '', '']
        sf = finals.get(h)
        row.append(sf['best_val'] if sf else '')
        if sf and sf.get('best_val'):
            cands.append(sf['best_val'])
            series_pts['search_min'].append((h, sf['best_val']))
        best = min(cands) if cands else None
        row.append(best if best is not None else '')
        if best is not None:
            best_pts.append((h, best))
        rows.append(row)
    md.append(table(['h', 'n vars', 'N bits'] + orders + ['#random', 'random min', 'random median',
                                                          'local-search min', 'MIN over all tried'],
                    rows) + '\n')
    # growth: ratio per unit h and fits in n = h(h+1)
    frows = []
    series_pts['MIN_over_all_tried'] = best_pts
    for o, pts in series_pts.items():
        pts = sorted(pts)
        if len(pts) < 3:
            continue
        ratios = [round(b[1] / a[1], 2) for a, b in zip(pts, pts[1:]) if b[0] == a[0] + 1]
        fh = fits(pts)                                       # x = h
        fn = fits([(h * (h + 1), v) for h, v in pts])       # x = n
        fs = linfit([h for h, _ in pts[-5:]], [math.log2(v) for _, v in pts[-5:]])
        S.setdefault('growth', {})[o] = dict(points=pts, ratios=ratios, fit_vs_h=fh, fit_vs_n=fn)
        frows.append([o, f'{pts[0][0]}..{pts[-1][0]}', json.dumps(ratios),
                      fmt(fh.get('exp_rate_bits'), 3), fmt(fs[0], 3) if fs else '-',
                      fmt(fn.get('exp_rate_bits'), 4), fmt(fn.get('power_exponent'), 2),
                      fmt(fn.get('exp_r2'), 3), fmt(fn.get('power_r2'), 3),
                      json.dumps(fn.get('local_exponents'))])
    md.append('Growth per order (ratio alloc(h+1)/alloc(h); exponential rate in bits per hole and '
              'per variable; power-law exponent in n = h(h+1))\n')
    md.append(table(['order', 'h range', 'successive ratios', 'bits per h (all)',
                     'bits per h (last 5)', 'bits per var', 'power exp in n', 'R2 exp(n)',
                     'R2 pow(n)', 'local power exponents in n'], frows) + '\n')
    # exhaustive
    ex = defaultdict(list)
    for b in data['batches']:
        if b['family'] == 'php' and b['orders_type'] == 'perm_range' and (b.get('dag') or 'original') == dag:
            ex[json.dumps(b['params'], sort_keys=True)].append(b)
    rows = []
    for k in sorted(ex):
        bs = sorted(ex[k], key=lambda b: b['start'])
        allocs = [a for b in bs for a in b['allocs']]
        peaks = [a for b in bs for a in b['peaks']]
        p = json.loads(k)
        h = p['h']
        pig = h + p.get('excess', 1)
        hist = defaultdict(int)
        for a in allocs:
            hist[a] += 1
        amin = min(allocs)
        res = defaultdict(int)
        for b in bs:
            for kk, v in b['results'].items():
                res[kk] += v
        rows.append([f'PHP({pig},{h})', bs[0]['n'], len(allocs), amin, hist[amin],
                     statistics.median(allocs), max(allocs), hist[max(allocs)],
                     min(peaks) if peaks else '-', max(peaks) if peaks else '-',
                     json.dumps(dict(res)), sum(b['disagreements'] for b in bs)])
        S.setdefault('exhaustive', []).append(dict(
            instance=f'PHP({pig},{h})', n=bs[0]['n'], orders=len(allocs), min=amin,
            orders_at_min=hist[amin], median=statistics.median(allocs), max=max(allocs),
            orders_at_max=hist[max(allocs)], histogram=dict(sorted(hist.items())),
            results=dict(res)))
    if rows:
        md.append('**Exhaustive enumeration of ALL elimination orders**\n')
        md.append(table(['instance', 'n', 'orders', 'min alloc', '#orders at min', 'median',
                         'max alloc', '#orders at max', 'min peak reach', 'max peak reach',
                         'answers', 'disagreements'], rows) + '\n')


# ------------------------------------------------------------------ E4 ----
def analyze_e4(summary, md, name='E4', dag='original', title='## E4 random 3-CNF\n'):
    data = load(name)
    if not data:
        return
    runs = [r for r in data['runs'] if r.get('family') == 'kcnf' and (r.get('dag') or 'original') == dag]
    if not runs:
        return
    md.append(title)
    S = summary.setdefault(name + '_3cnf', {})
    S['agreement'] = agreement(runs)
    S['cap_reasons'] = cap_reasons(runs)
    src = defaultdict(int)
    for r in runs:
        if r.get('result') in DONE:
            src[r.get('expected_source')] += 1
    S['expected_sources'] = dict(src)
    md.append(f"Runs: {json.dumps(S['agreement'])}; non-completions: {json.dumps(S['cap_reasons'])}; "
              f"expected-answer sources of completed runs: {json.dumps(dict(src))}\n")
    st = series_table(runs, 'kcnf', 'n', dag=dag)
    sbm = shuffle_best_median(runs, 'kcnf', 'n', dag=dag)
    for fk in sorted({fk for fk, _ in st}):
        h, rows = size_matrix(runs, 'kcnf', 'n', fk, [g for g in ORDER_SORT if g != 'shuffle'], dag=dag)
        md.append(f'**kcnf {fk}: allocated nodes, structured orders (gmean over 3 instances)**\n')
        md.append(table(h, rows) + '\n')
        if fk in sbm:
            slot = S.setdefault(f'kcnf {fk}', {})
            rows, fb, fm = shuffle_rows(sbm, fk, slot)
            md.append(f'**kcnf {fk}: random shuffles per instance (best / median)**\n')
            md.append(table(['n', 'n', 'shuffles completed', 'best', 'median'], rows) + '\n')
            md.append(f"best fit: {json.dumps(fb)}\n\nmedian fit: {json.dumps(fm)}\n")
    by_fixed = defaultdict(dict)
    for (fk, g), cells in st.items():
        by_fixed[fk][g] = cells
    for fk in sorted(by_fixed):
        rows = []
        for g in sorted(by_fixed[fk], key=okey):
            d = describe_series(f'kcnf {fk} {g}', by_fixed[fk][g])
            S.setdefault('fits', {})[f'kcnf {fk} {g}'] = d
            rows.append(fit_row(g, d))
        md.append(f'**kcnf {fk} fits** (x = n)\n')
        md.append(table(FIT_HEADERS, rows) + '\n')


# ------------------------------------------------------------------ E5 ----
E5_KEYS = dict(rand2cnf='n', regular_2cnf='nv', grid_2cnf='a', implication_grid='a',
               ladder_2cnf='k', bipartite_implication='k', subsume_2cnf='k', random_horn3='n',
               horn_grid='a', subsume_horn='k')


def analyze_e5(summary, md):
    data = load('E5')
    if not data:
        return
    runs = data['runs']
    md.append('## E5 2-SAT / Horn hunt\n')
    summary['E5'] = dict(agreement=agreement(runs), cap_reasons=cap_reasons(runs))
    md.append(f"Runs: {json.dumps(summary['E5']['agreement'])}; non-completions: "
              f"{json.dumps(summary['E5']['cap_reasons'])}\n")
    overview = []
    for family, size_key in E5_KEYS.items():
        st = series_table(runs, family, size_key)
        for fk in sorted({fk for fk, _ in st}):
            h, rows = size_matrix(runs, family, size_key, fk, None)
            md.append(f'**{family} {fk}: allocated nodes (gmean over instances / shuffles)**\n')
            md.append(table(h, rows) + '\n')
            groups = sorted({g for (f2, g) in st if f2 == fk}, key=okey)
            per_order = {}
            for g in groups:
                d = describe_series(f'{family} {fk} {g}', st[(fk, g)])
                summary['E5'].setdefault('fits', {})[f'{family} {fk} {g}'] = d
                per_order[g] = d
            # the order that survives to the largest size (ties: fewest nodes there)
            alive = [g for g in groups if per_order[g]['largest_complete_n']]
            if not alive:
                continue
            best = min(alive, key=lambda g: (-per_order[g]['largest_complete_n'],
                                             per_order[g]['alloc_at_largest']))
            worst = min(alive, key=lambda g: (per_order[g]['largest_complete_n'],
                                              -per_order[g]['alloc_at_largest']))
            fb = per_order[best]['fit_vs_n']

            def cell(g):
                if g not in per_order or not per_order[g]['largest_complete_n']:
                    return '-'
                d = per_order[g]
                f = d['fit_vs_n']
                return (f"n<={fmt(d['largest_complete_n'])}: {fmt(d['alloc_at_largest'])}; "
                        f"b={fmt(f.get('power_exponent'), 2)}, tail b={fmt(f.get('tail_power_exponent'), 2)}, "
                        f"r={fmt(f.get('exp_rate_bits'), 3)} ({f.get('better_fit', '-')})")
            summary['E5'].setdefault('best_order', {})[f'{family} {fk}'] = dict(
                best=best, fit=per_order[best], worst=worst,
                per_order={g: dict(largest_complete_n=per_order[g]['largest_complete_n'],
                                   alloc=per_order[g]['alloc_at_largest'],
                                   power_exponent=per_order[g]['fit_vs_n'].get('power_exponent'),
                                   tail_power_exponent=per_order[g]['fit_vs_n'].get('tail_power_exponent'),
                                   exp_rate_bits=per_order[g]['fit_vs_n'].get('exp_rate_bits'),
                                   better_fit=per_order[g]['fit_vs_n'].get('better_fit'))
                           for g in groups})
            overview.append([family, fk, best, fmt(per_order[best]['largest_complete_n']),
                             fmt(per_order[best]['alloc_at_largest']),
                             fmt(fb.get('power_exponent'), 2), fmt(fb.get('tail_power_exponent'), 2),
                             fmt(fb.get('exp_rate_bits'), 4), fmt(fb.get('power_r2'), 3),
                             fmt(fb.get('exp_r2'), 3), fb.get('better_fit', '-'),
                             cell('greedy_min'), cell('bfs'), cell('min_degree'), cell('min_fill'),
                             cell('natural'), cell('shuffle')])
    md.append('**E5 overview.** "best order" = the order that completed at the largest size '
              '(ties: fewest nodes there); its own fit is shown, then per-order cells '
              '"n<=largest fully completed n: gmean alloc there; b = power exponent, r = '
              'exponential rate in bits/variable (better-fitting model)".\n')
    md.append(table(['family', 'fixed params', 'best order', 'its largest n', 'alloc there',
                     'power exp', 'tail power exp', 'exp rate bits/var', 'R2 pow', 'R2 exp',
                     'better fit', 'greedy_min', 'bfs', 'min_degree', 'min_fill', 'natural',
                     'shuffle'], overview) + '\n')
    summary['E5']['overview'] = overview
    # induced width of the order (primal graph) against allocated nodes, 2-CNF on regular graphs
    wrows = []
    for nv in (56, 80):
        cell = defaultdict(lambda: dict(w=[], a=[], tot=0))
        for r in runs:
            if r.get('family') != 'regular_2cnf' or r['params'].get('nv') != nv:
                continue
            c = cell[(r['params']['d'], order_group(r['order']))]
            c['tot'] += 1
            if r.get('result') in DONE and r.get('width') is not None:
                c['w'].append(r['width'])
                c['a'].append(r['alloc'])
        for d in sorted({k[0] for k in cell}):
            for g in sorted({k[1] for k in cell if k[0] == d}, key=okey):
                c = cell[(d, g)]
                if not c['a']:
                    wrows.append([nv, d, g, '-', f"0/{c['tot']}", 'all capped'])
                    continue
                wrows.append([nv, d, g, f"{statistics.median(c['w']):.0f}",
                              f"{len(c['a'])}/{c['tot']}", f"{gmean(c['a']):.0f}"])
    if wrows:
        summary['E5']['width_vs_alloc'] = wrows
        md.append('**Induced width of the order vs allocated nodes** (2-CNF on random d-regular '
                  'graphs, all sign modes and seeds pooled; gmean over the runs that completed)\n')
        md.append(table(['n', 'd', 'order', 'median induced width', 'completed', 'gmean alloc'],
                        wrows) + '\n')


# ------------------------------------------------------------------ E6 ----
def analyze_e6(summary, md, name='E6', dag='original', title='## E6 H-SUBSUME family G_k\n'):
    data = load(name)
    if not data:
        return
    runs = [r for r in data['runs'] if r.get('family') == 'subsume' and (r.get('dag') or 'original') == dag]
    if not runs:
        return
    md.append(title)
    S = summary.setdefault(name + '_subsume', {})
    S['agreement'] = agreement(runs)
    ks = sorted({r['params']['k'] for r in runs})
    orders = sorted({r['order'] for r in runs}, key=okey)
    idx = {(r['params']['k'], r['order']): r for r in runs}
    rows = []
    for k in ks:
        row = [k, 2 * k + 2]
        for o in ('x_then_a', 'a_then_x'):
            r = idx.get((k, o))
            if r and r.get('result') in DONE:
                row += [r['alloc'], r['max_or_arity'], r['peak_reachable'], r['child_refs'],
                        r['cofactor_cache']]
            else:
                row += ['CAP' if r else ''] * 5
        r = idx.get((k, 'x_then_a'))
        row.append(2 ** (k - 1) + 2)
        row.append('yes' if r and r.get('max_or_arity') == 2 ** (k - 1) + 2 else 'no')
        for o in orders:
            if o in ('x_then_a', 'a_then_x'):
                continue
            r2 = idx.get((k, o))
            row.append(r2['alloc'] if r2 and r2.get('result') in DONE else 'CAP')
        rows.append(row)
    others = [o for o in orders if o not in ('x_then_a', 'a_then_x')]
    md.append(table(['k', 'n', 'x,a..: alloc', 'max OR arity', 'peak reach', 'child refs',
                     'cofactor cache', 'a..,x: alloc', 'max OR arity', 'peak reach', 'child refs',
                     'cofactor cache', '2^(k-1)+2', 'OR arity = 2^(k-1)+2 ?'] +
                    [o + ' alloc' for o in others], rows) + '\n')
    for o in ('x_then_a', 'a_then_x'):
        pts = [(k, idx[(k, o)]['alloc']) for k in ks if (k, o) in idx and idx[(k, o)].get('result') in DONE]
        f = fits(pts)
        ar = [(k, idx[(k, o)]['max_or_arity']) for k in ks if (k, o) in idx and idx[(k, o)].get('result') in DONE]
        S[o] = dict(alloc=pts, max_or_arity=ar, fit_vs_k=f,
                    first_differences=[b[1] - a[1] for a, b in zip(pts, pts[1:])])
        md.append(f"{o}: exp rate {f.get('exp_rate_bits')} bits per k (tail "
                  f"{f.get('tail_exp_rate_bits')}), power exponent in k {f.get('power_exponent')}, "
                  f"first differences of alloc {S[o]['first_differences']}\n")


# ------------------------------------------------------------------ E7 ----
def analyze_e7(summary, md):
    data = load('E7')
    if not data:
        return
    md.append('## E7 semantic census (truth tables of every reachable node after every step)\n')
    rows = []
    S = summary.setdefault('E7', dict(rows=[]))
    bad = 0
    for c in data['census']:
        if 'steps' not in c or not c.get('steps'):
            rows.append([c.get('family'), json.dumps(c.get('params')), c.get('order'),
                         c.get('result'), '-', '-', '-', '-', '-', '-', '-', '-'])
            continue
        if not c.get('projection_ok') or c.get('agree') is False:
            bad += 1
        pr, pd = c['peak_reachable'], c['peak_distinct']
        pi, pid = c['peak_internal'], c['peak_internal_distinct']
        ai, aid = c.get('alloc_internal'), c.get('alloc_internal_distinct')
        mr = c.get('max_redundant_refs') or {}
        row = [c['family'], json.dumps({k: v for k, v in c['params'].items()}), c['order'],
               c['result'], c['n'], c['alloc'], pr, pd, f'{pd / pr:.3f}', pi, pid,
               f'{pid / pi:.3f}' if pi else '-', ai if ai is not None else '-',
               aid if aid is not None else '-', f'{aid / ai:.3f}' if ai else '-',
               c.get('peak_child_refs', '-'),
               f"{mr.get('redundant_refs')}/{mr.get('child_refs')}" if mr else '-',
               'ok' if c.get('projection_ok') else 'FAIL']
        rows.append(row)
        S['rows'].append(dict(family=c['family'], params=c['params'], order=c['order'], n=c['n'],
                              alloc=c['alloc'], peak_reachable=pr, peak_distinct=pd,
                              peak_internal=pi, peak_internal_distinct=pid,
                              alloc_internal=ai, alloc_internal_distinct=aid,
                              peak_child_refs=c.get('peak_child_refs'),
                              max_redundant_refs=mr.get('redundant_refs'),
                              refs_at_max_redundant=mr.get('child_refs'),
                              result=c['result'], projection_ok=c.get('projection_ok')))
    S['projection_or_answer_failures'] = bad
    md.append(table(['family', 'params', 'order', 'answer', 'n', 'alloc', '(a) peak reachable',
                     '(b) peak distinct functions', 'b/a', 'peak internal (and/or)',
                     'distinct internal', 'ratio', 'ALL allocated internal', 'distinct among them',
                     'ratio', 'peak child refs (reachable)',
                     'max redundant child refs / refs at that step',
                     'root == exact projection at every step'], rows) + '\n')
    # compact per-family summary
    agg = defaultdict(list)
    for r in S['rows']:
        agg[r['family']].append(r)
    rows = []
    for fam, rs in sorted(agg.items()):
        ratio = [r['peak_distinct'] / r['peak_reachable'] for r in rs]
        ratio_i = [r['peak_internal_distinct'] / r['peak_internal'] for r in rs if r['peak_internal']]
        ratio_all = [r['alloc_internal_distinct'] / r['alloc_internal'] for r in rs if r.get('alloc_internal')]
        redf = [r['max_redundant_refs'] / r['refs_at_max_redundant'] for r in rs
                if r.get('refs_at_max_redundant')]
        rows.append([fam, len(rs), f'{min(ratio):.3f}', f'{statistics.median(ratio):.3f}',
                     f'{min(ratio_i):.3f}' if ratio_i else '-',
                     f'{statistics.median(ratio_i):.3f}' if ratio_i else '-',
                     f'{min(ratio_all):.3f}' if ratio_all else '-',
                     f'{statistics.median(ratio_all):.3f}' if ratio_all else '-',
                     f'{statistics.median(redf):.3f}' if redf else '-',
                     f'{max(redf):.3f}' if redf else '-'])
    S['per_family'] = rows
    md.append('**Per family: distinct functions / nodes** (1.000 = no semantic redundancy at all)\n')
    md.append(table(['family', 'censuses', 'min b/a at peak', 'median b/a', 'min internal ratio',
                     'median internal ratio', 'min ratio over ALL allocated internal nodes',
                     'median', 'median fraction of redundant child refs (worst step)',
                     'max fraction'], rows) + '\n')


# ----------------------------------------------------------------- E7b ----
def analyze_e7b(summary, md):
    recs = []
    for name in ('E7b', 'E7c'):
        p = RESULTS / f'{name}.json'
        if p.exists():
            recs += json.loads(p.read_text()).get('support', [])
    if not recs:
        return
    md.append('## E7b support-multiplicity census (mechanism test, no truth tables)\n')
    cell = defaultdict(lambda: defaultdict(list))
    for r in recs:
        p = r['params']
        fam = r['family']
        if fam == 'tseitin_regular':
            name, size = f"Tseitin d={p['d']} (size = vertices)", p['nv']
        elif fam == 'xor_two_occ':
            name, size = '4-XOR, each variable in 2 equations (size = equations)', p['m_eq']
        elif fam == 'xor3':
            name, size = '3-XOR m=n planted (size = n)', p['n']
        elif fam == 'php':
            name, size = 'PHP(h+1,h) (size = h)', p['h']
        elif fam == 'kcnf':
            name, size = 'random 3-CNF 4.26 (size = n)', p['n']
        elif fam == 'regular_2cnf':
            name, size = f"2-CNF on {p['d']}-regular graph, {p['mode']} (size = n)", p['nv']
        else:
            name, size = fam, p.get('n') or p.get('k')
        cell[(name, r['order'])][size].append(r)
    rows = []
    S = summary.setdefault('E7b', {})
    for (name, order) in sorted(cell, key=lambda k: (k[0], okey(order_group(k[1])), k[1])):
        parts = []
        series = []
        for size in sorted(cell[(name, order)]):
            rs = cell[(name, order)][size]
            done = [r for r in rs if r.get('result') in DONE]
            if not done:
                parts.append(f'{size}: CAP')
                continue
            m = max(r['max_nodes_per_support'] for r in done)
            mo = max(r['max_or_nodes_per_support'] for r in done)
            star = '' if len(done) == len(rs) else '*'
            parts.append(f'{size}: {m}/{mo}{star}')
            series.append((size, m))
        S[f'{name} | {order}'] = series
        f = fits(series)
        rows.append([name, order, ', '.join(parts), fmt(f.get('power_exponent'), 2),
                     fmt(f.get('exp_rate_bits'), 3), f.get('better_fit', '-')])
    md.append('After every forget step the and/or nodes reachable from the root are grouped by '
              '(kind, set of variables mentioned); the cell is "size: largest group / largest group '
              'of OR nodes" (max over the steps of the run and over the instances at that size; * = '
              'some instance capped).  Last columns: power-law exponent and exponential rate of the '
              'largest group against the size parameter.\n')
    md.append(table(['family', 'order', 'size: max nodes per support / max OR nodes per support',
                     'power exp', 'exp rate per unit size', 'better fit'], rows) + '\n')


# ------------------------------------------------------------------ E8 ----
def analyze_e8(summary, md):
    data = load('E8')
    if not data:
        return
    md.append('## E8 repaired subclass (AND-subset subsumption inside OR, and its dual)\n')
    S = summary.setdefault('E8', {})
    val = defaultdict(lambda: defaultdict(int))
    for v in data['validation']:
        d = val[v.get('dag') or 'original']
        d['tasks'] += 1
        d['formulas'] += v.get('formulas', 0)
        d['stages'] += v.get('stages_checked', 0)
        d['evaluate_points'] += v.get('evaluate_points_checked', 0)
        d['failures'] += len(v.get('failures', []))
        d['crashed'] += 0 if 'formulas' in v else 1
    S['validation'] = {k: dict(v) for k, v in val.items()}
    md.append(f"Validation against brute force at every elimination stage: {json.dumps(S['validation'])}\n")
    analyze_e6(summary, md, 'E8', 'repaired', '### E8 / E6 rerun (repaired)\n')
    analyze_e3(summary, md, 'E8', 'repaired', '### E8 / E3 rerun (repaired)\n')
    analyze_e4(summary, md, 'E8', 'repaired', '### E8 / E4 rerun (repaired)\n')
    # side-by-side rates
    rows = []
    o3, r3 = summary.get('E3_php', {}).get('growth', {}), summary.get('E8_php', {}).get('growth', {})
    for o in sorted(set(o3) & set(r3), key=okey):
        a, b = o3[o], r3[o]
        common = sorted(set(h for h, _ in a['points']) & set(h for h, _ in b['points']))
        da, db = dict(a['points']), dict(b['points'])
        if len(common) < 3:
            continue
        fa = fits([(h, da[h]) for h in common])
        fb = fits([(h, db[h]) for h in common])
        rows.append(['PHP ' + o, f'h={common[0]}..{common[-1]}', da[common[-1]], db[common[-1]],
                     fmt(fa.get('exp_rate_bits'), 3), fmt(fb.get('exp_rate_bits'), 3),
                     fmt(fa.get('tail_exp_rate_bits'), 3), fmt(fb.get('tail_exp_rate_bits'), 3)])
    f4, g4 = summary.get('E4_3cnf', {}).get('fits', {}), summary.get('E8_3cnf', {}).get('fits', {})
    for k in sorted(set(f4) & set(g4)):
        a, b = dict(map(tuple, f4[k]['sizes'])), dict(map(tuple, g4[k]['sizes']))
        common = sorted(set(a) & set(b))
        if len(common) < 3:
            continue
        fa = fits([(n, a[n]) for n in common])
        fb = fits([(n, b[n]) for n in common])
        rows.append([k, f'n={common[0]:.0f}..{common[-1]:.0f}', fmt(a[common[-1]]),
                     fmt(b[common[-1]]), fmt(fa.get('exp_rate_bits'), 4),
                     fmt(fb.get('exp_rate_bits'), 4), fmt(fa.get('tail_exp_rate_bits'), 4),
                     fmt(fb.get('tail_exp_rate_bits'), 4)])
    e6o, e6r = summary.get('E6_subsume', {}), summary.get('E8_subsume', {})
    for o in ('x_then_a', 'a_then_x'):
        if o in e6o and o in e6r:
            a, b = dict(map(tuple, e6o[o]['alloc'])), dict(map(tuple, e6r[o]['alloc']))
            common = sorted(set(a) & set(b))
            fa = fits([(k, a[k]) for k in common])
            fb = fits([(k, b[k]) for k in common])
            rows.append(['G_k ' + o, f'k={common[0]}..{common[-1]}', a[common[-1]], b[common[-1]],
                         fmt(fa.get('exp_rate_bits'), 3), fmt(fb.get('exp_rate_bits'), 3),
                         fmt(fa.get('tail_exp_rate_bits'), 3), fmt(fb.get('tail_exp_rate_bits'), 3)])
    S['rate_comparison'] = rows
    md.append('### Original vs repaired: growth rates on the SAME sizes (exponential fit, bits per '
              'unit of the size parameter)\n')
    md.append(table(['series', 'common range', 'original alloc at largest', 'repaired alloc at largest',
                     'original rate', 'repaired rate', 'original tail rate', 'repaired tail rate'],
                    rows) + '\n')


def analyze_e0(summary, md):
    data = load('E0')
    if not data:
        return
    sc = data.get('selfcheck', [])
    summary['E0'] = dict(selfcheck_runs=sum(s.get('runs', 0) for s in sc),
                         failed_tasks=sum(1 for s in sc if s.get('kind') != 'selfcheck'),
                         hashseed_independent=data.get('hashseed_independent'),
                         candidate_sha256=data['meta']['candidate_sha256'])
    md.append('## E0 sanity\n')
    md.append(json.dumps(summary['E0']) + '\n')


def main():
    summary, md = {}, []
    for fn in (analyze_e0, analyze_e1, analyze_e2, analyze_e3, analyze_e4, analyze_e5, analyze_e6,
               analyze_e7, analyze_e7b, analyze_e8):
        try:
            fn(summary, md)
        except Exception as e:  # keep going: partial results are still useful
            import traceback
            md.append(f'ANALYSIS ERROR in {fn.__name__}: {e!r}\n')
            traceback.print_exc()
    (RESULTS / 'tables.md').write_text('\n'.join(md) + '\n')
    (RESULTS / 'summary.json').write_text(json.dumps(summary, indent=1, default=str) + '\n')
    print('wrote', RESULTS / 'tables.md', 'and', RESULTS / 'summary.json')


if __name__ == '__main__':
    main()
