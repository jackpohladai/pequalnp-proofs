#!/usr/bin/env python3
"""Re-runnable structural experiments on native-search/residual_dag.DAG.

    python3 run_experiments.py E1            # one experiment
    python3 run_experiments.py E3 E6 E7      # several
    python3 run_experiments.py all
    python3 run_experiments.py E4 --quick    # tiny smoke-test grid -> results/quick/
    python3 run_experiments.py HOLES E1 E5   # re-run load-induced time caps (see fill_holes)
    options: --workers K (default 5), --tag T (write results/<EXP>.<T>.json)
    environment: E1_PART=grid|adv|all, E2_PARTS=..., E5_ONLY=family,..., E5_MATCH=substr,
                 DAG_RETRIES=k

Every single DAG run happens in its own forked process (or in a short batch for
sub-millisecond instances) with: allocated-node cap 400000, soft wall-clock cap
25 s (checked inside the candidate's put()), SIGALRM backstop at 27.5 s, parent
hard kill at 29.5 s, memory cap 480 MB (peak RSS).  Results are flushed
incrementally to results/<EXP>.json.

Result vocabulary: SAT / UNSAT are the candidate's answers after eliminating
every variable (root == 1 / root == 0).  CAP means the run was stopped by a
resource cap (cap_reason says which); CAP is never a refutation and never a
lower bound on anything except "at least this many nodes were allocated".
`expected` is an INDEPENDENT answer (see verify.py); `agree` compares the two.
"""
import argparse
import gc
import hashlib
import importlib.util
import itertools
import json
import math
import os
import platform
import random
import sys
import time
from collections import defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import families as F  # noqa: E402
import orders as O  # noqa: E402
import verify as V  # noqa: E402
import harness as H  # noqa: E402

RESULTS = HERE / 'results'
RETRIES = int(os.environ.get('DAG_RETRIES', '0'))   # re-run load-induced time caps this many times
TWO_CNF = {'rand2cnf', 'regular_2cnf', 'grid_2cnf', 'implication_grid', 'ladder_2cnf',
           'bipartite_implication', 'subsume_2cnf'}
HORN = {'random_horn3', 'subsume_horn', 'horn_grid'}


# --------------------------------------------------------------------------
# instances and independent expected answers
# --------------------------------------------------------------------------
def build_instance(family, p):
    if family == 'tseitin_regular':
        return F.tseitin_regular(p['nv'], p['d'], p['seed'], p['sat'])
    if family == 'tseitin_torus':
        return F.tseitin_torus(p['a'], p['a'], p['seed'], p['sat'])
    if family == 'tseitin_complete':
        return F.tseitin_complete(p['m'], p['seed'], p['sat'])
    if family == 'tseitin_named':
        return F.tseitin_named(p['graph'], p['seed'], p['sat'])
    if family == 'xor3':
        return F.xor_system(p['n'], p['n'] + p['extra'], 3, p['seed'], p['planted'])
    if family == 'xor_two_occ':
        return F.xor_two_occurrence(p['m_eq'], p['k'], p['seed'], p['sat'])
    if family == 'php':
        return F.php(p['h'] + p.get('excess', 1), p['h'])
    if family == 'kcnf':
        return F.random_kcnf(p['n'], round(p['density'] * p['n']), p['k'], p['seed'])
    if family == 'subsume':
        return F.subsume_family(p['k'])
    if family == 'rand2cnf':
        return F.random_kcnf(p['n'], round(p['density'] * p['n']), 2, p['seed'])
    if family == 'regular_2cnf':
        return F.regular_2cnf(p['nv'], p['d'], p['seed'], p['mode'])
    if family == 'grid_2cnf':
        return F.grid_2cnf(p['a'], p['a'], p['seed'], p['mode'])
    if family == 'implication_grid':
        return F.implication_grid(p['a'], p['a'], p['variant'])
    if family == 'ladder_2cnf':
        return F.ladder_2cnf(p['k'])
    if family == 'bipartite_implication':
        return F.bipartite_implication(p['k'], p['seed'], p['p'])
    if family == 'subsume_2cnf':
        return F.subsume_2cnf(p['k'])
    if family == 'random_horn3':
        n = p['n']
        return F.random_horn3(n, round(p['density'] * n), p['seed'],
                              facts=round(p.get('facts', 0) * n),
                              goals=round(p.get('goals', 0) * n))
    if family == 'subsume_horn':
        return F.subsume_horn(p['k'])
    if family == 'horn_grid':
        return F.horn_grid(p['a'], p['a'], p['variant'])
    raise ValueError('unknown family ' + family)


def _vertex_equations(inst):
    inc = [[] for _ in range(inst['nv'])]
    for i, (a, b) in enumerate(inst['edges'], 1):
        inc[a].append(i)
        inc[b].append(i)
    return [(inc[v], inst['charges'][v]) for v in range(inst['nv'])]


def expected_answer(family, p, inst):
    """Independent expected answer -> (status, source).  SAT answers carry a
    witness that was checked against the original clauses inside verify.py / here."""
    n, cl = inst['n'], inst['clauses']
    if family.startswith('tseitin') or family == 'xor_two_occ':
        par = V.component_parity(inst['nv'], inst['edges'], inst['charges'])
        ok, _rank, sol = V.gf2_solve(n, _vertex_equations(inst))
        gf = 'SAT' if ok else 'UNSAT'
        if gf != par:
            raise AssertionError('parity criterion and GF(2) elimination disagree')
        if ok and not V.check_model(cl, sol):
            raise AssertionError('GF(2) witness failed')
        return par, 'component charge parity + GF(2) elimination (witness checked if SAT)'
    if family == 'xor3':
        ok, _rank, sol = V.gf2_solve(n, [(vs, r) for vs, r in inst['eqs']])
        if ok and not V.check_model(cl, sol):
            raise AssertionError('GF(2) witness failed')
        return ('SAT' if ok else 'UNSAT'), 'GF(2) elimination (witness checked if SAT)'
    if family == 'php':
        if inst['pigeons'] > inst['holes']:
            return 'UNSAT', 'pigeonhole principle (pigeons > holes)'
        a = [False] * n
        for i in range(inst['pigeons']):
            a[F.php_var(i, i, inst['holes']) - 1] = True
        assert V.check_model(cl, a)
        return 'SAT', 'explicit injective witness (checked)'
    if family == 'subsume':
        a = [False] * n
        for v in inst['a']:
            a[v - 1] = True
        assert V.check_model(cl, a)
        return 'SAT', 'explicit witness (checked)'
    if family in TWO_CNF or (family == 'kcnf' and p['k'] == 2):
        return V.twosat(n, cl)[0], '2-SAT SCC (witness checked if SAT)'
    if family in HORN:
        return V.horn_sat(n, cl)[0], 'Horn unit propagation (least model checked if SAT)'
    return None, 'none'


_oracle = None


def oracle_exhaustive(n, clauses):
    global _oracle
    if _oracle is None:
        spec = importlib.util.spec_from_file_location('adv_oracle', H.ADVERSARIAL / 'oracle.py')
        _oracle = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(_oracle)
    return _oracle.exhaustive(n, clauses)


# --------------------------------------------------------------------------
# child-side task functions
# --------------------------------------------------------------------------
def shuffle_spec(*key):
    """Deterministic shuffle seed from a key (independent of PYTHONHASHSEED)."""
    h = hashlib.sha256(repr(key).encode()).digest()
    return 'shuffle' + str(int.from_bytes(h[:4], 'big'))


def dag_class(name):
    if name in (None, 'original'):
        return None
    if name == 'repaired':
        import repaired_dag
        return repaired_dag.CappedRepairedDAG
    raise ValueError(name)


def get_order(spec, n, cl, inst, dag=None, t=None):
    """Order by spec.  'greedy_min' / 'greedy_max' are DAG-aware (harness.greedy_order,
    using the same DAG class as the run); everything else comes from orders.py."""
    t = time.perf_counter() if t is None else t
    if isinstance(spec, str) and spec.startswith('greedy_'):
        return H.greedy_order(n, cl, spec[len('greedy_'):], sample=12,
                              seed=n * 1000003 + len(cl), time_cap=12.0,
                              dag_cls=dag_class(dag))
    return O.make_order(spec, n, cl, inst, deadline=t + 8.0)


def do_run(task):
    gc.disable()
    t_task = time.perf_counter()
    family, p = task['family'], task['params']
    inst = build_instance(family, p)
    n, cl = inst['n'], inst['clauses']
    rec = dict(kind='run', exp=task['exp'], family=family, params=p, seed=p.get('seed'),
               order=task['order'], order_spec=task.get('order_spec', task['order']),
               dag=(task.get('dag') or 'original'), n=n, m=len(cl), N=F.encoded_bits(cl),
               attempt=task.get('attempt', 0))
    if 'expected' in task:
        rec['expected'], rec['expected_source'] = task['expected'], task['expected_source']
    else:
        rec['expected'], rec['expected_source'] = expected_answer(family, p, inst)
    t = time.perf_counter()
    try:
        order = get_order(rec['order_spec'], n, cl, inst, task.get('dag'), t)
    except (O.OrderTimeout, H.Cap) as e:
        rec.update(result='ORDER_TIMEOUT', cap_reason='order:' + str(e.args[0] if e.args else ''),
                   alloc=None, order_seconds=round(time.perf_counter() - t, 4))
        return rec
    rec['order_seconds'] = round(time.perf_counter() - t, 4)
    if task.get('width', True):
        rec['width'] = O.induced_width(n, cl, order)
    budget = max(1.0, H.TIME_CAP - (time.perf_counter() - t_task))
    r = H.run_order(n, cl, order, time_cap=budget, reach=task.get('reach', 'auto'),
                    dag_cls=dag_class(task.get('dag')))
    rec.update(r)
    if task.get('keep_order'):
        rec['order_list'] = order
    done = rec['result'] in ('SAT', 'UNSAT')
    rec['agree'] = (rec['result'] == rec['expected']) if done and rec['expected'] else None
    return rec


def do_expect(task):
    """Expected answer for random 3-CNF: project oracle (n <= 20) and/or own DPLL."""
    gc.disable()
    family, p = task['family'], task['params']
    inst = build_instance(family, p)
    n, cl = inst['n'], inst['clauses']
    out = dict(kind='expect', family=family, params=p, n=n, m=len(cl))
    t = time.perf_counter()
    status, _ = V.dpll(n, cl, time_limit=8.0)
    out['dpll'] = status
    out['dpll_seconds'] = round(time.perf_counter() - t, 3)
    out['oracle'] = None
    if n <= task.get('oracle_max', 20):
        t = time.perf_counter()
        try:
            o = oracle_exhaustive(n, cl)
        except H.Cap:                       # SIGALRM backstop: machine too loaded
            o = None
            out['oracle_note'] = 'oracle timed out (wall clock); DPLL answer used'
        if o is not None:
            out['oracle'] = o['status']
            out['oracle_models'] = o['model_count']
            out['oracle_seconds'] = round(time.perf_counter() - t, 3)
            if o['status'] == 'SAT' and not V.check_model(cl, o['first_witness']):
                raise AssertionError('oracle witness failed')
            if status != 'UNKNOWN' and status != o['status']:
                raise AssertionError('oracle and DPLL disagree')
    if out['oracle']:
        out['expected'] = out['oracle']
        out['expected_source'] = 'adversarial/oracle.py exhaustive (DPLL cross-checked)'
    elif status != 'UNKNOWN':
        out['expected'] = status
        out['expected_source'] = 'own complete DPLL (not the project oracle)'
    else:
        out['expected'], out['expected_source'] = None, 'unverified'
    return out


def perm_unrank(n, idx):
    """idx-th permutation of 1..n in lexicographic order."""
    items = list(range(1, n + 1))
    out = []
    for i in range(n, 0, -1):
        f = math.factorial(i - 1)
        q, idx = divmod(idx, f)
        out.append(items.pop(q))
    return out


def do_batch(task):
    """Many orders on one small instance inside one process.
    orders: {'type': 'perm_range', 'start', 'stop'} or {'type': 'shuffles', 'specs': [...]}.
    Stops early (returning done_until) if the batch has used 16 s of wall clock."""
    gc.disable()
    t0 = time.perf_counter()
    family, p = task['family'], task['params']
    inst = build_instance(family, p)
    n, cl = inst['n'], inst['clauses']
    expected, source = expected_answer(family, p, inst)
    spec = task['orders']
    cls = dag_class(task.get('dag'))
    allocs, peaks, results, caches = [], [], defaultdict(int), []
    start = spec.get('start', 0)
    stop = spec['stop'] if spec['type'] == 'perm_range' else len(spec['specs'])
    idx = start
    disagreements = 0
    while idx < stop:
        if time.perf_counter() - t0 > 16.0:
            break
        if spec['type'] == 'perm_range':
            order = perm_unrank(n, idx)
        else:
            order = O.make_order(spec['specs'][idx], n, cl, inst)
        r = H.run_order(n, cl, order, time_cap=8.0, reach=task.get('reach', False),
                        dag_cls=cls)
        allocs.append(r['alloc'] if r['result'] != 'CAP' else None)
        caches.append(r['cofactor_cache'])
        if task.get('reach', False):
            peaks.append(r['peak_reachable'])
        results[r['result']] += 1
        if r['result'] in ('SAT', 'UNSAT') and expected and r['result'] != expected:
            disagreements += 1
        idx += 1
    return dict(kind='batch', exp=task['exp'], family=family, params=p,
                dag=(task.get('dag') or 'original'), n=n, m=len(cl), N=F.encoded_bits(cl),
                orders_type=spec['type'], start=start, done_until=idx, stop=stop,
                allocs=allocs, cofactor_caches=caches, peaks=peaks, results=dict(results),
                expected=expected, expected_source=source, disagreements=disagreements,
                seconds=round(time.perf_counter() - t0, 3))


def _move(order, rng):
    cand = order[:]
    n = len(cand)
    kind = rng.randrange(3)
    i, j = rng.randrange(n), rng.randrange(n)
    if kind == 0:
        cand[i], cand[j] = cand[j], cand[i]
    elif kind == 1:
        x = cand.pop(i)
        cand.insert(j, x)
    else:
        if i > j:
            i, j = j, i
        cand[i:j + 1] = reversed(cand[i:j + 1])
    return cand


def do_search(task):
    """Greedy local search over elimination orders (objective = allocated nodes).
    goal 'min' or 'max'.  A fixed number of evaluations (task['evals']) so the
    result is deterministic; a wall deadline of 18 s only truncates (reported)."""
    gc.disable()
    t0 = time.perf_counter()
    family, p = task['family'], task['params']
    inst = build_instance(family, p)
    n, cl = inst['n'], inst['clauses']
    rng = random.Random(task['seed'])
    goal = task['goal']
    cls = dag_class(task.get('dag'))

    def evaluate(order, cap):
        r = H.run_order(n, cl, order, node_cap=cap, time_cap=6.0, reach=False, dag_cls=cls)
        return r['alloc'] if r['result'] != 'CAP' else None, r

    cur = list(task['start_order'])
    cur_val, _ = evaluate(cur, H.NODE_CAP)
    if cur_val is None:
        return dict(kind='search', exp=task['exp'], family=family, params=p, goal=goal,
                    n=n, error='start order hit a cap', seed=task['seed'])
    best, best_val = cur[:], cur_val
    evals = 1
    capped_hits = 0
    truncated = False
    for _ in range(task['evals']):
        if time.perf_counter() - t0 > 18.0:
            truncated = True
            break
        cand = _move(cur, rng)
        cap = H.NODE_CAP if goal == 'max' else cur_val + 1
        val, r = evaluate(cand, cap)
        evals += 1
        if val is None:
            if goal == 'max' and r['cap_reason'] == 'nodes':
                capped_hits += 1
                best, best_val = cand, H.NODE_CAP + 1
                break
            continue
        if (goal == 'min' and val <= cur_val) or (goal == 'max' and val >= cur_val):
            cur, cur_val = cand, val
            if (goal == 'min' and val < best_val) or (goal == 'max' and val > best_val):
                best, best_val = cand[:], val
    return dict(kind='search', exp=task['exp'], family=family, params=p, goal=goal, n=n,
                m=len(cl), N=F.encoded_bits(cl), seed=task['seed'], evals=evals,
                dag=(task.get('dag') or 'original'), start_val=task.get('start_val'),
                best_val=best_val, best_order=best, truncated=truncated,
                capped_hits=capped_hits, round=task.get('round'),
                seconds=round(time.perf_counter() - t0, 3))


def do_census(task):
    """E7: after every forget step, truth tables of all nodes reachable from the
    root: (a) reachable nodes, (b) semantically distinct functions among them.
    Also checks root == exact existential projection at every step."""
    gc.disable()
    t0 = time.perf_counter()
    family, p = task['family'], task['params']
    inst = build_instance(family, p)
    n, cl = inst['n'], inst['clauses']
    order = O.make_order(task['order_spec'], n, cl, inst)
    ones, tabs = H.var_tables(n)
    cls = dag_class(task.get('dag')) or H.CappedDAG
    d = cls(H.NODE_CAP, t0 + 22.0, H.MEM_CAP_MB)
    keep_all = n <= 16
    memo = {}
    rec = dict(kind='census', exp=task['exp'], family=family, params=p, order=task['order'],
               order_spec=task['order_spec'], dag=(task.get('dag') or 'original'), n=n,
               m=len(cl), N=F.encoded_bits(cl), steps=[], result=None, projection_ok=True)
    try:
        root = d.cnf(cl)
        truth = H.cnf_table(cl, ones, tabs)
        for step in range(n + 1):
            if not keep_all:
                memo = {}
            reach = H.reach_set(d, root)
            for x in sorted(reach):
                H.node_table(d, x, ones, tabs, memo)
            if memo[root] != truth:
                rec['projection_ok'] = False
            distinct = len({memo[x] for x in reach})
            # constants and literals are "free": also report internal (and/or) nodes only
            internal = [x for x in reach if d.nodes[x][0] in ('and', 'or')]
            distinct_internal = len({memo[x] for x in internal})
            refs, dropped, touched = H.redundant_child_refs(d, reach, memo, ones)
            rec['steps'].append([step, len(reach), distinct, len(internal), distinct_internal,
                                 len(d.nodes), refs, dropped, touched])
            if step < n:
                v = order[step]
                root = d.forget(root, v)
                truth = H.exists_table(truth, v, n)
        rec['result'] = 'SAT' if root == 1 else 'UNSAT' if root == 0 else 'ERROR_NONCONST'
        if keep_all and len(d.nodes) * (1 << n) // 8 < 300_000_000:
            for x in range(len(d.nodes)):
                H.node_table(d, x, ones, tabs, memo)
            rec['alloc_distinct_functions'] = len(set(memo.values()))
            internal_all = [x for x in range(len(d.nodes)) if d.nodes[x][0] in ('and', 'or')]
            rec['alloc_internal'] = len(internal_all)
            rec['alloc_internal_distinct'] = len({memo[x] for x in internal_all})
    except H.Cap as e:
        rec['result'], rec['cap_reason'] = 'CAP', e.args[0]
    rec.update(H.dag_stats(d))
    if rec['steps']:
        rec['peak_reachable'] = max(s[1] for s in rec['steps'])
        rec['peak_distinct'] = max(s[2] for s in rec['steps'])
        rec['peak_internal'] = max(s[3] for s in rec['steps'])
        rec['peak_internal_distinct'] = max(s[4] for s in rec['steps'])
        worst = max(rec['steps'], key=lambda s: s[1])
        rec['at_peak_reachable'] = dict(step=worst[0], reachable=worst[1], distinct=worst[2],
                                        child_refs=worst[6], redundant_refs=worst[7])
        rec['peak_child_refs'] = max(s[6] for s in rec['steps'])
        most = max(rec['steps'], key=lambda s: s[7])
        rec['max_redundant_refs'] = dict(step=most[0], child_refs=most[6], redundant_refs=most[7],
                                         nodes_touched=most[8])
        rec['steps_format'] = ('step, reachable, distinct functions, internal nodes, distinct '
                               'internal, allocated so far, child refs of reachable nodes, '
                               'semantically redundant child refs, nodes with a redundant child')
    expected, source = expected_answer(family, p, inst)
    if expected is None and n <= 20:
        expected = 'SAT' if H.cnf_table(cl, ones, tabs) else 'UNSAT'
        source = 'truth table of the CNF (exhaustive)'
    rec['expected'], rec['expected_source'] = expected, source
    rec['agree'] = (rec['result'] == expected) if rec['result'] in ('SAT', 'UNSAT') else None
    rec['seconds'] = round(time.perf_counter() - t0, 3)
    rec['maxrss_mb'] = round(H._rss_mb(), 1)
    return rec


def do_support(task):
    """E7b: mechanism test without truth tables.  After every forget step, group the
    internal nodes reachable from the root by (kind, support) where support = set of
    variables the node mentions.  H-TSEITIN's mechanism predicts a bounded number of
    nodes per support (a merged component is determined by its remaining edges and
    one parity bit); a trellis-like state space shows up as many nodes on one support."""
    gc.disable()
    t0 = time.perf_counter()
    family, p = task['family'], task['params']
    inst = build_instance(family, p)
    n, cl = inst['n'], inst['clauses']
    order = get_order(task['order_spec'], n, cl, inst)
    d = H.CappedDAG(H.NODE_CAP, t0 + 20.0, H.MEM_CAP_MB)
    supp = {0: 0, 1: 0}
    rec = dict(kind='support', exp=task['exp'], family=family, params=p, order=task['order'],
               n=n, m=len(cl), N=F.encoded_bits(cl), result=None)
    peak_mult = peak_or_mult = 0
    peak_groups = peak_reach = 0
    hist_at_peak = None
    try:
        root = d.cnf(cl)
        for step in range(n + 1):
            reach = H.reach_set(d, root)
            for x in sorted(reach):
                if x in supp:
                    continue
                kind, data = d.nodes[x]
                if kind == 'lit':
                    supp[x] = 1 << abs(data)
                else:
                    m = 0
                    for c in data:
                        m |= supp[c]
                    supp[x] = m
            groups = defaultdict(int)
            for x in reach:
                kind = d.nodes[x][0]
                if kind in ('and', 'or'):
                    groups[(kind, supp[x])] += 1
            if groups:
                mult = max(groups.values())
                ormult = max((v for (k, _s), v in groups.items() if k == 'or'), default=0)
                if mult > peak_mult:
                    peak_mult = mult
                    hist = defaultdict(int)
                    for v in groups.values():
                        hist[v] += 1
                    hist_at_peak = dict(step=step, reachable=len(reach), supports=len(groups),
                                        multiplicity_histogram=dict(sorted(hist.items())))
                peak_or_mult = max(peak_or_mult, ormult)
                peak_groups = max(peak_groups, len(groups))
            peak_reach = max(peak_reach, len(reach))
            if step < n:
                root = d.forget(root, order[step])
        rec['result'] = 'SAT' if root == 1 else 'UNSAT' if root == 0 else 'ERROR_NONCONST'
    except H.Cap as e:
        rec['result'], rec['cap_reason'] = 'CAP', e.args[0]
    rec.update(H.dag_stats(d))
    rec.update(max_nodes_per_support=peak_mult, max_or_nodes_per_support=peak_or_mult,
               peak_distinct_supports=peak_groups, peak_reachable=peak_reach,
               at_peak=hist_at_peak, seconds=round(time.perf_counter() - t0, 3))
    return rec


def do_validate(task):
    """E8: brute-force validation of a DAG class on random small CNFs at EVERY
    elimination stage (full truth-table equality with the exact projection), plus
    a direct evaluate()-based check in the style of residual_dag.check_random."""
    gc.disable()
    from itertools import product
    cls = dag_class(task.get('dag')) or H.CappedDAG
    rng = random.Random(task['seed'])
    checked_tables = checked_points = formulas = 0
    failures = []
    for _ in range(task['count']):
        n = rng.randrange(1, task.get('max_n', 8) + 1)
        clauses = []
        for _ in range(rng.randrange(1, task.get('max_m', 16) + 1)):
            width = rng.randrange(0 if rng.random() < 0.02 else 1, min(4, n) + 1)
            vs = [rng.randrange(1, n + 1) for _ in range(width)] if rng.random() < 0.15 \
                else rng.sample(range(1, n + 1), width)
            clauses.append([v * rng.choice((-1, 1)) for v in vs])
        order = list(range(1, n + 1))
        rng.shuffle(order)
        ones, tabs = H.var_tables(n)
        d = cls(H.NODE_CAP, None, 0)
        root = d.cnf(clauses)
        truth = H.cnf_table(clauses, ones, tabs)
        memo = {}
        ok = True
        eliminated = []
        for step in range(n + 1):
            if H.node_table(d, root, ones, tabs, memo) != truth:
                ok = False
            checked_tables += 1
            if formulas % 10 == 0:          # independent re-check via DAG.evaluate
                retained = order[step:]
                for values in product((False, True), repeat=len(retained)):
                    a = dict(zip(retained, values))
                    exp = False
                    for old in product((False, True), repeat=len(eliminated)):
                        full = a | dict(zip(eliminated, old))
                        exp |= all(any(full[abs(l)] == (l > 0) for l in c) for c in clauses)
                    if d.evaluate(root, a) != exp:
                        ok = False
                    checked_points += 1
            if step < n:
                root = d.forget(root, order[step])
                truth = H.exists_table(truth, order[step], n)
                eliminated.append(order[step])
        if root not in (0, 1):
            ok = False
        if not ok and len(failures) < 5:
            failures.append(dict(n=n, clauses=clauses, order=order))
        formulas += 1
    return dict(kind='validate', exp=task['exp'], dag=(task.get('dag') or 'original'),
                seed=task['seed'], formulas=formulas, stages_checked=checked_tables,
                evaluate_points_checked=checked_points, failures=failures)


def greedy_seed(n, cl):
    return n * 1000003 + len(cl)


def do_greedy(task):
    """One <= 18 s chunk of the resumable DAG-aware greedy order construction."""
    gc.disable()
    t0, c0 = time.perf_counter(), time.process_time()
    inst = build_instance(task['family'], task['params'])
    n, cl = inst['n'], inst['clauses']
    try:
        order, complete = H.greedy_extend(n, cl, task['goal'], task['prefix'], sample=12,
                                          seed=greedy_seed(n, cl), wall_budget=16.0,
                                          dag_cls=dag_class(task.get('dag')))
        err = None
    except H.Cap as e:                      # replaying the prefix itself hit a cap
        order, complete, err = list(task['prefix']), False, str(e.args[0])
    return dict(kind='greedy', prefix=order, complete=complete, error=err,
                seconds=round(time.perf_counter() - t0, 3),
                cpu_seconds=round(time.process_time() - c0, 3))


def do_task(task):
    return {'greedy': do_greedy, 'support': do_support, 'run': do_run, 'expect': do_expect, 'batch': do_batch, 'search': do_search,
            'census': do_census, 'validate': do_validate}[task['kind']](task)


# --------------------------------------------------------------------------
# parent-side helpers
# --------------------------------------------------------------------------
class Store:
    def __init__(self, exp, quick, argv, tag=''):
        self.exp = exp
        outdir = RESULTS / 'quick' if quick else RESULTS
        try:
            outdir.mkdir(parents=True, exist_ok=True)
        except OSError:
            pass
        self.path = outdir / (f'{exp}.{tag}.json' if tag else f'{exp}.json')
        self.data = dict(meta=dict(
            experiment=exp, quick=quick, command=' '.join(argv),
            candidate='work/alg001/native-search/residual_dag.py',
            candidate_sha256=H.candidate_sha256(), python=platform.python_version(),
            platform=platform.platform(), node_cap=H.NODE_CAP, soft_time_cap_s=H.TIME_CAP,
            alarm_cap_s=H.ALARM_CAP, hard_kill_s=H.HARD_CAP, mem_cap_mb=H.MEM_CAP_MB,
            started=time.strftime('%Y-%m-%d %H:%M:%S'), finished=None, retries=RETRIES,
            env={k: v for k, v in os.environ.items() if k.startswith(('E1_', 'E2_', 'E5_', 'DAG_'))},
            encoding_bits='N = sum over literals (4 + 2*bitlen(var)) + 2 per clause'),
            runs=[], batches=[], searches=[], census=[], validation=[], expect=[],
            skipped=[], notes=[])
        self.last = 0.0

    def add(self, rec):
        rec = dict(rec)
        rec.pop('task', None)
        key = {'run': 'runs', 'batch': 'batches', 'search': 'searches', 'census': 'census',
               'validate': 'validation', 'expect': 'expect'}.get(rec.get('kind'), 'runs')
        self.data[key].append(rec)
        if time.time() - self.last > 10:
            self.flush()

    def flush(self, final=False):
        """Atomic rewrite.  The host intermittently refuses file writes under heavy
        load (EPERM); a failed intermediate flush is skipped (data stays in memory),
        the final flush retries for up to ten minutes."""
        if final:
            self.data['meta']['finished'] = time.strftime('%Y-%m-%d %H:%M:%S')
        payload = json.dumps(self.data, separators=(',', ':')) + '\n'
        tmp = self.path.with_suffix('.json.tmp')
        for attempt in range(120 if final else 1):
            try:
                tmp.write_text(payload)
                os.replace(tmp, self.path)
                self.last = time.time()
                return True
            except OSError as e:
                self.write_errors = getattr(self, 'write_errors', 0) + 1
                print(f'  [store] write refused ({e!r}); '
                      f'{"retrying" if final else "will retry at next flush"}', flush=True)
                if final:
                    time.sleep(5)
        self.last = time.time()
        return False


def retry_load_induced(task, res):
    """A time cap that used little CPU was caused by machine load: retry (max 2)."""
    if res.get('result') != 'CAP':
        return False
    if res.get('cap_reason') not in ('time', 'alarm', 'task_alarm', 'hard_kill'):
        return False
    if task.get('attempt', 0) >= RETRIES:
        return False
    cpu = res.get('cpu_seconds')
    return cpu is None or cpu < 10.0


def execute(store, tasks, workers, label):
    """Run tasks with load-induced-timeout retries; returns final results in order."""
    final = [None] * len(tasks)
    todo = list(enumerate(tasks))
    for attempt in range(RETRIES + 1):
        if not todo:
            break
        batch = [dict(t, attempt=attempt) for _, t in todo]
        res = H.run_tasks(do_task, batch, workers=workers, label=f'{label} try{attempt}')
        again = []
        for (i, t), tk, r in zip(todo, batch, res):
            if r.get('result') in ('CAP', 'CRASH') and 'family' not in r:
                # worker-level failure: keep the task identity in the record
                r = dict(kind=t['kind'], exp=t['exp'], family=t.get('family'),
                         params=t.get('params'), seed=(t.get('params') or {}).get('seed'),
                         order=t.get('order'), order_spec=t.get('order_spec'),
                         dag=t.get('dag') or 'original', attempt=attempt, alloc=None, **{
                             k: v for k, v in r.items() if k != 'task'})
            if retry_load_induced(tk, r):
                again.append((i, t))
                store.data['notes'].append(dict(note='retry after load-induced time cap',
                                                family=t.get('family'), params=t.get('params'),
                                                order=t.get('order'), attempt=attempt,
                                                cpu_seconds=r.get('cpu_seconds')))
            else:
                final[i] = r
        todo = again
    for r in final:
        store.add(r)
    store.flush()
    return final


def compute_greedy_orders(store, exp, items, goal, workers, dag=None, max_chunks=6):
    """Chained <= 30 s chunks of the DAG-aware greedy order for each (family, params).
    Returns {index: order or None}.  Every chunk is its own process; an instance is
    abandoned (None) if a chunk makes no progress or after max_chunks chunks."""
    state = {i: dict(prefix=[], complete=False, chunks=0, cpu=0.0, dead=False)
             for i in range(len(items))}
    for _ in range(max_chunks):
        todo = [i for i, st in state.items() if not st['complete'] and not st['dead']]
        if not todo:
            break
        tasks = [dict(kind='greedy', exp=exp, family=items[i][0], params=items[i][1], goal=goal,
                      prefix=state[i]['prefix'], dag=dag) for i in todo]
        res = H.run_tasks(do_task, tasks, workers=workers, label=f'{exp} greedy_{goal}')
        for i, r in zip(todo, res):
            st = state[i]
            st['chunks'] += 1
            if r.get('kind') != 'greedy' or r.get('error'):
                st['dead'] = True
                st['why'] = r.get('error') or r.get('cap_reason') or r.get('result')
                continue
            st['cpu'] += r['cpu_seconds']
            if len(r['prefix']) <= len(st['prefix']) and not r['complete']:
                st['dead'] = True
                st['why'] = 'no progress within one chunk'
            st['prefix'], st['complete'] = r['prefix'], r['complete']
    out = {}
    for i, st in state.items():
        out[i] = st['prefix'] if st['complete'] else None
        store.data.setdefault('greedy_orders', []).append(dict(
            family=items[i][0], params=items[i][1], goal=goal, dag=dag or 'original',
            complete=st['complete'], chunks=st['chunks'], cpu_seconds=round(st['cpu'], 3),
            steps_done=len(st['prefix']), why=st.get('why'),
            order=st['prefix'] if st['complete'] else None))
    return out


def order_group(label):
    return 'shuffle' if label.startswith('shuffle') else label


def run_grid(store, exp, family, fixed, size_key, sizes, variants, seeds, labels, workers,
             extra=None, expected_lookup=None, min_frac=0.25, greedy_max_size=None,
             seed_exp=None):
    """Sizes in increasing order.  A series (family, fixed, order group) stops being
    scheduled once fewer than min_frac of its runs completed at the previous size."""
    dead = set()
    fixed_key = json.dumps(fixed, sort_keys=True)
    dag = (extra or {}).get('dag')
    for size in sizes:
        tasks = []
        plist = []
        for var in variants:
            for seed in seeds:
                p = dict(fixed)
                p[size_key] = size
                p.update(var)
                if seed is not None:
                    p['seed'] = seed
                plist.append(p)
        greedy = {}
        if greedy_max_size is not None and size > greedy_max_size:
            for label in labels:
                if label.startswith('greedy_'):
                    dead.add((family, fixed_key, label))   # not attempted beyond this size
        for label in labels:
            if label.startswith('greedy_') and (family, fixed_key, label) not in dead:
                got = compute_greedy_orders(store, exp, [(family, p) for p in plist],
                                            label[len('greedy_'):], workers, dag)
                for i, p in enumerate(plist):
                    greedy[(label, i)] = got[i]
        pseudo = []
        for i, p in enumerate(plist):
            for label in labels:
                series = (family, fixed_key, order_group(label))
                if series in dead:
                    store.data['skipped'].append(dict(family=family, params=p, order=label,
                                                      reason='series capped at smaller size'))
                    continue
                spec = label
                if label.startswith('shuffle'):
                    spec = shuffle_spec(seed_exp or exp, family, sorted(p.items()), label)
                if label.startswith('greedy_'):
                    spec = greedy[(label, i)]
                    if spec is None:
                        pseudo.append(dict(kind='run', exp=exp, family=family, params=p,
                                           seed=p.get('seed'), order=label, order_spec=None,
                                           dag=dag or 'original', result='ORDER_TIMEOUT',
                                           cap_reason='order:greedy chunks exhausted',
                                           alloc=None, series=series))
                        continue
                t = dict(kind='run', exp=exp, family=family, params=p, order=label,
                         order_spec=spec)
                if extra:
                    t.update(extra)
                if expected_lookup is not None:
                    e = expected_lookup(p)
                    t['expected'], t['expected_source'] = e
                tasks.append(t)
        for r in pseudo:
            series = r.pop('series')
            store.add(r)
        if not tasks and not pseudo:
            break
        res = execute(store, tasks, workers, f'{exp} {family} {fixed_key} {size_key}={size}') \
            if tasks else []
        tally = defaultdict(lambda: [0, 0])
        for r in pseudo:
            tally[(family, fixed_key, order_group(r['order']))][1] += 1
        for t, r in zip(tasks, res):
            s = (family, fixed_key, order_group(t['order']))
            tally[s][1] += 1
            if r.get('result') in ('SAT', 'UNSAT'):
                tally[s][0] += 1
        for s, (ok, tot) in tally.items():
            if ok == 0 or ok / tot < min_frac:
                dead.add(s)
        done = sum(1 for r in res if r.get('result') in ('SAT', 'UNSAT'))
        bad = sum(1 for r in res if r.get('agree') is False)
        print(f'{exp} {family} {fixed_key} {size_key}={size}: {done}/{len(res)} completed, '
              f'{bad} disagreements, dead series {len(dead)}', flush=True)


STD_ORDERS = ['natural', 'reverse', 'min_degree', 'min_fill', 'max_degree', 'bfs']


def shuffles(k):
    return [f'shuffle{j:02d}' for j in range(k)]


# --------------------------------------------------------------------------
# E1 Tseitin
# --------------------------------------------------------------------------
def e1(store, workers, quick):
    labels = STD_ORDERS + shuffles(5) + ['greedy_max', 'greedy_min']
    sat_variants = [dict(sat=True), dict(sat=False)]
    grids = [
        ('tseitin_regular', dict(d=3), 'nv', [8, 12, 16, 24, 32, 48, 64, 96, 128, 192, 256], 64),
        ('tseitin_regular', dict(d=4), 'nv', [8, 12, 16, 24, 32, 48, 64, 96, 128, 192], 48),
        ('tseitin_regular', dict(d=5), 'nv', [8, 12, 16, 24, 32, 48, 64, 96, 128], 32),
        ('tseitin_torus', dict(), 'a', [3, 4, 5, 6, 7, 8, 10, 12], 7),
        ('tseitin_complete', dict(), 'm', [4, 5, 6, 7, 8, 9, 10, 11], 9),
    ]
    if quick:
        grids = [(f, fx, k, s[:3], g) for f, fx, k, s, g in grids]
    if os.environ.get('E1_PART', 'grid') in ('grid', 'all'):
        for family, fixed, key, sizes, gmax in grids:
            run_grid(store, 'E1', family, fixed, key, sizes, sat_variants, [1, 2], labels,
                     workers, greedy_max_size=gmax)
    if os.environ.get('E1_PART', 'adv') in ('adv', 'all'):
        e1_adversarial(store, workers, quick)


def e1_adversarial(store, workers, quick):
    """Try to break H-TSEITIN: exhaustive orders on tiny graphs, then hill-climbing
    for the order maximising allocated nodes on small/medium graphs."""
    # (a) exhaustive: K4 (6 edges, 720 orders, both charges), wheel W4 (8 edges, 40320)
    ex = [('tseitin_named', dict(graph='K4', seed=1, sat=False)),
          ('tseitin_named', dict(graph='K4', seed=1, sat=True)),
          ('tseitin_named', dict(graph='W4', seed=1, sat=False))]
    if quick:
        ex = ex[:1]
    tasks = []
    for family, p in ex:
        n = build_instance(family, p)['n']
        total = math.factorial(n)
        chunk = 720 if n <= 6 else 2016
        for start in range(0, total, chunk):
            tasks.append(dict(kind='batch', exp='E1', family=family, params=p,
                              orders=dict(type='perm_range', start=start,
                                          stop=min(total, start + chunk))))
    run_batches(store, tasks, workers, 'E1 exhaustive')
    # (a') 4000 random orders each on K33, prism (9 edges), cube (12), Petersen (15)
    tasks = []
    for g in (('K33',) if quick else ('K33', 'prism', 'cube', 'petersen')):
        p = dict(graph=g, seed=1, sat=False)
        cnt = 200 if quick else 4000
        specs = [shuffle_spec('E1', 'named', g, j) for j in range(cnt)]
        for st in range(0, cnt, 500):
            tasks.append(dict(kind='batch', exp='E1', family='tseitin_named', params=p,
                              orders=dict(type='shuffles', specs=specs[st:st + 500], offset=st)))
    run_batches(store, tasks, workers, 'E1 sampled')
    # (a'') designed adversarial order (spanning caterpillar first, chords last)
    if not quick:
        for fixed, sizes in ((dict(d=3), [8, 12, 16, 24, 32, 48, 64, 96, 128, 192]),
                             (dict(d=4), [8, 12, 16, 24, 32, 48, 64, 96, 128]),
                             (dict(d=5), [8, 12, 16, 24, 32, 48, 64, 96])):
            run_grid(store, 'E1', 'tseitin_regular', fixed, 'nv', sizes,
                     [dict(sat=True), dict(sat=False)], [1, 2], ['tree_first', 'tree_first_bfs'],
                     workers)
    # (b) hill-climb for the WORST order (maximise allocated nodes)
    targets = [('tseitin_regular', dict(nv=nv, d=3, seed=1, sat=False)) for nv in (8, 12, 16, 24, 32, 48)]
    targets += [('tseitin_regular', dict(nv=nv, d=4, seed=1, sat=False)) for nv in (8, 12, 16, 24)]
    targets += [('tseitin_complete', dict(m=m, seed=1, sat=False)) for m in (5, 6, 7)]
    targets += [('tseitin_torus', dict(a=a, seed=1, sat=False)) for a in (3, 4)]
    if quick:
        targets = targets[:2]
    run_searches(store, 'E1', targets, 'max', workers, rounds=2 if quick else 6,
                 starts=['greedy_max', 'max_degree', 'bfs', 'tree_first', 'tree_first_bfs',
                         'shuffle'])


def run_batches(store, tasks, workers, label):
    """Run batch tasks; requeue the unfinished tail of any batch that stopped early."""
    todo = tasks
    guard = 0
    while todo and guard < 50:
        guard += 1
        res = H.run_tasks(do_task, todo, workers=workers, label=label)
        nxt = []
        for t, r in zip(todo, res):
            if r.get('kind') != 'batch':
                store.data['notes'].append(dict(note='batch task failed', task=t,
                                                result=r.get('result'), reason=r.get('cap_reason')))
                # split the range in two and retry (bounded by guard)
                o = t['orders']
                if o['type'] == 'perm_range' and o['stop'] - o['start'] > 1:
                    mid = (o['start'] + o['stop']) // 2
                    nxt.append(dict(t, orders=dict(o, stop=mid)))
                    nxt.append(dict(t, orders=dict(o, start=mid)))
                continue
            store.add(r)
            if r['done_until'] < r['stop']:
                nxt.append(dict(t, orders=dict(t['orders'], start=r['done_until'])))
        todo = nxt
    store.flush()


def run_searches(store, exp, targets, goal, workers, rounds, starts, dag=None,
                 seeds_per_round=3):
    """Chained local search.  Round 0 starts from each named start order; later
    rounds restart from the best order found so far with fresh seeds."""
    state = {}
    greedy = {}
    for s_name in starts:
        if s_name.startswith('greedy_'):
            got = compute_greedy_orders(store, exp, targets, s_name[len('greedy_'):], workers, dag)
            greedy[s_name] = got
    for ti, (family, p) in enumerate(targets):
        inst = build_instance(family, p)
        key = json.dumps([family, p], sort_keys=True)
        cands = []
        for s_name in starts:
            if s_name.startswith('greedy_'):
                if greedy[s_name][ti] is not None:
                    cands.append(greedy[s_name][ti])
                continue
            spec = shuffle_spec(exp, 'search', key) if s_name == 'shuffle' else s_name
            try:
                cands.append(O.make_order(spec, inst['n'], inst['clauses'], inst))
            except Exception as e:
                store.data['notes'].append(dict(note='search start order unavailable',
                                                family=family, params=p, start=s_name,
                                                error=repr(e)))
        # deterministic evaluation budget per task (about 1.5 CPU-seconds unloaded)
        evals = max(8, min(150, 3_000_000 // (inst['n'] * F.encoded_bits(inst['clauses']))))
        state[key] = dict(family=family, params=p, starts=cands, best=None, best_val=None,
                          evals=evals)
    for rnd in range(rounds):
        tasks = []
        for key, st in state.items():
            if rnd == 0:
                seeds = [(o, 1000 + i) for i, o in enumerate(st['starts'])]
            else:
                if st['best'] is None or st['best_val'] > H.NODE_CAP:
                    continue
                seeds = [(st['best'], 1000 * (rnd + 1) + i) for i in range(seeds_per_round)]
            for order, seed in seeds:
                tasks.append(dict(kind='search', exp=exp, family=st['family'],
                                  params=st['params'], goal=goal, seed=seed, evals=st['evals'],
                                  start_order=order, round=rnd, dag=dag, key=key))
        if not tasks:
            break
        res = H.run_tasks(do_task, tasks, workers=workers, label=f'{exp} search r{rnd}')
        for t, r in zip(tasks, res):
            if r.get('kind') != 'search' or 'best_val' not in r:
                store.data['notes'].append(dict(note='search task failed', family=t['family'],
                                                params=t['params'], result=r.get('result'),
                                                error=r.get('error')))
                continue
            store.add(r)
            st = state[t['key']]
            better = st['best_val'] is None or (
                r['best_val'] < st['best_val'] if goal == 'min' else r['best_val'] > st['best_val'])
            if better:
                st['best'], st['best_val'] = r['best_order'], r['best_val']
        store.flush()
        print(f'{exp} search round {rnd}: ' + ', '.join(
            f"{st['family']}{[v for k, v in st['params'].items() if k not in ('seed', 'sat')]}"
            f"={st['best_val']}" for st in state.values()), flush=True)
    for key, st in state.items():
        store.data['notes'].append(dict(note=f'search final ({goal})', family=st['family'],
                                        params=st['params'], best_val=st['best_val'],
                                        best_order=st['best'], dag=dag or 'original'))
    store.flush()


# --------------------------------------------------------------------------
# E2 XOR systems
# --------------------------------------------------------------------------
def e2(store, workers, quick):
    """Parts (env E2_PARTS, comma separated; default all):
    planted_structured, planted_shuffle, random_structured, random_shuffle, occ."""
    structured = ['natural', 'min_degree', 'min_fill', 'greedy_min']
    sizes = [16, 24, 32, 40, 48, 56, 64, 72, 80, 88, 96, 104, 112, 120, 136, 152, 168, 184, 200]
    occ = [8, 12, 16, 24, 32, 48, 64, 96, 128]
    seeds, sh = [1, 2, 3], shuffles(20)
    if quick:
        sizes, occ, seeds, sh = sizes[:3], occ[:3], [1], shuffles(3)
    parts = os.environ.get('E2_PARTS', 'planted_structured,planted_shuffle,random_structured,'
                                       'random_shuffle,occ').split(',')
    for name, fixed in (('planted', dict(planted=True, extra=0)),
                        ('random', dict(planted=False, extra=5))):
        if name + '_structured' in parts:
            run_grid(store, 'E2', 'xor3', fixed, 'n', sizes, [{}], seeds, structured, workers)
        if name + '_shuffle' in parts:
            run_grid(store, 'E2', 'xor3', fixed, 'n', sizes, [{}], seeds[:2], sh, workers,
                     min_frac=0.4)
    if 'occ' in parts:
        sat_variants = [dict(sat=True), dict(sat=False)]
        run_grid(store, 'E2', 'xor_two_occ', dict(k=4), 'm_eq', occ, sat_variants, seeds[:2],
                 structured + ['reverse', 'max_degree', 'bfs', 'greedy_max'], workers,
                 greedy_max_size=48)
        run_grid(store, 'E2', 'xor_two_occ', dict(k=4), 'm_eq', occ, sat_variants, seeds[:1],
                 sh, workers, min_frac=0.4)


# --------------------------------------------------------------------------
# E3 PHP
# --------------------------------------------------------------------------
def e3(store, workers, quick, dag=None, exp='E3'):
    extra = dict(dag=dag) if dag else None
    hs = list(range(2, 12))
    if quick:
        hs = hs[:4]
    run_grid(store, exp, 'php', dict(), 'h', hs, [{}], [None],
             ['pigeon_major', 'hole_major', 'min_degree', 'min_fill', 'reverse', 'max_degree',
              'bfs', 'greedy_min', 'greedy_max'],
             workers, extra=extra, seed_exp='E3')
    # 200 random orders: batches for small h, single runs for larger h
    random_counts = {2: 200, 3: 200, 4: 200, 5: 200, 6: 200, 7: 30}
    if dag:
        random_counts = {2: 200, 3: 200, 4: 200, 5: 200, 6: 60}
    if quick:
        random_counts = {2: 20, 3: 20, 4: 10}
    tasks = []
    for h, cnt in random_counts.items():
        if h > 5:
            continue
        p = dict(h=h)
        specs = [shuffle_spec('E3', 'php', h, j) for j in range(cnt)]
        for s in range(0, cnt, 50):
            tasks.append(dict(kind='batch', exp=exp, family='php', params=p, dag=dag, reach=True,
                              orders=dict(type='shuffles', specs=specs[s:s + 50], offset=s)))
    run_batches(store, tasks, workers, f'{exp} random small')
    for h, cnt in random_counts.items():
        if h <= 5:
            continue
        tasks = [dict(kind='run', exp=exp, family='php', params=dict(h=h), dag=dag,
                      order=f'random{j:03d}', order_spec=shuffle_spec('E3', 'php', h, j))
                 for j in range(cnt)]
        res = execute(store, tasks, workers, f'{exp} php random h={h}')
        done = sum(1 for r in res if r.get('result') in ('SAT', 'UNSAT'))
        print(f'{exp} php random h={h}: {done}/{cnt} completed', flush=True)
        if done == 0:
            break
    if dag is None:
        # exhaustive: PHP(3,2) 6 vars (720 orders), PHP(4,2) 8 vars (40320 orders)
        tasks = [dict(kind='batch', exp=exp, family='php', params=dict(h=2), reach=True,
                      orders=dict(type='perm_range', start=0, stop=720))]
        if not quick:
            for start in range(0, 40320, 2016):
                tasks.append(dict(kind='batch', exp=exp, family='php', reach=True,
                                  params=dict(h=2, excess=2),
                                  orders=dict(type='perm_range', start=start, stop=start + 2016)))
        run_batches(store, tasks, workers, f'{exp} exhaustive')
    # local search for the best (minimum) order
    targets = [('php', dict(h=h)) for h in ((3, 4) if quick else (3, 4, 5, 6))]
    run_searches(store, exp, targets, 'min', workers, rounds=2 if quick else 6, dag=dag,
                 starts=['hole_major', 'pigeon_major', 'min_degree', 'min_fill', 'greedy_min'])


# --------------------------------------------------------------------------
# E4 random 3-CNF
# --------------------------------------------------------------------------
def e4(store, workers, quick, dag=None, exp='E4'):
    extra = dict(dag=dag) if dag else None
    structured = ['natural', 'min_degree', 'min_fill', 'greedy_min']
    sh = shuffles(5 if dag else 20)
    sizes = [12, 16, 20, 24, 28, 32, 36, 40, 44, 48, 52, 56, 60, 64]
    seeds = [1, 2, 3]
    dens = [2.0, 3.0, 4.26]
    if quick:
        sizes, seeds, sh = sizes[:3], [1], shuffles(2)
    # expected answers once per instance (reused from results/E4.json when present)
    table = {}
    prior = RESULTS / 'E4.json'
    if exp != 'E4' and prior.exists():
        for r in json.loads(prior.read_text()).get('expect', []):
            p = r['params']
            table[(p['density'], p['n'], p['seed'])] = (r['expected'], r['expected_source'])
    tasks = [dict(kind='expect', exp=exp, family='kcnf',
                  params=dict(density=dn, k=3, n=n, seed=s))
             for dn in dens for n in sizes for s in seeds
             if (dn, n, s) not in table]
    res = H.run_tasks(do_task, tasks, workers=workers, label=f'{exp} expected')
    for attempt in range(2):                # retry oracle time-outs caused by load
        redo = [i for i, (t, r) in enumerate(zip(tasks, res))
                if r.get('kind') != 'expect' or r.get('oracle_note')]
        if not redo:
            break
        res2 = H.run_tasks(do_task, [tasks[i] for i in redo], workers=workers,
                           label=f'{exp} expected retry{attempt}')
        for i, r in zip(redo, res2):
            if r.get('kind') == 'expect' and (not r.get('oracle_note')
                                              or res[i].get('kind') != 'expect'):
                res[i] = r
    for t, r in zip(tasks, res):
        p = t['params']
        if r.get('kind') == 'expect':
            store.add(r)
            table[(p['density'], p['n'], p['seed'])] = (r['expected'], r['expected_source'])
        else:
            table[(p['density'], p['n'], p['seed'])] = (None, 'unverified (expect task failed)')
            store.data['notes'].append(dict(note='expect task failed', params=p,
                                            result=r.get('result'), error=r.get('error')))
    store.flush()
    look = lambda p: table[(p['density'], p['n'], p['seed'])]
    for dn in dens:
        run_grid(store, exp, 'kcnf', dict(density=dn, k=3), 'n', sizes, [{}], seeds,
                 structured, workers, extra=extra, expected_lookup=look, seed_exp='E4')
        run_grid(store, exp, 'kcnf', dict(density=dn, k=3), 'n', sizes, [{}], seeds[:2], sh,
                 workers, extra=extra, expected_lookup=look, min_frac=0.4, seed_exp='E4')


# --------------------------------------------------------------------------
# E5 2-SAT / Horn hunt
# --------------------------------------------------------------------------
def e5(store, workers, quick):
    """2-SAT / Horn hunt.  env E5_ONLY=family[,family...] restricts the families."""
    base = STD_ORDERS + shuffles(3) + ['greedy_min']
    two = base + ['scc_topo', 'scc_topo_rev']           # 2-CNF-specific orders as well
    geo = [10, 14, 20, 28, 40, 56, 80, 112, 160, 224, 320]
    grids = []
    for d in (3, 4):
        for mode in ('rand', 'planted', 'impl'):
            grids.append(('regular_2cnf', dict(d=d, mode=mode), 'nv', geo, [1, 2, 3], two))
    for mode in ('planted', 'impl'):
        grids.append(('regular_2cnf', dict(d=5, mode=mode), 'nv', geo, [1, 2], two))
    for dn in (0.9, 1.0, 1.5):
        grids.append(('rand2cnf', dict(density=dn), 'n', [20, 40, 80, 160, 320, 640], [1, 2], two))
    for mode in ('planted', 'impl'):
        grids.append(('grid_2cnf', dict(mode=mode), 'a', [4, 6, 8, 10, 12, 14, 16], [1, 2], two))
    for variant in ('mono', 'equiv', 'unsat'):
        grids.append(('implication_grid', dict(variant=variant), 'a', [4, 6, 8, 10, 12, 14, 16],
                      [None], two))
    grids.append(('ladder_2cnf', dict(), 'k', [8, 32, 128], [None], two))
    grids.append(('bipartite_implication', dict(p=1.0), 'k', [4, 8, 12, 16], [1], two))
    grids.append(('bipartite_implication', dict(p=0.5), 'k', [4, 8, 12, 16, 24], [1, 2], two))
    grids.append(('subsume_2cnf', dict(), 'k', list(range(2, 15)), [None], two))
    horn_sizes = [12, 16, 20, 24, 28, 32, 36, 40, 48, 56, 64, 80]
    for dn, facts, goals in ((2.0, 0, 0), (3.0, 0, 0), (4.0, 0, 0), (3.0, 0.1, 0.2)):
        grids.append(('random_horn3', dict(density=dn, facts=facts, goals=goals), 'n',
                      horn_sizes, [1, 2, 3], base))
    for variant in ('free', 'fire'):
        grids.append(('horn_grid', dict(variant=variant), 'a', [3, 4, 5, 6, 7, 8, 9, 10], [None],
                      base))
    grids.append(('subsume_horn', dict(), 'k', list(range(2, 15)), [None], base))
    if quick:
        grids = [(f, fx, k, s[:2], sd[:1], lb) for f, fx, k, s, sd, lb in grids]
    only = os.environ.get('E5_ONLY')
    match = os.environ.get('E5_MATCH')        # substring of the fixed-params JSON
    for family, fixed, key, sizes, sds, labels in grids:
        if only and family not in only.split(','):
            continue
        if match and match not in json.dumps(fixed, sort_keys=True):
            continue
        run_grid(store, 'E5', family, fixed, key, sizes, [{}], sds, labels, workers,
                 min_frac=0.34)


# --------------------------------------------------------------------------
# E6 H-SUBSUME
# --------------------------------------------------------------------------
def subsume_orders(k):
    inst = F.subsume_family(k)
    x, a, b, c = inst['x'], inst['a'], inst['b'], inst['c']
    return {'x_then_a': [x] + a + b + [c], 'a_then_x': a + [x] + b + [c]}


def e6(store, workers, quick, dag=None, exp='E6'):
    ks = range(2, 6) if quick else range(2, 15)
    tasks = []
    for k in ks:
        named = subsume_orders(k)
        for label in ('x_then_a', 'a_then_x', 'min_degree', 'min_fill', 'reverse'):
            tasks.append(dict(kind='run', exp=exp, family='subsume', params=dict(k=k),
                              order=label, order_spec=named.get(label, label), reach=True,
                              dag=dag))
    res = execute(store, tasks, workers, exp)
    for t, r in zip(tasks, res):
        if t['order'] in ('x_then_a', 'a_then_x'):
            print(exp, 'k', t['params']['k'], t['order'], r.get('result'), 'alloc', r.get('alloc'),
                  'max_or_arity', r.get('max_or_arity'), 'peak_reach', r.get('peak_reachable'),
                  flush=True)


# --------------------------------------------------------------------------
# E7 semantic census
# --------------------------------------------------------------------------
def e7(store, workers, quick):
    tasks = []

    def add(family, p, labels):
        for label in labels:
            spec = label
            if label.startswith('shuffle'):
                spec = shuffle_spec('E7', family, sorted(p.items()), label)
            tasks.append(dict(kind='census', exp='E7', family=family, params=p, order=label,
                              order_spec=spec))
    gen = ['natural', 'min_degree', 'min_fill'] + shuffles(3)
    add('php', dict(h=3), ['pigeon_major', 'hole_major', 'min_degree', 'min_fill'] + shuffles(3))
    if not quick:
        add('php', dict(h=4), ['pigeon_major', 'hole_major', 'min_degree', 'min_fill'] + shuffles(3))
    for n in ((14,) if quick else (14, 15, 16)):
        for seed in ((1,) if quick else (1, 2)):
            add('kcnf', dict(density=4.26, k=3, n=n, seed=seed), gen)
            add('xor3', dict(n=n, extra=0, planted=True, seed=seed), gen)
            add('xor3', dict(n=n, extra=5, planted=False, seed=seed), gen)
    for nv in ((6,) if quick else (6, 8, 10)):
        for sat in (True, False):
            add('tseitin_regular', dict(nv=nv, d=3, seed=1, sat=sat), gen + ['max_degree', 'bfs'])
    if not quick:
        for m in (5, 6):
            add('tseitin_complete', dict(m=m, seed=1, sat=False), gen + ['max_degree', 'bfs'])
        for k in (4, 5, 6, 7):
            named = subsume_orders(k)
            for label in ('x_then_a', 'a_then_x'):
                tasks.append(dict(kind='census', exp='E7', family='subsume', params=dict(k=k),
                                  order=label, order_spec=named[label]))
        add('subsume_2cnf', dict(k=3), ['natural', 'min_degree'])
        add('random_horn3', dict(density=3.0, facts=0, goals=0, n=16, seed=1), gen)
        add('rand2cnf', dict(density=1.0, n=16, seed=1), gen)
    res = H.run_tasks(do_task, tasks, workers=workers, label='E7')
    for t, r in zip(tasks, res):
        if r.get('kind') != 'census':
            r = dict(kind='census', exp='E7', family=t['family'], params=t['params'],
                     order=t['order'], **{k: v for k, v in r.items() if k != 'task'})
        store.add(r)
        print('E7', t['family'], t['params'], t['order'], r.get('result'),
              'peak reach', r.get('peak_reachable'), 'peak distinct', r.get('peak_distinct'),
              'proj_ok', r.get('projection_ok'), flush=True)
    store.flush()


# --------------------------------------------------------------------------
# E8 repaired subclass
# --------------------------------------------------------------------------
def e8(store, workers, quick):
    # validation: 2000 random small CNFs, every elimination stage, both classes
    # 40 tasks x 50 formulas per DAG class = 2000 formulas each (small tasks: the host
    # is heavily loaded and every task must stay under 30 s of wall clock)
    count = 10 if quick else 50
    tasks = [dict(kind='validate', exp='E8', dag=dag, seed=7000 + i, count=count)
             for dag in ('repaired', 'original') for i in range(40)]
    res = H.run_tasks(do_task, tasks, workers=workers, label='E8 validate')
    for attempt in range(3):                # re-run tasks killed by the wall-clock cap
        redo = [i for i, r in enumerate(res) if r.get('kind') != 'validate']
        if not redo:
            break
        res2 = H.run_tasks(do_task, [tasks[i] for i in redo], workers=workers,
                           label=f'E8 validate retry{attempt}')
        for i, r in zip(redo, res2):
            if r.get('kind') == 'validate':
                res[i] = r
    for t, r in zip(tasks, res):
        if r.get('kind') != 'validate':
            r = dict(kind='validate', exp='E8', dag=t['dag'], seed=t['seed'],
                     **{k: v for k, v in r.items() if k != 'task'})
        store.add(r)
    store.flush()
    for dag in ('repaired', 'original'):
        rs = [r for r in store.data['validation'] if r.get('dag') == dag]
        print('E8 validate', dag, 'formulas', sum(r.get('formulas', 0) for r in rs),
              'stages', sum(r.get('stages_checked', 0) for r in rs),
              'failures', sum(len(r.get('failures', [])) for r in rs),
              'crashed tasks', sum(1 for r in rs if 'formulas' not in r), flush=True)
    e6(store, workers, quick, dag='repaired', exp='E8')
    e3(store, workers, quick, dag='repaired', exp='E8')
    e4(store, workers, quick, dag='repaired', exp='E8')


def do_selfcheck(task):
    """Plain residual_dag.DAG vs the capped subclass: identical counters; and the
    verifiers against the exhaustive oracle on small instances."""
    gc.disable()
    rng = random.Random(task['seed'])
    checked = 0
    allocs = []
    for _ in range(task['count']):
        which = rng.randrange(6)
        if which == 0:
            fam, p = 'kcnf', dict(density=rng.choice((2.0, 3.0, 4.26)), k=3,
                                  n=rng.randrange(6, 15), seed=rng.randrange(10 ** 6))
        elif which == 1:
            fam, p = 'xor3', dict(n=rng.randrange(6, 15), extra=rng.choice((0, 5)),
                                  planted=bool(rng.randrange(2)), seed=rng.randrange(10 ** 6))
        elif which == 2:
            fam, p = 'tseitin_regular', dict(nv=rng.choice((4, 6, 8)), d=3,
                                             seed=rng.randrange(10 ** 6),
                                             sat=bool(rng.randrange(2)))
        elif which == 3:
            fam, p = 'rand2cnf', dict(density=rng.choice((0.9, 1.0, 1.5)),
                                      n=rng.randrange(6, 15), seed=rng.randrange(10 ** 6))
        elif which == 4:
            fam, p = 'random_horn3', dict(density=3.0, facts=0.1, goals=0.2,
                                          n=rng.randrange(6, 15), seed=rng.randrange(10 ** 6))
        else:
            fam, p = 'php', dict(h=rng.choice((2, 3)), excess=rng.choice((0, 1)))
        inst = build_instance(fam, p)
        n, cl = inst['n'], inst['clauses']
        truth = oracle_exhaustive(n, cl)['status']
        exp, _src = expected_answer(fam, p, inst)
        if exp is None:
            exp = V.dpll(n, cl)[0]
        assert exp == truth, (fam, p, exp, truth)
        assert V.dpll(n, cl)[0] == truth, (fam, p)
        for name in ('natural', 'reverse', 'min_degree', 'min_fill', 'max_degree', 'bfs',
                     'shuffle%d' % rng.randrange(10 ** 6)):
            order = O.make_order(name, n, cl, inst)
            a = H.selfcheck_identical(n, cl, order)
            r = H.run_order(n, cl, order, reach=True)
            assert r['result'] == truth, (fam, p, name, r['result'], truth)
            allocs.append(a)
            checked += 1
    return dict(kind='selfcheck', seed=task['seed'], runs=checked,
                alloc_digest=hashlib.sha256(repr(allocs).encode()).hexdigest())


def e0(store, workers, quick):
    """Sanity: capped subclass == plain candidate; verifiers == exhaustive oracle;
    allocation counts independent of PYTHONHASHSEED."""
    import subprocess
    tasks = [dict(kind='selfcheck', seed=s, count=10 if quick else 40) for s in range(6)]
    res = H.run_tasks(do_selfcheck, tasks, workers=workers, label='E0')
    store.data['selfcheck'] = [{k: v for k, v in r.items() if k != 'task'} for r in res]
    code = ("import sys; sys.path.insert(0, %r); import run_experiments as R; "
            "print(R.do_selfcheck(dict(seed=0, count=6))['alloc_digest'])" % str(HERE))
    digests = []
    for hs in ('0', '1', '12345'):
        out = subprocess.run([sys.executable, '-c', code], capture_output=True, text=True,
                             timeout=29, env=dict(os.environ, PYTHONHASHSEED=hs))
        digests.append(out.stdout.strip() or out.stderr.strip()[-200:])
    store.data['hashseed_digests'] = digests
    store.data['hashseed_independent'] = len(set(digests)) == 1 and len(digests[0]) == 64
    print('E0 selfcheck runs', sum(r.get('runs', 0) for r in res),
          'failed tasks', sum(1 for r in res if r.get('kind') != 'selfcheck'),
          'hashseed independent', store.data['hashseed_independent'], flush=True)
    for r in res:
        if r.get('kind') != 'selfcheck':
            print('  FAILED', r.get('result'), r.get('error'), r.get('traceback'), flush=True)


def e2b(store, workers, quick):
    """Supplement to E2: DAG-aware greedy orders computed in resumable chunks."""
    sizes = [16, 24, 32, 40, 48, 56, 64, 72, 80, 88, 96, 104, 112, 120, 136, 152]
    occ = [8, 12, 16, 24, 32, 48, 64]
    if quick:
        sizes, occ = sizes[:2], occ[:2]
    for fixed in (dict(planted=True, extra=0), dict(planted=False, extra=5)):
        run_grid(store, 'E2', 'xor3', fixed, 'n', sizes, [{}], [1, 2, 3], ['greedy_min'], workers)
    run_grid(store, 'E2', 'xor_two_occ', dict(k=4), 'm_eq', occ,
             [dict(sat=True), dict(sat=False)], [1, 2], ['greedy_min', 'greedy_max'], workers)


def e5b(store, workers, quick):
    """Supplement to E5: depth-first order on the 2-CNF expander families (added after
    seeing that primal-graph treewidth heuristics are the WORST orders there)."""
    geo = [10, 14, 20, 28, 40, 56, 80, 112, 160, 224, 320]
    if quick:
        geo = geo[:3]
    for d in (3, 4, 5):
        for mode in ('rand', 'planted', 'impl'):
            if d == 5 and mode == 'rand':
                continue
            run_grid(store, 'E5', 'regular_2cnf', dict(d=d, mode=mode), 'nv', geo, [{}],
                     [1, 2, 3] if d < 5 else [1, 2], ['dfs'], workers)
    for dn, facts, goals in ((2.0, 0, 0), (3.0, 0, 0), (4.0, 0, 0), (3.0, 0.1, 0.2)):
        run_grid(store, 'E5', 'random_horn3', dict(density=dn, facts=facts, goals=goals), 'n',
                 [12, 16, 20, 24, 28, 32, 36, 40, 48, 56, 64, 80], [{}], [1, 2, 3], ['dfs'],
                 workers)


def e7b(store, workers, quick):
    """Support-multiplicity census (mechanism test for H-TSEITIN vs the others)."""
    tasks = []

    def add(family, p, labels):
        for label in labels:
            spec = label
            if label.startswith('shuffle'):
                spec = shuffle_spec('E7b', family, sorted(p.items()), label)
            tasks.append(dict(kind='support', exp='E7b', family=family, params=p, order=label,
                              order_spec=spec))
    ts = ['natural', 'min_degree', 'max_degree', 'bfs', 'tree_first_bfs', 'shuffle00', 'shuffle01']
    gen = ['natural', 'min_degree', 'min_fill', 'shuffle00', 'shuffle01']
    for d, nvs in ((3, (8, 16, 32, 64, 96)), (4, (8, 16, 32, 48)), (5, (8, 16, 24, 32))):
        for nv in (nvs[:2] if quick else nvs):
            add('tseitin_regular', dict(nv=nv, d=d, seed=1, sat=False), ts)
    for m_eq in ((8, 16) if quick else (8, 16, 32, 64)):
        add('xor_two_occ', dict(m_eq=m_eq, k=4, seed=1, sat=False), gen)
    for n in ((16, 24) if quick else (16, 24, 32, 40, 48, 56)):
        add('xor3', dict(n=n, extra=0, planted=True, seed=1), gen)
    for h in ((3, 4) if quick else (3, 4, 5, 6, 7)):
        add('php', dict(h=h), ['pigeon_major', 'hole_major', 'min_degree', 'min_fill', 'shuffle00'])
    for n in ((16, 20) if quick else (16, 20, 24, 28, 32)):
        add('kcnf', dict(density=4.26, k=3, n=n, seed=1), gen)
    for nv in ((20, 28) if quick else (20, 28, 40, 56, 80)):
        add('regular_2cnf', dict(nv=nv, d=4, seed=1, mode='planted'), gen + ['bfs'])
    res = H.run_tasks(do_task, tasks, workers=workers, label='E7b')
    for t, r in zip(tasks, res):
        if r.get('kind') != 'support':
            r = dict(kind='support', exp='E7b', family=t['family'], params=t['params'],
                     order=t['order'], **{k: v for k, v in r.items() if k != 'task'})
        store.data.setdefault('support', []).append({k: v for k, v in r.items() if k != 'task'})
    store.flush()
    for r in store.data['support']:
        print('E7b', r['family'], r['params'], r['order'], r.get('result'), 'alloc', r.get('alloc'),
              'max nodes/support', r.get('max_nodes_per_support'), flush=True)


def e7c(store, workers, quick):
    """Extension of E7b to larger sizes for the orders that matter most:
    3-XOR under its BEST orders, Tseitin under its WORST orders, PHP structured orders."""
    tasks = []

    def add(family, p, labels):
        for label in labels:
            tasks.append(dict(kind='support', exp='E7c', family=family, params=p, order=label,
                              order_spec=label))
    for seed in ((1,) if quick else (1, 2, 3)):
        for n in ((16, 24) if quick else (16, 24, 32, 40, 48, 56, 64, 72, 80, 88, 96, 104, 112)):
            add('xor3', dict(n=n, extra=0, planted=True, seed=seed), ['min_degree', 'min_fill'])
    for nv in ((8, 16) if quick else (8, 16, 32, 64, 96, 128, 160)):
        add('tseitin_regular', dict(nv=nv, d=3, seed=2, sat=False),
            ['min_degree', 'max_degree', 'bfs', 'tree_first_bfs'])
    for h in ((3, 4) if quick else (3, 4, 5, 6, 7, 8, 9)):
        add('php', dict(h=h), ['hole_major', 'pigeon_major'])
    res = H.run_tasks(do_task, tasks, workers=workers, label='E7c')
    for t, r in zip(tasks, res):
        if r.get('kind') != 'support':
            r = dict(kind='support', exp='E7c', family=t['family'], params=t['params'],
                     order=t['order'], **{k: v for k, v in r.items() if k != 'task'})
        store.data.setdefault('support', []).append({k: v for k, v in r.items() if k != 'task'})
    store.flush()
    print('E7c:', sum(1 for r in store.data['support'] if r.get('result') in ('SAT', 'UNSAT')),
          'of', len(tasks), 'completed', flush=True)


def e3b(store, workers, quick):
    """Supplement to E3: DAG-aware greedy orders computed in resumable chunks."""
    hs = list(range(2, 6 if quick else 11))
    run_grid(store, 'E3', 'php', dict(), 'h', hs, [{}], [None], ['greedy_min', 'greedy_max'],
             workers)


EXPERIMENTS = dict(E0=e0, E1=e1, E2=e2, E2b=e2b, E3=e3, E3b=e3b, E4=e4, E5=e5, E5b=e5b, E6=e6,
                   E7=e7, E7b=e7b, E7c=e7c, E8=e8)


SIZE_KEYS = dict(tseitin_regular='nv', tseitin_torus='a', tseitin_complete='m', xor3='n',
                 xor_two_occ='m_eq', php='h', kcnf='n', subsume='k', rand2cnf='n',
                 regular_2cnf='nv', grid_2cnf='a', implication_grid='a', ladder_2cnf='k',
                 bipartite_implication='k', subsume_2cnf='k', random_horn3='n', horn_grid='a',
                 subsume_horn='k')


def fill_holes(name, workers):
    """Re-run time-capped runs that are 'holes': the same series (family, fixed
    params, order group, dag) has a completed run at the same or a larger size, so
    the cap was caused by machine load, not by growth.  Results go to
    results/<name>.retry.json; analyze.py lets a completed record win."""
    files = sorted(RESULTS.glob(f'{name}.json')) + sorted(RESULTS.glob(f'{name}.*.json')) + \
        sorted(RESULTS.glob(f'{name}b.json'))
    runs = []
    for f in files:
        if f.name.endswith('.retry.json'):
            continue
        try:
            runs += json.loads(f.read_text()).get('runs', [])
        except Exception as e:
            print('cannot read', f, e)

    def series(r):
        sk = SIZE_KEYS.get(r.get('family'))
        fixed = {k: v for k, v in (r.get('params') or {}).items() if k not in (sk, 'seed', 'sat')}
        return (r.get('family'), json.dumps(fixed, sort_keys=True), order_group(r.get('order') or ''),
                r.get('dag') or 'original'), (r.get('params') or {}).get(sk)

    best = {}
    done_keys = set()
    for r in runs:
        s, size = series(r)
        key = json.dumps([r.get('family'), r.get('params'), r.get('order'),
                          r.get('dag') or 'original'], sort_keys=True)
        if r.get('result') in ('SAT', 'UNSAT'):
            done_keys.add(key)
            if size is not None and (s not in best or size > best[s]):
                best[s] = size
    tasks, seen = [], set()
    for r in runs:
        if r.get('result') not in ('CAP', 'ORDER_TIMEOUT'):
            continue
        if r.get('result') == 'CAP' and r.get('cap_reason') not in ('time', 'alarm', 'task_alarm',
                                                                    'hard_kill'):
            continue
        s, size = series(r)
        key = json.dumps([r.get('family'), r.get('params'), r.get('order'),
                          r.get('dag') or 'original'], sort_keys=True)
        if key in done_keys or key in seen or size is None or s not in best or size > best[s]:
            continue
        if r.get('order_spec') is None:
            continue
        seen.add(key)
        t = dict(kind='run', exp=r.get('exp') or name, family=r['family'], params=r['params'],
                 order=r['order'], order_spec=r['order_spec'])
        if r.get('dag') not in (None, 'original'):
            t['dag'] = r['dag']
        if r.get('family') == 'kcnf' and r.get('expected_source'):
            t['expected'], t['expected_source'] = r.get('expected'), r['expected_source']
        tasks.append(t)
    print(f'{name}: {len(tasks)} load-induced holes to re-run', flush=True)
    if not tasks:
        return
    store = Store(name, False, sys.argv, 'retry')
    res = execute(store, tasks, workers, f'{name} holes')
    store.flush(final=True)
    print(f'{name}: filled {sum(1 for r in res if r.get("result") in ("SAT", "UNSAT"))} of '
          f'{len(tasks)} holes -> {store.path}', flush=True)


def main():
    if len(sys.argv) > 2 and sys.argv[1] == 'HOLES':
        oracle_exhaustive(1, [[1]])
        w = int(os.environ.get('WORKERS', '6'))
        for name in sys.argv[2:]:
            fill_holes(name, w)
        return
    ap = argparse.ArgumentParser()
    ap.add_argument('experiments', nargs='+')
    ap.add_argument('--workers', type=int, default=5)
    ap.add_argument('--quick', action='store_true')
    ap.add_argument('--tag', default='', help='write results/<EXP>.<tag>.json (partial reruns)')
    args = ap.parse_args()
    names = list(EXPERIMENTS) if 'all' in args.experiments else args.experiments
    oracle_exhaustive(1, [[1]])             # import adversarial/oracle.py before forking
    for name in names:
        t0 = time.time()
        store = Store(name, args.quick, sys.argv, args.tag)
        try:
            EXPERIMENTS[name](store, args.workers, args.quick)
        finally:
            store.flush(final=True)
        print(f'{name} finished in {time.time() - t0:.0f}s -> {store.path}', flush=True)


if __name__ == '__main__':
    main()
