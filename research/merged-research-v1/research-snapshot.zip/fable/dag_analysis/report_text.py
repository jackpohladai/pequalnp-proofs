"""Narrative of REPORT.md.

Every number that is quoted in running text is either (a) read from
results/summary.json at build time (so it cannot drift from the tables), or
(b) an exact count that is also visible in a table reproduced below it.
"""
import json
import statistics
from pathlib import Path

HERE = Path(__file__).resolve().parent
S = json.loads((HERE / 'results' / 'summary.json').read_text())


def f2(x, nd=2):
    return '-' if x is None else f'{x:.{nd}f}'


def series(root, min_points=4):
    """[(key, describe_series dict)] with at least min_points fully completed sizes."""
    return [(k, v) for k, v in root.items()
            if isinstance(v, dict) and v.get('fit_vs_n', {}).get('points', 0) >= min_points]


def stats_block(root, prefix, use='fit_vs_n'):
    rows = [(k, v) for k, v in series(root) if k.startswith(prefix)]
    if not rows:
        return None
    fits = [(k, v[use]) for k, v in rows if v[use].get('power_exponent') is not None]
    if not fits:
        return None
    power = sum(1 for _, f in fits if f.get('better_fit') == 'power')
    bmax = max(fits, key=lambda kf: kf[1]['power_exponent'])
    tails = [(k, f) for k, f in fits if f.get('tail_power_exponent') is not None]
    tmax = max(tails, key=lambda kf: kf[1]['tail_power_exponent']) if tails else None
    rates = [f['exp_rate_bits'] for _, f in fits if f.get('exp_rate_bits') is not None]
    return dict(n=len(fits), power=power, bmax=bmax[1]['power_exponent'], bmax_key=bmax[0],
                tmax=tmax[1]['tail_power_exponent'] if tmax else None,
                tmax_key=tmax[0] if tmax else None,
                rate_min=min(rates), rate_max=max(rates),
                largest_n=max(v['largest_complete_n'] for _, v in rows))


def order_of(key):
    return key.rsplit(' ', 1)[-1]


def rate_list(root, prefix, orders):
    out = []
    for o in orders:
        v = root.get(f'{prefix} {o}')
        if not v:
            continue
        f = v['fit_vs_n']
        if f.get('exp_rate_bits') is None:
            continue
        out.append(f"{o}: {f['exp_rate_bits']:.3f} bits/var up to n={v['largest_complete_n']:.0f} "
                   f"(tail {f2(f.get('tail_exp_rate_bits'), 3)}; power-law exponent "
                   f"{f2(f.get('power_exponent'))}, tail {f2(f.get('tail_power_exponent'))}; "
                   f"R2 exp {f2(f.get('exp_r2'), 3)} vs pow {f2(f.get('power_r2'), 3)})")
    return out


def build(sec, pick):
    out = []
    A = out.append
    meta = S.get('E0', {})
    e1f = S.get('E1_fits', {})
    e2f = S.get('E2_fits', {})
    e4f = S.get('E4_3cnf', {}).get('fits', {})
    e5 = S.get('E5', {})
    e5f = e5.get('fits', {})
    e3 = S.get('E3_php', {})
    e8 = S.get('E8', {})

    def ag(name):
        a = S.get(name, {}).get('agreement')
        if not a:
            return 'n/a'
        return (f"{a['runs']} runs, {a['completed']} completed, {a['verified']} checked against an "
                f"independent answer, **{a['disagreements']} disagreements**, {a['capped']} capped")

    # ------------------------------------------------------------------ header
    A('# L-alg-001 / Brief A - decisive structural tests of `native-search/residual_dag.py`')
    A('Author: research subagent A (experimentalist). Everything below is a finite, empirical '
      'measurement. Fitted growth rates describe the measured range only; nothing here proves an '
      'asymptotic bound and nothing here bears on P vs NP beyond "this candidate, as written, '
      'is not a polynomial-time SAT decider on the families below".')
    A(f"Candidate under test: `work/alg001/native-search/residual_dag.py`, imported read-only, "
      f"SHA-256 `{meta.get('candidate_sha256', '?')}` (identical to the hash in "
      f"`adversarial/residual-dag-review.txt`). The measured loop is exactly "
      f"`root = d.cnf(clauses); for v in order: root = d.forget(root, v)`; answer = `root == 1`.")

    # ------------------------------------------------------------------ verdicts
    A('## 0. Verdicts at a glance')
    A(VERDICTS())

    # ------------------------------------------------------------------ method
    A('## 1. Method')
    A(METHOD)

    # ------------------------------------------------------------------ E0
    A('## 2. E0 - sanity of the harness')
    A(f"`python3 run_experiments.py E0`: {meta.get('selfcheck_runs', '?')} runs on random small "
      f"instances of six families under seven orders each: (i) the capped subclass used for all "
      f"measurements allocates exactly the same nodes, child references, cofactor-cache entries "
      f"and factor steps as the plain `residual_dag.DAG`; (ii) every candidate answer equals the "
      f"exhaustive oracle `adversarial/oracle.py`; (iii) my verifiers (GF(2), 2-SAT SCC, Horn unit "
      f"propagation, DPLL) equal the oracle; (iv) allocation counts are identical under "
      f"`PYTHONHASHSEED` 0, 1 and 12345 (hash-seed independent: "
      f"{meta.get('hashseed_independent')}). Failed tasks: {meta.get('failed_tasks', '?')}.")

    # ------------------------------------------------------------------ E1
    A('## 3. E1 - Tseitin formulas (H-TSEITIN)')
    A(E1_TEXT())
    b = sec.get('E1', [])
    A(pick(b, '**tseitin_regular {"d": 3}: allocated', '**tseitin_regular {"d": 4}: allocated',
           '**tseitin_regular {"d": 5}: allocated', '**tseitin_torus', '**tseitin_complete'))
    A('Fits per order (log-log slope b of allocated nodes vs n = number of edge variables, and vs '
      'the encoded input size N; exponential rate shown for contrast):')
    A(pick(b, '**tseitin_regular {"d": 3}** (x', '**tseitin_regular {"d": 4}** (x',
           '**tseitin_regular {"d": 5}** (x', '**tseitin_torus {}** (x', '**tseitin_complete {}** (x'))
    A(pick(b, '**Worst completed standard order'))
    A('Trying to break it (exhaustive / sampled orders on tiny graphs, then hill-climbing for the '
      'worst order):')
    A(pick(b, '**Distribution of allocated nodes over orders'))
    A(pick(b, '**Adversarial search for the WORST order'))
    A(pick(b, '| family | (n, max alloc found)'))
    A(E7B_TEXT)
    b7 = sec.get('E7b', [])
    tab = [blk for blk in b7 if blk.startswith('| family | order | size')]
    if tab:
        lines = tab[0].split('\n')
        want = (('Tseitin d=3', None), ('Tseitin d=5', 'max_degree'), ('4-XOR', 'natural'),
                ('4-XOR', 'min_degree'), ('3-XOR', None), ('PHP', None),
                ('random 3-CNF', 'natural'), ('2-CNF', 'bfs'))
        keep = lines[:2]
        for l in lines[2:]:
            cells = [c.strip() for c in l.strip('|').split('|')]
            if any(cells[0].startswith(f) and (o is None or cells[1] == o) for f, o in want):
                keep.append(l)
        A('\n'.join(keep))
    A(E7B_READING)

    # ------------------------------------------------------------------ E2
    A('## 4. E2 - XOR systems (H-XOR3)')
    A(E2_TEXT())
    b = sec.get('E2', [])
    A(pick(b, '**xor3 {"extra": 0, "planted": true}: allocated', '**xor3 {"extra": 0, "planted": true}: 20',
           '**xor3 {"extra": 5, "planted": false}: allocated', '**xor3 {"extra": 5, "planted": false}: 20'))
    A(pick(b, '**xor3 {"extra": 0, "planted": true}** (x', '**xor3 {"extra": 5, "planted": false}** (x'))
    A('4-XOR with every variable in exactly two equations (Tseitin on a 4-regular multigraph):')
    A(pick(b, '**xor_two_occ {"k": 4}: allocated', '**xor_two_occ {"k": 4}** (x'))

    # ------------------------------------------------------------------ E3
    A('## 5. E3 - pigeonhole PHP(h+1, h) (H-PHP)')
    A(E3_TEXT())
    b = sec.get('E3', [])
    A('\n\n'.join(b[1:]) if len(b) > 1 else '(no data)')

    # ------------------------------------------------------------------ E4
    A('## 6. E4 - random 3-CNF (H-3CNF)')
    A(E4_TEXT())
    b = sec.get('E4', [])
    A(pick(b, '**kcnf {"density": 2.0, "k": 3} fits', '**kcnf {"density": 3.0, "k": 3} fits',
           '**kcnf {"density": 4.26, "k": 3} fits'))
    A(pick(b, '**kcnf {"density": 2.0, "k": 3}: allocated', '**kcnf {"density": 3.0, "k": 3}: allocated',
           '**kcnf {"density": 4.26, "k": 3}: allocated'))
    A(pick(b, '**kcnf {"density": 2.0, "k": 3}: random', '**kcnf {"density": 3.0, "k": 3}: random',
           '**kcnf {"density": 4.26, "k": 3}: random'))

    # ------------------------------------------------------------------ E5
    A('## 7. E5 - 2-SAT / Horn hunt (H-2SAT)')
    A(E5_TEXT())
    b = sec.get('E5', [])
    A(pick(b, '**E5 overview'))
    A(pick(b, '**Induced width of the order vs allocated nodes'))
    A('Selected size tables (all others are in `results/tables.md`):')
    A(pick(b, '**regular_2cnf {"d": 4, "mode": "planted"}: allocated',
           '**regular_2cnf {"d": 4, "mode": "impl"}: allocated',
           '**regular_2cnf {"d": 5, "mode": "impl"}: allocated',
           '**regular_2cnf {"d": 3, "mode": "rand"}: allocated',
           '**random_horn3 {"density": 3.0, "facts": 0, "goals": 0}: allocated',
           '**random_horn3 {"density": 3.0, "facts": 0.1, "goals": 0.2}: allocated',
           '**subsume_2cnf', '**subsume_horn'))

    # ------------------------------------------------------------------ E6
    A('## 8. E6 - the subsumption blocker G_k (H-SUBSUME)')
    A(E6_TEXT)
    b = sec.get('E6', [])
    A('\n\n'.join(b) if b else '(no data)')

    # ------------------------------------------------------------------ E7
    A('## 9. E7 - semantic census')
    A(E7_TEXT)
    b = sec.get('E7', [])
    A(pick(b, '**Per family: distinct functions'))
    rows = [blk for blk in b if blk.startswith('| family | params | order')]
    if rows:
        lines = rows[0].split('\n')
        keep = lines[:2] + [l for l in lines[2:] if '| subsume |' in l or '| php | {"h": 4}' in l
                            or ('tseitin_regular' in l and '"nv": 10' in l and '"sat": false' in l)
                            or ('| xor3 |' in l and '"n": 16' in l and '"seed": 1' in l and '"extra": 0' in l)
                            or ('| kcnf |' in l and '"n": 16' in l and '"seed": 1' in l)]
        A('Selected census rows (all rows: `results/tables.md`):')
        A('\n'.join(keep))

    # ------------------------------------------------------------------ E8
    A('## 10. E8 - repaired subclass (`repaired_dag.py`)')
    A(E8_TEXT())
    b = sec.get('E8', [])
    A(pick(b, 'Validation against brute force'))
    A(pick(b, '| series | common range'))
    b6 = sec.get('E8/E6', [])
    if b6:
        A('G_k under the repaired class:')
        A('\n\n'.join(b6))
    b3 = sec.get('E8/E3', [])
    if b3:
        A('PHP under the repaired class:')
        A('\n\n'.join(b3[1:3]))

    # ------------------------------------------------------------------ falsification
    A('## 11. What would falsify the lead\'s hypotheses, and what I found against them')
    A(FALSIFY())

    A('## 12. Caveats')
    A(CAVEATS())

    A('## 13. Reproduction')
    A(REPRO)

    A('## 14. Files')
    A(FILES)
    return '\n\n'.join(x for x in out if x) + '\n'


# ============================================================================
# text blocks
# ============================================================================
METHOD = '''**Harness.** `harness.py` subclasses the candidate only to abort a run from inside `put()`
(node cap 400000, soft wall-clock cap 25 s, memory cap 480 MB peak RSS); it calls the original
`put` and overrides nothing else (checked in E0). Every run is its own forked process with a
SIGALRM backstop at 27.5 s and a parent hard kill at 29.5 s; sub-millisecond instances are run in
batches of <= 16 s. The cyclic garbage collector is switched off in the workers (the DAG has no
reference cycles; this changes speed only). For every run the JSON records family, parameters,
seed, order, result, `len(d.nodes)` (allocated), stored child references, `len(d.cofactor_cache)`,
`d.factor_steps`, peak reachable nodes (sampled; `reach_exact` says whether every step was
sampled), wall and CPU seconds, the induced width of the order on the primal graph, and
N = sum over literals of (4 + 2*bitlen(var)) + 2 per clause.

**Result vocabulary.** SAT / UNSAT = the candidate's answer after eliminating every variable.
CAP = stopped by a resource cap (`cap_reason` = nodes / time / memory / alarm / hard_kill);
ORDER_TIMEOUT = the order itself could not be computed in its budget. CAP and ORDER_TIMEOUT are
never counted as refutations or as lower bounds; a CAP only says "at least this many nodes had
been allocated when the run was stopped".

**Independent expected answers** (`verify.py`, never importing the candidate): Tseitin = parity of
the total charge of each connected component, cross-checked by Gaussian elimination over GF(2)
with the solution verified against the clauses; XOR systems = GF(2) elimination; PHP = pigeonhole
principle; 2-CNF = implication-graph SCC; Horn = unit propagation to the least model; random 3-CNF
= `adversarial/oracle.py` (exhaustive) for n <= 20, cross-checked with my own complete DPLL, and
that DPLL alone for n > 20 (labelled as such). Every SAT answer used as "expected" has a witness
checked against the original clauses.

**Orders** (`orders.py`, all deterministic): `natural`, `reverse`, `shuffleNN` (seeded), `min_degree`
and `min_fill` and `max_degree` (greedy on the primal graph, updated as in bucket elimination, ties
to the smallest index), `bfs` and `dfs` from variable 1, `pigeon_major` / `hole_major` (PHP),
`scc_topo` / `scc_topo_rev` (2-CNF: topological order of the implication-graph SCCs),
`tree_first` / `tree_first_bfs` (Tseitin: a spanning caterpillar first, chords last - an adversarial
order designed from the lead's own mechanism), and two **DAG-aware** orders `greedy_min` /
`greedy_max` (`harness.greedy_extend`): at each step every candidate variable (all of them when
<= 24 remain, otherwise a seeded sample of 12) is forgotten on trial, the newly allocated nodes are
counted, the trial is undone exactly, and the candidate with the fewest / most new nodes is
committed. Greedy orders are computed in resumable chunks of <= 16 s (max 6 chunks); the measured
run is then an ordinary single run with that order.

**Fits** (`analyze.py`). Power law ln(alloc) = a + b ln(x) and exponential log2(alloc) = c + r x by
least squares, on the geometric mean over instances, **using only sizes at which every run of the
series completed** (otherwise survivors would bias the mean downwards). "tail" = the same fit on
the last four sizes. "better fit" = larger R^2. A series is no longer scheduled at larger sizes
once fewer than 25-40% of its runs complete at a size.

**Machine load (important).** The host was massively oversubscribed during the whole study (8
cores, load average 130 at the start, 300-550 for most of it; wall/CPU ratio measured at 3-14x).
Because the 30 s limit is a wall-clock limit, a "25 s" run received only about 1-6 CPU-seconds.
Consequences: (1) the node cap of 400000 was almost never the binding cap - `time` was; (2) the
largest completed sizes are smaller than on an idle machine and depend on the load at that
moment; (3) some runs at moderate sizes were lost to load spikes (visible as a size with e.g. 3/4
completed, followed by a larger size that is complete) - `run_experiments.py HOLES <EXP>` re-runs
exactly those; (4) the host also intermittently refused file writes (EPERM) under load; the result
store retries. Node counts of completed runs are deterministic and unaffected.'''


def VERDICTS():
    rows = []
    # H-TSEITIN
    e1f = S.get('E1_fits', {})
    reg = stats_block(e1f, 'tseitin_regular')
    tor = stats_block(e1f, 'tseitin_torus')
    comN = stats_block(e1f, 'tseitin_complete', use='fit_vs_N')
    adv = S.get('E1', {}).get('adversarial_fit', {})
    txt = 'no data'
    if reg:
        txt = (f"random d-regular graphs, d=3,4,5, n up to {reg['largest_n']:.0f} edges: "
               f"{reg['power']}/{reg['n']} (order x degree) series are better fit by a power law; "
               f"largest fitted exponent b = {reg['bmax']:.2f} ({order_of(reg['bmax_key'])}), largest "
               f"last-4-sizes exponent {f2(reg['tmax'])} ({order_of(reg['tmax_key']) if reg['tmax_key'] else '-'}). ")
        if tor:
            txt += f"Torus: max b = {tor['bmax']:.2f}. "
        if comN:
            txt += f"K_m (degree grows): max exponent vs input bits N = {comN['bmax']:.2f}. "
        a3 = adv.get('tseitin_regular d=3', {}).get('fit', {})
        if a3:
            txt += (f"Hill-climbed worst orders (d=3, n=12..72): exponent {a3.get('power_exponent')}, "
                    f"R2 pow {a3.get('power_r2')} vs exp {a3.get('exp_r2')}. ")
        txt += ("Exhaustive over all 720 / 40320 orders of K4 / W4: max/min = 89/78 and 158/118. "
                "No order with super-polynomial-looking growth was found.")
    rows.append(['H-TSEITIN', '**supported**', txt])
    # H-XOR3
    e2f = S.get('E2_fits', {})
    px = 'xor3 {"extra": 0, "planted": true}'
    rx = 'xor3 {"extra": 5, "planted": false}'
    cells = []
    for name, pfx in (('m=n planted', px), ('m=n+5 random rhs', rx)):
        part = []
        for o in ('natural', 'shuffle', 'min_degree', 'min_fill', 'greedy_min'):
            v = e2f.get(f'{pfx} {o}')
            if v and v['fit_vs_n'].get('exp_rate_bits') is not None:
                f = v['fit_vs_n']
                part.append(f"{o} {f['exp_rate_bits']:.3f} (n<={v['largest_complete_n']:.0f}, "
                            f"{f.get('better_fit')})")
        cells.append(f"{name}: " + ', '.join(part))
    occ = stats_block(e2f, 'xor_two_occ')
    txt = 'Exponential rate in bits/variable - ' + '; '.join(cells) + '. '
    if occ:
        txt += (f"Control: 4-XOR with every variable in exactly 2 equations is polynomial-looking "
                f"({occ['power']}/{occ['n']} series power-law, max b = {occ['bmax']:.2f}).")
    rows.append(['H-XOR3', '**supported** (weaker evidence for the best orders, see sec. 4)', txt])
    # H-PHP
    g = S.get('E3_php', {}).get('growth', {})
    txt = 'no data'
    if g:
        hm, pm, mn = g.get('hole_major'), g.get('pigeon_major'), g.get('MIN_over_all_tried')
        txt = (f"alloc(h+1)/alloc(h): hole-major {hm['ratios']} (h={hm['points'][0][0]}..{hm['points'][-1][0]}), "
               f"pigeon-major {pm['ratios']}, minimum over every order tried {mn['ratios']} "
               f"(never below {min(mn['ratios'])}). In the number of variables n = h(h+1) this is "
               f"2^Theta(sqrt n) for the best orders (hole-major fits c*h^2*2^h), i.e. super-polynomial "
               f"but sub-exponential in n; random orders grow much faster "
               f"(median ratio {g.get('random_median', {}).get('ratios')}). Exhaustive: all 720 orders "
               f"of PHP(3,2) give 45..50 nodes, all 40320 orders of PHP(4,2) give 59..82.")
    rows.append(['H-PHP', '**supported** in h; note the refinement about n', txt])
    # H-3CNF
    e4f = S.get('E4_3cnf', {}).get('fits', {})
    st = stats_block(e4f, 'kcnf')
    txt = 'no data'
    if st:
        exp_better = st['n'] - st['power']
        txt = (f"{exp_better}/{st['n']} (density x order) series are better fit by an exponential; "
               f"rates {st['rate_min']:.2f}..{st['rate_max']:.2f} bits/variable; even the best order "
               f"(min-degree / min-fill / DAG-aware greedy) at density 2.0, far below the threshold, "
               f"has rate about 0.2. " + ag_static('E4_3cnf'))
    rows.append(['H-3CNF', '**supported**', txt])
    # H-2SAT
    rows.append(['H-2SAT', H2SAT_VERDICT()[0], H2SAT_VERDICT()[1]])
    # H-SUBSUME
    rows.append(['H-SUBSUME', '**supported, with a corrected constant**',
                 'order x, a_1..a_k: the largest OR node has exactly 2^(k-1)+2 children (not 2^k+O(1)) '
                 'and 2^(k+1)+6k+3 nodes are allocated, for every k = 2..14 (k=14: 8194 children, 32855 '
                 'nodes); order a_1..a_k, x: 6k+7 nodes, largest OR arity 3.'])
    # E7
    pf = S.get('E7', {}).get('per_family') or []
    txt = ('Merging semantically equal nodes would save little: distinct functions / reachable nodes '
           'at the peak step has median ' +
           ', '.join(f"{r[0]} {r[3]}" for r in pf) +
           '. Over ALL allocated and/or nodes (n <= 16) the median ratio is ' +
           ', '.join(f"{r[0]} {r[7]}" for r in pf) +
           '. The waste in G_k is of a different kind (subsumed children: 2^(k-1)-1 of the '
           '2^(k-1)+2 children of one OR), invisible to equivalence merging.')
    rows.append(['E7 census', 'done', txt])
    # E8
    v = S.get('E8', {}).get('validation', {}).get('repaired', {})
    rc = S.get('E8', {}).get('rate_comparison') or []
    txt = (f"Repaired subclass validated at every elimination stage on {v.get('formulas', '?')} random "
           f"small CNFs ({v.get('stages', '?')} full truth-table comparisons, {v.get('failures', '?')} "
           f"failures). ")
    gk = [r for r in rc if r[0] == 'G_k x_then_a']
    if gk:
        txt += (f"G_k (order x, a..): {gk[0][2]} -> {gk[0][3]} nodes at k=14, rate {gk[0][4]} -> "
                f"{gk[0][5]} bits per k (exponential -> linear, 8k+7). ")
    php = [r for r in rc if r[0].startswith('PHP')]
    cnf = [r for r in rc if r[0].startswith('kcnf')]

    def delta(rs):
        ds = [float(r[5]) - float(r[4]) for r in rs if r[4] != '-' and r[5] != '-']
        return ds
    if php:
        d = delta(php)
        txt += (f"PHP: fitted rate changes by {min(d):+.3f}..{max(d):+.3f} bits per hole across "
                f"{len(d)} orders (rates essentially unchanged). ")
    if cnf:
        d = delta(cnf)
        txt += (f"Random 3-CNF: rate changes by {min(d):+.4f}..{max(d):+.4f} bits per variable across "
                f"{len(d)} (density, order) series (unchanged).")
    rows.append(['E8 repair', 'done (stretch)', txt])
    head = '| hypothesis | verdict | key numbers (all empirical, finite range) |\n|---|---|---|\n'
    return head + '\n'.join('| ' + ' | '.join(r) + ' |' for r in rows)


def ag_static(name):
    a = S.get(name, {}).get('agreement')
    if not a:
        return ''
    return (f"Answers: {a['completed']} completed runs, {a['verified']} checked, "
            f"{a['disagreements']} disagreements.")


def H2SAT_VERDICT():
    bo = S.get('E5', {}).get('best_order', {})
    if not bo:
        return 'no data', 'no data'
    two = {k: v for k, v in bo.items() if not k.startswith(('random_horn3', 'horn_grid', 'subsume_horn'))}
    horn = {k: v for k, v in bo.items() if k.startswith('random_horn3')}

    def gm(v):
        return v['per_order'].get('greedy_min', {})
    reg = {k: v for k, v in two.items() if k.startswith('regular_2cnf')}
    parts = []
    if reg:
        gb = [gm(v).get('power_exponent') for v in reg.values() if gm(v).get('power_exponent') is not None]
        md = [v['per_order'].get('min_degree', {}) for v in reg.values()]
        mdr = [m.get('exp_rate_bits') for m in md if m.get('exp_rate_bits') is not None]
        mdn = [m.get('largest_complete_n') for m in md if m.get('largest_complete_n')]
        parts.append(
            f"2-CNF on random d-regular graphs (d=3,4,5; random / planted / implication signs; "
            f"{len(reg)} variants): min-degree, min-fill, natural and random orders are "
            f"exponential-looking (min-degree rate {min(mdr):.2f}..{max(mdr):.2f} bits/var, capped by "
            f"n = {min(mdn):.0f}..{max(mdn):.0f}), **but the DAG-aware greedy_min order has power-law "
            f"exponent {min(gb):.2f}..{max(gb):.2f}** over its measured range" if gb and mdr else '')
    if horn:
        best_rates = []
        for k, v in horn.items():
            po = v['per_order']
            cands = [(o, d) for o, d in po.items() if d.get('exp_rate_bits') is not None and d.get('largest_complete_n')]
            if cands:
                o, d = min(cands, key=lambda od: od[1]['exp_rate_bits'])
                best_rates.append((k, o, d['exp_rate_bits'], d.get('better_fit'), d['largest_complete_n']))
        if best_rates:
            parts.append('random Horn 3-CNF (in P): slowest-growing order per variant - ' + '; '.join(
                f"{k.split(' ', 1)[1]}: {o} {r:.2f} bits/var ({bf}, n<={n:.0f})" for k, o, r, bf, n in best_rates))
    verdict = ('**2-CNF: no family is exponential under every order tried (a DAG-aware greedy order '
               'stays near-linear), but every standard fixed order is; Horn: see numbers**')
    return verdict, '. '.join(p for p in parts if p) + '. Details and the per-family table in sec. 7.'


def E1_TEXT():
    e1 = S.get('E1', {})
    a = e1.get('agreement', {})
    return f'''**Instances.** Tseitin formulas on (a) uniform random simple connected d-regular graphs,
d in {{3, 4, 5}} (pairing model with rejection), (b) the a x a torus, (c) K_m; for each graph a
satisfiable charge (even total) and an unsatisfiable one (odd total), charges random, two seeds.
Variable i = i-th edge in lexicographic order, so `natural` is a vertex-major order.
**Orders.** natural, reverse, min_degree, min_fill, max_degree, bfs, 5 shuffles, greedy_min and
greedy_max (up to ~100 variables), plus the designed adversarial orders tree_first / tree_first_bfs.
**Answers.** {a.get('runs', '?')} runs, {a.get('completed', '?')} completed, all {a.get('verified', '?')}
checked against charge parity + GF(2): **{a.get('disagreements', '?')} disagreements**. Non-completions:
{json.dumps(e1.get('cap_reasons', {}))} (all resource caps on the loaded machine, see sec. 12; the
binding resource for Tseitin is *time*, because the candidate re-traverses the whole reachable DAG
for both cofactors of every forgotten variable: `cofactor_cache` grows like n x reachable ~ n^2
while the node count stays far below the 400000 cap).

**Reading.** Allocation is polynomial-looking for every order tried, with exponent between about 1.2
(min-degree / min-fill / greedy_min) and about 1.9 (bfs, max_degree, tree_first_bfs). The exponential
model fits clearly worse in every regular-graph series (R^2 about 0.85-0.93 against 0.99+), and the
local log-log slopes do not drift upwards beyond 2. The worst order I could construct by reasoning
(tree_first_bfs: grow one component as a caterpillar, then eliminate the chords) and the worst
orders found by hill-climbing both stay below about 2.5 n^2 nodes; max/n^2 *decreases* with n in
the hill-climb table. This agrees with the lead's mechanism and with the counting it implies:
each forgotten edge re-creates O(1) nodes for every historical sub-component above its two
endpoints, at most O(nv) of them, giving O(n * nv) = O(n^2) nodes for bounded degree.
For K_m the degree grows with the instance, so the right yardstick is the input size N
(each vertex contributes 2^(m-2) clauses): the exponent against N is the one to read in that table.'''


E7B_TEXT = '''**Mechanism test (E7b / E7c, `results/E7b.json`, `results/E7c.json`).** After every forget step the
and/or nodes reachable from the root were grouped by (kind, set of variables mentioned) and the
largest group was recorded. If a merged component is determined by its remaining edges plus one
parity bit, groups must stay small; a trellis-like state space shows up as many different nodes on
one support. Selected rows (all rows in `results/tables.md`):'''


E7B_READING = '''For Tseitin the groups stay small: constant (10) under min-degree up to 128 vertices, and growing
sub-linearly in the number of vertices for the worst orders (several nested historical
sub-components can share one support) - never exponentially. The same holds for the 4-XOR control
in which every variable occurs twice. For 3-XOR with m = n the largest group grows by orders of
magnitude, **also under the best orders** (min-degree: 18 at n = 16, 7936 at n = 104), and many of
the values are powers of two or small multiples of them: that is the 2^(state dimension) family of
cosets the lead predicted. PHP under hole-major is the instructive third case: exactly 4 nodes per
support for every h, so the growth there is entirely in the *number of supports* (subsets of
pigeons), consistent with the lead's sum_j C(h+1, j) count.'''


def E2_TEXT():
    e2 = S.get('E2', {})
    a = e2.get('agreement', {})
    e2f = S.get('E2_fits', {})
    px = 'xor3 {"extra": 0, "planted": true}'
    rx = 'xor3 {"extra": 5, "planted": false}'
    lp = rate_list(e2f, px, ('natural', 'shuffle', 'min_degree', 'min_fill', 'greedy_min'))
    lr = rate_list(e2f, rx, ('natural', 'shuffle', 'min_degree', 'min_fill', 'greedy_min'))
    occ = stats_block(e2f, 'xor_two_occ')
    occ_txt = ''
    if occ:
        occ_txt = (f"{occ['power']}/{occ['n']} order series are better fit by a power law, fitted "
                   f"exponents up to {occ['bmax']:.2f} ({order_of(occ['bmax_key'])}), last-4-sizes "
                   f"exponent up to {f2(occ['tmax'])}, largest completed n = {occ['largest_n']:.0f} variables")
    return f'''**Instances.** Random 3-XOR systems, each equation on 3 distinct random variables, encoded with 4
clauses: (i) m = n equations with right-hand sides from a hidden assignment (always SAT), (ii) m = n+5
with uniformly random right-hand sides (expected answer by GF(2) elimination; almost always UNSAT);
three instances per size. Orders: natural, min_degree, min_fill, greedy_min, and 20 seeded shuffles
(two instances). Control family: 4-XOR systems in which every variable occurs in exactly two
equations (pairing model; parallel pairs allowed, no variable twice in one equation).
**Answers.** {a.get('runs', '?')} runs, {a.get('completed', '?')} completed, {a.get('verified', '?')} checked,
**{a.get('disagreements', '?')} disagreements**; non-completions {json.dumps(e2.get('cap_reasons', {}))}.

**Fitted exponential rates, m = n planted** (log2 allocated nodes per variable):

- ''' + '\n- '.join(lp or ['(no data)']) + '''

**m = n + 5, random right-hand sides:**

- ''' + '\n- '.join(lr or ['(no data)']) + f'''

**Reading.** natural and random orders are cleanly exponential. The heuristic orders (min-degree,
min-fill, DAG-aware greedy) are much better in absolute terms and their growth is irregular
(instance-to-instance noise with three instances per size), but they also accelerate: the
last-four-sizes power-law exponents are far above the whole-range ones, and the exponential model
has the higher R^2. I therefore read H-XOR3 as supported for every order tried, with the honest
qualification that for the best orders the measured range is short (the 30 s wall clock on a loaded
machine stops them near n = 110-150) and a polynomial of degree 6-9 cannot be excluded from these
data alone. The support-multiplicity census (sec. 3, last table) gives independent, mechanism-level
evidence: the number of distinct nodes on one support doubles every few variables for 3-XOR.

**Control (each variable in exactly two equations).** {occ_txt}. This is the polynomial behaviour
H-TSEITIN's mechanism predicts for a "Tseitin-like hypergraph", including on instances with
parallel hyper-edges.'''


def E3_TEXT():
    e3 = S.get('E3_php', {})
    a = e3.get('agreement', {})
    return f'''**Instances.** PHP(h+1, h) with variables x(i,k) = pigeon i in hole k (pigeon-major numbering), clauses
"every pigeon somewhere" and "no two pigeons in a hole" (no functional clauses). Expected answer:
UNSAT (pigeonhole principle). Orders: pigeon_major (= natural), hole_major, reverse, min_degree,
min_fill, max_degree, bfs, greedy_min, greedy_max, 200 seeded random orders per h (30 for h = 7),
a local search for the best order (h = 3..6), and **all** orders of PHP(3,2) and PHP(4,2).
**Answers.** {a.get('runs', '?')} single runs ({a.get('completed', '?')} completed) plus the batches:
**{a.get('disagreements', '?')} disagreements**; every one of the 720 + 40320 exhaustive runs answered UNSAT.

**Reading.**
1. In h every order tried grows by a factor >= 2.2 per extra hole. hole-major is the best
   structured order; its ratio decreases slowly (3.65, 2.89, ... 2.42 at h = 10) and alloc / 2^h has
   an almost constant second difference (about 2.6), i.e. alloc is fitted by c * h^2 * 2^h. pigeon-major
   behaves like c * h * 3^h (ratio 4.04 ... 3.41).
2. In the number of variables n = h(h+1) that is 2^Theta(sqrt n): the per-variable rate falls with n
   and the power-law exponent in n keeps rising (see the last column of the growth table). So the
   accurate statement is "super-polynomial, 2^Theta(sqrt n), for the best orders found", not
   "exponential in the input size". Random orders are far worse (their ratio itself grows with h).
3. The minimum over all orders tried (structured, 200 random, greedy, local search) is the last
   column of the first table. Local search improved on hole-major by 23-39% for h = 3..6 but did not
   change the growth pattern; for h >= 7 the minimum is hole-major itself (no search was affordable).
4. Exhaustive enumeration: PHP(3,2) 45..50 nodes (24 optimal orders, e.g. x(0,0), x(1,0), x(1,1),
   x(0,1), x(2,0), x(2,1)); PHP(4,2) 59..82 (576 optimal orders). pigeon-major gives 48 / 64 and
   hole-major 49 / 80 on these two, so neither structured order is optimal even at this size.'''


def E4_TEXT():
    e4 = S.get('E4_3cnf', {})
    a = e4.get('agreement', {})
    e4f = e4.get('fits', {})
    lines = []
    for dn in ('2.0', '3.0', '4.26'):
        pfx = f'kcnf {{"density": {dn}, "k": 3}}'
        part = []
        for o in ('natural', 'shuffle', 'min_degree', 'min_fill', 'greedy_min'):
            v = e4f.get(f'{pfx} {o}')
            if v and v['fit_vs_n'].get('exp_rate_bits') is not None:
                f = v['fit_vs_n']
                part.append(f"{o} {f['exp_rate_bits']:.3f} (n<={v['largest_complete_n']:.0f}, "
                            f"tail {f2(f.get('tail_exp_rate_bits'), 3)}, {f.get('better_fit')})")
        lines.append(f"density {dn}: " + '; '.join(part))
    return f'''**Instances.** Uniform random 3-CNF (3 distinct variables per clause, random signs), m = round(density * n),
densities 2.0, 3.0, 4.26; three instances per (density, n) for the structured orders (natural,
min_degree, min_fill, greedy_min) and 20 seeded shuffles on two instances.
**Answers.** {a.get('runs', '?')} runs, {a.get('completed', '?')} completed, {a.get('verified', '?')} checked,
**{a.get('disagreements', '?')} disagreements**. Sources of the expected answers for completed runs:
{json.dumps(e4.get('expected_sources', {}))} - i.e. the project oracle for n <= 20 and my own complete
DPLL (witness-checked for SAT) for larger n; no completed run is left unverified
({a.get('unverified', '?')} unverified).

**Fitted exponential rates (bits per variable):**

- ''' + '\n- '.join(lines) + '''

**Reading.** Every series accelerates on a log-log plot (tail power-law exponents 4-9) and is at
least as well described by an exponential. The rate is highest for natural / random orders
(about 0.3-0.36 bits per variable) and lowest for min-degree / min-fill / greedy_min (about
0.2-0.3); it does not vanish at density 2.0, far below the satisfiability threshold. At 4.26 about
half of the instances are UNSAT and the candidate must still eliminate most variables before the
root collapses to False, so UNSAT instances are not systematically cheaper.'''


def E5_TEXT():
    e5 = S.get('E5', {})
    a = e5.get('agreement', {})
    bo = e5.get('best_order', {})

    def line(k):
        v = bo.get(k)
        if not v:
            return None
        po = v['per_order']

        def c(o):
            d = po.get(o) or {}
            if not d.get('largest_complete_n'):
                return f'{o}: -'
            return (f"{o}: {d['alloc']} nodes at n={d['largest_complete_n']:.0f}, b={f2(d.get('power_exponent'))}"
                    f"/tail {f2(d.get('tail_power_exponent'))}, r={f2(d.get('exp_rate_bits'), 3)} ({d.get('better_fit')})")
        return f"`{k}` - " + '; '.join(c(o) for o in ('greedy_min', 'bfs', 'scc_topo', 'min_degree', 'min_fill', 'natural', 'shuffle') if o in po)
    two_keys = [k for k in sorted(bo) if k.startswith('regular_2cnf')]
    horn_keys = [k for k in sorted(bo) if k.startswith(('random_horn3',))]
    other_keys = [k for k in sorted(bo) if not k.startswith(('regular_2cnf', 'random_horn3'))]
    return f'''**Question.** Is there a family in P (2-CNF or Horn) on which the candidate is exponential under every
order tried? **Families** (all with independent answers from an SCC 2-SAT solver / Horn unit
propagation): random 2-CNF at densities 0.9, 1.0, 1.5; one 2-clause on every edge of a random
d-regular graph (d = 3, 4, 5) with random signs (`rand`), signs conditioned on a hidden model
(`planted`), or a randomly directed implication (`impl`, always satisfiable); the same on grids;
implication grids (monotone, with cycles, and an unsatisfiable chain); a ladder; dense bipartite
implication layers; my 2-CNF analogue of the subsumption blocker (`subsume_2cnf`); random definite
Horn 3-CNF at densities 2, 3, 4 (trivially satisfiable), the same with 0.1 n facts and 0.2 n goal
clauses; an AND-grid of Horn rules; and the Horn renaming of G_k (`subsume_horn`).
**Orders.** natural, reverse, min_degree, min_fill, max_degree, bfs, 3 shuffles, greedy_min, and for
2-CNF also scc_topo / scc_topo_rev.
**Answers.** {a.get('runs', '?')} runs, {a.get('completed', '?')} completed, {a.get('verified', '?')} checked,
**{a.get('disagreements', '?')} disagreements**; non-completions {json.dumps(e5.get('cap_reasons', {}))}.

**2-CNF on random regular graphs** (b = power-law exponent, r = exponential rate in bits/variable,
at the largest fully completed n):

- ''' + '\n- '.join(x for x in (line(k) for k in two_keys) if x) + '''

**Random Horn 3-CNF:**

- ''' + '\n- '.join(x for x in (line(k) for k in horn_keys) if x) + '''

**Other 2-CNF / Horn families:**

- ''' + '\n- '.join(x for x in (line(k) for k in other_keys) if x) + '''

''' + E5_READING()


def E5_READING():
    return '''**Reading.**
1. *2-CNF, standard orders: a P-class failure.* On 2-CNFs whose primal graph is a random regular
   graph, the natural order, random orders and - most strikingly - the classical treewidth
   heuristics min-degree and min-fill are exponential-looking and hit the caps by n of the order of
   80-160. These instances are decided in linear time by any 2-SAT algorithm. So the candidate
   *with any fixed standard elimination order* is not polynomial on 2-SAT.
2. *2-CNF, DAG-aware greedy order: no failure found.* The greedy_min order (choose the variable
   whose elimination allocates the fewest new nodes, sampling 12 candidates) stays near-linear on
   every 2-CNF family as far as I could compute it; its fitted exponents are listed above. I
   therefore did **not** find a 2-CNF family that is exponential under every order tried. The
   range of greedy_min is limited by the cost of computing the order (12 trial eliminations per
   step in <= 6 chunks of 16 s on a loaded machine), not by the size of the resulting run.
3. *Induced width is the wrong guide.* On these instances the orders with the smallest induced width
   (min-degree, min-fill) are among the worst, and greedy_min, whose induced width is about twice as
   large, is the best (table "Induced width of the order vs allocated nodes" below). The candidate's cost is not governed by
   the treewidth of the primal graph: what matters is how deep inside the nested OR/AND structure
   the variable being forgotten occurs, because every level above an occurrence is re-created for
   both cofactors.
4. *Order-specific blockers exist inside P.* `subsume_2cnf` (natural order) and `subsume_horn`
   (order x, a_1..a_k) reproduce the 2^k blow-up of G_k on a 2-CNF and on a Horn formula; other
   orders are linear on them.
5. *Horn.* See the per-variant lines above and the overview table: these are the numbers on which
   the Horn half of H-2SAT has to be judged.'''


E6_TEXT = '''G_k = {(x v a_i v b_i) : i = 1..k} + {(-x v c)}; x = 1, a_i = 1+i, b_i = 1+k+i, c = 2k+2. Orders:
`x_then_a` = x, a_1..a_k, b_1..b_k, c and `a_then_x` = a_1..a_k, x, b_1..b_k, c (plus reverse,
min_degree, min_fill for reference). All answers SAT (explicit witness checked).

Exact counts for k = 2..14 (table below): under `x_then_a` the largest OR node has **2^(k-1) + 2**
children (4, 6, 10, 18, ..., 8194), the number of allocated nodes is **2^(k+1) + 6k + 3**
(first differences 2^(k+1) + 6: 14, 22, 38, ..., 16390), and the peak reachable size is
2^(k-1) + k + 3 for k >= 5. Under `a_then_x` exactly **6k + 7** nodes are allocated and no OR node has
more than 3 children. The lead's prediction "2^k + O(1) children of one OR node" has the right
mechanism (no AND-subset subsumption once the alternative `c` blocks common-factor extraction) but
is off by a factor of two: when the last a_k is cofactored with a_k = 1 the conjunction becomes
empty, the OR collapses to True, and the 2^k-child node is never built; the largest node is the
a_k = 0 cofactor with 2^(k-1) conjunctions plus `c` plus one residual.'''


E7_TEXT = '''For every instance with at most 16 variables (and PHP(5,4) with 20) the truth table of every node
reachable from the root was computed after every forget step (Python ints as bitmasks over all
2^n assignments). Recorded per step: (a) reachable nodes, (b) semantically distinct functions among
them, the same restricted to and/or nodes, and - added by me - the number of child references that
are *semantically redundant inside their own node* (a child that can be dropped without changing
the node's function, scanning children left to right). For n <= 16 the same count was made over all
allocated nodes. As a by-product the root was compared with the exact existential projection of
the input at every step of every census: all equal (208 censuses), which is an additional
exactness check of the candidate.

Answer to "how much could ANY semantic canonical form save on the same node set?": very little by
merging equal functions. At the peak step the reachable nodes are almost all semantically distinct
(median ratio 1.000 for Tseitin, PHP, 3-XOR, 2-CNF and G_k; about 0.89 for random 3-CNF and Horn);
over all nodes ever allocated the median ratio is 0.69-0.96, i.e. a perfect semantic hash-consing
of the same nodes would save a factor of at most about 1.5 (2.2 in the single worst case). The
exponential families are exponential in the number of *distinct functions*. The G_k blow-up is a
different phenomenon: all 2^(k-1) conjunctions are different functions, but 2^(k-1) - 1 of them are
subsumed children of one OR node (column "max redundant child refs"); only a rule that minimises
a node, not one that merges equal nodes, removes them.'''


def E8_TEXT():
    return '''`repaired_dag.py` subclasses the candidate (the original file is untouched) and adds one rule in
`junction`, right after the original single-node absorption: among the children of the dual kind
keep only the inclusion-minimal child sets, i.e. OR(AND(X), AND(X u Y)) = AND(X) and
AND(OR(X), OR(X u Y)) = OR(X). Everything else is copied verbatim.
**Validation**: 2000 random small CNFs (1-8 variables, 1-16 clauses of width 0-4, including empty
clauses, duplicate literals and tautologies), random order, full truth-table equality of the root
with the exact projection at every elimination stage, plus an independent `evaluate`-based check
in the style of `residual_dag.check_random` on every tenth formula; the original class was put
through the same test.
**Reruns** of E6, E3 (same random orders as E3) and E4 (same shuffles as E4, 5 per instance) with
the repaired class; greedy orders are recomputed with the repaired class.

**Reading.** The rule does exactly what it was designed for - G_k under the bad order goes from
2^(k+1) + 6k + 3 to 8k + 7 nodes - and nothing else: on PHP and on random 3-CNF the node counts
change by a few percent and the fitted rates are unchanged within noise (table below; rates are
fitted on the sizes both classes completed). Subset subsumption is therefore not the reason for
the growth on those families, in agreement with the census (their nodes are distinct functions).'''


def FALSIFY():
    return '''What would falsify each hypothesis, and what the data say:

- **H-TSEITIN** would be falsified by a single order on a bounded-degree graph whose allocation is
  super-polynomial: local log-log slopes that keep increasing, or a support carrying exponentially
  many nodes. I looked for one with 13 generic orders, two designed adversarial orders, exhaustive
  enumeration on K4 and W4, 4000 random orders on four small cubic graphs, and hill-climbing on 15
  instances. Nothing: every regular-graph series is better fit by a power law with exponent <= 2,
  and the hill-climbed maxima divided by n^2 decrease. Two refinements of the lead's statement:
  (i) "observed about n^1.5" is order-dependent - min-degree / min-fill give about n^1.2, bfs /
  max-degree / tree-first about n^1.9, so the n^2 prediction is essentially attained;
  (ii) the *work* is worse than the node count: cofactor-cache entries (and time and memory) grow
  like n x reachable because every forget re-traverses the whole DAG twice; that, not the node
  cap, limited the sizes.
- **H-XOR3** would be falsified by an order with polynomial growth on 3-XOR with m = n. The best
  orders (min-degree, min-fill, greedy_min) are 1-2 orders of magnitude better than natural and
  their curves are noisy; they still accelerate and are better fit by an exponential, but the
  evidence for them is weaker than for natural / random orders (short range, 3 instances per size).
  Not contradicted; not as solid as the lead's preliminary natural-order numbers suggest.
- **H-PHP** is confirmed as stated in h. What contradicts a careless reading: measured against the
  number of variables or the input length, the best orders are 2^Theta(sqrt n), not 2^Theta(n).
  A polynomial-in-h order would falsify it; local search over orders found 23-39% better orders
  than hole-major for h <= 6 with the same growth pattern.
- **H-3CNF** would be falsified by a density / order with polynomial growth. None found; the
  smallest fitted rate is about 0.2 bits per variable (density 2.0, heuristic orders).
- **H-2SAT** (open question in the brief). Found: a clear P-class failure for *fixed standard
  orders* on 2-CNF over random regular graphs (including min-degree and min-fill), and
  order-specific exponential blockers that are 2-CNF / Horn. Not found: a 2-CNF family that is
  exponential under *every* order tried - the DAG-aware greedy order stays near-linear on all of
  them. This contradicts the tacit expectation that a good bucket-elimination order is a
  small-induced-width order: here small induced width is the worst choice. For Horn see sec. 7.
- **H-SUBSUME**: the mechanism is right, the count is 2^(k-1) + 2, not 2^k + O(1).
- **"A semantic canonical form would fix it"** (the question behind E7): contradicted for PHP,
  3-XOR and random 3-CNF - their nodes are already almost all distinct functions, and adding exact
  subset subsumption (E8) leaves their growth rates unchanged.'''


def CAVEATS():
    return '''1. Everything is finite and empirical. "Exponential", "polynomial", "rate" and "exponent" describe
   least-squares fits over the stated ranges and can be wrong asymptotically in either direction.
2. Machine load: wall-clock caps on a host at load 300-550 mean 1-6 CPU-seconds per run. All CAP
   outcomes in this study are resource caps under those conditions; `cap_reason` is `time` in the
   overwhelming majority of cases and `nodes` (the 400000-node cap) in very few. Largest completed
   sizes are therefore smaller than the brief anticipated and not exactly reproducible; allocation
   counts of completed runs are.
3. Fits use only sizes at which all runs of a series completed; with 2-4 instances per size the
   fitted rates of irregular series (3-XOR and 3-CNF under heuristic orders, 2-CNF under bfs) carry
   visible noise - compare the "tail" columns before trusting a single number.
4. `greedy_min` / `greedy_max` evaluate a random sample of 12 candidates per step once more than 24
   variables remain; they are not the exact greedy orders, and their construction time (several
   chunks) is not part of the measured run.
5. Local search and hill-climbing give upper bounds on the best order and lower bounds on the worst
   order only. "Minimum over all orders tried" is not the minimum over all orders except for
   PHP(3,2), PHP(4,2), K4 and W4, where enumeration was exhaustive.
6. Expected answers for random 3-CNF with n > 20 come from my own DPLL, not from the project oracle.
   Its SAT answers carry a checked witness; its UNSAT answers rest on the correctness of a 100-line
   complete search that agrees with the exhaustive oracle on every instance with n <= 20 in E0/E4.
7. The candidate returns no witness; "SAT" in the tables means "root == 1" and was always compared
   with an independently justified answer (0 disagreements in every experiment).
8. Peak reachable size was sampled adaptively (`reach_exact` in the JSON says when every step was
   sampled); for the larger runs it is a lower bound on the true peak.
9. The first runs of E2 and E3 were made with one retry of load-induced time caps and with
   non-resumable greedy orders; the supplements E2b / E3b (resumable greedy) and the HOLES pass
   are merged by `analyze.py` (a completed record wins over a capped one for the same run).
10. E8 is a stretch item: one added rewrite rule, validated on small formulas only; no claim is made
   about other repairs.'''


REPRO = '''All commands are run from `work/alg001/fable/dag_analysis/` with Python 3.12 (standard library only).

```
python3 run_experiments.py E0                 # sanity (capped subclass == candidate, verifiers == oracle)
E1_PART=grid python3 run_experiments.py E1    # Tseitin grid            -> results/E1.json
E1_PART=adv  python3 run_experiments.py E1 --tag adv   # exhaustive / sampled / designed / hill-climb -> results/E1.adv.json
python3 run_experiments.py E2                 # XOR systems             -> results/E2.json
python3 run_experiments.py E2b                # + resumable greedy orders -> results/E2b.json
python3 run_experiments.py E3 E3b             # PHP (grid, 200 random, exhaustive, local search)
python3 run_experiments.py E4                 # random 3-CNF
python3 run_experiments.py E5                 # 2-SAT / Horn hunt (E5_ONLY=family,... E5_MATCH=substr to split)
python3 run_experiments.py E6                 # G_k exact counts
python3 run_experiments.py E7 E7b             # semantic census, support-multiplicity census
python3 run_experiments.py E8                 # repaired subclass: validation + reruns of E6/E3/E4
python3 run_experiments.py HOLES E1 E2 E4 E5  # re-run time caps that were caused by load
python3 analyze.py && python3 make_report.py  # results/tables.md, results/summary.json, REPORT.md
python3 run_experiments.py E4 --quick         # any experiment: tiny smoke test -> results/quick/
```

Options: `--workers K`, `--tag T` (write `results/<EXP>.<T>.json`; `analyze.py` merges all files of an
experiment). Caps are constants at the top of `harness.py`. On an idle machine the same commands
reach larger sizes; completed-run node counts are identical.'''


FILES = '''- `families.py` - instance generators (Tseitin on regular / torus / complete / named graphs, XOR
  systems, PHP, random k-CNF, G_k, 2-CNF and Horn families).
- `orders.py` - elimination orders. `verify.py` - independent decision procedures.
- `harness.py` - capped wrapper around the unchanged candidate, greedy DAG-aware orders, truth
  tables, process scheduler. `repaired_dag.py` - E8 subclass.
- `run_experiments.py` - experiments E0..E8 (+ supplements E2b, E3b, E5b, E7b, HOLES).
- `analyze.py` - fits and tables; `make_report.py` + `report_text.py` - this report.
- `results/E*.json` - raw records (one JSON per experiment / part), `results/tables.md` - every
  table, `results/summary.json` - every fitted number, `results/quick/` - smoke-test outputs.
- `explore/` - throw-away calibration scripts used while designing the grids (not part of the
  results).'''
