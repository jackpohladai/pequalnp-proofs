"""Measurement harness around the UNCHANGED candidate native-search/residual_dag.DAG.

The candidate is imported read-only.  `CappedDAG` subclasses it only to abort a
run (node cap / wall-clock deadline / memory cap) from inside `put`; it calls the
original `DAG.put` and overrides nothing else, so every node, cache entry and
factor step is exactly what the original class would have produced (this is
re-checked by `selfcheck_identical`).
"""
import hashlib
import multiprocessing as mp
import multiprocessing.connection as mpc
import os
import resource
import signal
import sys
import time
from collections import deque
from pathlib import Path

HERE = Path(__file__).resolve().parent
NATIVE = HERE.parent.parent / 'native-search'
ADVERSARIAL = HERE.parent.parent / 'adversarial'
if str(NATIVE) not in sys.path:
    sys.path.insert(0, str(NATIVE))
sys.setrecursionlimit(400000)

from residual_dag import DAG  # noqa: E402  (read-only import of the candidate)

NODE_CAP = 400000
TIME_CAP = 25.0          # soft in-process deadline for the DAG work of one run
ALARM_CAP = 27.5         # SIGALRM backstop inside the worker
HARD_CAP = 29.5          # parent kills the worker process after this many seconds
MEM_CAP_MB = 480


def candidate_sha256():
    return hashlib.sha256((NATIVE / 'residual_dag.py').read_bytes()).hexdigest()


class Cap(Exception):
    pass


def _rss_mb():
    # ru_maxrss is bytes on macOS, kilobytes on Linux.
    r = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    return r / (1024 * 1024) if sys.platform == 'darwin' else r / 1024


class CapMixin:
    """Abort checks only (node cap / wall-clock deadline / memory cap).
    Calls the wrapped class's own put(); changes no node, cache entry or factor step."""

    def __init__(self, node_cap=NODE_CAP, deadline=None, mem_cap_mb=MEM_CAP_MB):
        super().__init__()
        self._node_cap = node_cap
        self._deadline = deadline
        self._mem_cap = mem_cap_mb
        self._ticks = 0

    def put(self, key):
        out = super().put(key)
        if len(self.nodes) > self._node_cap:
            raise Cap('nodes')
        self._ticks += 1
        if not self._ticks & 127:
            if self._deadline is not None and time.perf_counter() > self._deadline:
                raise Cap('time')
            if not self._ticks & 4095 and self._mem_cap and _rss_mb() > self._mem_cap:
                raise Cap('memory')
        return out


class CappedDAG(CapMixin, DAG):
    """The original candidate + abort checks.  No semantic change."""


def reach_count(d, root):
    """Number of nodes reachable from root (iterative; same count as DAG.reachable)."""
    nodes = d.nodes
    seen = {root}
    stack = [root]
    while stack:
        kind, data = nodes[stack.pop()]
        if kind == 'and' or kind == 'or':
            for c in data:
                if c not in seen:
                    seen.add(c)
                    stack.append(c)
    return len(seen)


def reach_set(d, root):
    nodes = d.nodes
    seen = {root}
    stack = [root]
    while stack:
        kind, data = nodes[stack.pop()]
        if kind == 'and' or kind == 'or':
            for c in data:
                if c not in seen:
                    seen.add(c)
                    stack.append(c)
    return seen


def dag_stats(d):
    child_refs = 0
    max_or = max_and = 0
    n_and = n_or = n_lit = 0
    for kind, data in d.nodes:
        if kind == 'and':
            n_and += 1
            child_refs += len(data)
            if len(data) > max_and:
                max_and = len(data)
        elif kind == 'or':
            n_or += 1
            child_refs += len(data)
            if len(data) > max_or:
                max_or = len(data)
        elif kind == 'lit':
            n_lit += 1
    return dict(alloc=len(d.nodes), child_refs=child_refs,
                cofactor_cache=len(d.cofactor_cache), factor_steps=d.factor_steps,
                and_nodes=n_and, or_nodes=n_or, lit_nodes=n_lit,
                max_or_arity=max_or, max_and_arity=max_and)


def run_order(n, clauses, order, node_cap=NODE_CAP, time_cap=TIME_CAP,
              mem_cap_mb=MEM_CAP_MB, reach='auto', dag_cls=None, trace=False):
    """Run `root = d.cnf(clauses); for v in order: root = d.forget(root, v)`.

    Returns a dict with result in {SAT, UNSAT, CAP, ERROR_NONCONST} and the size
    counters.  `seconds` is the wall time of the DAG work only (reachability
    sampling is timed separately in `reach_seconds`).
    reach: False (off), True (after every step), 'auto' (sample while the
    sampling cost stays below ~30% of the DAG time; then peak is a lower bound
    and `reach_exact` is False)."""
    assert sorted(order) == list(range(1, n + 1)), 'order must be a permutation of 1..n'
    start = time.perf_counter()
    cpu_start = time.process_time()
    cls = dag_cls or CappedDAG
    d = cls(node_cap, start + time_cap, mem_cap_mb)
    out = dict(result=None, cap_reason=None, eliminated=0)
    peak = None
    sampled = 0
    reach_time = 0.0
    steps = []
    try:
        root = d.cnf(clauses)
        if reach:
            t = time.perf_counter()
            peak = reach_count(d, root)
            reach_time += time.perf_counter() - t
            sampled += 1
        for v in order:
            before = len(d.nodes)
            root = d.forget(root, v)
            out['eliminated'] += 1
            if trace:
                steps.append([v, len(d.nodes) - before])
            if reach:
                now = time.perf_counter()
                work = now - start - reach_time
                if reach is True or reach_time <= 0.3 * work + 0.02:
                    r = reach_count(d, root)
                    reach_time += time.perf_counter() - now
                    sampled += 1
                    if r > peak:
                        peak = r
        if root == 1:
            out['result'] = 'SAT'
        elif root == 0:
            out['result'] = 'UNSAT'
        else:
            out['result'] = 'ERROR_NONCONST'
    except Cap as e:
        out['result'], out['cap_reason'] = 'CAP', e.args[0]
    except RecursionError:
        out['result'], out['cap_reason'] = 'CAP', 'recursion'
    except MemoryError:
        out['result'], out['cap_reason'] = 'CAP', 'memory'
    total = time.perf_counter() - start
    out.update(dag_stats(d))
    out['seconds'] = round(total - reach_time, 4)
    out['reach_seconds'] = round(reach_time, 4)
    out['cpu_seconds'] = round(time.process_time() - cpu_start, 4)   # includes reach sampling
    out['peak_reachable'] = peak
    out['reach_exact'] = bool(reach) and sampled == n + 1 and out['result'] != 'CAP'
    out['maxrss_mb'] = round(_rss_mb(), 1)
    if trace:
        out['trace'] = steps
    return out


def greedy_extend(n, clauses, goal, prefix=(), sample=12, seed=0, wall_budget=16.0,
                  node_cap=NODE_CAP, dag_cls=None):
    """DAG-aware greedy order, resumable.  Replays `prefix`, then at every step
    forgets each candidate variable ON TRIAL, records the number of newly
    allocated nodes, and undoes the trial exactly (nodes / intern /
    cofactor_cache are insertion-ordered, so truncating them restores the
    previous state bit for bit).
      goal 'min': commit the candidate allocating the fewest new nodes;
      goal 'max': the most.  Ties -> smallest variable index.
    Candidates: all remaining variables if at most 2*sample remain, otherwise a
    random sample of `sample` of them drawn from Random(seed, step) - so the
    resulting order does not depend on how the work is split into chunks.
    Returns (order_so_far, complete).  Stops (complete=False) when wall_budget
    seconds are used up; an unfinished step is simply redone by the next chunk."""
    import random
    t0 = time.perf_counter()
    cls = dag_cls or CappedDAG
    d = cls(node_cap, None, MEM_CAP_MB)
    root = d.cnf(clauses)
    order = list(prefix)
    for v in order:
        root = d.forget(root, v)
    done = set(order)
    remaining = [v for v in range(1, n + 1) if v not in done]
    deadline = t0 + wall_budget
    while remaining:
        if time.perf_counter() > deadline:
            return order, False
        rng = random.Random(seed * 1000003 + len(order))
        cands = remaining if len(remaining) <= 2 * sample else sorted(rng.sample(remaining, sample))
        best = None
        best_gain = None
        d._deadline = deadline
        for v in cands:
            sn, sc, sf = len(d.nodes), len(d.cofactor_cache), d.factor_steps
            if goal == 'min' and best_gain is not None:
                d._node_cap = min(node_cap, sn + best_gain)   # prune: cannot beat best
            gain = None
            abort = None
            try:
                d.forget(root, v)
                gain = len(d.nodes) - sn
            except Cap as e:
                if e.args[0] == 'nodes' and goal == 'max' and len(d.nodes) > node_cap:
                    abort = 'blowup'          # this candidate alone exceeds the node cap
                elif e.args[0] != 'nodes':
                    abort = e.args[0]         # time / memory
            finally:
                d._node_cap = node_cap
                cache = d.cofactor_cache
                while len(cache) > sc:
                    cache.popitem()
                for key in d.nodes[sn:]:
                    del d.intern[key]
                del d.nodes[sn:]
                d.factor_steps = sf
            if abort == 'blowup':
                rest = [u for u in remaining if u != v]
                return order + [v] + rest, True
            if abort is not None:
                return order, False
            if gain is None:
                continue
            if best_gain is None or (gain < best_gain if goal == 'min' else gain > best_gain):
                best, best_gain = v, gain
        if best is None:
            best = cands[0]
        d._deadline = None
        root = d.forget(root, best)
        remaining.remove(best)
        order.append(best)
    return order, True


def greedy_order(n, clauses, goal, sample=12, seed=0, time_cap=14.0, node_cap=NODE_CAP,
                 dag_cls=None):
    """One-shot greedy order; raises Cap('time') if not finished within time_cap."""
    order, complete = greedy_extend(n, clauses, goal, (), sample, seed, time_cap, node_cap,
                                    dag_cls)
    if not complete:
        raise Cap('time')
    return order


def selfcheck_identical(n, clauses, order):
    """The capped subclass must allocate exactly what the plain candidate does."""
    d = DAG()
    root = d.cnf(clauses)
    for v in order:
        root = d.forget(root, v)
    r = run_order(n, clauses, order, reach=False)
    s = dag_stats(d)
    assert r['result'] == ('SAT' if root == 1 else 'UNSAT'), (r, root)
    for k, val in s.items():
        assert r[k] == val, (k, r[k], val)
    return s['alloc']


# --------------------------------------------------------------------------
# truth tables (semantic census, validation)
# --------------------------------------------------------------------------
def var_tables(n):
    """tables[v] = bitmask over the 2^n assignments in which variable v is true
    (assignment index a has variable v true iff bit v-1 of a is set)."""
    ones = (1 << (1 << n)) - 1
    tabs = [None]
    for v in range(1, n + 1):
        half = 1 << (v - 1)
        tabs.append((ones // ((1 << half) + 1)) << half)
    return ones, tabs


def node_table(d, node, ones, tabs, memo):
    """Truth table of a DAG node (iterative post-order, memoised in `memo`)."""
    nodes = d.nodes
    stack = [node]
    while stack:
        x = stack[-1]
        if x in memo:
            stack.pop()
            continue
        kind, data = nodes[x]
        if kind == 'const':
            memo[x] = ones if data else 0
            stack.pop()
        elif kind == 'lit':
            memo[x] = tabs[data] if data > 0 else ones ^ tabs[-data]
            stack.pop()
        else:
            missing = [c for c in data if c not in memo]
            if missing:
                stack.extend(missing)
                continue
            if kind == 'and':
                acc = ones
                for c in data:
                    acc &= memo[c]
            else:
                acc = 0
                for c in data:
                    acc |= memo[c]
            memo[x] = acc
            stack.pop()
    return memo[node]


def redundant_child_refs(d, reach, memo, ones):
    """Local semantic redundancy inside nodes: for every reachable AND/OR node,
    scan its children left to right and drop a child whenever the node's function
    is unchanged without it (given the children still kept).  Returns
    (total child references, references dropped, nodes that lost >= 1 child).
    Equivalence-merging of nodes does not see this kind of waste (a subsumed
    child is a DIFFERENT function from the child that subsumes it)."""
    total = dropped = touched = 0
    nodes = d.nodes
    for x in reach:
        kind, data = nodes[x]
        if kind != 'and' and kind != 'or':
            continue
        m = len(data)
        total += m
        tabs = [memo[c] for c in data]
        unit = 0 if kind == 'or' else ones
        suffix = [unit] * (m + 1)
        for i in range(m - 1, -1, -1):
            suffix[i] = (suffix[i + 1] | tabs[i]) if kind == 'or' else (suffix[i + 1] & tabs[i])
        acc = unit
        lost = 0
        for i in range(m):
            if kind == 'or':
                others = acc | suffix[i + 1]
                if tabs[i] | others == others:
                    lost += 1
                else:
                    acc |= tabs[i]
            else:
                others = acc & suffix[i + 1]
                if others & tabs[i] == others:
                    lost += 1
                else:
                    acc &= tabs[i]
        if lost:
            dropped += lost
            touched += 1
    return total, dropped, touched


def cnf_table(clauses, ones, tabs):
    acc = ones
    for c in clauses:
        t = 0
        for l in c:
            t |= tabs[l] if l > 0 else ones ^ tabs[-l]
        acc &= t
    return acc


def exists_table(table, v, n):
    """Truth table of EXISTS x_v . f  (still a table over all n variables)."""
    half = 1 << (v - 1)
    ones = (1 << (1 << n)) - 1
    low_mask = ones // ((1 << half) + 1)        # positions where bit v-1 == 0
    lo = table & low_mask
    hi = (table >> half) & low_mask
    either = lo | hi
    return either | (either << half)


# --------------------------------------------------------------------------
# process scheduler: one forked process per task, hard wall-clock kill
# --------------------------------------------------------------------------
def _child(fn, task, conn):
    def on_alarm(signum, frame):
        raise Cap('alarm')
    try:
        signal.signal(signal.SIGALRM, on_alarm)
        signal.setitimer(signal.ITIMER_REAL, ALARM_CAP)
        try:
            res = fn(task)
        except Cap as e:
            res = dict(task=task, result='CAP', cap_reason='task_' + str(e.args[0]))
        except Exception as e:  # report, never hide
            import traceback
            res = dict(task=task, result='CRASH', error=repr(e),
                       traceback=traceback.format_exc()[-2000:])
        signal.setitimer(signal.ITIMER_REAL, 0)
        conn.send(res)
    finally:
        conn.close()
        os._exit(0)


def run_tasks(fn, tasks, workers=6, on_result=None, hard_cap=HARD_CAP, label=''):
    """Run fn(task) for every task, each in its own forked process.
    Results are delivered to on_result(index, task, result) as they finish.
    A task that exceeds hard_cap seconds is killed and reported as CAP/hard_kill."""
    ctx = mp.get_context('fork')
    pending = deque(enumerate(tasks))
    running = {}
    results = [None] * len(tasks)
    done = 0
    t_start = time.time()
    last_print = t_start
    while pending or running:
        while pending and len(running) < workers:
            idx, task = pending.popleft()
            rconn, wconn = ctx.Pipe(duplex=False)
            p = ctx.Process(target=_child, args=(fn, task, wconn))
            p.start()
            wconn.close()
            running[rconn] = (p, idx, task, time.time())
        ready = mpc.wait(list(running), timeout=0.05)
        now = time.time()
        for conn in list(running):
            p, idx, task, t0 = running[conn]
            res = None
            if conn in ready:
                try:
                    res = conn.recv()
                except (EOFError, OSError):
                    res = dict(task=task, result='CRASH', error='worker died without result')
            elif now - t0 > hard_cap:
                p.kill()
                res = dict(task=task, result='CAP', cap_reason='hard_kill',
                           seconds=round(now - t0, 2))
            if res is not None:
                conn.close()
                p.join()
                del running[conn]
                results[idx] = res
                done += 1
                if on_result:
                    on_result(idx, task, res)
        if now - last_print > 15:
            last_print = now
            print(f'  [{label}] {done}/{len(tasks)} tasks, {now - t_start:.0f}s', flush=True)
    return results
