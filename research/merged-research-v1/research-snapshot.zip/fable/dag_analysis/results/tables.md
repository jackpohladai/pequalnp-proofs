## E0 sanity

{"selfcheck_runs": 1680, "failed_tasks": 0, "hashseed_independent": true, "candidate_sha256": "eb68d16927c8405ff51d271a258be32a3e7a311daf70ec7eb326161f8db1e255"}

## E1 Tseitin

Runs: {"runs": 1808, "completed": 1642, "verified": 1642, "disagreements": 0, "unverified": 0, "capped": 166, "other": 0, "bad_examples": []}; non-completions: {"CAP:time": 166}

**tseitin_regular {"d": 3}: allocated nodes (gmean over 2 charges x 2 seeds [x 5 shuffles])**

| nv | n vars | N bits | natural | reverse | min_degree | min_fill | greedy_min | bfs | max_degree | greedy_max | tree_first | tree_first_bfs | shuffle |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 8 | 12 | 1040 | 221 | 231 | 209 | 209 | 202 | 242 | 235 | 265 | 227 | 257 | 222 |
| 12 | 18 | 1696 | 319 | 331 | 290 | 290 | 289 | 319 | 429 | 402 | 373 | 387 | 348 |
| 16 | 24 | 2400 | 576 | 567 | 473 | 462 | 469 | 689 | 648 | 805 | 569 | 744 | 556 |
| 24 | 36 | 3888 | 922 | 886 | 760 | 757 | 761 | 1278 | 1253 | 1381 | 1095 | 1481 | 937 |
| 32 | 48 | 5488 | 1462 | 1487 | 1025 | 1038 | 1020 | 2011 | 2137 | 2225 | 1714 | 2426 | 1414 |
| 48 | 72 | 8832 | 2258 | 2453 | 1718 | 1703 | 1734 | 3832 | 3704 | 4026 | 3426 | 4970 | 2477 |
| 64 | 96 | 12416 | 3709 | 3838 | 2453 | 2341 | 2329 | 7439 | 6520 | 7446 | 5615 | 8949 | 3543 |
| 96 | 144 | 19856 | 7274 | 7481 | >4037* (3/4) | >3886* (3/4) |  | >14912* (3/4) | 13874 |  | 11634 | 18704 | >6957* (17/20) |
| 128 | 192 | 27792 | 10826 | 9990 | 5723 | 5351 |  | 26667 | 23960 |  | 19543 | 33647 | 10208 |
| 192 | 288 | 44192 | 21532 | 21970 | 9182 | 8820 |  | 61065 | 51031 |  | >44441* (1/4) | >77319* (1/4) | 19687 |
| 256 | 384 | 61600 | CAP(time) | CAP(time) | CAP(time) | CAP(time) |  | CAP(time) | CAP(time) |  |  |  | CAP(time) |

**tseitin_regular {"d": 4}: allocated nodes (gmean over 2 charges x 2 seeds [x 5 shuffles])**

| nv | n vars | N bits | natural | reverse | min_degree | min_fill | greedy_min | bfs | max_degree | greedy_max | tree_first | tree_first_bfs | shuffle |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 8 | 16 | 2880 | 423 | 405 | 392 | 384 | 375 | 452 | 442 | 484 | 437 | 478 | 426 |
| 12 | 24 | 4736 | 763 | 674 | 611 | 625 | 624 | 795 | 883 | 910 | 821 | 915 | 735 |
| 16 | 32 | 6624 | 1149 | 1062 | 884 | 864 | 861 | 1231 | 1301 | 1354 | 1290 | 1452 | 1083 |
| 24 | 48 | 10848 | 2073 | 1841 | 1492 | 1424 | 1394 | 2701 | 2519 | 2821 | 2525 | 2989 | 1921 |
| 32 | 64 | 15104 | 3149 | 2836 | 2063 | 1952 | 1988 | 3977 | 4166 | 4507 | 4020 | 4862 | 2927 |
| 48 | 96 | 24576 | 5753 | 5132 | 3399 | 3297 | 3563 | 8426 | 8514 | 9010 | 8592 | 10483 | 5035 |
| 64 | 128 | 34080 | 8674 | 7946 | 5041 | 4731 |  | 14777 | 14015 |  | 13823 | 18211 | 8246 |
| 96 | 192 | 55072 | 17245 | 16572 | 8104 | 7651 |  | 32446 | 29421 |  | 30025 | 39074 | 15532 |
| 128 | 256 | 76096 | CAP(time) | >26590* (1/4) | CAP(time) | CAP(time) |  | >51181* (1/4) | CAP(time) |  | CAP(time) | CAP(time) | CAP(time) |
| 192 | 384 | 122176 |  | CAP(time) |  |  |  | CAP(time) |  |  |  |  |  |

**tseitin_regular {"d": 5}: allocated nodes (gmean over 2 charges x 2 seeds [x 5 shuffles])**

| nv | n vars | N bits | natural | reverse | min_degree | min_fill | greedy_min | bfs | max_degree | greedy_max | tree_first | tree_first_bfs | shuffle |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 8 | 20 | 7552 | 750 | 714 | 673 | 654 | 612 | 763 | 784 | 744 | 793 | 802 | 740 |
| 12 | 30 | 12160 | 1295 | 1255 | 1085 | 1083 | 1200 | 1386 | 1412 | 1295 | 1446 | 1493 | 1289 |
| 16 | 40 | 17344 | 1871 | 1748 | 1520 | 1513 | 1586 | 2120 | 2112 | 1900 | 2195 | 2415 | 1846 |
| 24 | 60 | 27840 | 3234 | 3199 | 2452 | 2386 | 2605 | 4144 | 4005 | 3590 | 4251 | 4745 | 3227 |
| 32 | 80 | 39424 | 5467 | 4772 | 3621 | 3483 | 3986 | 6680 | 6720 | 5494 | 6920 | 7897 | 5055 |
| 48 | 120 | 62976 | 10094 | 9047 | 5883 | 5637 |  | 13769 | 13601 |  | 14548 | 16585 | 9044 |
| 64 | 160 | 88640 | 13649 | 12555 | 7853 | 7496 |  | 22865 | 21359 |  | 23908 | 28070 | 13988 |
| 96 | 240 | 140864 | CAP(time) | CAP(time) | CAP(time) | CAP(time) |  | CAP(time) | CAP(time) |  | CAP(time) | CAP(time) | CAP(time) |

**tseitin_torus {}: allocated nodes (gmean over 2 charges x 2 seeds [x 5 shuffles])**

| a | n vars | N bits | natural | reverse | min_degree | min_fill | greedy_min | bfs | max_degree | greedy_max | shuffle |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 3 | 18 | 3344 | 525 | 469 | 448 | 443 | 425 | 539 | 556 | 551 | 516 |
| 4 | 32 | 6624 | 1165 | 959 | 846 | 846 | 884 | 1219 | 1324 | 1459 | 1119 |
| 5 | 50 | 11376 | 2068 | 1667 | 1540 | 1502 | 1457 | 2459 | 2673 | 2962 | 2095 |
| 6 | 72 | 17472 | 3339 | 2629 | 2220 | 2243 | 2235 | 4079 | 4561 | 4900 | 3485 |

**tseitin_regular {"d": 3}** (x = n; gmean over instances/shuffles; fits use fully completed sizes only)

| series / order | pts | largest complete n | alloc there (gmean) | power exp b | tail b (last 4) | R2 pow | exp rate bits/var | tail rate | R2 exp | better fit | power exp vs N | first incomplete size |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| natural | 10 | 288 | 21532 | 1.45 | 1.59 | 0.997 | 0.0228 | 0.0128 | 0.870 | power | 1.23 | 256: 0/4 done (timex4) |
| reverse | 10 | 288 | 21970 | 1.44 | 1.55 | 0.997 | 0.0227 | 0.0126 | 0.868 | power | 1.22 | 256: 0/4 done (timex4) |
| min_degree | 9 | 288 | 9182 | 1.21 | 1.21 | 0.999 | 0.0183 | 0.0110 | 0.845 | power | 1.02 | 96: 3/4 done (timex1) |
| min_fill | 9 | 288 | 8820 | 1.19 | 1.19 | 0.999 | 0.0180 | 0.0109 | 0.843 | power | 1.01 | 96: 3/4 done (timex1) |
| greedy_min | 7 | 96 | 2329 | 1.20 | 1.17 | 0.997 | 0.0406 | 0.0271 | 0.916 | power | 1.01 | - |
| bfs | 9 | 288 | 61065 | 1.78 | 1.96 | 0.994 | 0.0274 | 0.0179 | 0.875 | power | 1.50 | 96: 3/4 done (timex1) |
| max_degree | 10 | 288 | 51031 | 1.69 | 1.87 | 0.998 | 0.0268 | 0.0151 | 0.874 | power | 1.44 | 256: 0/4 done (timex4) |
| greedy_max | 7 | 96 | 7446 | 1.61 | 1.68 | 0.994 | 0.0548 | 0.0394 | 0.934 | power | 1.35 | - |
| tree_first | 9 | 192 | 19543 | 1.63 | 1.78 | 0.997 | 0.0342 | 0.0207 | 0.906 | power | 1.37 | 192: 1/4 done (timex3) |
| tree_first_bfs | 9 | 192 | 33647 | 1.79 | 1.93 | 0.997 | 0.0376 | 0.0225 | 0.898 | power | 1.51 | 192: 1/4 done (timex3) |
| shuffle | 9 | 288 | 19687 | 1.41 | 1.50 | 0.999 | 0.0216 | 0.0138 | 0.866 | power | 1.20 | 96: 17/20 done (timex3) |

**tseitin_regular {"d": 4}** (x = n; gmean over instances/shuffles; fits use fully completed sizes only)

| series / order | pts | largest complete n | alloc there (gmean) | power exp b | tail b (last 4) | R2 pow | exp rate bits/var | tail rate | R2 exp | better fit | power exp vs N | first incomplete size |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| natural | 8 | 192 | 17245 | 1.48 | 1.54 | 1.000 | 0.0286 | 0.0187 | 0.904 | power | 1.25 | 128: 0/4 done (timex4) |
| reverse | 8 | 192 | 16572 | 1.48 | 1.60 | 0.998 | 0.0289 | 0.0195 | 0.916 | power | 1.25 | 128: 1/4 done (timex3) |
| min_degree | 8 | 192 | 8104 | 1.23 | 1.25 | 1.000 | 0.0237 | 0.0151 | 0.896 | power | 1.04 | 128: 0/4 done (timex4) |
| min_fill | 8 | 192 | 7651 | 1.21 | 1.24 | 1.000 | 0.0233 | 0.0150 | 0.897 | power | 1.02 | 128: 0/4 done (timex4) |
| greedy_min | 6 | 96 | 3563 | 1.24 | 1.29 | 0.998 | 0.0386 | 0.0314 | 0.951 | power | 1.04 | - |
| bfs | 8 | 192 | 32446 | 1.73 | 1.91 | 0.997 | 0.0338 | 0.0231 | 0.918 | power | 1.46 | 128: 1/4 done (timex3) |
| max_degree | 8 | 192 | 29421 | 1.68 | 1.78 | 0.999 | 0.0327 | 0.0215 | 0.909 | power | 1.42 | 128: 0/4 done (timex4) |
| greedy_max | 6 | 96 | 9010 | 1.64 | 1.72 | 0.999 | 0.0510 | 0.0414 | 0.946 | power | 1.37 | - |
| tree_first | 8 | 192 | 30025 | 1.70 | 1.82 | 0.999 | 0.0331 | 0.0220 | 0.911 | power | 1.43 | 128: 0/4 done (timex4) |
| tree_first_bfs | 8 | 192 | 39074 | 1.78 | 1.90 | 0.999 | 0.0346 | 0.0229 | 0.911 | power | 1.50 | 128: 0/4 done (timex4) |
| shuffle | 8 | 192 | 15532 | 1.44 | 1.53 | 0.999 | 0.0280 | 0.0186 | 0.910 | power | 1.22 | 128: 0/20 done (timex20) |

**tseitin_regular {"d": 5}** (x = n; gmean over instances/shuffles; fits use fully completed sizes only)

| series / order | pts | largest complete n | alloc there (gmean) | power exp b | tail b (last 4) | R2 pow | exp rate bits/var | tail rate | R2 exp | better fit | power exp vs N | first incomplete size |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| natural | 7 | 160 | 13649 | 1.43 | 1.47 | 0.998 | 0.0291 | 0.0203 | 0.925 | power | 1.21 | 96: 0/4 done (timex4) |
| reverse | 7 | 160 | 12555 | 1.40 | 1.42 | 0.999 | 0.0284 | 0.0198 | 0.927 | power | 1.18 | 96: 0/4 done (timex4) |
| min_degree | 7 | 160 | 7853 | 1.20 | 1.19 | 0.999 | 0.0242 | 0.0165 | 0.919 | power | 1.01 | 96: 0/4 done (timex4) |
| min_fill | 7 | 160 | 7496 | 1.18 | 1.17 | 0.999 | 0.0238 | 0.0162 | 0.916 | power | 1.00 | 96: 0/4 done (timex4) |
| greedy_min | 5 | 80 | 3986 | 1.31 | 1.22 | 0.994 | 0.0420 | 0.0346 | 0.948 | power | 1.10 | - |
| bfs | 7 | 160 | 22865 | 1.64 | 1.75 | 0.999 | 0.0337 | 0.0245 | 0.942 | power | 1.39 | 96: 0/4 done (timex4) |
| max_degree | 7 | 160 | 21359 | 1.61 | 1.71 | 0.998 | 0.0329 | 0.0238 | 0.940 | power | 1.36 | 96: 0/4 done (timex4) |
| greedy_max | 5 | 80 | 5494 | 1.45 | 1.49 | 0.999 | 0.0470 | 0.0417 | 0.972 | power | 1.21 | - |
| tree_first | 7 | 160 | 23908 | 1.65 | 1.77 | 0.998 | 0.0338 | 0.0248 | 0.943 | power | 1.39 | 96: 0/4 done (timex4) |
| tree_first_bfs | 7 | 160 | 28070 | 1.72 | 1.81 | 0.999 | 0.0351 | 0.0254 | 0.939 | power | 1.45 | 96: 0/4 done (timex4) |
| shuffle | 7 | 160 | 13988 | 1.41 | 1.49 | 0.999 | 0.0289 | 0.0208 | 0.936 | power | 1.19 | 96: 0/20 done (timex20) |

**tseitin_torus {}** (x = n; gmean over instances/shuffles; fits use fully completed sizes only)

| series / order | pts | largest complete n | alloc there (gmean) | power exp b | tail b (last 4) | R2 pow | exp rate bits/var | tail rate | R2 exp | better fit | power exp vs N | first incomplete size |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| natural | 4 | 72 | 3339 | 1.33 | 1.33 | 1.000 | 0.0480 | 0.0480 | 0.954 | power | 1.11 | - |
| reverse | 4 | 72 | 2629 | 1.24 | 1.24 | 1.000 | 0.0450 | 0.0450 | 0.960 | power | 1.04 | - |
| min_degree | 4 | 72 | 2220 | 1.17 | 1.17 | 0.998 | 0.0424 | 0.0424 | 0.955 | power | 0.98 | - |
| min_fill | 4 | 72 | 2243 | 1.18 | 1.18 | 0.999 | 0.0427 | 0.0427 | 0.960 | power | 0.99 | - |
| greedy_min | 4 | 72 | 2235 | 1.19 | 1.19 | 0.999 | 0.0430 | 0.0430 | 0.950 | power | 1.00 | - |
| bfs | 4 | 72 | 4079 | 1.47 | 1.47 | 1.000 | 0.0532 | 0.0532 | 0.960 | power | 1.23 | - |
| max_degree | 4 | 72 | 4561 | 1.52 | 1.52 | 1.000 | 0.0551 | 0.0551 | 0.959 | power | 1.28 | - |
| greedy_max | 4 | 72 | 4900 | 1.58 | 1.58 | 0.998 | 0.0568 | 0.0568 | 0.942 | power | 1.33 | - |
| shuffle | 4 | 72 | 3485 | 1.38 | 1.38 | 1.000 | 0.0500 | 0.0500 | 0.963 | power | 1.16 | - |

**Worst completed standard order per size (max over instances and all 13 orders)**

| family | pts | largest n | max alloc there | power exp | tail exp | exp rate | better fit |
|---|---|---|---|---|---|---|---|
| tseitin_regular {"d": 3} | 10 | 288 | 77319 | 1.79 | 1.94 | 0.0283 | power |
| tseitin_regular {"d": 4} | 9 | 256 | 51181 | 1.74 | 1.63 | 0.0268 | power |
| tseitin_regular {"d": 5} | 7 | 160 | 29048 | 1.73 | 1.83 | 0.0353 | power |
| tseitin_torus {} | 4 | 72 | 4900 | 1.55 | 1.55 | 0.0556 | power |

**Distribution of allocated nodes over orders (tiny graphs)**

| family | params | orders | # | min | median | max | answers | disagreements |
|---|---|---|---|---|---|---|---|---|
| tseitin_named | {"graph": "K33", "sat": false, "seed": 1} | random sample | 4000 | 131 | 152.0 | 170 | {"UNSAT": 4000} | 0 |
| tseitin_named | {"graph": "K4", "sat": false, "seed": 1} | ALL orders | 720 | 78 | 85.0 | 89 | {"UNSAT": 720} | 0 |
| tseitin_named | {"graph": "K4", "sat": true, "seed": 1} | ALL orders | 720 | 78 | 85.0 | 89 | {"SAT": 720} | 0 |
| tseitin_named | {"graph": "W4", "sat": false, "seed": 1} | ALL orders | 40320 | 118 | 138.0 | 158 | {"UNSAT": 40320} | 0 |
| tseitin_named | {"graph": "cube", "sat": false, "seed": 1} | random sample | 4000 | 179 | 224.0 | 271 | {"UNSAT": 4000} | 0 |
| tseitin_named | {"graph": "petersen", "sat": false, "seed": 1} | random sample | 4000 | 261 | 306.0 | 369 | {"UNSAT": 4000} | 0 |
| tseitin_named | {"graph": "prism", "sat": false, "seed": 1} | random sample | 4000 | 120 | 149.0 | 174 | {"UNSAT": 4000} | 0 |

**Adversarial search for the WORST order (hill-climb maximising allocated nodes)**

| family | params | n | N | max alloc found | evaluations | worst standard order alloc | which | max/n^2 |
|---|---|---|---|---|---|---|---|---|
| tseitin_regular | {"nv": 8, "d": 3, "seed": 1, "sat": false} | 12 | 1040 | 277 | 3171 | 265 | greedy_max | 1.924 |
| tseitin_regular | {"nv": 12, "d": 3, "seed": 1, "sat": false} | 18 | 1696 | 546 | 2079 | 458 | max_degree | 1.685 |
| tseitin_regular | {"nv": 16, "d": 3, "seed": 1, "sat": false} | 24 | 2400 | 866 | 1113 | 768 | greedy_max | 1.503 |
| tseitin_regular | {"nv": 24, "d": 3, "seed": 1, "sat": false} | 36 | 3888 | 1651 | 462 | 1505 | greedy_max | 1.274 |
| tseitin_regular | {"nv": 32, "d": 3, "seed": 1, "sat": false} | 48 | 5488 | 2509 | 252 | 2303 | tree_first_bfs | 1.089 |
| tseitin_regular | {"nv": 48, "d": 3, "seed": 1, "sat": false} | 72 | 8832 | 5373 | 181 | 4981 | tree_first_bfs | 1.036 |
| tseitin_regular | {"nv": 8, "d": 4, "seed": 1, "sat": false} | 16 | 2880 | 513 | 1386 | 501 | greedy_max | 2.004 |
| tseitin_regular | {"nv": 12, "d": 4, "seed": 1, "sat": false} | 24 | 4736 | 970 | 567 | 909 | tree_first_bfs | 1.684 |
| tseitin_regular | {"nv": 16, "d": 4, "seed": 1, "sat": false} | 32 | 6624 | 1630 | 315 | 1433 | tree_first_bfs | 1.592 |
| tseitin_regular | {"nv": 24, "d": 4, "seed": 1, "sat": false} | 48 | 10848 | 3163 | 189 | 3102 | tree_first_bfs | 1.373 |
| tseitin_complete | {"m": 5, "seed": 1, "sat": false} | 10 | 1648 | 240 | 3171 | - | - | 2.400 |
| tseitin_complete | {"m": 6, "seed": 1, "sat": false} | 15 | 5248 | 540 | 819 | - | - | 2.400 |
| tseitin_complete | {"m": 7, "seed": 1, "sat": false} | 21 | 15936 | 1121 | 189 | - | - | 2.542 |
| tseitin_torus | {"a": 3, "seed": 1, "sat": false} | 18 | 3344 | 633 | 1050 | 582 | shuffle03 | 1.954 |
| tseitin_torus | {"a": 4, "seed": 1, "sat": false} | 32 | 6624 | 1569 | 315 | 1459 | greedy_max | 1.532 |

| family | (n, max alloc found) | power exp | exp rate bits/var | R2 pow | R2 exp | better | local exponents |
|---|---|---|---|---|---|---|---|
| tseitin_complete | [[10, 240], [15, 540], [21, 1121]] | 2.08 | 0.2013 | 0.999 | 0.993 | power | [2.0, 2.17] |
| tseitin_regular d=3 | [[12, 277], [18, 546], [24, 866], [36, 1651], [48, 2509], [72, 5373]] | 1.63 | 0.0676 | 0.999 | 0.942 | power | [1.67, 1.6, 1.59, 1.45, 1.88] |
| tseitin_regular d=4 | [[16, 513], [24, 970], [32, 1630], [48, 3163]] | 1.67 | 0.0805 | 0.999 | 0.974 | power | [1.57, 1.8, 1.64] |
| tseitin_torus | [[18, 633], [32, 1569]] | - | - | - | - | - | null |

## E2 XOR systems

Runs: {"runs": 1620, "completed": 1446, "verified": 1446, "disagreements": 0, "unverified": 0, "capped": 158, "other": 16, "bad_examples": []}; non-completions: {"CAP:nodes": 2, "CAP:time": 154, "CAP:task_alarm": 1, "ORDER_TIMEOUT:order:time": 16, "CAP:hard_kill": 1}

**xor3 {"extra": 0, "planted": true}: allocated nodes, structured orders (gmean over instances)**

| n | n vars | N bits | natural | min_degree | min_fill | greedy_min |
|---|---|---|---|---|---|---|
| 16 | 16 | 2261 | 354 | 296 | 290 | 268 |
| 24 | 24 | 3736 | 709 | 510 | 470 | 463 |
| 32 | 32 | 5048 | 2929 | 865 | 803 | 758 |
| 40 | 40 | 6688 | 7404 | 1614 | 1661 | 1213 |
| 48 | 48 | 8219 | 16948 | 2439 | 2044 | 1567 |
| 56 | 56 | 9763 | 37542 | 2478 | 2488 | 1973 |
| 64 | 64 | 11259 | 31853 | 2699 | 3166 | 2054 |
| 72 | 72 | 13053 | >233736* (2/3) | 4376 | 6887 | 3804 |
| 80 | 80 | 14907 | >241551* (1/3) | 4898 | 7702 | 5775 |
| 88 | 88 | 16667 | CAP(time) | 12103 | 9421 |  |
| 96 | 96 | 18437 |  | 23153 | 15775 |  |
| 104 | 104 | 20288 |  | 26584 | 24751 |  |
| 112 | 112 | 22061 |  | 57876 | 45923 |  |
| 120 | 120 | 23829 |  | >32320* (2/3) | 114847 |  |
| 136 | 136 | 27952 |  | CAP(time) | CAP(time) |  |

**xor3 {"extra": 0, "planted": true}: 20 random shuffles per instance** (best / median per instance, then gmean over instances; CAP if any instance has it capped)

| n | n | shuffles completed | best of 20 | median of 20 |
|---|---|---|---|---|
| 16 | 16 | 40/40 | 282 | 339 |
| 24 | 24 | 40/40 | 490 | 738 |
| 32 | 32 | 40/40 | 1141 | 2628 |
| 40 | 40 | 40/40 | 2829 | 8093 |
| 48 | 48 | 40/40 | 5555 | 17295 |
| 56 | 56 | 38/40 | 6359 | 27009 |
| 64 | 64 | 35/40 | 5046 | 41707 |
| 72 | 72 | 31/40 | 16872 | 69090 |
| 80 | 80 | 21/40 | 20714 | CAP |
| 88 | 88 | 10/40 | 26667 | CAP |

best-of-20 fit: {"points": 10, "power_exponent": 2.761, "power_r2": 0.9639, "exp_rate_bits": 0.0902, "exp_r2": 0.9426, "local_exponents": [1.37, 2.94, 4.07, 3.7, 0.88, -1.73, 10.25, 1.95, 2.65], "tail_power_exponent": 4.988, "tail_exp_rate_bits": 0.0938, "better_fit": "power"}

median-of-20 fit: {"points": 8, "power_exponent": 3.73, "power_r2": 0.9865, "exp_rate_bits": 0.1398, "exp_r2": 0.9615, "local_exponents": [1.91, 4.42, 5.04, 4.17, 2.89, 3.25, 4.29], "tail_power_exponent": 3.382, "tail_exp_rate_bits": 0.0828, "better_fit": "power"}

**xor3 {"extra": 5, "planted": false}: allocated nodes, structured orders (gmean over instances)**

| n | n vars | N bits | natural | min_degree | min_fill | greedy_min |
|---|---|---|---|---|---|---|
| 16 | 16 | 2971 | 433 | 312 | 332 | 270 |
| 24 | 24 | 4389 | 827 | 584 | 545 | 483 |
| 32 | 32 | 5792 | 1672 | 786 | 793 | 736 |
| 40 | 40 | 7491 | 5836 | 1555 | 1327 | >888* (1/3) |
| 48 | 48 | 9059 | 8654 | 2195 | 1509 | CAP(order:time) |
| 56 | 56 | 10632 | 31481 | 3353 | 3283 |  |
| 64 | 64 | 12181 | >42672* (2/3) | 3925 | 4003 |  |
| 72 | 72 | 14093 | >108616* (1/3) | 7357 | 8728 |  |
| 80 | 80 | 15933 | >36902* (1/3) | 8587 | 7950 |  |
| 88 | 88 | 17787 | CAP(time) | 19951 | 12664 |  |
| 96 | 96 | 19560 |  | >12261* (2/3) | 17846 |  |
| 104 | 104 | 21304 |  | 23262 | 15891 |  |
| 112 | 112 | 23195 |  | 39707 | 27441 |  |
| 120 | 120 | 24907 |  | 50490 | 44597 |  |
| 136 | 136 | 28763 |  | >128436* (1/3) | >115497* (1/3) |  |
| 152 | 152 | 32861 |  | CAP(time) | CAP(time) |  |

**xor3 {"extra": 5, "planted": false}: 20 random shuffles per instance** (best / median per instance, then gmean over instances; CAP if any instance has it capped)

| n | n | shuffles completed | best of 20 | median of 20 |
|---|---|---|---|---|
| 16 | 16 | 40/40 | 245 | 357 |
| 24 | 24 | 40/40 | 462 | 874 |
| 32 | 32 | 40/40 | 453 | 1175 |
| 40 | 40 | 40/40 | 1501 | 3375 |
| 48 | 48 | 40/40 | 2607 | 9208 |
| 56 | 56 | 40/40 | 6360 | 24695 |
| 64 | 64 | 35/40 | 9544 | 43124 |
| 72 | 72 | 24/40 | 11130 | 102443 |
| 80 | 80 | 7/40 | 35710 | CAP |

best-of-20 fit: {"points": 9, "power_exponent": 3.055, "power_r2": 0.918, "exp_rate_bits": 0.1113, "exp_r2": 0.9763, "local_exponents": [1.57, -0.07, 5.37, 3.03, 5.78, 3.04, 1.31, 11.06], "tail_power_exponent": 4.402, "tail_exp_rate_bits": 0.0961, "better_fit": "exponential"}

median-of-20 fit: {"points": 8, "power_exponent": 3.801, "power_r2": 0.935, "exp_rate_bits": 0.1487, "exp_r2": 0.9918, "local_exponents": [2.2, 1.03, 4.73, 5.51, 6.4, 4.17, 7.35], "tail_power_exponent": 5.76, "tail_exp_rate_bits": 0.1404, "better_fit": "exponential"}

**xor_two_occ {"k": 4}: allocated nodes, structured orders (gmean over instances)**

| m_eq | n vars | N bits | natural | reverse | min_degree | min_fill | greedy_min | bfs | max_degree | greedy_max |
|---|---|---|---|---|---|---|---|---|---|---|
| 8 | 16 | 2880 | 365 | 366 | 353 | 342 | 340 | 391 | 425 | 472 |
| 12 | 24 | 4736 | 657 | 710 | 563 | 566 | 562 | 721 | 852 | 888 |
| 16 | 32 | 6624 | 1042 | 1034 | 876 | 862 | 846 | 1239 | 1263 | 1421 |
| 24 | 48 | 10848 | 2073 | 1841 | 1492 | 1424 | >1434* (1/4) | 2701 | 2519 | CAP(order:time) |
| 32 | 64 | 15104 | 3136 | 2559 | 2080 | 1992 | CAP(order:time) | 4002 | 4070 |  |
| 48 | 96 | 24576 | 5833 | 5392 | 3336 | 3236 |  | 8112 | 8570 |  |
| 64 | 128 | 34080 | 8847 | 7693 | 4760 | 4479 |  | 14435 | 13347 |  |
| 96 | 192 | 55072 | 15589 | 14655 | 7913 | 7442 |  | 32038 | 28244 |  |
| 128 | 256 | 76096 | >29646* (3/4) | 24650 | >11029* (3/4) | >10458* (3/4) |  | >55339* (3/4) | >51507* (3/4) |  |

**xor_two_occ {"k": 4}: 20 random shuffles per instance** (best / median per instance, then gmean over instances; CAP if any instance has it capped)

| m_eq | n | shuffles completed | best of 20 | median of 20 |
|---|---|---|---|---|
| 8 | 16 | 40/40 | 369 | 409 |
| 12 | 24 | 40/40 | 611 | 699 |
| 16 | 32 | 40/40 | 1006 | 1100 |
| 24 | 48 | 40/40 | 1780 | 1958 |
| 32 | 64 | 40/40 | 2508 | 2857 |
| 48 | 96 | 40/40 | 4340 | 5006 |
| 64 | 128 | 40/40 | 6728 | 7962 |
| 96 | 192 | 38/40 | 12496 | 15307 |

best-of-20 fit: {"points": 8, "power_exponent": 1.41, "power_r2": 0.999, "exp_rate_bits": 0.0272, "exp_r2": 0.8968, "local_exponents": [1.25, 1.73, 1.41, 1.19, 1.35, 1.52, 1.53], "tail_power_exponent": 1.466, "tail_exp_rate_bits": 0.0178, "better_fit": "power"}

median-of-20 fit: {"points": 8, "power_exponent": 1.446, "power_r2": 0.9991, "exp_rate_bits": 0.0281, "exp_r2": 0.9055, "local_exponents": [1.32, 1.57, 1.42, 1.31, 1.38, 1.61, 1.61], "tail_power_exponent": 1.533, "tail_exp_rate_bits": 0.0186, "better_fit": "power"}

**xor3 {"extra": 0, "planted": true}** (x = n; gmean over instances/shuffles; fits use fully completed sizes only)

| series / order | pts | largest complete n | alloc there (gmean) | power exp b | tail b (last 4) | R2 pow | exp rate bits/var | tail rate | R2 exp | better fit | power exp vs N | first incomplete size |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| natural | 7 | 64 | 31853 | 3.67 | 3.39 | 0.971 | 0.1494 | 0.0933 | 0.950 | power | 3.17 | 72: 2/3 done (nodesx1) |
| min_degree | 13 | 112 | 57876 | 2.50 | 6.00 | 0.900 | 0.0719 | 0.0872 | 0.969 | exponential | 2.15 | 120: 2/3 done (timex1) |
| min_fill | 14 | 120 | 114847 | 2.71 | 8.79 | 0.910 | 0.0739 | 0.1185 | 0.980 | exponential | 2.32 | 136: 0/3 done (timex3) |
| greedy_min | 9 | 80 | 5775 | 1.79 | 3.18 | 0.967 | 0.0633 | 0.0692 | 0.971 | exponential | 1.54 | - |
| shuffle | 5 | 48 | 18705 | 3.63 | 4.56 | 0.963 | 0.1826 | 0.1901 | 0.994 | exponential | 3.12 | 56: 38/40 done (timex2) |

**xor3 {"extra": 5, "planted": false}** (x = n; gmean over instances/shuffles; fits use fully completed sizes only)

| series / order | pts | largest complete n | alloc there (gmean) | power exp b | tail b (last 4) | R2 pow | exp rate bits/var | tail rate | R2 exp | better fit | power exp vs N | first incomplete size |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| natural | 6 | 56 | 31481 | 3.32 | 4.91 | 0.931 | 0.1532 | 0.1659 | 0.984 | exponential | 3.26 | 64: 2/3 done (hard_killx1) |
| min_degree | 13 | 120 | 50490 | 2.59 | 3.04 | 0.955 | 0.0694 | 0.0433 | 0.986 | exponential | 2.43 | 96: 2/3 done (timex1) |
| min_fill | 14 | 120 | 44597 | 2.46 | 4.36 | 0.953 | 0.0658 | 0.0594 | 0.980 | exponential | 2.31 | 136: 1/3 done (timex2) |
| greedy_min | 3 | 32 | 736 | 1.45 | - | 1.000 | 0.0905 | - | 0.992 | power | 1.50 | 40: 1/3 done (order:timex2) |
| shuffle | 6 | 56 | 22691 | 3.24 | 5.05 | 0.939 | 0.1492 | 0.1705 | 0.991 | exponential | 3.19 | 64: 35/40 done (timex5) |

**xor_two_occ {"k": 4}** (x = n; gmean over instances/shuffles; fits use fully completed sizes only)

| series / order | pts | largest complete n | alloc there (gmean) | power exp b | tail b (last 4) | R2 pow | exp rate bits/var | tail rate | R2 exp | better fit | power exp vs N | first incomplete size |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| natural | 8 | 192 | 15589 | 1.53 | 1.46 | 0.999 | 0.0292 | 0.0175 | 0.878 | power | 1.29 | 128: 3/4 done (timex1) |
| reverse | 9 | 256 | 24650 | 1.49 | 1.55 | 0.998 | 0.0234 | 0.0137 | 0.894 | power | 1.26 | - |
| min_degree | 8 | 192 | 7913 | 1.25 | 1.22 | 0.999 | 0.0240 | 0.0147 | 0.881 | power | 1.06 | 128: 3/4 done (timex1) |
| min_fill | 8 | 192 | 7442 | 1.23 | 1.20 | 0.999 | 0.0236 | 0.0144 | 0.879 | power | 1.04 | 128: 3/4 done (timex1) |
| greedy_min | 3 | 32 | 846 | 1.31 | - | 0.999 | 0.0822 | - | 0.997 | power | 1.09 | 24: 1/4 done (order:timex3) |
| bfs | 8 | 192 | 32038 | 1.77 | 1.90 | 0.999 | 0.0343 | 0.0230 | 0.907 | power | 1.49 | 128: 3/4 done (timex1) |
| max_degree | 8 | 192 | 28244 | 1.68 | 1.75 | 0.999 | 0.0326 | 0.0211 | 0.904 | power | 1.42 | 128: 3/4 done (timex1) |
| greedy_max | 3 | 32 | 1421 | 1.59 | - | 1.000 | 0.0993 | - | 0.993 | power | 1.32 | 24: 0/4 done (order:timex4) |
| shuffle | 7 | 128 | 7884 | 1.42 | 1.42 | 1.000 | 0.0361 | 0.0248 | 0.924 | power | 1.20 | 96: 38/40 done (timex2) |

## E3 PHP(h+1, h)

Runs: {"runs": 302, "completed": 268, "verified": 268, "disagreements": 0, "unverified": 0, "capped": 32, "other": 2, "bad_examples": []}; non-completions: {"ORDER_TIMEOUT:order:time": 1, "CAP:time": 32, "ORDER_TIMEOUT:order:greedy chunks exhausted": 1}

| h | n vars | N bits | reverse | pigeon_major | hole_major | min_degree | min_fill | greedy_min | bfs | max_degree | greedy_max | #random | random min | random median | local-search min | MIN over all tried |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 2 | 6 | 174 | 48 | 48 | 49 | 47 | 47 | 47 | 48 | 48 | 49 | 200 | 45 | 48 |  | 45 |
| 3 | 12 | 532 | 194 | 194 | 179 | 166 | 152 | 154 | 192 | 194 | 241 | 200 | 144 | 185 | 137 | 137 |
| 4 | 20 | 1230 | 725 | 725 | 518 | 464 | 518 | 488 | 695 | 725 | 1164 | 200 | 586 | 824 | 375 | 375 |
| 5 | 30 | 2370 | 2717 | 2717 | 1373 | 1722 | 1259 | 1966 | 2152 | 2717 | 5404 | 200 | 2640 | 4640 | 837 | 837 |
| 6 | 42 | 4172 | 10071 | 10071 | 3520 | 7293 | 5436 | 5527 | 6288 | 10071 | 27053 | 200 | 19550 | 33754 | 2648 | 2648 |
| 7 | 56 | 6664 | 35985 | 35985 | 8873 | 29213 | 23297 | CAP:order:time | 17673 | 35985 | CAP:order:greedy chunks exhausted | 30 | 185462 | CAP |  | 8873 |
| 8 | 72 | 10098 | 122603 | 122603 | 22070 | 69944 | 86065 |  | 48068 | 122603 |  |  |  |  |  | 22070 |
| 9 | 90 | 14630 | CAP:time | CAP:time | 54161 | CAP:time | 251242 |  | 126906 | CAP:time |  |  |  |  |  | 54161 |
| 10 | 110 | 20262 |  |  | 131092 |  | CAP:time |  | CAP:time |  |  |  |  |  |  | 131092 |
| 11 | 132 | 27228 |  |  | CAP:time |  |  |  |  |  |  |  |  |  |  |  |

Growth per order (ratio alloc(h+1)/alloc(h); exponential rate in bits per hole and per variable; power-law exponent in n = h(h+1))

| order | h range | successive ratios | bits per h (all) | bits per h (last 5) | bits per var | power exp in n | R2 exp(n) | R2 pow(n) | local power exponents in n |
|---|---|---|---|---|---|---|---|---|---|
| reverse | 2..8 | [4.04, 3.74, 3.75, 3.71, 3.57, 3.41] | 1.887 | 1.853 | 0.1669 | 3.15 | 0.970 | 0.974 | [2.01, 2.58, 3.26, 3.89, 4.43, 4.88] |
| pigeon_major | 2..8 | [4.04, 3.74, 3.75, 3.71, 3.57, 3.41] | 1.887 | 1.853 | 0.1669 | 3.15 | 0.970 | 0.974 | [2.01, 2.58, 3.26, 3.89, 4.43, 4.88] |
| hole_major | 2..10 | [3.65, 2.89, 2.65, 2.56, 2.52, 2.49, 2.45, 2.42] | 1.396 | 1.305 | 0.1034 | 2.70 | 0.951 | 0.977 | [1.87, 2.08, 2.4, 2.8, 3.21, 3.63, 4.02, 4.4] |
| min_degree | 2..8 | [3.53, 2.8, 3.71, 4.24, 4.01, 2.39] | 1.804 | 1.856 | 0.1601 | 3.00 | 0.974 | 0.962 | [1.82, 2.01, 3.23, 4.29, 4.82, 3.47] |
| min_fill | 2..9 | [3.23, 3.41, 2.43, 4.32, 4.29, 3.69, 2.92] | 1.798 | 1.927 | 0.1464 | 3.20 | 0.979 | 0.950 | [1.69, 2.4, 2.19, 4.35, 5.06, 5.2, 4.8] |
| greedy_min | 2..6 | [3.28, 3.17, 4.03, 2.81] | 1.743 | 1.743 | 0.1903 | 2.46 | 0.980 | 0.978 | [1.71, 2.26, 3.44, 3.07] |
| bfs | 2..9 | [4.0, 3.62, 3.1, 2.92, 2.81, 2.72, 2.64] | 1.607 | 1.470 | 0.1290 | 2.91 | 0.950 | 0.983 | [2.0, 2.52, 2.79, 3.19, 3.59, 3.98, 4.35] |
| max_degree | 2..8 | [4.04, 3.74, 3.75, 3.71, 3.57, 3.41] | 1.887 | 1.853 | 0.1669 | 3.15 | 0.970 | 0.974 | [2.01, 2.58, 3.26, 3.89, 4.43, 4.88] |
| greedy_max | 2..6 | [4.92, 4.83, 4.64, 5.01] | 2.271 | 2.270 | 0.2480 | 3.21 | 0.983 | 0.979 | [2.3, 3.08, 3.79, 4.79] |
| random_min | 2..7 | [3.2, 4.07, 4.51, 7.41, 9.49] | 2.385 | 2.572 | 0.2377 | 3.60 | 0.999 | 0.921 | [1.68, 2.75, 3.71, 5.95, 7.82] |
| random_median | 2..6 | [3.85, 4.45, 5.63, 7.27] | 2.356 | 2.356 | 0.2600 | 3.29 | 0.997 | 0.952 | [1.95, 2.92, 4.26, 5.9] |
| search_min | 3..6 | [2.74, 2.23, 3.16] | 1.398 | 1.398 | 0.1391 | 2.30 | 0.994 | 0.982 | [1.97, 1.98, 3.42] |
| MIN_over_all_tried | 2..10 | [3.04, 2.74, 2.23, 3.16, 3.35, 2.49, 2.45, 2.42] | 1.451 | 1.387 | 0.1080 | 2.78 | 0.963 | 0.962 | [1.61, 1.97, 1.98, 3.42, 4.2, 3.63, 4.02, 4.4] |

**Exhaustive enumeration of ALL elimination orders**

| instance | n | orders | min alloc | #orders at min | median | max alloc | #orders at max | min peak reach | max peak reach | answers | disagreements |
|---|---|---|---|---|---|---|---|---|---|---|---|
| PHP(4,2) | 8 | 40320 | 59 | 576 | 72.0 | 82 | 384 | 33 | 33 | {"UNSAT": 40320} | 0 |
| PHP(3,2) | 6 | 720 | 45 | 24 | 48.0 | 50 | 96 | 22 | 22 | {"UNSAT": 720} | 0 |

## E4 random 3-CNF

Runs: {"runs": 1311, "completed": 1138, "verified": 1138, "disagreements": 0, "unverified": 0, "capped": 157, "other": 16, "bad_examples": []}; non-completions: {"CAP:time": 152, "ORDER_TIMEOUT:order:greedy chunks exhausted": 16, "CAP:hard_kill": 3, "CAP:task_alarm": 2}; expected-answer sources of completed runs: {"adversarial/oracle.py exhaustive (DPLL cross-checked)": 312, "own complete DPLL (not the project oracle)": 826}

**kcnf {"density": 2.0, "k": 3}: allocated nodes, structured orders (gmean over 3 instances)**

| n | n vars | N bits | natural | min_degree | min_fill | greedy_min |
|---|---|---|---|---|---|---|
| 12 | 12 | 790 | 275 | 202 | 195 | 156 |
| 16 | 16 | 1108 | 601 | 310 | 336 | 239 |
| 20 | 20 | 1451 | 1720 | 621 | 656 | 463 |
| 24 | 24 | 1790 | 4588 | 1005 | 940 | 705 |
| 28 | 28 | 2124 | 10437 | 1839 | 1376 | 891 |
| 32 | 32 | 2503 | 29289 | 3818 | 4298 | 2811 |
| 36 | 36 | 2921 | CAP(time) | 7964 | 7187 | 2894 |
| 40 | 40 | 3305 |  | 20131 | 11584 | 8210 |
| 44 | 44 | 3732 |  | >17753* (2/3) | 27262 | >14904* (2/3) |
| 48 | 48 | 4100 |  | 51298 | >26811* (2/3) | >14162* (1/3) |
| 52 | 52 | 4525 |  | 74118 | 68849 | 42237 |
| 56 | 56 | 4937 |  | CAP(time) | CAP(time) | CAP(order:greedy chunks exhausted) |

**kcnf {"density": 2.0, "k": 3}: random shuffles per instance (best / median)**

| n | n | shuffles completed | best | median |
|---|---|---|---|---|
| 12 | 12 | 40/40 | 180 | 255 |
| 16 | 16 | 40/40 | 473 | 630 |
| 20 | 20 | 40/40 | 815 | 1874 |
| 24 | 24 | 40/40 | 2095 | 4681 |
| 28 | 28 | 40/40 | 3765 | 12600 |
| 32 | 32 | 40/40 | 14837 | 36209 |
| 36 | 36 | 36/40 | 24810 | 73940 |
| 40 | 40 | 8/40 | 83244 | CAP |

best fit: {"points": 8, "power_exponent": 4.943, "power_r2": 0.9481, "exp_rate_bits": 0.3094, "exp_r2": 0.9916, "local_exponents": [3.36, 2.44, 5.18, 3.8, 10.27, 4.36, 11.49], "tail_power_exponent": 8.249, "tail_exp_rate_bits": 0.3536, "better_fit": "exponential"}

median fit: {"points": 7, "power_exponent": 5.265, "power_r2": 0.979, "exp_rate_bits": 0.348, "exp_r2": 0.9985, "local_exponents": [3.15, 4.88, 5.02, 6.42, 7.91, 6.06], "tail_power_exponent": 6.916, "tail_exp_rate_bits": 0.3367, "better_fit": "exponential"}

**kcnf {"density": 3.0, "k": 3}: allocated nodes, structured orders (gmean over 3 instances)**

| n | n vars | N bits | natural | min_degree | min_fill | greedy_min |
|---|---|---|---|---|---|---|
| 12 | 12 | 1173 | 389 | 346 | 346 | 284 |
| 16 | 16 | 1643 | 1078 | 713 | 717 | 579 |
| 20 | 20 | 2172 | 3544 | 1908 | 1929 | 1023 |
| 24 | 24 | 2677 | 7380 | 2021 | 2276 | 1544 |
| 28 | 28 | 3208 | 19953 | 6146 | 5289 | 6010 |
| 32 | 32 | 3786 | 55745 | 18239 | 18161 | 11437 |
| 36 | 36 | 4408 | CAP(time) | 42329 | 34339 | >28237* (2/3) |
| 40 | 40 | 4973 |  | 79071 | 74014 | CAP(order:greedy chunks exhausted) |
| 44 | 44 | 5602 |  | >134775* (1/3) | >119998* (1/3) |  |
| 48 | 48 | 6174 |  | CAP(time) | >208642* (1/3) |  |
| 52 | 52 | 6788 |  |  | CAP(time) |  |

**kcnf {"density": 3.0, "k": 3}: random shuffles per instance (best / median)**

| n | n | shuffles completed | best | median |
|---|---|---|---|---|
| 12 | 12 | 40/40 | 275 | 388 |
| 16 | 16 | 40/40 | 731 | 1159 |
| 20 | 20 | 40/40 | 2010 | 3532 |
| 24 | 24 | 40/40 | 2897 | 6058 |
| 28 | 28 | 40/40 | 12594 | 20226 |
| 32 | 32 | 40/40 | 24189 | 65306 |
| 36 | 36 | 24/40 | 58003 | CAP |
| 40 | 40 | 0/40 | CAP | CAP |

best fit: {"points": 7, "power_exponent": 4.839, "power_r2": 0.9674, "exp_rate_bits": 0.3205, "exp_r2": 0.9906, "local_exponents": [3.39, 4.53, 2.0, 9.53, 4.89, 7.43], "tail_power_exponent": 7.18, "tail_exp_rate_bits": 0.3478, "better_fit": "exponential"}

median fit: {"points": 6, "power_exponent": 5.026, "power_r2": 0.97, "exp_rate_bits": 0.3581, "exp_r2": 0.9925, "local_exponents": [3.8, 4.99, 2.96, 7.82, 8.78], "tail_power_exponent": 6.27, "tail_exp_rate_bits": 0.3591, "better_fit": "exponential"}

**kcnf {"density": 4.26, "k": 3}: allocated nodes, structured orders (gmean over 3 instances)**

| n | n vars | N bits | natural | min_degree | min_fill | greedy_min |
|---|---|---|---|---|---|---|
| 12 | 12 | 1657 | 446 | 369 | 386 | 321 |
| 16 | 16 | 2316 | 966 | 800 | 883 | 665 |
| 20 | 20 | 3093 | 3114 | 2048 | 1965 | 1376 |
| 24 | 24 | 3823 | 5490 | 3028 | 3184 | 2425 |
| 28 | 28 | 4566 | 12168 | 7823 | 6968 | 5459 |
| 32 | 32 | 5334 | 22886 | 10774 | 11020 | 11805 |
| 36 | 36 | 6240 | 108247 | 32532 | 32014 | >22773* (1/3) |
| 40 | 40 | 7053 | >98477* (1/3) | 58529 | 64325 | >40255* (2/3) |
| 44 | 44 | 7937 | CAP(time) | >38847* (1/3) | >77473* (1/3) | CAP(order:greedy chunks exhausted) |
| 48 | 48 | 8767 |  | CAP(time) | CAP(time) |  |

**kcnf {"density": 4.26, "k": 3}: random shuffles per instance (best / median)**

| n | n | shuffles completed | best | median |
|---|---|---|---|---|
| 12 | 12 | 40/40 | 292 | 426 |
| 16 | 16 | 40/40 | 649 | 1033 |
| 20 | 20 | 40/40 | 1348 | 2539 |
| 24 | 24 | 40/40 | 3493 | 5280 |
| 28 | 28 | 40/40 | 7247 | 15913 |
| 32 | 32 | 40/40 | 13847 | 33187 |
| 36 | 36 | 34/40 | 37306 | 71278 |
| 40 | 40 | 22/40 | 35364 | CAP |

best fit: {"points": 8, "power_exponent": 4.311, "power_r2": 0.9789, "exp_rate_bits": 0.2643, "exp_r2": 0.9828, "local_exponents": [2.78, 3.28, 5.22, 4.73, 4.85, 8.41, -0.51], "tail_power_exponent": 4.891, "tail_exp_rate_bits": 0.2073, "better_fit": "exponential"}

median fit: {"points": 7, "power_exponent": 4.702, "power_r2": 0.9779, "exp_rate_bits": 0.3109, "exp_r2": 0.9981, "local_exponents": [3.08, 4.03, 4.02, 7.16, 5.5, 6.49], "tail_power_exponent": 6.34, "tail_exp_rate_bits": 0.3081, "better_fit": "exponential"}

**kcnf {"density": 2.0, "k": 3} fits** (x = n)

| series / order | pts | largest complete n | alloc there (gmean) | power exp b | tail b (last 4) | R2 pow | exp rate bits/var | tail rate | R2 exp | better fit | power exp vs N | first incomplete size |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| natural | 6 | 32 | 29289 | 4.75 | 5.93 | 0.975 | 0.3389 | 0.3364 | 0.999 | exponential | 4.05 | 36: 0/3 done (timex3) |
| min_degree | 10 | 52 | 74118 | 4.26 | 5.91 | 0.947 | 0.2250 | 0.1947 | 0.994 | exponential | 3.58 | 44: 2/3 done (timex1) |
| min_fill | 10 | 52 | 68849 | 4.03 | 6.34 | 0.941 | 0.2177 | 0.2085 | 0.992 | exponential | 3.39 | 48: 2/3 done (timex1) |
| greedy_min | 9 | 52 | 42237 | 3.69 | 5.99 | 0.917 | 0.2031 | 0.2087 | 0.986 | exponential | 3.10 | 44: 2/3 done (order:greedy chunks exhaustedx1) |
| shuffle | 6 | 32 | 36388 | 4.97 | 6.40 | 0.975 | 0.3547 | 0.3635 | 0.999 | exponential | 4.20 | 36: 36/40 done (timex4) |

**kcnf {"density": 3.0, "k": 3} fits** (x = n)

| series / order | pts | largest complete n | alloc there (gmean) | power exp b | tail b (last 4) | R2 pow | exp rate bits/var | tail rate | R2 exp | better fit | power exp vs N | first incomplete size |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| natural | 6 | 32 | 55745 | 4.99 | 5.86 | 0.984 | 0.3535 | 0.3340 | 0.997 | exponential | 4.18 | 36: 0/3 done (timex3) |
| min_degree | 8 | 40 | 79071 | 4.55 | 7.19 | 0.941 | 0.2848 | 0.3068 | 0.985 | exponential | 3.79 | 44: 1/3 done (timex2) |
| min_fill | 8 | 40 | 74014 | 4.43 | 7.23 | 0.946 | 0.2768 | 0.3085 | 0.988 | exponential | 3.69 | 44: 1/3 done (timex2) |
| greedy_min | 6 | 32 | 11437 | 3.70 | 5.44 | 0.929 | 0.2671 | 0.3102 | 0.974 | exponential | 3.10 | 36: 2/3 done (order:greedy chunks exhaustedx1) |
| shuffle | 6 | 32 | 55572 | 4.96 | 6.12 | 0.975 | 0.3525 | 0.3491 | 0.994 | exponential | 4.14 | 36: 24/40 done (timex16) |

**kcnf {"density": 4.26, "k": 3} fits** (x = n)

| series / order | pts | largest complete n | alloc there (gmean) | power exp b | tail b (last 4) | R2 pow | exp rate bits/var | tail rate | R2 exp | better fit | power exp vs N | first incomplete size |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| natural | 7 | 36 | 108247 | 4.68 | 7.00 | 0.953 | 0.3113 | 0.3454 | 0.985 | exponential | 3.90 | 40: 1/3 done (timex2) |
| min_degree | 8 | 40 | 58529 | 4.15 | 5.97 | 0.968 | 0.2573 | 0.2576 | 0.992 | exponential | 3.45 | 44: 1/3 done (timex2) |
| min_fill | 8 | 40 | 64325 | 4.12 | 6.47 | 0.963 | 0.2564 | 0.2790 | 0.994 | exponential | 3.43 | 44: 1/3 done (timex2) |
| greedy_min | 6 | 32 | 11805 | 3.60 | 4.60 | 0.974 | 0.2566 | 0.2618 | 0.998 | exponential | 3.00 | 36: 1/3 done (order:greedy chunks exhaustedx2) |
| shuffle | 6 | 32 | 30975 | 4.42 | 5.48 | 0.982 | 0.3140 | 0.3104 | 0.999 | exponential | 3.68 | 36: 34/40 done (timex6) |

## E5 2-SAT / Horn hunt

Runs: {"runs": 2649, "completed": 2358, "verified": 2358, "disagreements": 0, "unverified": 0, "capped": 265, "other": 26, "bad_examples": []}; non-completions: {"CAP:time": 265, "ORDER_TIMEOUT:order:greedy chunks exhausted": 26}

**rand2cnf {"density": 0.9}: allocated nodes (gmean over instances / shuffles)**

| n | n vars | N bits | natural | reverse | min_degree | min_fill | greedy_min | bfs | scc_topo | scc_topo_rev | max_degree | shuffle |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 20 | 20 | 461 | 89 | 83 | 73 | 74 | 65 | 87 | 78 | 86 | 85 | 83 |
| 40 | 40 | 1034 | 271 | 255 | 184 | 182 | 144 | 241 | 229 | 263 | 360 | 241 |
| 80 | 80 | 2309 | 554 | 914 | 402 | 405 | 327 | 588 | 538 | 531 | 4621 | 905 |
| 160 | 160 | 5193 | 2998 | 5441 | 807 | 807 | 618 | 1868 | 1363 | 5393 | CAP(time) | 8653 |
| 320 | 320 | 11478 | >5386* (1/2) | CAP(time) | 1994 | 1900 | CAP(order:greedy chunks exhausted) | 2693 | 4792 | >8648* (1/2) |  | >3931* (2/6) |
| 640 | 640 | 25222 | CAP(time) |  | CAP(time) | CAP(time) |  | CAP(time) | CAP(time) | CAP(time) |  |  |

**rand2cnf {"density": 1.0}: allocated nodes (gmean over instances / shuffles)**

| n | n vars | N bits | natural | reverse | min_degree | min_fill | greedy_min | bfs | scc_topo | scc_topo_rev | max_degree | shuffle |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 20 | 20 | 510 | 141 | 102 | 88 | 90 | 74 | 113 | 88 | 102 | 122 | 105 |
| 40 | 40 | 1140 | 308 | 308 | 237 | 235 | 162 | 326 | 286 | 298 | 1130 | 322 |
| 80 | 80 | 2561 | 973 | 1096 | 543 | 520 | 374 | 734 | 811 | 776 | 6773 | 837 |
| 160 | 160 | 5765 | 6434 | 17316 | 1525 | 1628 | 682 | 2086 | 1665 | 16832 | CAP(time) | >10103* (5/6) |
| 320 | 320 | 12737 | CAP(time) | CAP(time) | 4482 | 5236 | CAP(order:greedy chunks exhausted) | >9951* (1/2) | >3281* (1/2) | CAP(time) |  | CAP(time) |
| 640 | 640 | 28042 |  |  | CAP(time) | CAP(time) |  | CAP(time) | CAP(time) |  |  |  |

**rand2cnf {"density": 1.5}: allocated nodes (gmean over instances / shuffles)**

| n | n vars | N bits | natural | reverse | min_degree | min_fill | greedy_min | bfs | scc_topo | scc_topo_rev | max_degree | shuffle |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 20 | 20 | 753 | 349 | 146 | 153 | 154 | 89 | 158 | 252 | 146 | 296 | 210 |
| 40 | 40 | 1691 | 581 | 602 | 744 | 581 | 279 | 427 | 756 | 511 | 881 | 683 |
| 80 | 80 | 3859 | 3801 | 646 | 930 | 865 | 252 | 634 | 1104 | 723 | 2116 | 1105 |
| 160 | 160 | 8662 | CAP(time) | >15445* (1/2) | 10034 | 8167 | 571 | 9820 | >80869* (1/2) | 7431 | >37206* (1/2) | >8455* (2/6) |
| 320 | 320 | 19106 |  | CAP(time) | CAP(time) | CAP(time) | CAP(order:greedy chunks exhausted) | >21481* (1/2) | CAP(time) | >39524* (1/2) | CAP(time) |  |
| 640 | 640 | 42013 |  |  |  |  |  | CAP(time) |  | CAP(time) |  |  |

**regular_2cnf {"d": 3, "mode": "impl"}: allocated nodes (gmean over instances / shuffles)**

| nv | n vars | N bits | natural | reverse | min_degree | min_fill | greedy_min | bfs | scc_topo | scc_topo_rev | max_degree | shuffle |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 10 | 10 | 324 | 85 | 91 | 79 | 86 | 67 | 77 | 91 | 86 | 96 | 94 |
| 14 | 14 | 480 | 164 | 197 | 180 | 138 | 104 | 129 | 137 | 145 | 162 | 165 |
| 20 | 20 | 744 | 267 | 241 | 297 | 198 | 125 | 258 | 191 | 177 | 270 | 266 |
| 28 | 28 | 1104 | 502 | 603 | 586 | 435 | 217 | 385 | 355 | 333 | 715 | 575 |
| 40 | 40 | 1698 | 1652 | 795 | 1948 | 1429 | 285 | 807 | 591 | 532 | 1643 | 1011 |
| 56 | 56 | 2514 | 2544 | 3848 | 4756 | 1844 | 433 | 775 | 852 | 1455 | 2338 | 2501 |
| 80 | 80 | 3840 | 12859 | 24831 | 39884 | 22548 | 664 | 1291 | 2201 | 3753 | 5027 | 8532 |
| 112 | 112 | 5664 | 65460 | >27216* (1/3) | >58494* (1/3) | >57870* (2/3) | 820 | 3021 | 2040 | 4729 | >27908* (2/3) | >18580* (6/9) |
| 160 | 160 | 8598 | CAP(time) |  |  | CAP(time) | 1273 | 12256 | 4767 | >10731* (2/3) | CAP(time) | CAP(time) |
| 224 | 224 | 12630 |  |  |  |  | CAP(order:greedy chunks exhausted) | >9463* (1/3) | 11493 | CAP(time) |  |  |
| 320 | 320 | 19068 |  |  |  |  |  |  | >17147* (2/3) |  |  |  |

**regular_2cnf {"d": 3, "mode": "planted"}: allocated nodes (gmean over instances / shuffles)**

| nv | n vars | N bits | natural | reverse | min_degree | min_fill | greedy_min | bfs | scc_topo | scc_topo_rev | max_degree | shuffle |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 10 | 10 | 324 | 86 | 82 | 77 | 72 | 63 | 85 | 92 | 83 | 93 | 100 |
| 14 | 14 | 480 | 177 | 139 | 167 | 131 | 94 | 129 | 144 | 135 | 179 | 154 |
| 20 | 20 | 744 | 228 | 287 | 224 | 229 | 123 | 165 | 174 | 209 | 215 | 227 |
| 28 | 28 | 1104 | 401 | 563 | 442 | 318 | 184 | 281 | 299 | 376 | 363 | 464 |
| 40 | 40 | 1698 | 1509 | 1073 | 2413 | 1460 | 274 | 452 | 756 | 863 | 1112 | 952 |
| 56 | 56 | 2514 | 3067 | 1892 | 8599 | 2570 | 360 | 763 | 1390 | 891 | 2834 | 3270 |
| 80 | 80 | 3840 | 28582 | 11143 | >48614* (2/3) | >19524* (2/3) | 574 | 964 | 8129 | 8061 | 3785 | 16660 |
| 112 | 112 | 5664 | >29697* (2/3) | 40767 | >47424* (1/3) | CAP(time) | 797 | 1770 | 10364 | 30834 | >16911* (1/3) | >20617* (8/9) |
| 160 | 160 | 8598 | CAP(time) | CAP(time) |  |  | 1164 | 4137 | >36269* (1/3) | CAP(time) |  | CAP(time) |
| 224 | 224 | 12630 |  |  |  |  | 1592 | 9410 |  |  |  |  |
| 320 | 320 | 19068 |  |  |  |  | CAP(order:greedy chunks exhausted) | 9986 |  |  |  |  |

**regular_2cnf {"d": 3, "mode": "rand"}: allocated nodes (gmean over instances / shuffles)**

| nv | n vars | N bits | natural | reverse | min_degree | min_fill | greedy_min | bfs | scc_topo | scc_topo_rev | max_degree | shuffle |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 10 | 10 | 324 | 90 | 85 | 78 | 84 | 62 | 79 | 99 | 91 | 86 | 89 |
| 14 | 14 | 480 | 152 | 157 | 181 | 113 | 89 | 126 | 156 | 108 | 157 | 123 |
| 20 | 20 | 744 | 203 | 286 | 212 | 156 | 114 | 165 | 175 | 227 | 235 | 226 |
| 28 | 28 | 1104 | 383 | 602 | 623 | 386 | 195 | 407 | 372 | 558 | 531 | 435 |
| 40 | 40 | 1698 | 1081 | 684 | 1123 | 1150 | 269 | 432 | 569 | 546 | 974 | 1089 |
| 56 | 56 | 2514 | 2183 | 2713 | 7222 | 3447 | 411 | 874 | 1133 | 1704 | 1934 | 2763 |
| 80 | 80 | 3840 | 9263 | 8526 | 39751 | 24264 | 620 | 2086 | 2344 | 4112 | 15889 | 7755 |
| 112 | 112 | 5664 | >14760* (1/3) | CAP(time) | >56293* (1/3) | >72956* (1/3) | 920 | 4747 | 5675 | 11282 | CAP(time) | >29191* (3/9) |
| 160 | 160 | 8598 |  |  |  |  | 1359 | 9975 | 17924 | >6357* (1/3) |  |  |
| 224 | 224 | 12630 |  |  |  |  | 1861 | 16812 | CAP(time) |  |  |  |
| 320 | 320 | 19068 |  |  |  |  | CAP(order:greedy chunks exhausted) | CAP(time) |  |  |  |  |

**regular_2cnf {"d": 4, "mode": "planted"}: allocated nodes (gmean over instances / shuffles)**

| nv | n vars | N bits | natural | reverse | min_degree | min_fill | greedy_min | bfs | scc_topo | scc_topo_rev | max_degree | shuffle |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 10 | 10 | 432 | 106 | 91 | 104 | 90 | 77 | 99 | 110 | 102 | 109 | 112 |
| 14 | 14 | 640 | 236 | 151 | 276 | 212 | 149 | 232 | 185 | 228 | 223 | 183 |
| 20 | 20 | 992 | 338 | 525 | 433 | 300 | 204 | 417 | 419 | 345 | 523 | 402 |
| 28 | 28 | 1472 | 962 | 1252 | 1266 | 1020 | 310 | 408 | 765 | 834 | 1035 | 840 |
| 40 | 40 | 2264 | 2500 | 3452 | 4321 | 3193 | 559 | 1329 | 1940 | 2545 | 4129 | 2818 |
| 56 | 56 | 3352 | 16036 | 7783 | 12492 | 28448 | 1482 | 7370 | 14635 | 5923 | 20937 | 11470 |
| 80 | 80 | 5120 | >37975* (2/3) | >103542* (2/3) | CAP(time) | >76526* (2/3) | 2920 | 16381 | 60497 | 24971 | >24894* (1/3) | >45478* (6/9) |
| 112 |  |  |  |  |  |  | CAP(order:greedy chunks exhausted) |  |  |  |  |  |

**regular_2cnf {"d": 4, "mode": "rand"}: allocated nodes (gmean over instances / shuffles)**

| nv | n vars | N bits | natural | reverse | min_degree | min_fill | greedy_min | bfs | scc_topo | scc_topo_rev | max_degree | shuffle |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 10 | 10 | 432 | 101 | 100 | 118 | 90 | 75 | 96 | 118 | 91 | 106 | 92 |
| 14 | 14 | 640 | 188 | 152 | 210 | 168 | 124 | 151 | 161 | 169 | 216 | 192 |
| 20 | 20 | 992 | 293 | 319 | 296 | 231 | 172 | 201 | 349 | 362 | 309 | 317 |
| 28 | 28 | 1472 | 753 | 588 | 1121 | 783 | 282 | 368 | 608 | 1065 | 942 | 837 |
| 40 | 40 | 2264 | 2039 | 1446 | 1291 | 1386 | 380 | 693 | 1384 | 1456 | 3871 | 1523 |
| 56 | 56 | 3352 | 3458 | 3387 | 5765 | 13273 | 555 | 1310 | 3687 | 3050 | 4710 | 3120 |
| 80 | 80 | 5120 | 9940 | 8773 | 10148 | 18613 | 688 | 5640 | 7778 | 4335 | 50338 | 11911 |
| 112 | 112 | 7552 | 33706 | >11092* (2/3) | >78561* (2/3) | >94647* (1/3) | 1026 | 3621 | 30228 | >6125* (2/3) | CAP(time) | >39523* (7/9) |
| 160 | 160 | 11464 | CAP(time) | >89659* (2/3) | CAP(time) |  | 1498 | 29691 | CAP(time) | >89600* (1/3) |  | CAP(time) |
| 224 | 224 | 16840 |  | CAP(time) |  |  | 1869 | 15345 |  |  |  |  |
| 320 | 320 | 25424 |  |  |  |  | CAP(order:greedy chunks exhausted) | CAP(time) |  |  |  |  |

**regular_2cnf {"d": 5, "mode": "planted"}: allocated nodes (gmean over instances / shuffles)**

| nv | n vars | N bits | natural | reverse | min_degree | min_fill | greedy_min | bfs | scc_topo | scc_topo_rev | max_degree | shuffle |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 10 | 10 | 540 | 109 | 120 | 109 | 106 | 87 | 92 | 134 | 112 | 115 | 119 |
| 14 | 14 | 800 | 200 | 207 | 245 | 172 | 124 | 179 | 211 | 200 | 208 | 219 |
| 20 | 20 | 1240 | 381 | 283 | 488 | 348 | 176 | 306 | 442 | 406 | 413 | 325 |
| 28 | 28 | 1840 | 896 | 1148 | 1533 | 763 | 244 | 735 | 961 | 804 | 865 | 974 |
| 40 | 40 | 2830 | 2603 | 1734 | 3971 | 3000 | 523 | 1797 | 2916 | 1229 | 3530 | 2232 |
| 56 | 56 | 4190 | 10328 | 7860 | 14574 | 25439 | 1107 | 3073 | 10659 | 10401 | 21019 | 5536 |
| 80 | 80 | 6400 | 49960 | 19924 | CAP(time) | 61714 | 1621 | 11399 | 44617 | 17395 | 51192 | 31856 |

**grid_2cnf {"mode": "impl"}: allocated nodes (gmean over instances / shuffles)**

| a | n vars | N bits | natural | reverse | min_degree | min_fill | greedy_min | bfs | scc_topo | scc_topo_rev | max_degree | shuffle |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 4 | 16 | 566 | 165 | 160 | 138 | 138 | 111 | 163 | 139 | 135 | 239 | 172 |
| 6 | 36 | 1672 | 534 | 572 | 670 | 424 | 325 | 428 | 438 | 443 | 1315 | 1037 |
| 8 | 64 | 3436 | 1322 | 1392 | 3624 | 2216 | 692 | 976 | 1534 | 1588 | 6690 | 6114 |
| 10 | 100 | 6014 | 2400 | 2342 | 11263 | 7223 | 1249 | 2161 | 2093 | 2045 | 34325 | 16911 |
| 12 | 144 | 9316 | 4273 | 4326 | CAP(time) | 29594 | 2279 | 3861 | 4123 | 4143 | CAP(time) | >45935* (5/6) |
| 14 | 196 | 13524 | 6410 | 7049 |  | CAP(time) | CAP(order:greedy chunks exhausted) | 5480 | 5365 | 5387 |  | CAP(time) |

**grid_2cnf {"mode": "planted"}: allocated nodes (gmean over instances / shuffles)**

| a | n vars | N bits | natural | reverse | min_degree | min_fill | greedy_min | bfs | scc_topo | scc_topo_rev | max_degree | shuffle |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 4 | 16 | 566 | 155 | 143 | 136 | 136 | 103 | 144 | 136 | 160 | 171 | 185 |
| 6 | 36 | 1672 | 459 | 488 | 443 | 572 | 266 | 385 | 677 | 473 | 1228 | 870 |
| 8 | 64 | 3436 | 940 | 887 | 3418 | 1362 | 601 | 683 | 1308 | 1221 | 7706 | 5582 |
| 10 | 100 | 6014 | 1863 | 1745 | 9557 | 9712 | 1016 | 1317 | 4251 | 2257 | 64108 | >28004* (4/6) |
| 12 | 144 | 9316 | 3022 | 2710 | CAP(time) | 25881 | 1463 | 1932 | 5339 | 6069 | CAP(time) | >47663* (3/6) |
| 14 | 196 | 13524 | 4672 | 3740 |  | CAP(time) | 2131 | 2922 | 7961 | 6383 |  | >106862* (1/6) |
| 16 | 256 | 18394 | 5968 | 6683 |  |  | CAP(order:greedy chunks exhausted) | 3820 | 11173 | >7766* (1/2) |  |  |

**random_horn3 {"density": 2.0, "facts": 0, "goals": 0}: allocated nodes (gmean over instances / shuffles)**

| n | n vars | N bits | natural | reverse | min_degree | min_fill | greedy_min | bfs | max_degree | shuffle |
|---|---|---|---|---|---|---|---|---|---|---|
| 12 | 12 | 790 | 239 | 226 | 163 | 162 | 129 | 223 | 264 | 235 |
| 16 | 16 | 1135 | 429 | 491 | 316 | 290 | 258 | 469 | 940 | 482 |
| 20 | 20 | 1485 | 973 | 870 | 486 | 366 | 271 | 762 | 2196 | 891 |
| 24 | 24 | 1825 | 4002 | 2038 | 973 | 887 | 329 | 2561 | 6885 | 2761 |
| 28 | 28 | 2178 | 6525 | 9707 | 1074 | 916 | 261 | 4046 | 24163 | 7008 |
| 32 | 32 | 2489 | 20401 | 22737 | 3526 | 2714 | 658 | 10660 | 53751 | 17964 |
| 36 | 36 | 2908 | >60987* (1/3) | 33539 | 4556 | 4961 | 413 | >29816* (2/3) | CAP(time) | >28547* (7/9) |
| 40 | 40 | 3326 |  | >48641* (1/3) | 8473 | 7175 | 1767 | >29335* (2/3) |  | >38402* (3/9) |
| 48 | 48 | 4128 |  |  | 31350 | 21118 | >3179* (2/3) | CAP(time) |  |  |
| 56 | 56 | 4903 |  |  | >88576* (2/3) | >60650* (2/3) | >14221* (2/3) |  |  |  |
| 64 |  |  |  |  |  |  | CAP(order:greedy chunks exhausted) |  |  |  |

**E5 overview.** "best order" = the order that completed at the largest size (ties: fewest nodes there); its own fit is shown, then per-order cells "n<=largest fully completed n: gmean alloc there; b = power exponent, r = exponential rate in bits/variable (better-fitting model)".

| family | fixed params | best order | its largest n | alloc there | power exp | tail power exp | exp rate bits/var | R2 pow | R2 exp | better fit | greedy_min | bfs | min_degree | min_fill | natural | shuffle |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| rand2cnf | {"density": 0.9} | min_fill | 320 | 1900 | 1.15 | 1.11 | 0.0138 | 0.998 | 0.862 | power | n<=160: 618; b=1.09, tail b=1.09, r=0.021 (power) | n<=320: 2693; b=1.29, tail b=1.21, r=0.015 (power) | n<=320: 1994; b=1.17, tail b=1.13, r=0.014 (power) | n<=320: 1900; b=1.15, tail b=1.11, r=0.014 (power) | n<=160: 2998; b=1.62, tail b=1.62, r=0.034 (power) | n<=160: 8653; b=2.20, tail b=2.20, r=0.046 (exponential) |
| rand2cnf | {"density": 1.0} | min_degree | 320 | 4482 | 1.40 | 1.42 | 0.0172 | 0.998 | 0.894 | power | n<=160: 682; b=1.08, tail b=1.08, r=0.021 (power) | n<=160: 2086; b=1.38, tail b=1.38, r=0.028 (power) | n<=320: 4482; b=1.40, tail b=1.42, r=0.017 (power) | n<=320: 5236; b=1.45, tail b=1.51, r=0.018 (power) | n<=160: 6434; b=1.82, tail b=1.82, r=0.038 (exponential) | n<=80: 837; b=1.50, tail b=-, r=0.048 (power) |
| rand2cnf | {"density": 1.5} | greedy_min | 160 | 571 | 0.79 | 0.79 | 0.0155 | 0.852 | 0.750 | power | n<=160: 571; b=0.79, tail b=0.79, r=0.015 (power) | n<=160: 9820; b=1.84, tail b=1.84, r=0.041 (exponential) | n<=160: 10034; b=1.84, tail b=1.84, r=0.039 (exponential) | n<=160: 8167; b=1.78, tail b=1.78, r=0.038 (exponential) | n<=80: 3801; b=1.72, tail b=-, r=0.059 (exponential) | n<=80: 1105; b=1.20, tail b=-, r=0.037 (power) |
| regular_2cnf | {"d": 3, "mode": "impl"} | scc_topo | 224 | 11493 | 1.51 | 1.69 | 0.0305 | 0.984 | 0.892 | power | n<=160: 1273; b=1.06, tail b=0.99, r=0.026 (power) | n<=160: 12256; b=1.62, tail b=2.62, r=0.043 (power) | n<=80: 39884; b=2.79, tail b=3.89, r=0.122 (exponential) | n<=80: 22548; b=2.46, tail b=3.48, r=0.109 (exponential) | n<=112: 65460; b=2.63, tail b=3.68, r=0.091 (exponential) | n<=80: 8532; b=2.09, tail b=2.58, r=0.089 (exponential) |
| regular_2cnf | {"d": 3, "mode": "planted"} | bfs | 320 | 9986 | 1.45 | 1.72 | 0.0225 | 0.983 | 0.867 | power | n<=224: 1592; b=1.05, tail b=1.00, r=0.021 (power) | n<=320: 9986; b=1.45, tail b=1.72, r=0.022 (power) | n<=56: 8599; b=2.67, tail b=3.67, r=0.147 (exponential) | n<=56: 2570; b=2.10, tail b=2.55, r=0.113 (exponential) | n<=80: 28582; b=2.58, tail b=3.88, r=0.114 (exponential) | n<=80: 16660; b=2.36, tail b=3.43, r=0.104 (exponential) |
| regular_2cnf | {"d": 3, "mode": "rand"} | greedy_min | 224 | 1861 | 1.12 | 1.07 | 0.0220 | 0.998 | 0.849 | power | n<=224: 1861; b=1.12, tail b=1.07, r=0.022 (power) | n<=224: 16812; b=1.77, tail b=2.03, r=0.036 (power) | n<=80: 39751; b=2.86, tail b=4.11, r=0.126 (exponential) | n<=80: 24264; b=2.66, tail b=3.88, r=0.118 (exponential) | n<=80: 9263; b=2.15, tail b=2.95, r=0.094 (exponential) | n<=80: 7755; b=2.19, tail b=2.75, r=0.093 (exponential) |
| regular_2cnf | {"d": 4, "mode": "planted"} | greedy_min | 80 | 2920 | 1.70 | 2.21 | 0.0725 | 0.975 | 0.968 | power | n<=80: 2920; b=1.70, tail b=2.21, r=0.072 (power) | n<=80: 16381; b=2.41, tail b=3.67, r=0.104 (exponential) | n<=56: 12492; b=2.75, tail b=3.28, r=0.147 (power) | n<=56: 28448; b=3.15, tail b=4.29, r=0.174 (exponential) | n<=56: 16036; b=2.74, tail b=3.63, r=0.151 (exponential) | n<=56: 11470; b=2.65, tail b=3.27, r=0.144 (exponential) |
| regular_2cnf | {"d": 4, "mode": "rand"} | greedy_min | 224 | 1869 | 1.02 | 0.98 | 0.0196 | 0.994 | 0.809 | power | n<=224: 1869; b=1.02, tail b=0.98, r=0.020 (power) | n<=224: 15345; b=1.86, tail b=1.50, r=0.037 (power) | n<=80: 10148; b=2.21, tail b=2.32, r=0.093 (power) | n<=80: 18613; b=2.73, tail b=3.36, r=0.116 (power) | n<=112: 33706; b=2.37, tail b=2.75, r=0.080 (power) | n<=80: 11911; b=2.24, tail b=2.49, r=0.094 (power) |
| regular_2cnf | {"d": 5, "mode": "planted"} | greedy_min | 80 | 1621 | 1.47 | 1.84 | 0.0621 | 0.975 | 0.954 | power | n<=80: 1621; b=1.47, tail b=1.84, r=0.062 (power) | n<=80: 11399; b=2.26, tail b=2.52, r=0.095 (power) | n<=56: 14574; b=2.81, tail b=3.23, r=0.150 (power) | n<=80: 61714; b=3.22, tail b=4.39, r=0.139 (exponential) | n<=80: 49960; b=2.91, tail b=3.85, r=0.126 (exponential) | n<=80: 31856; b=2.59, tail b=3.26, r=0.112 (exponential) |
| grid_2cnf | {"mode": "impl"} | scc_topo | 196 | 5365 | 1.49 | 1.18 | 0.0271 | 0.988 | 0.842 | power | n<=144: 2279; b=1.36, tail b=1.39, r=0.032 (power) | n<=196: 5480; b=1.45, tail b=1.56, r=0.027 (power) | n<=100: 11263; b=2.43, tail b=2.43, r=0.075 (power) | n<=144: 29594; b=2.44, tail b=3.00, r=0.060 (exponential) | n<=196: 6410; b=1.47, tail b=1.43, r=0.027 (power) | n<=100: 16911; b=2.55, tail b=2.55, r=0.078 (power) |
| grid_2cnf | {"mode": "planted"} | bfs | 256 | 3820 | 1.19 | 1.15 | 0.0180 | 0.999 | 0.874 | power | n<=196: 2131; b=1.22, tail b=1.12, r=0.022 (power) | n<=256: 3820; b=1.19, tail b=1.15, r=0.018 (power) | n<=100: 9557; b=2.39, tail b=2.39, r=0.075 (power) | n<=144: 25881; b=2.39, tail b=2.87, r=0.059 (exponential) | n<=256: 5968; b=1.34, tail b=1.26, r=0.020 (power) | n<=64: 5582; b=2.42, tail b=-, r=0.102 (exponential) |
| random_horn3 | {"density": 2.0, "facts": 0, "goals": 0} | min_fill | 48 | 21118 | 3.51 | 4.99 | 0.1996 | 0.937 | 0.987 | exponential | n<=40: 1767; b=1.56, tail b=4.38, r=0.099 (exponential) | n<=32: 10660; b=3.89, tail b=5.36, r=0.279 (exponential) | n<=48: 31350; b=3.64, tail b=5.55, r=0.207 (exponential) | n<=48: 21118; b=3.51, tail b=4.99, r=0.200 (exponential) | n<=32: 20401; b=4.57, tail b=6.15, r=0.328 (exponential) | n<=32: 17964; b=4.42, tail b=6.35, r=0.318 (exponential) |

**Induced width of the order vs allocated nodes** (2-CNF on random d-regular graphs, all sign modes and seeds pooled; gmean over the runs that completed)

| n | d | order | median induced width | completed | gmean alloc |
|---|---|---|---|---|---|
| 56 | 3 | natural | 18 | 9/9 | 2573 |
| 56 | 3 | reverse | 17 | 9/9 | 2703 |
| 56 | 3 | min_degree | 11 | 9/9 | 6660 |
| 56 | 3 | min_fill | 10 | 9/9 | 2538 |
| 56 | 3 | greedy_min | 16 | 9/9 | 400 |
| 56 | 3 | bfs | 14 | 9/9 | 802 |
| 56 | 3 | scc_topo | 19 | 9/9 | 1103 |
| 56 | 3 | scc_topo_rev | 18 | 9/9 | 1302 |
| 56 | 3 | max_degree | 26 | 9/9 | 2340 |
| 56 | 3 | shuffle | 18 | 27/27 | 2827 |
| 56 | 4 | natural | 25 | 6/6 | 7446 |
| 56 | 4 | reverse | 27 | 6/6 | 5134 |
| 56 | 4 | min_degree | 17 | 6/6 | 8486 |
| 56 | 4 | min_fill | 17 | 6/6 | 19432 |
| 56 | 4 | greedy_min | 26 | 6/6 | 907 |
| 56 | 4 | bfs | 25 | 6/6 | 3107 |
| 56 | 4 | scc_topo | 26 | 6/6 | 7346 |
| 56 | 4 | scc_topo_rev | 26 | 6/6 | 4251 |
| 56 | 4 | max_degree | 36 | 6/6 | 9930 |
| 56 | 4 | shuffle | 26 | 18/18 | 5982 |
| 56 | 5 | natural | 30 | 2/2 | 10328 |
| 56 | 5 | reverse | 29 | 2/2 | 7860 |
| 56 | 5 | min_degree | 22 | 2/2 | 14574 |
| 56 | 5 | min_fill | 20 | 2/2 | 25439 |
| 56 | 5 | greedy_min | 30 | 2/2 | 1107 |
| 56 | 5 | bfs | 28 | 2/2 | 3073 |
| 56 | 5 | scc_topo | 28 | 2/2 | 10659 |
| 56 | 5 | scc_topo_rev | 29 | 2/2 | 10401 |
| 56 | 5 | max_degree | 39 | 2/2 | 21019 |
| 56 | 5 | shuffle | 30 | 6/6 | 5536 |
| 80 | 3 | natural | 26 | 9/9 | 15043 |
| 80 | 3 | reverse | 25 | 9/9 | 13312 |
| 80 | 3 | min_degree | 17 | 8/9 | 41855 |
| 80 | 3 | min_fill | 16 | 8/9 | 22357 |
| 80 | 3 | greedy_min | 24 | 9/9 | 618 |
| 80 | 3 | bfs | 23 | 9/9 | 1375 |
| 80 | 3 | scc_topo | 25 | 9/9 | 3474 |
| 80 | 3 | scc_topo_rev | 26 | 9/9 | 4992 |
| 80 | 3 | max_degree | 37 | 9/9 | 6711 |
| 80 | 3 | shuffle | 25 | 27/27 | 10330 |
| 80 | 4 | natural | 35 | 5/6 | 16992 |
| 80 | 4 | reverse | 35 | 5/6 | 23547 |
| 80 | 4 | min_degree | 24 | 3/6 | 10148 |
| 80 | 4 | min_fill | 22 | 5/6 | 32765 |
| 80 | 4 | greedy_min | 34 | 6/6 | 1418 |
| 80 | 4 | bfs | 35 | 6/6 | 9612 |
| 80 | 4 | scc_topo | 36 | 6/6 | 21692 |
| 80 | 4 | scc_topo_rev | 34 | 6/6 | 10404 |
| 80 | 4 | max_degree | 48 | 4/6 | 42213 |
| 80 | 4 | shuffle | 35 | 15/18 | 20356 |
| 80 | 5 | natural | 42 | 2/2 | 49960 |
| 80 | 5 | reverse | 42 | 2/2 | 19924 |
| 80 | 5 | min_degree | - | 0/2 | all capped |
| 80 | 5 | min_fill | 28 | 2/2 | 61714 |
| 80 | 5 | greedy_min | 48 | 2/2 | 1621 |
| 80 | 5 | bfs | 38 | 2/2 | 11399 |
| 80 | 5 | scc_topo | 45 | 2/2 | 44617 |
| 80 | 5 | scc_topo_rev | 40 | 2/2 | 17395 |
| 80 | 5 | max_degree | 54 | 2/2 | 51192 |
| 80 | 5 | shuffle | 42 | 6/6 | 31856 |

## E6 H-SUBSUME family G_k

| k | n | x,a..: alloc | max OR arity | peak reach | child refs | cofactor cache | a..,x: alloc | max OR arity | peak reach | child refs | cofactor cache | 2^(k-1)+2 | OR arity = 2^(k-1)+2 ? | reverse alloc | min_degree alloc | min_fill alloc |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 2 | 6 | 23 | 4 | 11 | 34 | 60 | 19 | 3 | 11 | 25 | 60 | 4 | yes | 21 | 19 | 21 |
| 3 | 8 | 37 | 6 | 14 | 69 | 102 | 25 | 3 | 14 | 38 | 90 | 6 | yes | 27 | 25 | 27 |
| 4 | 10 | 59 | 10 | 17 | 140 | 160 | 31 | 3 | 17 | 53 | 126 | 10 | yes | 33 | 31 | 33 |
| 5 | 12 | 97 | 18 | 24 | 291 | 242 | 37 | 3 | 20 | 70 | 168 | 18 | yes | 39 | 37 | 39 |
| 6 | 14 | 167 | 34 | 41 | 618 | 364 | 43 | 3 | 23 | 89 | 216 | 34 | yes | 45 | 43 | 45 |
| 7 | 16 | 301 | 66 | 74 | 1329 | 558 | 49 | 3 | 26 | 110 | 270 | 66 | yes | 51 | 49 | 51 |
| 8 | 18 | 563 | 130 | 139 | 2872 | 888 | 55 | 3 | 29 | 133 | 330 | 130 | yes | 57 | 55 | 57 |
| 9 | 20 | 1081 | 258 | 268 | 6207 | 1482 | 61 | 3 | 32 | 158 | 396 | 258 | yes | 63 | 61 | 63 |
| 10 | 22 | 2111 | 514 | 525 | 13382 | 2596 | 67 | 3 | 35 | 185 | 468 | 514 | yes | 69 | 67 | 69 |
| 11 | 24 | 4165 | 1026 | 1038 | 28749 | 4742 | 73 | 3 | 38 | 214 | 546 | 1026 | yes | 75 | 73 | 75 |
| 12 | 26 | 8267 | 2050 | 2063 | 61524 | 8944 | 79 | 3 | 41 | 245 | 630 | 2050 | yes | 81 | 79 | 81 |
| 13 | 28 | 16465 | 4098 | 4112 | 131163 | 17250 | 85 | 3 | 44 | 278 | 720 | 4098 | yes | 87 | 85 | 87 |
| 14 | 30 | 32855 | 8194 | 8209 | 278626 | 33756 | 91 | 3 | 47 | 313 | 816 | 8194 | yes | 93 | 91 | 93 |

x_then_a: exp rate 0.8837 bits per k (tail 0.9933), power exponent in k 3.781, first differences of alloc [14, 22, 38, 70, 134, 262, 518, 1030, 2054, 4102, 8198, 16390]

a_then_x: exp rate 0.1776 bits per k (tail 0.106), power exponent in k 0.818, first differences of alloc [6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6]

## E7 semantic census (truth tables of every reachable node after every step)

| family | params | order | answer | n | alloc | (a) peak reachable | (b) peak distinct functions | b/a | peak internal (and/or) | distinct internal | ratio | ALL allocated internal | distinct among them | ratio | peak child refs (reachable) | max redundant child refs / refs at that step | root == exact projection at every step |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| php | {"h": 3} | pigeon_major | UNSAT | 12 | 194 | 47 | 47 | 1.000 | 26 | 25 | 0.962 | 168 | 134 | 0.798 | 77 | 3/61 | ok |
| php | {"h": 3} | hole_major | UNSAT | 12 | 179 | 47 | 47 | 1.000 | 29 | 29 | 1.000 | 153 | 120 | 0.784 | 70 | 5/55 | ok |
| php | {"h": 3} | min_degree | UNSAT | 12 | 166 | 47 | 47 | 1.000 | 26 | 26 | 1.000 | 140 | 95 | 0.679 | 70 | 6/41 | ok |
| php | {"h": 3} | min_fill | UNSAT | 12 | 152 | 47 | 47 | 1.000 | 25 | 24 | 0.960 | 126 | 90 | 0.714 | 70 | 3/39 | ok |
| php | {"h": 3} | shuffle00 | UNSAT | 12 | 194 | 47 | 47 | 1.000 | 29 | 29 | 1.000 | 168 | 131 | 0.780 | 70 | 1/65 | ok |
| php | {"h": 3} | shuffle01 | UNSAT | 12 | 180 | 47 | 47 | 1.000 | 26 | 24 | 0.923 | 154 | 113 | 0.734 | 70 | 8/44 | ok |
| php | {"h": 3} | shuffle02 | UNSAT | 12 | 195 | 47 | 47 | 1.000 | 31 | 27 | 0.871 | 169 | 116 | 0.686 | 71 | 9/70 | ok |
| php | {"h": 4} | pigeon_major | UNSAT | 20 | 725 | 99 | 93 | 0.939 | 77 | 72 | 0.935 | - | - | - | 271 | 18/258 | ok |
| php | {"h": 4} | hole_major | UNSAT | 20 | 518 | 86 | 86 | 1.000 | 63 | 61 | 0.968 | - | - | - | 178 | 30/177 | ok |
| php | {"h": 4} | min_degree | UNSAT | 20 | 464 | 86 | 86 | 1.000 | 58 | 53 | 0.914 | - | - | - | 171 | 17/171 | ok |
| php | {"h": 4} | min_fill | UNSAT | 20 | 518 | 86 | 86 | 1.000 | 57 | 50 | 0.877 | - | - | - | 168 | 16/168 | ok |
| php | {"h": 4} | shuffle00 | UNSAT | 20 | 1054 | 151 | 139 | 0.921 | 135 | 123 | 0.911 | - | - | - | 384 | 41/308 | ok |
| php | {"h": 4} | shuffle01 | UNSAT | 20 | 851 | 127 | 116 | 0.913 | 113 | 102 | 0.903 | - | - | - | 295 | 31/268 | ok |
| php | {"h": 4} | shuffle02 | UNSAT | 20 | 979 | 131 | 115 | 0.878 | 117 | 101 | 0.863 | - | - | - | 334 | 47/306 | ok |
| kcnf | {"density": 4.26, "k": 3, "n": 14, "seed": 1} | natural | SAT | 14 | 644 | 122 | 99 | 0.811 | 106 | 79 | 0.745 | 614 | 383 | 0.624 | 378 | 95/378 | ok |
| kcnf | {"density": 4.26, "k": 3, "n": 14, "seed": 1} | min_degree | SAT | 14 | 562 | 117 | 102 | 0.872 | 103 | 89 | 0.864 | 532 | 385 | 0.724 | 304 | 34/272 | ok |
| kcnf | {"density": 4.26, "k": 3, "n": 14, "seed": 1} | min_fill | SAT | 14 | 490 | 103 | 96 | 0.932 | 87 | 81 | 0.931 | 460 | 344 | 0.748 | 258 | 36/188 | ok |
| kcnf | {"density": 4.26, "k": 3, "n": 14, "seed": 1} | shuffle00 | SAT | 14 | 860 | 150 | 137 | 0.913 | 138 | 124 | 0.899 | 830 | 584 | 0.704 | 386 | 47/381 | ok |
| kcnf | {"density": 4.26, "k": 3, "n": 14, "seed": 1} | shuffle01 | SAT | 14 | 491 | 91 | 91 | 1.000 | 79 | 71 | 0.899 | 461 | 322 | 0.698 | 250 | 57/250 | ok |
| kcnf | {"density": 4.26, "k": 3, "n": 14, "seed": 1} | shuffle02 | SAT | 14 | 570 | 99 | 91 | 0.919 | 87 | 73 | 0.839 | 540 | 376 | 0.696 | 252 | 34/252 | ok |
| xor3 | {"n": 14, "extra": 0, "planted": true, "seed": 1} | natural | SAT | 14 | 282 | 83 | 83 | 1.000 | 62 | 62 | 1.000 | 252 | 230 | 0.913 | 208 | 15/208 | ok |
| xor3 | {"n": 14, "extra": 0, "planted": true, "seed": 1} | min_degree | SAT | 14 | 253 | 83 | 82 | 0.988 | 59 | 58 | 0.983 | 223 | 206 | 0.924 | 208 | 17/206 | ok |
| xor3 | {"n": 14, "extra": 0, "planted": true, "seed": 1} | min_fill | SAT | 14 | 242 | 83 | 82 | 0.988 | 59 | 58 | 0.983 | 212 | 193 | 0.910 | 208 | 17/206 | ok |
| xor3 | {"n": 14, "extra": 0, "planted": true, "seed": 1} | shuffle00 | SAT | 14 | 293 | 86 | 83 | 0.965 | 70 | 61 | 0.871 | 263 | 210 | 0.798 | 208 | 44/205 | ok |
| xor3 | {"n": 14, "extra": 0, "planted": true, "seed": 1} | shuffle01 | SAT | 14 | 448 | 93 | 92 | 0.989 | 79 | 76 | 0.962 | 418 | 300 | 0.718 | 253 | 80/228 | ok |
| xor3 | {"n": 14, "extra": 0, "planted": true, "seed": 1} | shuffle02 | SAT | 14 | 311 | 82 | 82 | 1.000 | 59 | 59 | 1.000 | 281 | 264 | 0.940 | 208 | 19/189 | ok |
| xor3 | {"n": 14, "extra": 5, "planted": false, "seed": 1} | natural | UNSAT | 14 | 326 | 108 | 108 | 1.000 | 86 | 86 | 1.000 | 296 | 233 | 0.787 | 304 | 54/304 | ok |
| xor3 | {"n": 14, "extra": 5, "planted": false, "seed": 1} | min_degree | UNSAT | 14 | 340 | 107 | 107 | 1.000 | 85 | 85 | 1.000 | 310 | 243 | 0.784 | 304 | 54/304 | ok |
| xor3 | {"n": 14, "extra": 5, "planted": false, "seed": 1} | min_fill | UNSAT | 14 | 334 | 108 | 108 | 1.000 | 86 | 86 | 1.000 | 304 | 238 | 0.783 | 304 | 54/304 | ok |
| xor3 | {"n": 14, "extra": 5, "planted": false, "seed": 1} | shuffle00 | UNSAT | 14 | 421 | 120 | 105 | 0.875 | 100 | 78 | 0.780 | 391 | 190 | 0.486 | 369 | 138/369 | ok |
| xor3 | {"n": 14, "extra": 5, "planted": false, "seed": 1} | shuffle01 | UNSAT | 14 | 320 | 107 | 107 | 1.000 | 83 | 83 | 1.000 | 290 | 252 | 0.869 | 304 | 54/304 | ok |
| xor3 | {"n": 14, "extra": 5, "planted": false, "seed": 1} | shuffle02 | UNSAT | 14 | 339 | 107 | 107 | 1.000 | 88 | 83 | 0.943 | 309 | 201 | 0.650 | 304 | 66/257 | ok |
| kcnf | {"density": 4.26, "k": 3, "n": 14, "seed": 2} | natural | UNSAT | 14 | 612 | 110 | 101 | 0.918 | 96 | 83 | 0.865 | 582 | 382 | 0.656 | 287 | 62/287 | ok |
| kcnf | {"density": 4.26, "k": 3, "n": 14, "seed": 2} | min_degree | UNSAT | 14 | 542 | 102 | 98 | 0.961 | 86 | 82 | 0.953 | 512 | 333 | 0.650 | 258 | 40/223 | ok |
| kcnf | {"density": 4.26, "k": 3, "n": 14, "seed": 2} | min_fill | UNSAT | 14 | 596 | 109 | 94 | 0.862 | 94 | 77 | 0.819 | 566 | 371 | 0.655 | 282 | 56/282 | ok |
| kcnf | {"density": 4.26, "k": 3, "n": 14, "seed": 2} | shuffle00 | UNSAT | 14 | 623 | 121 | 90 | 0.744 | 109 | 72 | 0.661 | 593 | 314 | 0.530 | 326 | 86/303 | ok |
| kcnf | {"density": 4.26, "k": 3, "n": 14, "seed": 2} | shuffle01 | UNSAT | 14 | 511 | 114 | 110 | 0.965 | 96 | 92 | 0.958 | 481 | 364 | 0.757 | 288 | 47/242 | ok |
| kcnf | {"density": 4.26, "k": 3, "n": 14, "seed": 2} | shuffle02 | UNSAT | 14 | 566 | 117 | 105 | 0.897 | 99 | 87 | 0.879 | 536 | 368 | 0.687 | 288 | 46/216 | ok |
| xor3 | {"n": 14, "extra": 0, "planted": true, "seed": 2} | natural | SAT | 14 | 233 | 82 | 82 | 1.000 | 62 | 62 | 1.000 | 207 | 201 | 0.971 | 224 | 36/197 | ok |
| xor3 | {"n": 14, "extra": 0, "planted": true, "seed": 2} | min_degree | SAT | 14 | 245 | 84 | 83 | 0.988 | 68 | 68 | 1.000 | 219 | 202 | 0.922 | 224 | 26/224 | ok |
| xor3 | {"n": 14, "extra": 0, "planted": true, "seed": 2} | min_fill | SAT | 14 | 236 | 83 | 83 | 1.000 | 65 | 65 | 1.000 | 210 | 198 | 0.943 | 224 | 26/224 | ok |
| xor3 | {"n": 14, "extra": 0, "planted": true, "seed": 2} | shuffle00 | SAT | 14 | 304 | 82 | 82 | 1.000 | 64 | 62 | 0.969 | 278 | 239 | 0.860 | 224 | 28/105 | ok |
| xor3 | {"n": 14, "extra": 0, "planted": true, "seed": 2} | shuffle01 | SAT | 14 | 283 | 82 | 82 | 1.000 | 63 | 62 | 0.984 | 257 | 230 | 0.895 | 224 | 27/197 | ok |
| xor3 | {"n": 14, "extra": 0, "planted": true, "seed": 2} | shuffle02 | SAT | 14 | 314 | 83 | 82 | 0.988 | 73 | 62 | 0.849 | 288 | 179 | 0.622 | 224 | 82/208 | ok |
| xor3 | {"n": 14, "extra": 5, "planted": false, "seed": 2} | natural | UNSAT | 14 | 348 | 104 | 104 | 1.000 | 84 | 84 | 1.000 | 320 | 214 | 0.669 | 304 | 62/269 | ok |
| xor3 | {"n": 14, "extra": 5, "planted": false, "seed": 2} | min_degree | UNSAT | 14 | 307 | 105 | 105 | 1.000 | 83 | 83 | 1.000 | 279 | 227 | 0.814 | 304 | 51/304 | ok |
| xor3 | {"n": 14, "extra": 5, "planted": false, "seed": 2} | min_fill | UNSAT | 14 | 307 | 105 | 105 | 1.000 | 83 | 83 | 1.000 | 279 | 227 | 0.814 | 304 | 51/304 | ok |
| xor3 | {"n": 14, "extra": 5, "planted": false, "seed": 2} | shuffle00 | UNSAT | 14 | 260 | 104 | 104 | 1.000 | 82 | 80 | 0.976 | 232 | 182 | 0.784 | 304 | 51/304 | ok |
| xor3 | {"n": 14, "extra": 5, "planted": false, "seed": 2} | shuffle01 | UNSAT | 14 | 255 | 105 | 105 | 1.000 | 83 | 83 | 1.000 | 227 | 197 | 0.868 | 304 | 51/304 | ok |
| xor3 | {"n": 14, "extra": 5, "planted": false, "seed": 2} | shuffle02 | UNSAT | 14 | 385 | 106 | 104 | 0.981 | 90 | 82 | 0.911 | 357 | 196 | 0.549 | 317 | 102/317 | ok |
| kcnf | {"density": 4.26, "k": 3, "n": 15, "seed": 1} | natural | SAT | 15 | 718 | 111 | 104 | 0.937 | 89 | 84 | 0.944 | 686 | 519 | 0.757 | 316 | 56/316 | ok |
| kcnf | {"density": 4.26, "k": 3, "n": 15, "seed": 1} | min_degree | SAT | 15 | 524 | 104 | 102 | 0.981 | 88 | 83 | 0.943 | 492 | 376 | 0.764 | 256 | 31/256 | ok |
| kcnf | {"density": 4.26, "k": 3, "n": 15, "seed": 1} | min_fill | SAT | 15 | 524 | 104 | 102 | 0.981 | 88 | 83 | 0.943 | 492 | 376 | 0.764 | 256 | 31/256 | ok |
| kcnf | {"density": 4.26, "k": 3, "n": 15, "seed": 1} | shuffle00 | SAT | 15 | 985 | 137 | 126 | 0.920 | 123 | 112 | 0.911 | 953 | 666 | 0.699 | 347 | 54/309 | ok |
| kcnf | {"density": 4.26, "k": 3, "n": 15, "seed": 1} | shuffle01 | SAT | 15 | 739 | 107 | 102 | 0.953 | 87 | 82 | 0.943 | 707 | 543 | 0.768 | 279 | 39/279 | ok |
| kcnf | {"density": 4.26, "k": 3, "n": 15, "seed": 1} | shuffle02 | SAT | 15 | 587 | 106 | 105 | 0.991 | 86 | 85 | 0.988 | 555 | 442 | 0.796 | 275 | 37/269 | ok |
| xor3 | {"n": 15, "extra": 0, "planted": true, "seed": 1} | natural | SAT | 15 | 331 | 89 | 89 | 1.000 | 69 | 67 | 0.971 | 299 | 258 | 0.863 | 224 | 24/224 | ok |
| xor3 | {"n": 15, "extra": 0, "planted": true, "seed": 1} | min_degree | SAT | 15 | 267 | 89 | 88 | 0.989 | 63 | 62 | 0.984 | 235 | 220 | 0.936 | 224 | 24/224 | ok |
| xor3 | {"n": 15, "extra": 0, "planted": true, "seed": 1} | min_fill | SAT | 15 | 268 | 89 | 88 | 0.989 | 63 | 62 | 0.984 | 236 | 213 | 0.903 | 224 | 24/224 | ok |
| xor3 | {"n": 15, "extra": 0, "planted": true, "seed": 1} | shuffle00 | SAT | 15 | 352 | 91 | 89 | 0.978 | 73 | 64 | 0.877 | 320 | 246 | 0.769 | 228 | 62/228 | ok |
| xor3 | {"n": 15, "extra": 0, "planted": true, "seed": 1} | shuffle01 | SAT | 15 | 353 | 89 | 89 | 1.000 | 75 | 75 | 1.000 | 321 | 276 | 0.860 | 224 | 24/224 | ok |
| xor3 | {"n": 15, "extra": 0, "planted": true, "seed": 1} | shuffle02 | SAT | 15 | 354 | 89 | 89 | 1.000 | 65 | 65 | 1.000 | 322 | 265 | 0.823 | 224 | 50/193 | ok |
| xor3 | {"n": 15, "extra": 5, "planted": false, "seed": 1} | natural | UNSAT | 15 | 360 | 112 | 112 | 1.000 | 92 | 92 | 1.000 | 328 | 267 | 0.814 | 304 | 54/304 | ok |
| xor3 | {"n": 15, "extra": 5, "planted": false, "seed": 1} | min_degree | UNSAT | 15 | 356 | 111 | 111 | 1.000 | 91 | 91 | 1.000 | 324 | 250 | 0.772 | 304 | 54/304 | ok |
| xor3 | {"n": 15, "extra": 5, "planted": false, "seed": 1} | min_fill | UNSAT | 15 | 339 | 110 | 110 | 1.000 | 88 | 88 | 1.000 | 307 | 218 | 0.710 | 304 | 54/304 | ok |
| xor3 | {"n": 15, "extra": 5, "planted": false, "seed": 1} | shuffle00 | UNSAT | 15 | 388 | 110 | 110 | 1.000 | 86 | 86 | 1.000 | 356 | 280 | 0.787 | 304 | 54/304 | ok |
| xor3 | {"n": 15, "extra": 5, "planted": false, "seed": 1} | shuffle01 | UNSAT | 15 | 381 | 110 | 108 | 0.982 | 86 | 80 | 0.930 | 349 | 256 | 0.734 | 304 | 66/297 | ok |
| xor3 | {"n": 15, "extra": 5, "planted": false, "seed": 1} | shuffle02 | UNSAT | 15 | 406 | 108 | 108 | 1.000 | 80 | 80 | 1.000 | 374 | 270 | 0.722 | 304 | 65/196 | ok |
| kcnf | {"density": 4.26, "k": 3, "n": 15, "seed": 2} | natural | UNSAT | 15 | 1040 | 190 | 168 | 0.884 | 174 | 152 | 0.874 | 1008 | 727 | 0.721 | 538 | 78/538 | ok |
| kcnf | {"density": 4.26, "k": 3, "n": 15, "seed": 2} | min_degree | UNSAT | 15 | 759 | 149 | 123 | 0.826 | 133 | 105 | 0.789 | 727 | 459 | 0.631 | 392 | 74/392 | ok |
| kcnf | {"density": 4.26, "k": 3, "n": 15, "seed": 2} | min_fill | UNSAT | 15 | 759 | 149 | 123 | 0.826 | 133 | 105 | 0.789 | 727 | 459 | 0.631 | 392 | 74/392 | ok |
| kcnf | {"density": 4.26, "k": 3, "n": 15, "seed": 2} | shuffle00 | UNSAT | 15 | 890 | 178 | 141 | 0.792 | 162 | 123 | 0.759 | 858 | 529 | 0.617 | 485 | 91/483 | ok |
| kcnf | {"density": 4.26, "k": 3, "n": 15, "seed": 2} | shuffle01 | UNSAT | 15 | 914 | 170 | 130 | 0.765 | 156 | 116 | 0.744 | 882 | 573 | 0.650 | 455 | 107/443 | ok |
| kcnf | {"density": 4.26, "k": 3, "n": 15, "seed": 2} | shuffle02 | UNSAT | 15 | 801 | 147 | 130 | 0.884 | 131 | 114 | 0.870 | 769 | 524 | 0.681 | 415 | 42/338 | ok |
| xor3 | {"n": 15, "extra": 0, "planted": true, "seed": 2} | natural | SAT | 15 | 215 | 88 | 88 | 1.000 | 64 | 64 | 1.000 | 187 | 172 | 0.920 | 240 | 35/199 | ok |
| xor3 | {"n": 15, "extra": 0, "planted": true, "seed": 2} | min_degree | SAT | 15 | 245 | 91 | 89 | 0.978 | 77 | 76 | 0.987 | 217 | 184 | 0.848 | 240 | 30/240 | ok |
| xor3 | {"n": 15, "extra": 0, "planted": true, "seed": 2} | min_fill | SAT | 15 | 245 | 90 | 89 | 0.989 | 74 | 73 | 0.986 | 217 | 184 | 0.848 | 240 | 30/240 | ok |
| xor3 | {"n": 15, "extra": 0, "planted": true, "seed": 2} | shuffle00 | SAT | 15 | 223 | 89 | 89 | 1.000 | 71 | 69 | 0.972 | 195 | 169 | 0.867 | 240 | 35/208 | ok |
| xor3 | {"n": 15, "extra": 0, "planted": true, "seed": 2} | shuffle01 | SAT | 15 | 365 | 88 | 88 | 1.000 | 66 | 64 | 0.970 | 337 | 277 | 0.822 | 240 | 33/181 | ok |
| xor3 | {"n": 15, "extra": 0, "planted": true, "seed": 2} | shuffle02 | SAT | 15 | 307 | 89 | 89 | 1.000 | 67 | 67 | 1.000 | 279 | 227 | 0.814 | 240 | 30/240 | ok |
| xor3 | {"n": 15, "extra": 5, "planted": false, "seed": 2} | natural | UNSAT | 15 | 382 | 112 | 109 | 0.973 | 94 | 91 | 0.968 | 352 | 260 | 0.739 | 304 | 50/304 | ok |
| xor3 | {"n": 15, "extra": 5, "planted": false, "seed": 2} | min_degree | UNSAT | 15 | 352 | 109 | 109 | 1.000 | 89 | 89 | 1.000 | 322 | 262 | 0.814 | 304 | 50/304 | ok |
| xor3 | {"n": 15, "extra": 5, "planted": false, "seed": 2} | min_fill | UNSAT | 15 | 352 | 109 | 109 | 1.000 | 89 | 89 | 1.000 | 322 | 262 | 0.814 | 304 | 50/304 | ok |
| xor3 | {"n": 15, "extra": 5, "planted": false, "seed": 2} | shuffle00 | UNSAT | 15 | 302 | 107 | 106 | 0.991 | 85 | 83 | 0.976 | 272 | 190 | 0.699 | 304 | 92/223 | ok |
| xor3 | {"n": 15, "extra": 5, "planted": false, "seed": 2} | shuffle01 | UNSAT | 15 | 284 | 107 | 105 | 0.981 | 84 | 81 | 0.964 | 254 | 195 | 0.768 | 304 | 52/215 | ok |
| xor3 | {"n": 15, "extra": 5, "planted": false, "seed": 2} | shuffle02 | UNSAT | 15 | 339 | 107 | 107 | 1.000 | 83 | 83 | 1.000 | 309 | 223 | 0.722 | 304 | 55/140 | ok |
| kcnf | {"density": 4.26, "k": 3, "n": 16, "seed": 1} | natural | UNSAT | 16 | 580 | 110 | 102 | 0.927 | 90 | 81 | 0.900 | 546 | 411 | 0.753 | 282 | 47/222 | ok |
| kcnf | {"density": 4.26, "k": 3, "n": 16, "seed": 1} | min_degree | UNSAT | 16 | 611 | 109 | 109 | 1.000 | 89 | 89 | 1.000 | 577 | 434 | 0.752 | 268 | 42/268 | ok |
| kcnf | {"density": 4.26, "k": 3, "n": 16, "seed": 1} | min_fill | UNSAT | 16 | 824 | 130 | 113 | 0.869 | 114 | 97 | 0.851 | 790 | 486 | 0.615 | 325 | 42/268 | ok |
| kcnf | {"density": 4.26, "k": 3, "n": 16, "seed": 1} | shuffle00 | UNSAT | 16 | 909 | 165 | 135 | 0.818 | 149 | 117 | 0.785 | 875 | 621 | 0.710 | 465 | 71/465 | ok |
| kcnf | {"density": 4.26, "k": 3, "n": 16, "seed": 1} | shuffle01 | UNSAT | 16 | 700 | 123 | 106 | 0.862 | 105 | 87 | 0.829 | 666 | 497 | 0.746 | 331 | 55/331 | ok |
| kcnf | {"density": 4.26, "k": 3, "n": 16, "seed": 1} | shuffle02 | UNSAT | 16 | 750 | 137 | 121 | 0.883 | 117 | 101 | 0.863 | 716 | 538 | 0.751 | 369 | 53/351 | ok |
| xor3 | {"n": 16, "extra": 0, "planted": true, "seed": 1} | natural | SAT | 16 | 343 | 96 | 96 | 1.000 | 70 | 70 | 1.000 | 309 | 257 | 0.832 | 240 | 28/204 | ok |
| xor3 | {"n": 16, "extra": 0, "planted": true, "seed": 1} | min_degree | SAT | 16 | 275 | 99 | 95 | 0.960 | 79 | 75 | 0.949 | 241 | 210 | 0.871 | 240 | 26/240 | ok |
| xor3 | {"n": 16, "extra": 0, "planted": true, "seed": 1} | min_fill | SAT | 16 | 262 | 99 | 95 | 0.960 | 79 | 75 | 0.949 | 228 | 210 | 0.921 | 240 | 26/240 | ok |
| xor3 | {"n": 16, "extra": 0, "planted": true, "seed": 1} | shuffle00 | SAT | 16 | 302 | 95 | 95 | 1.000 | 72 | 71 | 0.986 | 268 | 243 | 0.907 | 240 | 26/240 | ok |
| xor3 | {"n": 16, "extra": 0, "planted": true, "seed": 1} | shuffle01 | SAT | 16 | 428 | 101 | 101 | 1.000 | 81 | 81 | 1.000 | 394 | 378 | 0.959 | 272 | 26/240 | ok |
| xor3 | {"n": 16, "extra": 0, "planted": true, "seed": 1} | shuffle02 | SAT | 16 | 294 | 96 | 95 | 0.990 | 70 | 69 | 0.986 | 260 | 237 | 0.912 | 240 | 26/240 | ok |
| xor3 | {"n": 16, "extra": 5, "planted": false, "seed": 1} | natural | UNSAT | 16 | 471 | 141 | 120 | 0.851 | 125 | 94 | 0.752 | 437 | 244 | 0.558 | 440 | 183/440 | ok |
| xor3 | {"n": 16, "extra": 5, "planted": false, "seed": 1} | min_degree | UNSAT | 16 | 275 | 119 | 119 | 1.000 | 91 | 91 | 1.000 | 241 | 211 | 0.876 | 336 | 66/336 | ok |
| xor3 | {"n": 16, "extra": 5, "planted": false, "seed": 1} | min_fill | UNSAT | 16 | 304 | 118 | 118 | 1.000 | 88 | 88 | 1.000 | 270 | 235 | 0.870 | 336 | 66/336 | ok |
| xor3 | {"n": 16, "extra": 5, "planted": false, "seed": 1} | shuffle00 | UNSAT | 16 | 227 | 118 | 118 | 1.000 | 90 | 88 | 0.978 | 193 | 176 | 0.912 | 336 | 66/336 | ok |
| xor3 | {"n": 16, "extra": 5, "planted": false, "seed": 1} | shuffle01 | UNSAT | 16 | 390 | 120 | 118 | 0.983 | 104 | 98 | 0.942 | 356 | 285 | 0.801 | 336 | 66/336 | ok |
| xor3 | {"n": 16, "extra": 5, "planted": false, "seed": 1} | shuffle02 | UNSAT | 16 | 330 | 118 | 118 | 1.000 | 91 | 88 | 0.967 | 296 | 221 | 0.747 | 336 | 72/304 | ok |
| kcnf | {"density": 4.26, "k": 3, "n": 16, "seed": 2} | natural | UNSAT | 16 | 1535 | 257 | 194 | 0.755 | 243 | 180 | 0.741 | 1501 | 938 | 0.625 | 730 | 106/730 | ok |
| kcnf | {"density": 4.26, "k": 3, "n": 16, "seed": 2} | min_degree | UNSAT | 16 | 822 | 133 | 119 | 0.895 | 115 | 101 | 0.878 | 788 | 503 | 0.638 | 353 | 58/324 | ok |
| kcnf | {"density": 4.26, "k": 3, "n": 16, "seed": 2} | min_fill | UNSAT | 16 | 822 | 133 | 119 | 0.895 | 115 | 101 | 0.878 | 788 | 503 | 0.638 | 353 | 58/324 | ok |
| kcnf | {"density": 4.26, "k": 3, "n": 16, "seed": 2} | shuffle00 | UNSAT | 16 | 1054 | 176 | 136 | 0.773 | 160 | 118 | 0.738 | 1020 | 659 | 0.646 | 532 | 94/532 | ok |
| kcnf | {"density": 4.26, "k": 3, "n": 16, "seed": 2} | shuffle01 | UNSAT | 16 | 1404 | 202 | 145 | 0.718 | 188 | 127 | 0.676 | 1370 | 764 | 0.558 | 557 | 152/530 | ok |
| kcnf | {"density": 4.26, "k": 3, "n": 16, "seed": 2} | shuffle02 | UNSAT | 16 | 1128 | 202 | 131 | 0.649 | 186 | 111 | 0.597 | 1094 | 574 | 0.525 | 622 | 178/622 | ok |
| xor3 | {"n": 16, "extra": 0, "planted": true, "seed": 2} | natural | SAT | 16 | 367 | 97 | 97 | 1.000 | 71 | 71 | 1.000 | 335 | 263 | 0.785 | 256 | 33/256 | ok |
| xor3 | {"n": 16, "extra": 0, "planted": true, "seed": 2} | min_degree | SAT | 16 | 279 | 96 | 96 | 1.000 | 70 | 69 | 0.986 | 247 | 198 | 0.802 | 256 | 33/256 | ok |
| xor3 | {"n": 16, "extra": 0, "planted": true, "seed": 2} | min_fill | SAT | 16 | 268 | 96 | 96 | 1.000 | 70 | 69 | 0.986 | 236 | 191 | 0.809 | 256 | 33/256 | ok |
| xor3 | {"n": 16, "extra": 0, "planted": true, "seed": 2} | shuffle00 | SAT | 16 | 306 | 96 | 96 | 1.000 | 71 | 68 | 0.958 | 274 | 221 | 0.807 | 256 | 33/256 | ok |
| xor3 | {"n": 16, "extra": 0, "planted": true, "seed": 2} | shuffle01 | SAT | 16 | 464 | 98 | 98 | 1.000 | 80 | 76 | 0.950 | 432 | 330 | 0.764 | 257 | 42/257 | ok |
| xor3 | {"n": 16, "extra": 0, "planted": true, "seed": 2} | shuffle02 | SAT | 16 | 401 | 96 | 96 | 1.000 | 70 | 70 | 1.000 | 369 | 271 | 0.734 | 256 | 34/163 | ok |
| xor3 | {"n": 16, "extra": 5, "planted": false, "seed": 2} | natural | UNSAT | 16 | 447 | 146 | 118 | 0.808 | 132 | 99 | 0.750 | 415 | 266 | 0.641 | 449 | 172/449 | ok |
| xor3 | {"n": 16, "extra": 5, "planted": false, "seed": 2} | min_degree | UNSAT | 16 | 316 | 117 | 117 | 1.000 | 91 | 91 | 1.000 | 284 | 244 | 0.859 | 336 | 62/336 | ok |
| xor3 | {"n": 16, "extra": 5, "planted": false, "seed": 2} | min_fill | UNSAT | 16 | 343 | 117 | 117 | 1.000 | 91 | 91 | 1.000 | 311 | 242 | 0.778 | 336 | 62/336 | ok |
| xor3 | {"n": 16, "extra": 5, "planted": false, "seed": 2} | shuffle00 | UNSAT | 16 | 594 | 176 | 116 | 0.659 | 164 | 91 | 0.555 | 562 | 253 | 0.450 | 661 | 410/661 | ok |
| xor3 | {"n": 16, "extra": 5, "planted": false, "seed": 2} | shuffle01 | UNSAT | 16 | 369 | 117 | 117 | 1.000 | 91 | 91 | 1.000 | 337 | 295 | 0.875 | 336 | 62/336 | ok |
| xor3 | {"n": 16, "extra": 5, "planted": false, "seed": 2} | shuffle02 | UNSAT | 16 | 363 | 118 | 118 | 1.000 | 98 | 98 | 1.000 | 331 | 264 | 0.798 | 336 | 64/315 | ok |
| tseitin_regular | {"nv": 6, "d": 3, "seed": 1, "sat": true} | natural | SAT | 9 | 141 | 44 | 44 | 1.000 | 32 | 31 | 0.969 | 121 | 105 | 0.868 | 96 | 4/96 | ok |
| tseitin_regular | {"nv": 6, "d": 3, "seed": 1, "sat": true} | min_degree | SAT | 9 | 134 | 44 | 44 | 1.000 | 30 | 30 | 1.000 | 114 | 105 | 0.921 | 96 | 4/96 | ok |
| tseitin_regular | {"nv": 6, "d": 3, "seed": 1, "sat": true} | min_fill | SAT | 9 | 134 | 44 | 44 | 1.000 | 30 | 30 | 1.000 | 114 | 105 | 0.921 | 96 | 4/96 | ok |
| tseitin_regular | {"nv": 6, "d": 3, "seed": 1, "sat": true} | shuffle00 | SAT | 9 | 148 | 45 | 45 | 1.000 | 35 | 33 | 0.943 | 128 | 114 | 0.891 | 96 | 4/96 | ok |
| tseitin_regular | {"nv": 6, "d": 3, "seed": 1, "sat": true} | shuffle01 | SAT | 9 | 148 | 44 | 44 | 1.000 | 33 | 31 | 0.939 | 128 | 110 | 0.859 | 96 | 4/96 | ok |
| tseitin_regular | {"nv": 6, "d": 3, "seed": 1, "sat": true} | shuffle02 | SAT | 9 | 147 | 45 | 45 | 1.000 | 33 | 33 | 1.000 | 127 | 109 | 0.858 | 96 | 4/96 | ok |
| tseitin_regular | {"nv": 6, "d": 3, "seed": 1, "sat": true} | max_degree | SAT | 9 | 167 | 44 | 44 | 1.000 | 33 | 32 | 0.970 | 147 | 134 | 0.912 | 96 | 4/96 | ok |
| tseitin_regular | {"nv": 6, "d": 3, "seed": 1, "sat": true} | bfs | SAT | 9 | 149 | 44 | 44 | 1.000 | 32 | 31 | 0.969 | 129 | 109 | 0.845 | 96 | 4/96 | ok |
| tseitin_regular | {"nv": 6, "d": 3, "seed": 1, "sat": false} | natural | UNSAT | 9 | 141 | 44 | 44 | 1.000 | 32 | 32 | 1.000 | 121 | 95 | 0.785 | 96 | 2/48 | ok |
| tseitin_regular | {"nv": 6, "d": 3, "seed": 1, "sat": false} | min_degree | UNSAT | 9 | 134 | 44 | 44 | 1.000 | 30 | 30 | 1.000 | 114 | 95 | 0.833 | 96 | 2/28 | ok |
| tseitin_regular | {"nv": 6, "d": 3, "seed": 1, "sat": false} | min_fill | UNSAT | 9 | 134 | 44 | 44 | 1.000 | 30 | 30 | 1.000 | 114 | 95 | 0.833 | 96 | 2/28 | ok |
| tseitin_regular | {"nv": 6, "d": 3, "seed": 1, "sat": false} | shuffle00 | UNSAT | 9 | 164 | 44 | 44 | 1.000 | 33 | 32 | 0.970 | 144 | 111 | 0.771 | 96 | 2/76 | ok |
| tseitin_regular | {"nv": 6, "d": 3, "seed": 1, "sat": false} | shuffle01 | UNSAT | 9 | 150 | 45 | 45 | 1.000 | 35 | 35 | 1.000 | 130 | 107 | 0.823 | 96 | 2/78 | ok |
| tseitin_regular | {"nv": 6, "d": 3, "seed": 1, "sat": false} | shuffle02 | UNSAT | 9 | 158 | 45 | 45 | 1.000 | 35 | 35 | 1.000 | 138 | 113 | 0.819 | 96 | 2/78 | ok |
| tseitin_regular | {"nv": 6, "d": 3, "seed": 1, "sat": false} | max_degree | UNSAT | 9 | 167 | 44 | 44 | 1.000 | 33 | 32 | 0.970 | 147 | 124 | 0.844 | 96 | 2/76 | ok |
| tseitin_regular | {"nv": 6, "d": 3, "seed": 1, "sat": false} | bfs | UNSAT | 9 | 149 | 44 | 44 | 1.000 | 32 | 32 | 1.000 | 129 | 99 | 0.767 | 96 | 2/52 | ok |
| tseitin_regular | {"nv": 8, "d": 3, "seed": 1, "sat": true} | natural | SAT | 12 | 217 | 58 | 58 | 1.000 | 42 | 42 | 1.000 | 191 | 169 | 0.885 | 128 | 4/128 | ok |
| tseitin_regular | {"nv": 8, "d": 3, "seed": 1, "sat": true} | min_degree | SAT | 12 | 204 | 61 | 61 | 1.000 | 46 | 46 | 1.000 | 178 | 160 | 0.899 | 128 | 4/128 | ok |
| tseitin_regular | {"nv": 8, "d": 3, "seed": 1, "sat": true} | min_fill | SAT | 12 | 208 | 61 | 61 | 1.000 | 47 | 46 | 0.979 | 182 | 164 | 0.901 | 128 | 4/128 | ok |
| tseitin_regular | {"nv": 8, "d": 3, "seed": 1, "sat": true} | shuffle00 | SAT | 12 | 230 | 59 | 59 | 1.000 | 42 | 42 | 1.000 | 204 | 179 | 0.877 | 128 | 4/128 | ok |
| tseitin_regular | {"nv": 8, "d": 3, "seed": 1, "sat": true} | shuffle01 | SAT | 12 | 236 | 58 | 58 | 1.000 | 44 | 44 | 1.000 | 210 | 175 | 0.833 | 128 | 4/128 | ok |
| tseitin_regular | {"nv": 8, "d": 3, "seed": 1, "sat": true} | shuffle02 | SAT | 12 | 217 | 59 | 59 | 1.000 | 45 | 43 | 0.956 | 191 | 166 | 0.869 | 128 | 4/128 | ok |
| tseitin_regular | {"nv": 8, "d": 3, "seed": 1, "sat": true} | max_degree | SAT | 12 | 242 | 58 | 58 | 1.000 | 42 | 42 | 1.000 | 216 | 202 | 0.935 | 128 | 4/128 | ok |
| tseitin_regular | {"nv": 8, "d": 3, "seed": 1, "sat": true} | bfs | SAT | 12 | 243 | 58 | 58 | 1.000 | 42 | 41 | 0.976 | 217 | 189 | 0.871 | 128 | 4/128 | ok |
| tseitin_regular | {"nv": 8, "d": 3, "seed": 1, "sat": false} | natural | UNSAT | 12 | 217 | 58 | 58 | 1.000 | 42 | 42 | 1.000 | 191 | 153 | 0.801 | 128 | 2/52 | ok |
| tseitin_regular | {"nv": 8, "d": 3, "seed": 1, "sat": false} | min_degree | UNSAT | 12 | 204 | 61 | 61 | 1.000 | 46 | 46 | 1.000 | 178 | 145 | 0.815 | 128 | 2/78 | ok |
| tseitin_regular | {"nv": 8, "d": 3, "seed": 1, "sat": false} | min_fill | UNSAT | 12 | 208 | 61 | 61 | 1.000 | 47 | 47 | 1.000 | 182 | 149 | 0.819 | 128 | 2/78 | ok |
| tseitin_regular | {"nv": 8, "d": 3, "seed": 1, "sat": false} | shuffle00 | UNSAT | 12 | 244 | 59 | 59 | 1.000 | 46 | 46 | 1.000 | 218 | 174 | 0.798 | 128 | 2/100 | ok |
| tseitin_regular | {"nv": 8, "d": 3, "seed": 1, "sat": false} | shuffle01 | UNSAT | 12 | 225 | 59 | 59 | 1.000 | 47 | 47 | 1.000 | 199 | 161 | 0.809 | 128 | 2/102 | ok |
| tseitin_regular | {"nv": 8, "d": 3, "seed": 1, "sat": false} | shuffle02 | UNSAT | 12 | 213 | 59 | 59 | 1.000 | 42 | 42 | 1.000 | 187 | 151 | 0.807 | 128 | 2/54 | ok |
| tseitin_regular | {"nv": 8, "d": 3, "seed": 1, "sat": false} | max_degree | UNSAT | 12 | 242 | 58 | 58 | 1.000 | 42 | 42 | 1.000 | 216 | 186 | 0.861 | 128 | 2/52 | ok |
| tseitin_regular | {"nv": 8, "d": 3, "seed": 1, "sat": false} | bfs | UNSAT | 12 | 243 | 58 | 58 | 1.000 | 42 | 42 | 1.000 | 217 | 173 | 0.797 | 128 | 2/52 | ok |
| tseitin_regular | {"nv": 10, "d": 3, "seed": 1, "sat": true} | natural | SAT | 15 | 309 | 72 | 72 | 1.000 | 54 | 53 | 0.981 | 277 | 247 | 0.892 | 160 | 4/160 | ok |
| tseitin_regular | {"nv": 10, "d": 3, "seed": 1, "sat": true} | min_degree | SAT | 15 | 270 | 73 | 73 | 1.000 | 49 | 49 | 1.000 | 238 | 219 | 0.920 | 160 | 4/160 | ok |
| tseitin_regular | {"nv": 10, "d": 3, "seed": 1, "sat": true} | min_fill | SAT | 15 | 274 | 72 | 72 | 1.000 | 46 | 46 | 1.000 | 242 | 218 | 0.901 | 160 | 4/160 | ok |
| tseitin_regular | {"nv": 10, "d": 3, "seed": 1, "sat": true} | shuffle00 | SAT | 15 | 306 | 74 | 74 | 1.000 | 55 | 55 | 1.000 | 274 | 237 | 0.865 | 160 | 4/160 | ok |
| tseitin_regular | {"nv": 10, "d": 3, "seed": 1, "sat": true} | shuffle01 | SAT | 15 | 269 | 72 | 72 | 1.000 | 48 | 48 | 1.000 | 237 | 212 | 0.895 | 160 | 4/160 | ok |
| tseitin_regular | {"nv": 10, "d": 3, "seed": 1, "sat": true} | shuffle02 | SAT | 15 | 292 | 74 | 74 | 1.000 | 58 | 57 | 0.983 | 260 | 237 | 0.912 | 160 | 4/160 | ok |
| tseitin_regular | {"nv": 10, "d": 3, "seed": 1, "sat": true} | max_degree | SAT | 15 | 321 | 72 | 72 | 1.000 | 52 | 51 | 0.981 | 289 | 268 | 0.927 | 160 | 4/160 | ok |
| tseitin_regular | {"nv": 10, "d": 3, "seed": 1, "sat": true} | bfs | SAT | 15 | 326 | 72 | 72 | 1.000 | 48 | 48 | 1.000 | 294 | 271 | 0.922 | 160 | 4/160 | ok |
| tseitin_regular | {"nv": 10, "d": 3, "seed": 1, "sat": false} | natural | UNSAT | 15 | 309 | 72 | 72 | 1.000 | 54 | 54 | 1.000 | 277 | 225 | 0.812 | 160 | 2/100 | ok |
| tseitin_regular | {"nv": 10, "d": 3, "seed": 1, "sat": false} | min_degree | UNSAT | 15 | 270 | 73 | 73 | 1.000 | 49 | 49 | 1.000 | 238 | 198 | 0.832 | 160 | 2/102 | ok |
| tseitin_regular | {"nv": 10, "d": 3, "seed": 1, "sat": false} | min_fill | UNSAT | 15 | 274 | 72 | 72 | 1.000 | 46 | 46 | 1.000 | 242 | 197 | 0.814 | 160 | 2/78 | ok |
| tseitin_regular | {"nv": 10, "d": 3, "seed": 1, "sat": false} | shuffle00 | UNSAT | 15 | 305 | 73 | 73 | 1.000 | 55 | 55 | 1.000 | 273 | 230 | 0.842 | 160 | 2/124 | ok |
| tseitin_regular | {"nv": 10, "d": 3, "seed": 1, "sat": false} | shuffle01 | UNSAT | 15 | 279 | 74 | 74 | 1.000 | 59 | 59 | 1.000 | 247 | 203 | 0.822 | 160 | 2/126 | ok |
| tseitin_regular | {"nv": 10, "d": 3, "seed": 1, "sat": false} | shuffle02 | UNSAT | 15 | 300 | 73 | 73 | 1.000 | 55 | 55 | 1.000 | 268 | 217 | 0.810 | 160 | 2/78 | ok |
| tseitin_regular | {"nv": 10, "d": 3, "seed": 1, "sat": false} | max_degree | UNSAT | 15 | 321 | 72 | 72 | 1.000 | 52 | 52 | 1.000 | 289 | 246 | 0.851 | 160 | 2/76 | ok |
| tseitin_regular | {"nv": 10, "d": 3, "seed": 1, "sat": false} | bfs | UNSAT | 15 | 326 | 72 | 72 | 1.000 | 48 | 48 | 1.000 | 294 | 249 | 0.847 | 160 | 2/76 | ok |
| tseitin_complete | {"m": 5, "seed": 1, "sat": false} | natural | UNSAT | 10 | 226 | 62 | 62 | 1.000 | 48 | 48 | 1.000 | 204 | 168 | 0.824 | 200 | 2/168 | ok |
| tseitin_complete | {"m": 5, "seed": 1, "sat": false} | min_degree | UNSAT | 10 | 213 | 63 | 63 | 1.000 | 48 | 48 | 1.000 | 191 | 164 | 0.859 | 200 | 2/120 | ok |
| tseitin_complete | {"m": 5, "seed": 1, "sat": false} | min_fill | UNSAT | 10 | 221 | 62 | 62 | 1.000 | 46 | 46 | 1.000 | 199 | 172 | 0.864 | 200 | 2/120 | ok |
| tseitin_complete | {"m": 5, "seed": 1, "sat": false} | shuffle00 | UNSAT | 10 | 220 | 63 | 63 | 1.000 | 49 | 49 | 1.000 | 198 | 164 | 0.828 | 200 | 2/162 | ok |
| tseitin_complete | {"m": 5, "seed": 1, "sat": false} | shuffle01 | UNSAT | 10 | 234 | 62 | 62 | 1.000 | 49 | 48 | 0.980 | 212 | 184 | 0.868 | 200 | 2/156 | ok |
| tseitin_complete | {"m": 5, "seed": 1, "sat": false} | shuffle02 | UNSAT | 10 | 230 | 63 | 63 | 1.000 | 49 | 48 | 0.980 | 208 | 176 | 0.846 | 200 | 2/156 | ok |
| tseitin_complete | {"m": 5, "seed": 1, "sat": false} | max_degree | UNSAT | 10 | 226 | 62 | 62 | 1.000 | 48 | 48 | 1.000 | 204 | 168 | 0.824 | 200 | 2/168 | ok |
| tseitin_complete | {"m": 5, "seed": 1, "sat": false} | bfs | UNSAT | 10 | 226 | 62 | 62 | 1.000 | 48 | 48 | 1.000 | 204 | 168 | 0.824 | 200 | 2/168 | ok |
| tseitin_complete | {"m": 6, "seed": 1, "sat": false} | natural | UNSAT | 15 | 510 | 128 | 128 | 1.000 | 102 | 102 | 1.000 | 478 | 403 | 0.843 | 576 | 2/488 | ok |
| tseitin_complete | {"m": 6, "seed": 1, "sat": false} | min_degree | UNSAT | 15 | 467 | 130 | 130 | 1.000 | 106 | 106 | 1.000 | 435 | 381 | 0.876 | 576 | 2/346 | ok |
| tseitin_complete | {"m": 6, "seed": 1, "sat": false} | min_fill | UNSAT | 15 | 469 | 129 | 129 | 1.000 | 103 | 103 | 1.000 | 437 | 395 | 0.904 | 576 | 2/248 | ok |
| tseitin_complete | {"m": 6, "seed": 1, "sat": false} | shuffle00 | UNSAT | 15 | 494 | 128 | 128 | 1.000 | 100 | 100 | 1.000 | 462 | 409 | 0.885 | 576 | 2/296 | ok |
| tseitin_complete | {"m": 6, "seed": 1, "sat": false} | shuffle01 | UNSAT | 15 | 495 | 129 | 129 | 1.000 | 103 | 103 | 1.000 | 463 | 411 | 0.888 | 576 | 2/204 | ok |
| tseitin_complete | {"m": 6, "seed": 1, "sat": false} | shuffle02 | UNSAT | 15 | 492 | 129 | 129 | 1.000 | 103 | 103 | 1.000 | 460 | 403 | 0.876 | 576 | 2/296 | ok |
| tseitin_complete | {"m": 6, "seed": 1, "sat": false} | max_degree | UNSAT | 15 | 510 | 128 | 128 | 1.000 | 102 | 102 | 1.000 | 478 | 403 | 0.843 | 576 | 2/488 | ok |
| tseitin_complete | {"m": 6, "seed": 1, "sat": false} | bfs | UNSAT | 15 | 510 | 128 | 128 | 1.000 | 102 | 102 | 1.000 | 478 | 403 | 0.843 | 576 | 2/488 | ok |
| subsume | {"k": 4} | x_then_a | SAT | 10 | 59 | 17 | 17 | 1.000 | 9 | 9 | 1.000 | 46 | 43 | 0.935 | 31 | 7/31 | ok |
| subsume | {"k": 4} | a_then_x | SAT | 10 | 31 | 17 | 17 | 1.000 | 6 | 6 | 1.000 | 18 | 17 | 0.944 | 19 | 1/9 | ok |
| subsume | {"k": 5} | x_then_a | SAT | 12 | 97 | 24 | 24 | 1.000 | 17 | 17 | 1.000 | 82 | 78 | 0.951 | 67 | 15/67 | ok |
| subsume | {"k": 5} | a_then_x | SAT | 12 | 37 | 20 | 20 | 1.000 | 7 | 7 | 1.000 | 22 | 21 | 0.955 | 23 | 1/9 | ok |
| subsume | {"k": 6} | x_then_a | SAT | 14 | 167 | 41 | 41 | 1.000 | 33 | 33 | 1.000 | 150 | 145 | 0.967 | 147 | 31/147 | ok |
| subsume | {"k": 6} | a_then_x | SAT | 14 | 43 | 23 | 23 | 1.000 | 8 | 8 | 1.000 | 26 | 25 | 0.962 | 27 | 1/9 | ok |
| subsume | {"k": 7} | x_then_a | SAT | 16 | 301 | 74 | 74 | 1.000 | 65 | 65 | 1.000 | 282 | 276 | 0.979 | 323 | 63/323 | ok |
| subsume | {"k": 7} | a_then_x | SAT | 16 | 49 | 26 | 26 | 1.000 | 9 | 9 | 1.000 | 30 | 29 | 0.967 | 31 | 1/9 | ok |
| subsume_2cnf | {"k": 3} | natural | SAT | 14 | 192 | 38 | 38 | 1.000 | 31 | 31 | 1.000 | 169 | 162 | 0.959 | 63 | 6/32 | ok |
| subsume_2cnf | {"k": 3} | min_degree | SAT | 14 | 64 | 35 | 35 | 1.000 | 14 | 14 | 1.000 | 41 | 38 | 0.927 | 39 | 1/24 | ok |
| random_horn3 | {"density": 3.0, "facts": 0, "goals": 0, "n": 16, "seed": 1} | natural | SAT | 16 | 1062 | 178 | 126 | 0.708 | 168 | 115 | 0.685 | 1028 | 694 | 0.675 | 399 | 73/399 | ok |
| random_horn3 | {"density": 3.0, "facts": 0, "goals": 0, "n": 16, "seed": 1} | min_degree | SAT | 16 | 434 | 92 | 88 | 0.957 | 80 | 74 | 0.925 | 400 | 365 | 0.912 | 215 | 25/215 | ok |
| random_horn3 | {"density": 3.0, "facts": 0, "goals": 0, "n": 16, "seed": 1} | min_fill | SAT | 16 | 516 | 90 | 86 | 0.956 | 76 | 71 | 0.934 | 482 | 417 | 0.865 | 202 | 18/202 | ok |
| random_horn3 | {"density": 3.0, "facts": 0, "goals": 0, "n": 16, "seed": 1} | shuffle00 | SAT | 16 | 991 | 172 | 150 | 0.872 | 156 | 134 | 0.859 | 957 | 792 | 0.828 | 454 | 51/435 | ok |
| random_horn3 | {"density": 3.0, "facts": 0, "goals": 0, "n": 16, "seed": 1} | shuffle01 | SAT | 16 | 1046 | 163 | 149 | 0.914 | 149 | 131 | 0.879 | 1012 | 739 | 0.730 | 390 | 48/390 | ok |
| random_horn3 | {"density": 3.0, "facts": 0, "goals": 0, "n": 16, "seed": 1} | shuffle02 | SAT | 16 | 1248 | 234 | 156 | 0.667 | 222 | 142 | 0.640 | 1214 | 701 | 0.577 | 645 | 85/616 | ok |
| rand2cnf | {"density": 1.0, "n": 16, "seed": 1} | natural | SAT | 16 | 66 | 36 | 36 | 1.000 | 17 | 17 | 1.000 | 45 | 39 | 0.867 | 48 | 3/48 | ok |
| rand2cnf | {"density": 1.0, "n": 16, "seed": 1} | min_degree | SAT | 16 | 65 | 36 | 36 | 1.000 | 17 | 17 | 1.000 | 44 | 37 | 0.841 | 48 | 3/48 | ok |
| rand2cnf | {"density": 1.0, "n": 16, "seed": 1} | min_fill | SAT | 16 | 67 | 36 | 36 | 1.000 | 17 | 17 | 1.000 | 46 | 37 | 0.804 | 48 | 3/48 | ok |
| rand2cnf | {"density": 1.0, "n": 16, "seed": 1} | shuffle00 | SAT | 16 | 81 | 36 | 36 | 1.000 | 18 | 17 | 0.944 | 60 | 46 | 0.767 | 48 | 4/44 | ok |
| rand2cnf | {"density": 1.0, "n": 16, "seed": 1} | shuffle01 | SAT | 16 | 78 | 36 | 36 | 1.000 | 18 | 18 | 1.000 | 57 | 47 | 0.825 | 50 | 3/48 | ok |
| rand2cnf | {"density": 1.0, "n": 16, "seed": 1} | shuffle02 | SAT | 16 | 55 | 36 | 36 | 1.000 | 17 | 17 | 1.000 | 34 | 33 | 0.971 | 48 | 3/48 | ok |

**Per family: distinct functions / nodes** (1.000 = no semantic redundancy at all)

| family | censuses | min b/a at peak | median b/a | min internal ratio | median internal ratio | min ratio over ALL allocated internal nodes | median | median fraction of redundant child refs (worst step) | max fraction |
|---|---|---|---|---|---|---|---|---|---|
| kcnf | 36 | 0.649 | 0.890 | 0.597 | 0.867 | 0.525 | 0.691 | 0.178 | 0.287 |
| php | 14 | 0.878 | 1.000 | 0.863 | 0.929 | 0.679 | 0.734 | 0.108 | 0.182 |
| rand2cnf | 6 | 1.000 | 1.000 | 0.944 | 1.000 | 0.767 | 0.833 | 0.062 | 0.091 |
| random_horn3 | 6 | 0.667 | 0.893 | 0.640 | 0.869 | 0.577 | 0.779 | 0.120 | 0.183 |
| subsume | 8 | 1.000 | 1.000 | 1.000 | 1.000 | 0.935 | 0.958 | 0.153 | 0.226 |
| subsume_2cnf | 2 | 1.000 | 1.000 | 1.000 | 1.000 | 0.927 | 0.943 | 0.115 | 0.188 |
| tseitin_complete | 16 | 1.000 | 1.000 | 0.980 | 1.000 | 0.824 | 0.852 | 0.011 | 0.017 |
| tseitin_regular | 48 | 1.000 | 1.000 | 0.939 | 1.000 | 0.767 | 0.849 | 0.029 | 0.071 |
| xor3 | 72 | 0.659 | 1.000 | 0.555 | 0.987 | 0.450 | 0.814 | 0.178 | 0.620 |

## E7b support-multiplicity census (mechanism test, no truth tables)

After every forget step the and/or nodes reachable from the root are grouped by (kind, set of variables mentioned); the cell is "size: largest group / largest group of OR nodes" (max over the steps of the run and over the instances at that size; * = some instance capped).  Last columns: power-law exponent and exponential rate of the largest group against the size parameter.

| family | order | size: max nodes per support / max OR nodes per support | power exp | exp rate per unit size | better fit |
|---|---|---|---|---|---|
| 2-CNF on 4-regular graph, planted (size = n) | natural | 20: 3/2, 28: 4/3, 40: 56/28, 56: 16/14, 80: CAP | 2.24 | 0.084 | power |
| 2-CNF on 4-regular graph, planted (size = n) | min_degree | 20: 5/3, 28: 5/4, 40: 71/39, 56: 20/12, 80: CAP | 2.00 | 0.075 | power |
| 2-CNF on 4-regular graph, planted (size = n) | min_fill | 20: 3/2, 28: 5/4, 40: 14/9, 56: 51/30, 80: CAP | 2.77 | 0.115 | exponential |
| 2-CNF on 4-regular graph, planted (size = n) | bfs | 20: 6/4, 28: 3/2, 40: 12/9, 56: 28/21, 80: 94/76 | 2.24 | 0.077 | exponential |
| 2-CNF on 4-regular graph, planted (size = n) | shuffle00 | 20: 6/3, 28: 8/4, 40: 51/16, 56: 12/12, 80: CAP | 1.16 | 0.039 | power |
| 2-CNF on 4-regular graph, planted (size = n) | shuffle01 | 20: 6/3, 28: 3/3, 40: 15/8, 56: 23/17, 80: 50/45 | 1.82 | 0.061 | exponential |
| 3-XOR m=n planted (size = n) | natural | 16: 8/8, 24: 24/12, 32: 96/48, 40: 208/88, 48: 1792/896, 56: 1152/256 | 4.42 | 0.199 | exponential |
| 3-XOR m=n planted (size = n) | min_degree | 16: 18/9, 24: 16/8, 32: 40/16, 40: 140/69, 48: 162/67, 56: 132/37, 64: 128/64, 72: 128/64, 80: 589/77, 88: 1921/897, 96: 3619/1571, 104: 7936/3841, 112: 2625/577* | 3.04 | 0.088 | exponential |
| 3-XOR m=n planted (size = n) | min_fill | 16: 12/6, 24: 11/7, 32: 44/13, 40: 144/72, 48: 128/57, 56: 101/37, 64: 224/112, 72: 484/229, 80: 656/256, 88: 512/256, 96: 704/256, 104: 1985/961, 112: 1041/512* | 2.63 | 0.072 | power |
| 3-XOR m=n planted (size = n) | shuffle00 | 16: 16/8, 24: 64/32, 32: 64/32, 40: 384/320, 48: 1121/512, 56: CAP | 3.66 | 0.186 | exponential |
| 3-XOR m=n planted (size = n) | shuffle01 | 16: 106/43, 24: 16/8, 32: 128/64, 40: 234/107, 48: 296/128, 56: 1536/384 | 2.34 | 0.117 | exponential |
| 4-XOR, each variable in 2 equations (size = equations) | natural | 8: 10/8, 16: 10/8, 32: 8/8, 64: 26/13 | 0.38 | 0.025 | exponential |
| 4-XOR, each variable in 2 equations (size = equations) | min_degree | 8: 10/8, 16: 8/8, 32: 10/8, 64: 10/8 | 0.03 | 0.002 | exponential |
| 4-XOR, each variable in 2 equations (size = equations) | min_fill | 8: 10/8, 16: 10/8, 32: 10/8, 64: 10/8 | 0.00 | 0.000 | power |
| 4-XOR, each variable in 2 equations (size = equations) | shuffle00 | 8: 14/10, 16: 18/9, 32: 22/11, 64: 26/13 | 0.30 | 0.015 | power |
| 4-XOR, each variable in 2 equations (size = equations) | shuffle01 | 8: 10/10, 16: 10/8, 32: 14/8, 64: 22/11 | 0.39 | 0.021 | exponential |
| PHP(h+1,h) (size = h) | pigeon_major | 3: 6/2, 4: 9/2, 5: 11/4, 6: 14/5, 7: 17/8, 8: CAP, 9: CAP | 1.20 | 0.364 | power |
| PHP(h+1,h) (size = h) | hole_major | 3: 4/3, 4: 4/3, 5: 4/3, 6: 4/3, 7: 4/3, 8: 4/3, 9: CAP | 0.00 | 0.000 | power |
| PHP(h+1,h) (size = h) | min_degree | 3: 9/3, 4: 16/5, 5: 62/16, 6: 361/90, 7: 1048/292 | 5.84 | 1.822 | exponential |
| PHP(h+1,h) (size = h) | min_fill | 3: 5/2, 4: 22/7, 5: 46/15, 6: 191/55, 7: 573/167 | 5.47 | 1.680 | exponential |
| PHP(h+1,h) (size = h) | shuffle00 | 3: 8/5, 4: 27/11, 5: 141/45, 6: 808/252, 7: CAP | 6.61 | 2.236 | exponential |
| Tseitin d=3 (size = vertices) | natural | 8: 8/7, 16: 10/7, 32: 14/7, 64: 14/7, 96: 24/12 | 0.39 | 0.015 | exponential |
| Tseitin d=3 (size = vertices) | min_degree | 8: 10/7, 16: 10/7, 32: 10/6, 64: 10/5, 96: 10/5, 128: 10/5, 160: CAP | 0.00 | 0.000 | power |
| Tseitin d=3 (size = vertices) | bfs | 8: 7/7, 16: 8/7, 32: 18/9, 64: 18/9, 96: 18/9, 128: 28/14, 160: 16/8 | 0.38 | 0.009 | power |
| Tseitin d=3 (size = vertices) | max_degree | 8: 10/7, 16: 18/9, 32: 31/15, 64: 47/23, 96: 67/33, 128: 83/41, 160: 91/45 | 0.74 | 0.019 | power |
| Tseitin d=3 (size = vertices) | tree_first_bfs | 8: 7/7, 16: 12/7, 32: 20/10, 64: 18/9, 96: 20/10, 128: 28/14, 160: CAP | 0.42 | 0.012 | power |
| Tseitin d=3 (size = vertices) | shuffle00 | 8: 14/7, 16: 14/7, 32: 8/6, 64: 12/6, 96: 24/12 | 0.12 | 0.009 | exponential |
| Tseitin d=3 (size = vertices) | shuffle01 | 8: 10/5, 16: 10/6, 32: 10/5, 64: 22/11, 96: 22/11 | 0.37 | 0.016 | exponential |
| Tseitin d=4 (size = vertices) | natural | 8: 11/11, 16: 14/8, 32: 18/9, 48: 24/12 | 0.42 | 0.027 | exponential |
| Tseitin d=4 (size = vertices) | min_degree | 8: 11/11, 16: 10/8, 32: 10/8, 48: 10/8 | -0.05 | -0.003 | power |
| Tseitin d=4 (size = vertices) | bfs | 8: 8/8, 16: 10/10, 32: 14/10, 48: 10/8 | 0.19 | 0.009 | power |
| Tseitin d=4 (size = vertices) | max_degree | 8: 11/11, 16: 19/9, 32: 35/17, 48: 46/23 | 0.81 | 0.050 | power |
| Tseitin d=4 (size = vertices) | tree_first_bfs | 8: 11/11, 16: 8/8, 32: 14/10, 48: 16/10 | 0.27 | 0.020 | exponential |
| Tseitin d=4 (size = vertices) | shuffle00 | 8: 10/8, 16: 8/8, 32: 10/8, 48: 18/9 | 0.29 | 0.023 | exponential |
| Tseitin d=4 (size = vertices) | shuffle01 | 8: 14/8, 16: 14/8, 32: 22/11, 48: 28/14 | 0.41 | 0.027 | exponential |
| Tseitin d=5 (size = vertices) | natural | 8: 16/16, 16: 16/16, 24: 16/16, 32: 16/16 | 0.00 | 0.000 | power |
| Tseitin d=5 (size = vertices) | min_degree | 8: 16/16, 16: 16/16, 24: 16/16, 32: 16/16 | 0.00 | 0.000 | power |
| Tseitin d=5 (size = vertices) | bfs | 8: 16/16, 16: 16/16, 24: 16/16, 32: 18/18 | 0.06 | 0.006 | exponential |
| Tseitin d=5 (size = vertices) | max_degree | 8: 16/16, 16: 16/16, 24: 23/16, 32: 42/21 | 0.63 | 0.059 | exponential |
| Tseitin d=5 (size = vertices) | tree_first_bfs | 8: 16/16, 16: 16/16, 24: 16/16, 32: 16/16 | 0.00 | 0.000 | power |
| Tseitin d=5 (size = vertices) | shuffle00 | 8: 16/16, 16: 16/16, 24: 18/16, 32: 16/16 | 0.03 | 0.002 | power |
| Tseitin d=5 (size = vertices) | shuffle01 | 8: 16/16, 16: 16/16, 24: 16/16, 32: 30/16 | 0.34 | 0.034 | exponential |
| random 3-CNF 4.26 (size = n) | natural | 16: 11/7, 20: 127/70, 24: 49/36, 28: 223/140, 32: 468/307 | 4.70 | 0.291 | power |
| random 3-CNF 4.26 (size = n) | min_degree | 16: 16/11, 20: 147/89, 24: 92/46, 28: 214/155, 32: 223/126 | 3.41 | 0.204 | power |
| random 3-CNF 4.26 (size = n) | min_fill | 16: 31/20, 20: 76/51, 24: 112/70, 28: 148/85, 32: 386/227 | 3.29 | 0.206 | exponential |
| random 3-CNF 4.26 (size = n) | shuffle00 | 16: 44/33, 20: 99/69, 24: 134/79, 28: 149/101, 32: 224/165 | 2.16 | 0.132 | power |
| random 3-CNF 4.26 (size = n) | shuffle01 | 16: 59/41, 20: 39/29, 24: 176/118, 28: 845/472, 32: 936/626 | 4.87 | 0.310 | exponential |

## E8 repaired subclass (AND-subset subsumption inside OR, and its dual)

Validation against brute force at every elimination stage: {"repaired": {"tasks": 40, "formulas": 2000, "stages": 11108, "evaluate_points": 24304, "failures": 0, "crashed": 0}, "original": {"tasks": 40, "formulas": 2000, "stages": 11108, "evaluate_points": 24304, "failures": 0, "crashed": 0}}

### E8 / E6 rerun (repaired)

| k | n | x,a..: alloc | max OR arity | peak reach | child refs | cofactor cache | a..,x: alloc | max OR arity | peak reach | child refs | cofactor cache | 2^(k-1)+2 | OR arity = 2^(k-1)+2 ? | reverse alloc | min_degree alloc | min_fill alloc |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 2 | 6 | 23 | 4 | 11 | 34 | 60 | 19 | 3 | 11 | 25 | 60 | 4 | yes | 21 | 19 | 21 |
| 3 | 8 | 31 | 4 | 14 | 50 | 92 | 25 | 3 | 14 | 38 | 90 | 6 | no | 27 | 25 | 27 |
| 4 | 10 | 39 | 4 | 17 | 68 | 130 | 31 | 3 | 17 | 53 | 126 | 10 | no | 33 | 31 | 33 |
| 5 | 12 | 47 | 4 | 20 | 88 | 174 | 37 | 3 | 20 | 70 | 168 | 18 | no | 39 | 37 | 39 |
| 6 | 14 | 55 | 4 | 23 | 110 | 224 | 43 | 3 | 23 | 89 | 216 | 34 | no | 45 | 43 | 45 |
| 7 | 16 | 63 | 4 | 26 | 134 | 280 | 49 | 3 | 26 | 110 | 270 | 66 | no | 51 | 49 | 51 |
| 8 | 18 | 71 | 4 | 29 | 160 | 342 | 55 | 3 | 29 | 133 | 330 | 130 | no | 57 | 55 | 57 |
| 9 | 20 | 79 | 4 | 32 | 188 | 410 | 61 | 3 | 32 | 158 | 396 | 258 | no | 63 | 61 | 63 |
| 10 | 22 | 87 | 4 | 35 | 218 | 484 | 67 | 3 | 35 | 185 | 468 | 514 | no | 69 | 67 | 69 |
| 11 | 24 | 95 | 4 | 38 | 250 | 564 | 73 | 3 | 38 | 214 | 546 | 1026 | no | 75 | 73 | 75 |
| 12 | 26 | 103 | 4 | 41 | 284 | 650 | 79 | 3 | 41 | 245 | 630 | 2050 | no | 81 | 79 | 81 |
| 13 | 28 | 111 | 4 | 44 | 320 | 742 | 85 | 3 | 44 | 278 | 720 | 4098 | no | 87 | 85 | 87 |
| 14 | 30 | 119 | 4 | 47 | 358 | 840 | 91 | 3 | 47 | 313 | 816 | 8194 | no | 93 | 91 | 93 |

x_then_a: exp rate 0.1853 bits per k (tail 0.1083), power exponent in k 0.856, first differences of alloc [8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8]

a_then_x: exp rate 0.1776 bits per k (tail 0.106), power exponent in k 0.818, first differences of alloc [6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6]

### E8 / E3 rerun (repaired)

Runs: {"runs": 123, "completed": 114, "verified": 114, "disagreements": 0, "unverified": 0, "capped": 7, "other": 2, "bad_examples": []}; non-completions: {"ORDER_TIMEOUT:order:greedy chunks exhausted": 2, "CAP:time": 7}

| h | n vars | N bits | reverse | pigeon_major | hole_major | min_degree | min_fill | greedy_min | bfs | max_degree | greedy_max | #random | random min | random median | local-search min | MIN over all tried |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 2 | 6 | 174 | 48 | 48 | 49 | 47 | 47 | 47 | 48 | 48 | 49 | 200 | 45 | 48 |  | 45 |
| 3 | 12 | 532 | 194 | 194 | 178 | 162 | 150 | 150 | 192 | 194 | 241 | 200 | 142 | 183 | 137 | 137 |
| 4 | 20 | 1230 | 723 | 723 | 506 | 444 | 511 | 465 | 669 | 723 | 1176 | 200 | 569 | 799 | 353 | 353 |
| 5 | 30 | 2370 | 2712 | 2712 | 1316 | 1674 | 1223 | 1243 | 1992 | 2712 | 5772 | 200 | 2481 | 4527 | 923 | 923 |
| 6 | 42 | 4172 | 10062 | 10062 | 3343 | 7000 | 5323 | 4763 | 5645 | 10062 | CAP:order:greedy chunks exhausted | 60 | 20063 | 31885 | 2432 | 2432 |
| 7 | 56 | 6664 | 35971 | 35971 | 8424 | 28885 | 22815 | CAP:order:greedy chunks exhausted | 15430 | 35971 |  |  |  |  |  | 8424 |
| 8 | 72 | 10098 | CAP:time | CAP:time | 21048 | 67730 | CAP:time |  | 40847 | CAP:time |  |  |  |  |  | 21048 |
| 9 | 90 | 14630 |  |  | CAP:time | CAP:time |  |  | CAP:time |  |  |  |  |  |  |  |

Growth per order (ratio alloc(h+1)/alloc(h); exponential rate in bits per hole and per variable; power-law exponent in n = h(h+1))

| order | h range | successive ratios | bits per h (all) | bits per h (last 5) | bits per var | power exp in n | R2 exp(n) | R2 pow(n) | local power exponents in n |
|---|---|---|---|---|---|---|---|---|---|
| reverse | 2..7 | [4.04, 3.73, 3.75, 3.71, 3.57] | 1.907 | 1.887 | 0.1864 | 2.94 | 0.975 | 0.977 | [2.01, 2.58, 3.26, 3.9, 4.43] |
| pigeon_major | 2..7 | [4.04, 3.73, 3.75, 3.71, 3.57] | 1.907 | 1.887 | 0.1864 | 2.94 | 0.975 | 0.977 | [2.01, 2.58, 3.26, 3.9, 4.43] |
| hole_major | 2..8 | [3.63, 2.84, 2.6, 2.54, 2.52, 2.5] | 1.432 | 1.344 | 0.1260 | 2.41 | 0.957 | 0.985 | [1.86, 2.05, 2.36, 2.77, 3.21, 3.64] |
| min_degree | 2..8 | [3.45, 2.74, 3.77, 4.18, 4.13, 2.34] | 1.800 | 1.862 | 0.1599 | 2.99 | 0.974 | 0.961 | [1.79, 1.97, 3.27, 4.25, 4.93, 3.39] |
| min_fill | 2..7 | [3.19, 3.41, 2.39, 4.35, 4.29] | 1.752 | 1.788 | 0.1729 | 2.68 | 0.989 | 0.954 | [1.67, 2.4, 2.15, 4.37, 5.06] |
| greedy_min | 2..6 | [3.19, 3.1, 2.67, 3.83] | 1.638 | 1.638 | 0.1793 | 2.31 | 0.985 | 0.974 | [1.67, 2.21, 2.42, 3.99] |
| bfs | 2..8 | [4.0, 3.48, 2.98, 2.83, 2.73, 2.65] | 1.605 | 1.482 | 0.1410 | 2.71 | 0.953 | 0.987 | [2.0, 2.44, 2.69, 3.1, 3.5, 3.87] |
| max_degree | 2..7 | [4.04, 3.73, 3.75, 3.71, 3.57] | 1.907 | 1.887 | 0.1864 | 2.94 | 0.975 | 0.977 | [2.01, 2.58, 3.26, 3.9, 4.43] |
| greedy_max | 2..5 | [4.92, 4.88, 4.91] | 2.293 | 2.293 | 0.2830 | 2.93 | 0.988 | 0.986 | [2.3, 3.1, 3.92] |
| random_min | 2..6 | [3.16, 4.01, 4.36, 8.09] | 2.173 | 2.173 | 0.2408 | 3.02 | 0.999 | 0.937 | [1.66, 2.72, 3.63, 6.21] |
| random_median | 2..6 | [3.81, 4.37, 5.67, 7.04] | 2.338 | 2.338 | 0.2580 | 3.26 | 0.997 | 0.952 | [1.93, 2.89, 4.28, 5.8] |
| search_min | 3..6 | [2.58, 2.61, 2.63] | 1.384 | 1.384 | 0.1373 | 2.28 | 0.993 | 0.990 | [1.85, 2.37, 2.88] |
| MIN_over_all_tried | 2..8 | [3.04, 2.58, 2.61, 2.63, 3.46, 2.5] | 1.474 | 1.499 | 0.1310 | 2.45 | 0.978 | 0.964 | [1.61, 1.85, 2.37, 2.88, 4.32, 3.64] |

### E8 / E4 rerun (repaired)

Runs: {"runs": 257, "completed": 219, "verified": 219, "disagreements": 0, "unverified": 0, "capped": 31, "other": 7, "bad_examples": []}; non-completions: {"CAP:time": 31, "ORDER_TIMEOUT:order:greedy chunks exhausted": 7}; expected-answer sources of completed runs: {"adversarial/oracle.py exhaustive (DPLL cross-checked)": 68, "own complete DPLL (not the project oracle)": 151}

**kcnf {"density": 2.0, "k": 3}: allocated nodes, structured orders (gmean over 3 instances)**

| n | n vars | N bits | natural | min_degree | min_fill | greedy_min |
|---|---|---|---|---|---|---|
| 12 | 12 | 790 | 282 | 250 | 250 | 164 |
| 16 | 16 | 1108 | 660 | 378 | 423 | 255 |
| 20 | 20 | 1451 | 1874 | 729 | 918 | 500 |
| 24 | 24 | 1790 | 4655 | 1152 | 1182 | 770 |
| 28 | 28 | 2124 | 10364 | 1923 | 1714 | 1172 |
| 32 | 32 | 2503 | 26398 | 4180 | 4312 | 2332 |
| 36 | 36 | 2921 | >111325* (2/3) | 8599 | 8080 | 4284 |
| 40 | 40 | 3305 | CAP(time) | 19769 | 12962 | 9730 |
| 44 | 44 | 3746 |  | >10762* (1/3) | >8274* (1/3) | >10003* (1/3) |
| 48 | 48 | 4112 |  | 46943 | >27777* (2/3) | >14236* (1/3) |
| 52 | 52 | 4525 |  | >59502* (1/3) | >63721* (2/3) | CAP(order:greedy chunks exhausted) |
| 56 | 56 | 4937 |  | CAP(time) | CAP(time) |  |

**kcnf {"density": 2.0, "k": 3}: random shuffles per instance (best / median)**

| n | n | shuffles completed | best | median |
|---|---|---|---|---|
| 12 | 12 | 10/10 | 195 | 257 |
| 16 | 16 | 10/10 | 523 | 639 |
| 20 | 20 | 10/10 | 1234 | 1977 |
| 24 | 24 | 10/10 | 2155 | 4224 |
| 28 | 28 | 10/10 | 7537 | 12069 |
| 32 | 32 | 10/10 | 28009 | 35043 |
| 36 | 36 | 6/10 | 23966 | 98560 |
| 40 | 40 | 1/10 | CAP | CAP |

best fit: {"points": 7, "power_exponent": 4.732, "power_r2": 0.9581, "exp_rate_bits": 0.3118, "exp_r2": 0.9711, "local_exponents": [3.43, 3.85, 3.06, 8.12, 9.83, -1.32], "tail_power_exponent": 6.439, "tail_exp_rate_bits": 0.308, "better_fit": "exponential"}

median fit: {"points": 7, "power_exponent": 5.364, "power_r2": 0.9692, "exp_rate_bits": 0.3564, "exp_r2": 0.9986, "local_exponents": [3.17, 5.06, 4.16, 6.81, 7.98, 8.78], "tail_power_exponent": 7.763, "tail_exp_rate_bits": 0.3793, "better_fit": "exponential"}

**kcnf {"density": 3.0, "k": 3}: allocated nodes, structured orders (gmean over 3 instances)**

| n | n vars | N bits | natural | min_degree | min_fill | greedy_min |
|---|---|---|---|---|---|---|
| 12 | 12 | 1173 | 408 | 411 | 392 | 283 |
| 16 | 16 | 1643 | 1160 | 816 | 826 | 674 |
| 20 | 20 | 2172 | 3974 | 2144 | 2150 | 1461 |
| 24 | 24 | 2677 | 7968 | 2334 | 2763 | 1925 |

**kcnf {"density": 2.0, "k": 3} fits** (x = n)

| series / order | pts | largest complete n | alloc there (gmean) | power exp b | tail b (last 4) | R2 pow | exp rate bits/var | tail rate | R2 exp | better fit | power exp vs N | first incomplete size |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| natural | 6 | 32 | 26398 | 4.63 | 5.56 | 0.983 | 0.3284 | 0.3151 | 0.999 | exponential | 3.94 | 36: 2/3 done (timex1) |
| min_degree | 9 | 48 | 46943 | 3.85 | 6.04 | 0.938 | 0.2196 | 0.2180 | 0.993 | exponential | 3.25 | 44: 1/3 done (timex2) |
| min_fill | 8 | 40 | 12962 | 3.26 | 5.67 | 0.949 | 0.2035 | 0.2415 | 0.988 | exponential | 2.75 | 44: 1/3 done (timex2) |
| greedy_min | 8 | 40 | 9730 | 3.27 | 5.83 | 0.943 | 0.2050 | 0.2509 | 0.992 | exponential | 2.76 | 44: 1/3 done (order:greedy chunks exhaustedx2) |
| shuffle | 6 | 32 | 38488 | 4.96 | 6.42 | 0.970 | 0.3544 | 0.3661 | 0.997 | exponential | 4.19 | 36: 6/10 done (timex4) |

**kcnf {"density": 3.0, "k": 3} fits** (x = n)

| series / order | pts | largest complete n | alloc there (gmean) | power exp b | tail b (last 4) | R2 pow | exp rate bits/var | tail rate | R2 exp | better fit | power exp vs N | first incomplete size |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| natural | 4 | 24 | 7968 | 4.39 | 4.39 | 0.993 | 0.3660 | 0.3660 | 0.989 | power | 3.68 | - |
| min_degree | 4 | 24 | 2334 | 2.71 | 2.71 | 0.952 | 0.2229 | 0.2229 | 0.924 | power | 2.27 | - |
| min_fill | 4 | 24 | 2763 | 2.97 | 2.97 | 0.977 | 0.2458 | 0.2458 | 0.958 | power | 2.49 | - |
| greedy_min | 4 | 24 | 1925 | 2.86 | 2.86 | 0.985 | 0.2354 | 0.2354 | 0.957 | power | 2.40 | - |

### Original vs repaired: growth rates on the SAME sizes (exponential fit, bits per unit of the size parameter)

| series | common range | original alloc at largest | repaired alloc at largest | original rate | repaired rate | original tail rate | repaired tail rate |
|---|---|---|---|---|---|---|---|
| PHP reverse | h=2..7 | 35985 | 35971 | 1.907 | 1.907 | 1.879 | 1.880 |
| PHP pigeon_major | h=2..7 | 35985 | 35971 | 1.907 | 1.907 | 1.879 | 1.880 |
| PHP hole_major | h=2..8 | 22070 | 21048 | 1.445 | 1.432 | 1.335 | 1.333 |
| PHP min_degree | h=2..8 | 69944 | 67730 | 1.804 | 1.800 | 1.803 | 1.806 |
| PHP min_fill | h=2..7 | 23297 | 22815 | 1.758 | 1.752 | 1.858 | 1.856 |
| PHP greedy_min | h=2..6 | 5527 | 4763 | 1.743 | 1.638 | 1.751 | 1.639 |
| PHP bfs | h=2..8 | 48068 | 40847 | 1.647 | 1.605 | 1.494 | 1.452 |
| PHP max_degree | h=2..7 | 35985 | 35971 | 1.907 | 1.907 | 1.879 | 1.880 |
| PHP greedy_max | h=2..5 | 5404 | 5772 | 2.263 | 2.293 | 2.263 | 2.293 |
| PHP random_min | h=2..6 | 19550 | 20063 | 2.172 | 2.173 | 2.343 | 2.355 |
| PHP MIN_over_all_tried | h=2..8 | 22070 | 21048 | 1.488 | 1.474 | 1.591 | 1.533 |
| PHP random_median | h=2..6 | 33754 | 31885 | 2.356 | 2.338 | 2.503 | 2.484 |
| PHP search_min | h=3..6 | 2648 | 2432 | 1.398 | 1.384 | 1.398 | 1.384 |
| kcnf {"density": 2.0, "k": 3} greedy_min | n=12..40 | 8210 | 9730 | 0.1969 | 0.2050 | 0.2414 | 0.2509 |
| kcnf {"density": 2.0, "k": 3} min_degree | n=12..48 | 51298 | 46943 | 0.2313 | 0.2196 | 0.2353 | 0.2180 |
| kcnf {"density": 2.0, "k": 3} min_fill | n=12..40 | 11584 | 12962 | 0.2144 | 0.2035 | 0.2491 | 0.2415 |
| kcnf {"density": 2.0, "k": 3} natural | n=12..32 | 29289 | 26398 | 0.3389 | 0.3285 | 0.3364 | 0.3151 |
| kcnf {"density": 2.0, "k": 3} shuffle | n=12..32 | 36388 | 38488 | 0.3547 | 0.3544 | 0.3635 | 0.3661 |
| kcnf {"density": 3.0, "k": 3} greedy_min | n=12..24 | 1544 | 1925 | 0.2039 | 0.2354 | 0.2039 | 0.2354 |
| kcnf {"density": 3.0, "k": 3} min_degree | n=12..24 | 2021 | 2334 | 0.2266 | 0.2229 | 0.2266 | 0.2229 |
| kcnf {"density": 3.0, "k": 3} min_fill | n=12..24 | 2276 | 2763 | 0.2395 | 0.2458 | 0.2395 | 0.2458 |
| kcnf {"density": 3.0, "k": 3} natural | n=12..24 | 7380 | 7968 | 0.3612 | 0.3660 | 0.3612 | 0.3660 |
| G_k x_then_a | k=2..14 | 32855 | 119 | 0.884 | 0.185 | 0.993 | 0.108 |
| G_k a_then_x | k=2..14 | 91 | 91 | 0.178 | 0.178 | 0.106 | 0.106 |

