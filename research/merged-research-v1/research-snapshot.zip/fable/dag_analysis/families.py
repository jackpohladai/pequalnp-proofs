"""Deterministic instance generators for the residual-DAG stress tests.

Standard library only.  Every generator is a pure function of its arguments
(seeds included) and returns a dict with at least
    n        number of declared variables (1-based ints 1..n)
    clauses  list of lists of signed non-zero ints
plus family-specific metadata that the independent verifiers in verify.py use
(graph edges / charges, XOR equations, ...).  Nothing here imports the candidate.
"""
import itertools
import random


# --------------------------------------------------------------------------
# generic helpers
# --------------------------------------------------------------------------
def encoded_bits(clauses):
    """Project encoding size N: sum over literals of (4 + 2*bitlen(var)) + 2 per clause."""
    return sum(4 + 2 * abs(l).bit_length() for c in clauses for l in c) + 2 * len(clauses)


def xor_clauses(vs, rhs):
    """CNF of XOR(vs) == rhs: one clause per wrong-parity assignment of vs."""
    out = []
    for bits in itertools.product((0, 1), repeat=len(vs)):
        if sum(bits) % 2 != rhs:
            out.append([v if b == 0 else -v for v, b in zip(vs, bits)])
    return out


def components(nv, edges):
    """Connected components of an undirected (multi)graph on vertices 0..nv-1."""
    parent = list(range(nv))

    def find(a):
        while parent[a] != a:
            parent[a] = parent[parent[a]]
            a = parent[a]
        return a
    for a, b in edges:
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[ra] = rb
    comp = {}
    for v in range(nv):
        comp.setdefault(find(v), []).append(v)
    return list(comp.values())


# --------------------------------------------------------------------------
# graphs
# --------------------------------------------------------------------------
def random_regular_graph(nv, d, seed, max_tries=200000):
    """Uniform random simple connected d-regular graph (pairing model + rejection).

    Edges are returned sorted lexicographically, so the 'natural' variable order
    of the Tseitin formula is vertex-major.  Returns (edges, tries)."""
    if nv * d % 2 or d >= nv:
        raise ValueError('need nv*d even and d < nv')
    rng = random.Random(seed)
    for tries in range(1, max_tries + 1):
        stubs = [v for v in range(nv) for _ in range(d)]
        rng.shuffle(stubs)
        edges = set()
        ok = True
        for i in range(0, len(stubs), 2):
            a, b = stubs[i], stubs[i + 1]
            if a == b:
                ok = False
                break
            e = (a, b) if a < b else (b, a)
            if e in edges:
                ok = False
                break
            edges.add(e)
        if ok and len(components(nv, edges)) == 1:
            return sorted(edges), tries
    raise RuntimeError('no simple connected regular graph found')


def torus_graph(a, b):
    """a x b 2D torus (4-regular, simple for a, b >= 3). Vertex (i, j) -> i*b + j."""
    if a < 3 or b < 3:
        raise ValueError('torus needs both sides >= 3 to be simple')
    edges = set()
    for i in range(a):
        for j in range(b):
            v = i * b + j
            for w in (((i + 1) % a) * b + j, i * b + (j + 1) % b):
                edges.add((v, w) if v < w else (w, v))
    return sorted(edges)


def grid_graph(a, b):
    """a x b planar grid (no wraparound)."""
    edges = []
    for i in range(a):
        for j in range(b):
            v = i * b + j
            if i + 1 < a:
                edges.append((v, (i + 1) * b + j))
            if j + 1 < b:
                edges.append((v, i * b + j + 1))
    return sorted(edges)


def complete_graph(m):
    return [(a, b) for a in range(m) for b in range(a + 1, m)]


def charges_with_parity(nv, parity, seed):
    """Random 0/1 charge per vertex with prescribed total parity (deterministic)."""
    rng = random.Random(seed)
    ch = [rng.randrange(2) for _ in range(nv)]
    if sum(ch) % 2 != parity:
        ch[rng.randrange(nv)] ^= 1
    return ch


# --------------------------------------------------------------------------
# Tseitin
# --------------------------------------------------------------------------
def tseitin(nv, edges, charges):
    """Variable i+1 = edges[i]; vertex v demands XOR(incident edges) == charges[v]."""
    inc = [[] for _ in range(nv)]
    for i, (a, b) in enumerate(edges, 1):
        inc[a].append(i)
        inc[b].append(i)
    clauses = []
    for v in range(nv):
        clauses += xor_clauses(inc[v], charges[v])
    return dict(n=len(edges), clauses=clauses, nv=nv, edges=[list(e) for e in edges],
                charges=list(charges))


def tseitin_regular(nv, d, seed, sat):
    edges, tries = random_regular_graph(nv, d, seed)
    inst = tseitin(nv, edges, charges_with_parity(nv, 0 if sat else 1, seed + 7919))
    inst.update(graph='regular', degree=d, graph_tries=tries)
    return inst


def tseitin_torus(a, b, seed, sat):
    edges = torus_graph(a, b)
    inst = tseitin(a * b, edges, charges_with_parity(a * b, 0 if sat else 1, seed + 7919))
    inst.update(graph='torus', dims=[a, b])
    return inst


def tseitin_grid(a, b, seed, sat):
    edges = grid_graph(a, b)
    inst = tseitin(a * b, edges, charges_with_parity(a * b, 0 if sat else 1, seed + 7919))
    inst.update(graph='grid', dims=[a, b])
    return inst


def tseitin_complete(m, seed, sat):
    edges = complete_graph(m)
    inst = tseitin(m, edges, charges_with_parity(m, 0 if sat else 1, seed + 7919))
    inst.update(graph='complete', degree=m - 1)
    return inst


NAMED_GRAPHS = {
    'K4': (4, [(0, 1), (0, 2), (0, 3), (1, 2), (1, 3), (2, 3)]),
    # wheel: hub 0, rim 1-2-3-4-1  (8 edges)
    'W4': (5, [(0, 1), (0, 2), (0, 3), (0, 4), (1, 2), (2, 3), (3, 4), (1, 4)]),
    'K33': (6, [(a, b) for a in range(3) for b in range(3, 6)]),
    'prism': (6, [(0, 1), (1, 2), (0, 2), (3, 4), (4, 5), (3, 5), (0, 3), (1, 4), (2, 5)]),
    'cube': (8, sorted((v, v ^ (1 << b)) for v in range(8) for b in range(3) if v < v ^ (1 << b))),
    # outer 5-cycle 0..4, spokes i -- i+5, inner pentagram 5..9
    'petersen': (10, sorted([tuple(sorted((i, (i + 1) % 5))) for i in range(5)] +
                            [(i, i + 5) for i in range(5)] +
                            [tuple(sorted((5 + i, 5 + (i + 2) % 5))) for i in range(5)])),
}


def tseitin_named(name, seed, sat):
    nv, edges = NAMED_GRAPHS[name]
    edges = sorted(tuple(sorted(e)) for e in edges)
    inst = tseitin(nv, edges, charges_with_parity(nv, 0 if sat else 1, seed + 7919))
    inst.update(graph=name)
    return inst


# --------------------------------------------------------------------------
# XOR systems
# --------------------------------------------------------------------------
def xor_system(n, m, k, seed, planted):
    """m random k-variable parity equations over n variables.

    planted=True: right-hand sides from a hidden random assignment (always SAT).
    planted=False: uniformly random right-hand sides."""
    rng = random.Random(seed)
    sol = [rng.randrange(2) for _ in range(n + 1)]
    eqs = []
    for _ in range(m):
        vs = rng.sample(range(1, n + 1), k)
        rhs = sum(sol[v] for v in vs) % 2 if planted else rng.randrange(2)
        eqs.append((vs, rhs))
    clauses = []
    for vs, r in eqs:
        clauses += xor_clauses(vs, r)
    return dict(n=n, clauses=clauses, eqs=[[list(vs), r] for vs, r in eqs],
                planted=sol[1:] if planted else None)


def xor_two_occurrence(m_eq, k, seed, sat, max_tries=200000):
    """k-XOR system in which every variable occurs in exactly two equations.

    Pairing model on m_eq equations with k stubs each; a variable is a pair of
    stubs from two DIFFERENT equations (no variable twice in one equation), but
    two equations may share several variables (parallel hyper-edges allowed).
    Retried until the equation graph is connected.  n = m_eq*k/2 variables.
    sat=True -> even total right-hand side, sat=False -> odd (connected, so UNSAT)."""
    if m_eq * k % 2:
        raise ValueError('m_eq*k must be even')
    rng = random.Random(seed)
    for tries in range(1, max_tries + 1):
        stubs = [e for e in range(m_eq) for _ in range(k)]
        rng.shuffle(stubs)
        pairs = [(stubs[i], stubs[i + 1]) for i in range(0, len(stubs), 2)]
        if any(a == b for a, b in pairs):
            continue
        if len(components(m_eq, pairs)) != 1:
            continue
        pairs = sorted((min(a, b), max(a, b)) for a, b in pairs)
        multi = len(pairs) - len(set(pairs))
        rhs = charges_with_parity(m_eq, 0 if sat else 1, seed + 7919)
        inc = [[] for _ in range(m_eq)]
        for i, (a, b) in enumerate(pairs, 1):
            inc[a].append(i)
            inc[b].append(i)
        eqs = [(inc[e], rhs[e]) for e in range(m_eq)]
        clauses = []
        for vs, r in eqs:
            clauses += xor_clauses(vs, r)
        return dict(n=len(pairs), clauses=clauses, eqs=[[list(vs), r] for vs, r in eqs],
                    nv=m_eq, edges=[list(p) for p in pairs], charges=rhs,
                    parallel_pairs=multi, graph_tries=tries)
    raise RuntimeError('no connected loop-free pairing found')


# --------------------------------------------------------------------------
# pigeonhole
# --------------------------------------------------------------------------
def php_var(i, k, h):
    """Pigeon i (0-based) sits in hole k (0-based); pigeon-major numbering."""
    return i * h + k + 1


def php(p, h):
    clauses = [[php_var(i, k, h) for k in range(h)] for i in range(p)]
    for k in range(h):
        for i in range(p):
            for j in range(i + 1, p):
                clauses.append([-php_var(i, k, h), -php_var(j, k, h)])
    return dict(n=p * h, clauses=clauses, pigeons=p, holes=h)


# --------------------------------------------------------------------------
# random k-CNF
# --------------------------------------------------------------------------
def random_kcnf(n, m, k, seed):
    rng = random.Random(seed)
    clauses = [[v * rng.choice((-1, 1)) for v in rng.sample(range(1, n + 1), k)]
               for _ in range(m)]
    return dict(n=n, clauses=clauses)


# --------------------------------------------------------------------------
# H-SUBSUME family
# --------------------------------------------------------------------------
def subsume_family(k):
    """G_k = {(x v a_i v b_i) : i=1..k} + {(-x v c)}.
    Numbering: x=1, a_i=1+i, b_i=1+k+i, c=2k+2."""
    x, c = 1, 2 * k + 2
    clauses = [[x, 1 + i, 1 + k + i] for i in range(1, k + 1)] + [[-x, c]]
    return dict(n=2 * k + 2, clauses=clauses, x=x, a=list(range(2, k + 2)),
                b=list(range(k + 2, 2 * k + 2)), c=c)


# --------------------------------------------------------------------------
# 2-CNF families (all in P)
# --------------------------------------------------------------------------
def implication_grid(a, b, variant):
    """Variables x[i][j] -> i*b + j + 1 on an a x b grid.

    variant 'mono'   : x[i][j] -> x[i+1][j], x[i][j] -> x[i][j+1]      (SAT)
    variant 'unsat'  : mono plus units x[0][0] and -x[a-1][b-1]        (UNSAT)
    variant 'equiv'  : right arrows as in mono, plus back arrows on rows
                       x[i][j+1] -> x[i][j] for even i (cycles)        (SAT)"""
    var = lambda i, j: i * b + j + 1
    clauses = []
    for i in range(a):
        for j in range(b):
            if i + 1 < a:
                clauses.append([-var(i, j), var(i + 1, j)])
            if j + 1 < b:
                clauses.append([-var(i, j), var(i, j + 1)])
                if variant == 'equiv' and i % 2 == 0:
                    clauses.append([-var(i, j + 1), var(i, j)])
    if variant == 'unsat':
        clauses += [[var(0, 0)], [-var(a - 1, b - 1)]]
    return dict(n=a * b, clauses=clauses, dims=[a, b])


def signed_graph_2cnf(nv, edges, seed, mode):
    """One 2-clause per edge of a graph on variables 1..nv.

    mode 'rand'    : independent random signs.
    mode 'planted' : random signs conditioned on a hidden assignment satisfying it.
    mode 'impl'    : implication u -> v with a random direction (always SAT).
    mode 'nae'     : both (u v w) and (-u v -w): u != w  (2-colouring; XOR-like)."""
    rng = random.Random(seed)
    hidden = [None] + [rng.randrange(2) for _ in range(nv)]
    clauses = []
    for a, b in edges:
        u, w = a + 1, b + 1
        if mode == 'rand':
            clauses.append([u * rng.choice((-1, 1)), w * rng.choice((-1, 1))])
        elif mode == 'planted':
            while True:
                c = [u * rng.choice((-1, 1)), w * rng.choice((-1, 1))]
                if any((l > 0) == bool(hidden[abs(l)]) for l in c):
                    break
            clauses.append(c)
        elif mode == 'impl':
            if rng.randrange(2):
                u, w = w, u
            clauses.append([-u, w])
        elif mode == 'nae':
            clauses += [[u, w], [-u, -w]]
        else:
            raise ValueError(mode)
    return dict(n=nv, clauses=clauses, edges=[list(e) for e in edges])


def regular_2cnf(nv, d, seed, mode):
    edges, tries = random_regular_graph(nv, d, seed)
    inst = signed_graph_2cnf(nv, edges, seed + 104729, mode)
    inst.update(degree=d)
    return inst


def grid_2cnf(a, b, seed, mode):
    inst = signed_graph_2cnf(a * b, grid_graph(a, b), seed + 104729, mode)
    inst.update(dims=[a, b])
    return inst


def ladder_2cnf(k):
    """Two implication rails x_1->..->x_k, y_1->..->y_k with rungs x_i -> y_i and
    crossings y_i -> x_{i+1}.  x_i = 2i-1, y_i = 2i.  SAT (all false)."""
    clauses = []
    for i in range(1, k + 1):
        x, y = 2 * i - 1, 2 * i
        clauses.append([-x, y])
        if i < k:
            clauses += [[-x, x + 2], [-y, y + 2], [-y, x + 2]]
    return dict(n=2 * k, clauses=clauses)


def bipartite_implication(k, seed, p):
    """Dense bipartite implication structure: sources s_i (1..k), middle m_j (k+1..2k),
    sinks t_l (2k+1..3k).  s_i -> m_j and m_j -> t_l each present with probability p
    (p=1: complete).  Pure implications, SAT."""
    rng = random.Random(seed)
    clauses = []
    for i in range(1, k + 1):
        for j in range(k + 1, 2 * k + 1):
            if p >= 1 or rng.random() < p:
                clauses.append([-i, j])
    for j in range(k + 1, 2 * k + 1):
        for l in range(2 * k + 1, 3 * k + 1):
            if p >= 1 or rng.random() < p:
                clauses.append([-j, l])
    return dict(n=3 * k, clauses=clauses)


def subsume_2cnf(k):
    """2-CNF analogue of the H-SUBSUME blocker (constructed in this study):
       (z_i v a_i), (z_i v x), (-z_i v b_i), (-a_i v d_i) for i=1..k, and (-x v c).
    Numbering: z_i = i, x = k+1, a_i = k+1+i, b_i = 2k+1+i, d_i = 3k+1+i, c = 4k+2.
    The natural order (z's, x, a's, ...) is the adversarial one."""
    x, c = k + 1, 4 * k + 2
    clauses = []
    for i in range(1, k + 1):
        z, a, b, dd = i, k + 1 + i, 2 * k + 1 + i, 3 * k + 1 + i
        clauses += [[z, a], [z, x], [-z, b], [-a, dd]]
    clauses.append([-x, c])
    return dict(n=4 * k + 2, clauses=clauses)


# --------------------------------------------------------------------------
# Horn families (all in P)
# --------------------------------------------------------------------------
def random_horn3(n, m, seed, facts=0, goals=0):
    """m random definite Horn 3-clauses (-a v -b v c) on distinct variables, plus
    `facts` positive unit clauses and `goals` all-negative 3-clauses."""
    rng = random.Random(seed)
    clauses = []
    for _ in range(m):
        a, b, c = rng.sample(range(1, n + 1), 3)
        clauses.append([-a, -b, c])
    for _ in range(facts):
        clauses.append([rng.randrange(1, n + 1)])
    for _ in range(goals):
        a, b, c = rng.sample(range(1, n + 1), 3)
        clauses.append([-a, -b, -c])
    return dict(n=n, clauses=clauses)


def subsume_horn(k):
    """Horn renaming of G_k: {(-x v -a_i v -b_i)} + {(x v -c)} (same numbering as G_k)."""
    x, c = 1, 2 * k + 2
    clauses = [[-x, -(1 + i), -(1 + k + i)] for i in range(1, k + 1)] + [[x, -c]]
    return dict(n=2 * k + 2, clauses=clauses)


def horn_grid(a, b, variant):
    """Definite Horn 'AND-grid': x[i+1][j+1] <- x[i][j+1] & x[i+1][j]
    (clause -x[i][j+1] v -x[i+1][j] v x[i+1][j+1]).
    variant 'free' : no units (SAT, all false or all true).
    variant 'fire' : units on the whole first row and first column (forces everything
                     true, SAT).
    variant 'unsat': 'fire' plus the unit -x[a-1][b-1]."""
    var = lambda i, j: i * b + j + 1
    clauses = []
    for i in range(a - 1):
        for j in range(b - 1):
            clauses.append([-var(i, j + 1), -var(i + 1, j), var(i + 1, j + 1)])
    if variant in ('fire', 'unsat'):
        clauses += [[var(0, j)] for j in range(b)] + [[var(i, 0)] for i in range(1, a)]
    if variant == 'unsat':
        clauses.append([-var(a - 1, b - 1)])
    return dict(n=a * b, clauses=clauses, dims=[a, b])
