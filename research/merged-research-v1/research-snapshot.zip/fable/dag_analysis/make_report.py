#!/usr/bin/env python3
"""Assemble REPORT.md = narrative (report_text.py) + tables regenerated from results/.

    python3 analyze.py && python3 make_report.py

Tables are copied verbatim from results/tables.md (written by analyze.py) so that
every number in a table is traceable to results/E*.json; the narrative lives in
report_text.py and quotes numbers from those tables.
"""
import re
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))


def sections(text):
    """Split tables.md into {'E1': [blocks...], ...}; a block is a paragraph/table."""
    out = {}
    cur = None
    for part in re.split(r'\n\s*\n', text):
        part = part.strip('\n')
        if not part:
            continue
        m = re.match(r'#{2,3} (E\d+b?)( / (E\d+))?', part)
        if m:
            cur = m.group(1) if not m.group(3) else f'{m.group(1)}/{m.group(3)}'
            out.setdefault(cur, [])
            continue
        if cur is not None:
            out[cur].append(part)
    return out


def pick(blocks, *prefixes, with_next=True, maxrows=None):
    """Blocks whose first line starts with one of the prefixes (plus the table that
    follows a bold title when the title is a block of its own)."""
    res = []
    i = 0
    while i < len(blocks):
        b = blocks[i]
        if any(b.startswith(p) for p in prefixes):
            res.append(b)
            if with_next and not b.lstrip().startswith('|') and '\n|' not in b and i + 1 < len(blocks) \
                    and blocks[i + 1].lstrip().startswith('|'):
                res.append(blocks[i + 1])
                i += 1
        i += 1
    if maxrows:
        res = [trim(b, maxrows) for b in res]
    return '\n\n'.join(res)


def trim(block, maxrows):
    lines = block.split('\n')
    if len(lines) <= maxrows + 2:
        return block
    return '\n'.join(lines[:maxrows + 2]) + f'\n| ... ({len(lines) - maxrows - 2} more rows in results/tables.md) |'


def main():
    import report_text
    tables = (HERE / 'results' / 'tables.md').read_text()
    sec = sections(tables)
    md = report_text.build(sec, pick)
    for attempt in range(60):
        try:
            (HERE / 'REPORT.md').write_text(md)
            print('wrote REPORT.md', len(md), 'chars')
            return
        except OSError as e:
            print('write refused, retrying', e)
            time.sleep(5)
    raise SystemExit('could not write REPORT.md')


if __name__ == '__main__':
    main()
