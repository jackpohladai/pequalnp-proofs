import sys, time, random, gc, cProfile, pstats
sys.path.insert(0, '.')
gc.disable()
import families as F, orders as O, verify as V, harness as H
inst = F.xor_two_occurrence(128, 4, 1, False)
n, cl = inst['n'], inst['clauses']
order = O.make_order('natural', n, cl)
d = H.CappedDAG(400000, time.perf_counter() + 100, 3000)
pr = cProfile.Profile()
pr.enable()
root = d.cnf(cl)
t0 = time.perf_counter()
for i, v in enumerate(order):
    root = d.forget(root, v)
    if time.perf_counter() - t0 > 40: break
pr.disable()
print('steps', i + 1, 'of', n, 'alloc', len(d.nodes), 'cache', len(d.cofactor_cache))
pstats.Stats(pr).sort_stats('tottime').print_stats(8)
