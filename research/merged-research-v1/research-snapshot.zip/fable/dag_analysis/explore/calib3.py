import sys, time, random, gc
sys.path.insert(0, '.')
import families as F, orders as O, verify as V, harness as H
if len(sys.argv) > 3 and sys.argv[3] == 'nogc': gc.disable()
d_, nv = int(sys.argv[1]), int(sys.argv[2])
inst = F.tseitin_regular(nv, d_, 1, sat=False)
n, cl = inst['n'], inst['clauses']
for name in ('natural', 'min_fill', 'max_degree'):
    order = O.make_order(name, n, cl)
    r = H.run_order(n, cl, order, time_cap=60, mem_cap_mb=3000, reach=False)
    print(name, {k: r[k] for k in ('result', 'alloc', 'child_refs', 'cofactor_cache', 'seconds', 'maxrss_mb')}, flush=True)
