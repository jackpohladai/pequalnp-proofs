import sys, time, random, cProfile, pstats
sys.path.insert(0, '.')
import families as F, orders as O, verify as V, harness as H

inst = F.tseitin_regular(256, 3, 1, sat=False)
n, cl = inst['n'], inst['clauses']
order = O.make_order('min_fill', n, cl)
d = H.CappedDAG(400000, time.perf_counter() + 40, 2000)
root = d.cnf(cl)
t0 = time.perf_counter()
worst = []
for i, v in enumerate(order):
    t = time.perf_counter(); a = len(d.nodes); c = len(d.cofactor_cache)
    root = d.forget(root, v)
    dt = time.perf_counter() - t
    worst.append((round(dt, 3), i, v, len(d.nodes) - a, len(d.cofactor_cache) - c, H.reach_count(d, root)))
    if time.perf_counter() - t0 > 30: break
worst.sort(reverse=True)
print('steps done', i + 1, 'of', n, 'total', round(time.perf_counter() - t0, 2))
print(worst[:15])
