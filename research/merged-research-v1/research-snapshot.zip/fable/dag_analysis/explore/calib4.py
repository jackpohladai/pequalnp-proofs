import sys, time, random, gc
sys.path.insert(0, '.')
gc.disable()
import families as F, orders as O, verify as V, harness as H
def go(tag, inst, names, meta=None):
    n, cl = inst['n'], inst['clauses']
    row = []
    for name in names:
        order = O.make_order(name, n, cl, meta)
        r = H.run_order(n, cl, order, time_cap=20, reach=False)
        row.append((name, r['result'] if r['result'] != 'CAP' else 'CAP:' + r['cap_reason'], r['alloc'], r['cofactor_cache'], r['seconds']))
    print(tag, n, F.encoded_bits(cl), row, flush=True)
which = sys.argv[1]
if which == 'xor':
    for n in (16, 24, 32, 40, 48, 56, 64, 72, 80, 88, 96):
        go('xor3 planted m=n', F.xor_system(n, n, 3, 1, True), ('natural', 'min_degree', 'min_fill', 'shuffle1'))
if which == 'xor4':
    for m in (8, 16, 32, 64, 128, 256):
        go('xor4 2occ', F.xor_two_occurrence(m, 4, 1, False), ('natural', 'min_degree', 'min_fill', 'shuffle1'))
if which == 'php':
    for h in range(2, 11):
        inst = F.php(h + 1, h)
        go(f'php h={h}', inst, ('pigeon_major', 'hole_major', 'min_degree', 'min_fill', 'shuffle1'), inst)
if which == 'cnf':
    for dens in (2.0, 3.0, 4.26):
        for n in (16, 20, 24, 28, 32, 36, 40, 48, 56):
            go(f'3cnf dens={dens}', F.random_kcnf(n, round(dens * n), 3, 1), ('natural', 'min_degree', 'min_fill', 'shuffle1'))
