import sys, time, random
sys.path.insert(0, '.')
import families as F, orders as O, verify as V, harness as H

# 1. selfcheck: capped subclass == plain candidate
for seed in range(5):
    inst = F.random_kcnf(14, 42, 3, seed)
    for name in ('natural', 'reverse', 'min_degree', 'min_fill', 'max_degree', 'bfs', 'shuffle3'):
        order = O.make_order(name, inst['n'], inst['clauses'])
        H.selfcheck_identical(inst['n'], inst['clauses'], order)
print('selfcheck ok')

# 2. Tseitin calibration
for d in (3, 4, 5):
    for nv in (16, 32, 64, 128, 256):
        if nv * d % 2: continue
        inst = F.tseitin_regular(nv, d, 1, sat=False)
        n, cl = inst['n'], inst['clauses']
        row = []
        for name in ('natural', 'shuffle1', 'min_degree', 'min_fill', 'max_degree', 'bfs'):
            t = time.perf_counter()
            order = O.make_order(name, n, cl)
            to = time.perf_counter() - t
            r = H.run_order(n, cl, order, time_cap=20)
            row.append((name, r['result'], r['alloc'], r['seconds'], round(to, 2), r['peak_reachable'], r['maxrss_mb']))
        print(d, nv, n, F.encoded_bits(cl), row, flush=True)
