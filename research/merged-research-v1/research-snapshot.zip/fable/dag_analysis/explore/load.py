import time
for rep in range(6):
    w0, c0 = time.perf_counter(), time.process_time()
    s = 0
    for i in range(6_000_000):
        s += i * i % 7
    w, c = time.perf_counter() - w0, time.process_time() - c0
    print(f'wall {w:.2f}s cpu {c:.2f}s ratio {w / c:.2f}', flush=True)
