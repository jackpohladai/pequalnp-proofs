# L-alg-001 / Brief A - decisive structural tests of `native-search/residual_dag.py`

Author: research subagent A (experimentalist). Everything below is a finite, empirical measurement. Fitted growth rates describe the measured range only; nothing here proves an asymptotic bound and nothing here bears on P vs NP beyond "this candidate, as written, is not a polynomial-time SAT decider on the families below".

Candidate under test: `work/alg001/native-search/residual_dag.py`, imported read-only, SHA-256 `eb68d16927c8405ff51d271a258be32a3e7a311daf70ec7eb326161f8db1e255` (identical to the hash in `adversarial/residual-dag-review.txt`). The measured loop is exactly `root = d.cnf(clauses); for v in order: root = d.forget(root, v)`; answer = `root == 1`.

## 0. Verdicts at a glance

| hypothesis | verdict | key numbers (all empirical, finite range) |
|---|---|---|
| H-TSEITIN | **supported** | random d-regular graphs, d=3,4,5, n up to 288 edges: 33/33 (order x degree) series are better fit by a power law; largest fitted exponent b = 1.79 (tree_first_bfs), largest last-4-sizes exponent 1.96 (bfs). Torus: max b = 1.58. Hill-climbed worst orders (d=3, n=12..72): exponent 1.63, R2 pow 0.999 vs exp 0.9424. Exhaustive over all 720 / 40320 orders of K4 / W4: max/min = 89/78 and 158/118. No order with super-polynomial-looking growth was found. |
| H-XOR3 | **supported** (weaker evidence for the best orders, see sec. 4) | Exponential rate in bits/variable - m=n planted: natural 0.149 (n<=64, power), shuffle 0.183 (n<=48, exponential), min_degree 0.072 (n<=112, exponential), min_fill 0.074 (n<=120, exponential), greedy_min 0.063 (n<=80, exponential); m=n+5 random rhs: natural 0.153 (n<=56, exponential), shuffle 0.149 (n<=56, exponential), min_degree 0.069 (n<=120, exponential), min_fill 0.066 (n<=120, exponential), greedy_min 0.090 (n<=32, power). Control: 4-XOR with every variable in exactly 2 equations is polynomial-looking (7/7 series power-law, max b = 1.77). |
| H-PHP | **supported** in h; note the refinement about n | alloc(h+1)/alloc(h): hole-major [3.65, 2.89, 2.65, 2.56, 2.52, 2.49, 2.45, 2.42] (h=2..10), pigeon-major [4.04, 3.74, 3.75, 3.71, 3.57, 3.41], minimum over every order tried [3.04, 2.74, 2.23, 3.16, 3.35, 2.49, 2.45, 2.42] (never below 2.23). In the number of variables n = h(h+1) this is 2^Theta(sqrt n) for the best orders (hole-major fits c*h^2*2^h), i.e. super-polynomial but sub-exponential in n; random orders grow much faster (median ratio [3.85, 4.45, 5.63, 7.27]). Exhaustive: all 720 orders of PHP(3,2) give 45..50 nodes, all 40320 orders of PHP(4,2) give 59..82. |
| H-3CNF | **supported** | 15/15 (density x order) series are better fit by an exponential; rates 0.20..0.35 bits/variable; even the best order (min-degree / min-fill / DAG-aware greedy) at density 2.0, far below the threshold, has rate about 0.2. Answers: 1138 completed runs, 1138 checked, 0 disagreements. |
| H-2SAT | **2-CNF: no family is exponential under every order tried (a DAG-aware greedy order stays near-linear), but every standard fixed order is; Horn: see numbers** | 2-CNF on random d-regular graphs (d=3,4,5; random / planted / implication signs; 6 variants): min-degree, min-fill, natural and random orders are exponential-looking (min-degree rate 0.09..0.15 bits/var, capped by n = 56..80), **but the DAG-aware greedy_min order has power-law exponent 1.02..1.70** over its measured range. random Horn 3-CNF (in P): slowest-growing order per variant - {"density": 2.0, "facts": 0, "goals": 0}: greedy_min 0.10 bits/var (exponential, n<=40). Details and the per-family table in sec. 7. |
| H-SUBSUME | **supported, with a corrected constant** | order x, a_1..a_k: the largest OR node has exactly 2^(k-1)+2 children (not 2^k+O(1)) and 2^(k+1)+6k+3 nodes are allocated, for every k = 2..14 (k=14: 8194 children, 32855 nodes); order a_1..a_k, x: 6k+7 nodes, largest OR arity 3. |
| E7 census | done | Merging semantically equal nodes would save little: distinct functions / reachable nodes at the peak step has median kcnf 0.890, php 1.000, rand2cnf 1.000, random_horn3 0.893, subsume 1.000, subsume_2cnf 1.000, tseitin_complete 1.000, tseitin_regular 1.000, xor3 1.000. Over ALL allocated and/or nodes (n <= 16) the median ratio is kcnf 0.691, php 0.734, rand2cnf 0.833, random_horn3 0.779, subsume 0.958, subsume_2cnf 0.943, tseitin_complete 0.852, tseitin_regular 0.849, xor3 0.814. The waste in G_k is of a different kind (subsumed children: 2^(k-1)-1 of the 2^(k-1)+2 children of one OR), invisible to equivalence merging. |
| E8 repair | done (stretch) | Repaired subclass validated at every elimination stage on 2000 random small CNFs (11108 full truth-table comparisons, 0 failures). G_k (order x, a..): 32855 -> 119 nodes at k=14, rate 0.884 -> 0.185 bits per k (exponential -> linear, 8k+7). PHP: fitted rate changes by -0.105..+0.030 bits per hole across 13 orders (rates essentially unchanged). Random 3-CNF: rate changes by -0.0117..+0.0081 bits per variable across 5 (density, order) series (unchanged). |

## 1. Method

**Harness.** `harness.py` subclasses the candidate only to abort a run from inside `put()`
(node cap 400000, soft wall-clock cap 25 s, memory cap 480 MB peak RSS); it calls the original
`put` and overrides nothing else (checked in E0). Every run is its own forked process with a
SIGALRM backstop at 27.5 s and a parent hard kill at 29.5 s; sub-millisecond instances are run in
batches of <= 16 s. The cyclic garbage collector is switched off in the workers (the DAG has no
reference cycles; this changes speed only). For every run the JSON records family, parameters,
seed, order, result, `len(d.nodes)` (allocated), stored child references, `len(d.cofactor_cache)`,
`d.factor_steps`, peak reachable nodes (sampled; `reach_exact` says whether every step was
sampled), wall and CPU seconds, the induced width of the order on the primal graph, and
N = sum over literals of (4 + 2*bitlen(var)) + 2 per clause.

**Result vocabulary.** SAT / UNSAT = the candidate's answer after eliminating every variable.
CAP = stopped by a resource cap (`cap_reason` = nodes / time / memory / alarm / hard_kill);
ORDER_TIMEOUT = the order itself could not be computed in its budget. CAP and ORDER_TIMEOUT are
never counted as refutations or as lower bounds; a CAP only says "at least this many nodes had
been allocated when the run was stopped".

**Independent expected answers** (`verify.py`, never importing the candidate): Tseitin = parity of
the total charge of each connected component, cross-checked by Gaussian elimination over GF(2)
with the solution verified against the clauses; XOR systems = GF(2) elimination; PHP = pigeonhole
principle; 2-CNF = implication-graph SCC; Horn = unit propagation to the least model; random 3-CNF
= `adversarial/oracle.py` (exhaustive) for n <= 20, cross-checked with my own complete DPLL, and
that DPLL alone for n > 20 (labelled as such). Every SAT answer used as "expected" has a witness
checked against the original clauses.

**Orders** (`orders.py`, all deterministic): `natural`, `reverse`, `shuffleNN` (seeded), `min_degree`
and `min_fill` and `max_degree` (greedy on the primal graph, updated as in bucket elimination, ties
to the smallest index), `bfs` and `dfs` from variable 1, `pigeon_major` / `hole_major` (PHP),
`scc_topo` / `scc_topo_rev` (2-CNF: topological order of the implication-graph SCCs),
`tree_first` / `tree_first_bfs` (Tseitin: a spanning caterpillar first, chords last - an adversarial
order designed from the lead's own mechanism), and two **DAG-aware** orders `greedy_min` /
`greedy_max` (`harness.greedy_extend`): at each step every candidate variable (all of them when
<= 24 remain, otherwise a seeded sample of 12) is forgotten on trial, the newly allocated nodes are
counted, the trial is undone exactly, and the candidate with the fewest / most new nodes is
committed. Greedy orders are computed in resumable chunks of <= 16 s (max 6 chunks); the measured
run is then an ordinary single run with that order.

**Fits** (`analyze.py`). Power law ln(alloc) = a + b ln(x) and exponential log2(alloc) = c + r x by
least squares, on the geometric mean over instances, **using only sizes at which every run of the
series completed** (otherwise survivors would bias the mean downwards). "tail" = the same fit on
the last four sizes. "better fit" = larger R^2. A series is no longer scheduled at larger sizes
once fewer than 25-40% of its runs complete at a size.

**Machine load (important).** The host was massively oversubscribed during the whole study (8
cores, load average 130 at the start, 300-550 for most of it; wall/CPU ratio measured at 3-14x).
Because the 30 s limit is a wall-clock limit, a "25 s" run received only about 1-6 CPU-seconds.
Consequences: (1) the node cap of 400000 was almost never the binding cap - `time` was; (2) the
largest completed sizes are smaller than on an idle machine and depend on the load at that
moment; (3) some runs at moderate sizes were lost to load spikes (visible as a size with e.g. 3/4
completed, followed by a larger size that is complete) - `run_experiments.py HOLES <EXP>` re-runs
exactly those; (4) the host also intermittently refused file writes (EPERM) under load; the result
store retries. Node counts of completed runs are deterministic and unaffected.

## 2. E0 - sanity of the harness

`python3 run_experiments.py E0`: 1680 runs on random small instances of six families under seven orders each: (i) the capped subclass used for all measurements allocates exactly the same nodes, child references, cofactor-cache entries and factor steps as the plain `residual_dag.DAG`; (ii) every candidate answer equals the exhaustive oracle `adversarial/oracle.py`; (iii) my verifiers (GF(2), 2-SAT SCC, Horn unit propagation, DPLL) equal the oracle; (iv) allocation counts are identical under `PYTHONHASHSEED` 0, 1 and 12345 (hash-seed independent: True). Failed tasks: 0.

## 3. E1 - Tseitin formulas (H-TSEITIN)

**Instances.** Tseitin formulas on (a) uniform random simple connected d-regular graphs,
d in {3, 4, 5} (pairing model with rejection), (b) the a x a torus, (c) K_m; for each graph a
satisfiable charge (even total) and an unsatisfiable one (odd total), charges random, two seeds.
Variable i = i-th edge in lexicographic order, so `natural` is a vertex-major order.
**Orders.** natural, reverse, min_degree, min_fill, max_degree, bfs, 5 shuffles, greedy_min and
greedy_max (up to ~100 variables), plus the designed adversarial orders tree_first / tree_first_bfs.
**Answers.** 1808 runs, 1642 completed, all 1642
checked against charge parity + GF(2): **0 disagreements**. Non-completions:
{"CAP:time": 166} (all resource caps on the loaded machine, see sec. 12; the
binding resource for Tseitin is *time*, because the candidate re-traverses the whole reachable DAG
for both cofactors of every forgotten variable: `cofactor_cache` grows like n x reachable ~ n^2
while the node count stays far below the 400000 cap).

**Reading.** Allocation is polynomial-looking for every order tried, with exponent between about 1.2
(min-degree / min-fill / greedy_min) and about 1.9 (bfs, max_degree, tree_first_bfs). The exponential
model fits clearly worse in every regular-graph series (R^2 about 0.85-0.93 against 0.99+), and the
local log-log slopes do not drift upwards beyond 2. The worst order I could construct by reasoning
(tree_first_bfs: grow one component as a caterpillar, then eliminate the chords) and the worst
orders found by hill-climbing both stay below about 2.5 n^2 nodes; max/n^2 *decreases* with n in
the hill-climb table. This agrees with the lead's mechanism and with the counting it implies:
each forgotten edge re-creates O(1) nodes for every historical sub-component above its two
endpoints, at most O(nv) of them, giving O(n * nv) = O(n^2) nodes for bounded degree.
For K_m the degree grows with the instance, so the right yardstick is the input size N
(each vertex contributes 2^(m-2) clauses): the exponent against N is the one to read in that table.

**tseitin_regular {"d": 3}: allocated nodes (gmean over 2 charges x 2 seeds [x 5 shuffles])**

| nv | n vars | N bits | natural | reverse | min_degree | min_fill | greedy_min | bfs | max_degree | greedy_max | tree_first | tree_first_bfs | shuffle |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 8 | 12 | 1040 | 221 | 231 | 209 | 209 | 202 | 242 | 235 | 265 | 227 | 257 | 222 |
| 12 | 18 | 1696 | 319 | 331 | 290 | 290 | 289 | 319 | 429 | 402 | 373 | 387 | 348 |
| 16 | 24 | 2400 | 576 | 567 | 473 | 462 | 469 | 689 | 648 | 805 | 569 | 744 | 556 |
| 24 | 36 | 3888 | 922 | 886 | 760 | 757 | 761 | 1278 | 1253 | 1381 | 1095 | 1481 | 937 |
| 32 | 48 | 5488 | 1462 | 1487 | 1025 | 1038 | 1020 | 2011 | 2137 | 2225 | 1714 | 2426 | 1414 |
| 48 | 72 | 8832 | 2258 | 2453 | 1718 | 1703 | 1734 | 3832 | 3704 | 4026 | 3426 | 4970 | 2477 |
| 64 | 96 | 12416 | 3709 | 3838 | 2453 | 2341 | 2329 | 7439 | 6520 | 7446 | 5615 | 8949 | 3543 |
| 96 | 144 | 19856 | 7274 | 7481 | >4037* (3/4) | >3886* (3/4) |  | >14912* (3/4) | 13874 |  | 11634 | 18704 | >6957* (17/20) |
| 128 | 192 | 27792 | 10826 | 9990 | 5723 | 5351 |  | 26667 | 23960 |  | 19543 | 33647 | 10208 |
| 192 | 288 | 44192 | 21532 | 21970 | 9182 | 8820 |  | 61065 | 51031 |  | >44441* (1/4) | >77319* (1/4) | 19687 |
| 256 | 384 | 61600 | CAP(time) | CAP(time) | CAP(time) | CAP(time) |  | CAP(time) | CAP(time) |  |  |  | CAP(time) |

**tseitin_regular {"d": 4}: allocated nodes (gmean over 2 charges x 2 seeds [x 5 shuffles])**

| nv | n vars | N bits | natural | reverse | min_degree | min_fill | greedy_min | bfs | max_degree | greedy_max | tree_first | tree_first_bfs | shuffle |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 8 | 16 | 2880 | 423 | 405 | 392 | 384 | 375 | 452 | 442 | 484 | 437 | 478 | 426 |
| 12 | 24 | 4736 | 763 | 674 | 611 | 625 | 624 | 795 | 883 | 910 | 821 | 915 | 735 |
| 16 | 32 | 6624 | 1149 | 1062 | 884 | 864 | 861 | 1231 | 1301 | 1354 | 1290 | 1452 | 1083 |
| 24 | 48 | 10848 | 2073 | 1841 | 1492 | 1424 | 1394 | 2701 | 2519 | 2821 | 2525 | 2989 | 1921 |
| 32 | 64 | 15104 | 3149 | 2836 | 2063 | 1952 | 1988 | 3977 | 4166 | 4507 | 4020 | 4862 | 2927 |
| 48 | 96 | 24576 | 5753 | 5132 | 3399 | 3297 | 3563 | 8426 | 8514 | 9010 | 8592 | 10483 | 5035 |
| 64 | 128 | 34080 | 8674 | 7946 | 5041 | 4731 |  | 14777 | 14015 |  | 13823 | 18211 | 8246 |
| 96 | 192 | 55072 | 17245 | 16572 | 8104 | 7651 |  | 32446 | 29421 |  | 30025 | 39074 | 15532 |
| 128 | 256 | 76096 | CAP(time) | >26590* (1/4) | CAP(time) | CAP(time) |  | >51181* (1/4) | CAP(time) |  | CAP(time) | CAP(time) | CAP(time) |
| 192 | 384 | 122176 |  | CAP(time) |  |  |  | CAP(time) |  |  |  |  |  |

**tseitin_regular {"d": 5}: allocated nodes (gmean over 2 charges x 2 seeds [x 5 shuffles])**

| nv | n vars | N bits | natural | reverse | min_degree | min_fill | greedy_min | bfs | max_degree | greedy_max | tree_first | tree_first_bfs | shuffle |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 8 | 20 | 7552 | 750 | 714 | 673 | 654 | 612 | 763 | 784 | 744 | 793 | 802 | 740 |
| 12 | 30 | 12160 | 1295 | 1255 | 1085 | 1083 | 1200 | 1386 | 1412 | 1295 | 1446 | 1493 | 1289 |
| 16 | 40 | 17344 | 1871 | 1748 | 1520 | 1513 | 1586 | 2120 | 2112 | 1900 | 2195 | 2415 | 1846 |
| 24 | 60 | 27840 | 3234 | 3199 | 2452 | 2386 | 2605 | 4144 | 4005 | 3590 | 4251 | 4745 | 3227 |
| 32 | 80 | 39424 | 5467 | 4772 | 3621 | 3483 | 3986 | 6680 | 6720 | 5494 | 6920 | 7897 | 5055 |
| 48 | 120 | 62976 | 10094 | 9047 | 5883 | 5637 |  | 13769 | 13601 |  | 14548 | 16585 | 9044 |
| 64 | 160 | 88640 | 13649 | 12555 | 7853 | 7496 |  | 22865 | 21359 |  | 23908 | 28070 | 13988 |
| 96 | 240 | 140864 | CAP(time) | CAP(time) | CAP(time) | CAP(time) |  | CAP(time) | CAP(time) |  | CAP(time) | CAP(time) | CAP(time) |

**tseitin_torus {}: allocated nodes (gmean over 2 charges x 2 seeds [x 5 shuffles])**

| a | n vars | N bits | natural | reverse | min_degree | min_fill | greedy_min | bfs | max_degree | greedy_max | shuffle |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 3 | 18 | 3344 | 525 | 469 | 448 | 443 | 425 | 539 | 556 | 551 | 516 |
| 4 | 32 | 6624 | 1165 | 959 | 846 | 846 | 884 | 1219 | 1324 | 1459 | 1119 |
| 5 | 50 | 11376 | 2068 | 1667 | 1540 | 1502 | 1457 | 2459 | 2673 | 2962 | 2095 |
| 6 | 72 | 17472 | 3339 | 2629 | 2220 | 2243 | 2235 | 4079 | 4561 | 4900 | 3485 |

**tseitin_torus {}** (x = n; gmean over instances/shuffles; fits use fully completed sizes only)

| series / order | pts | largest complete n | alloc there (gmean) | power exp b | tail b (last 4) | R2 pow | exp rate bits/var | tail rate | R2 exp | better fit | power exp vs N | first incomplete size |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| natural | 4 | 72 | 3339 | 1.33 | 1.33 | 1.000 | 0.0480 | 0.0480 | 0.954 | power | 1.11 | - |
| reverse | 4 | 72 | 2629 | 1.24 | 1.24 | 1.000 | 0.0450 | 0.0450 | 0.960 | power | 1.04 | - |
| min_degree | 4 | 72 | 2220 | 1.17 | 1.17 | 0.998 | 0.0424 | 0.0424 | 0.955 | power | 0.98 | - |
| min_fill | 4 | 72 | 2243 | 1.18 | 1.18 | 0.999 | 0.0427 | 0.0427 | 0.960 | power | 0.99 | - |
| greedy_min | 4 | 72 | 2235 | 1.19 | 1.19 | 0.999 | 0.0430 | 0.0430 | 0.950 | power | 1.00 | - |
| bfs | 4 | 72 | 4079 | 1.47 | 1.47 | 1.000 | 0.0532 | 0.0532 | 0.960 | power | 1.23 | - |
| max_degree | 4 | 72 | 4561 | 1.52 | 1.52 | 1.000 | 0.0551 | 0.0551 | 0.959 | power | 1.28 | - |
| greedy_max | 4 | 72 | 4900 | 1.58 | 1.58 | 0.998 | 0.0568 | 0.0568 | 0.942 | power | 1.33 | - |
| shuffle | 4 | 72 | 3485 | 1.38 | 1.38 | 1.000 | 0.0500 | 0.0500 | 0.963 | power | 1.16 | - |

Fits per order (log-log slope b of allocated nodes vs n = number of edge variables, and vs the encoded input size N; exponential rate shown for contrast):

**tseitin_regular {"d": 3}** (x = n; gmean over instances/shuffles; fits use fully completed sizes only)

| series / order | pts | largest complete n | alloc there (gmean) | power exp b | tail b (last 4) | R2 pow | exp rate bits/var | tail rate | R2 exp | better fit | power exp vs N | first incomplete size |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| natural | 10 | 288 | 21532 | 1.45 | 1.59 | 0.997 | 0.0228 | 0.0128 | 0.870 | power | 1.23 | 256: 0/4 done (timex4) |
| reverse | 10 | 288 | 21970 | 1.44 | 1.55 | 0.997 | 0.0227 | 0.0126 | 0.868 | power | 1.22 | 256: 0/4 done (timex4) |
| min_degree | 9 | 288 | 9182 | 1.21 | 1.21 | 0.999 | 0.0183 | 0.0110 | 0.845 | power | 1.02 | 96: 3/4 done (timex1) |
| min_fill | 9 | 288 | 8820 | 1.19 | 1.19 | 0.999 | 0.0180 | 0.0109 | 0.843 | power | 1.01 | 96: 3/4 done (timex1) |
| greedy_min | 7 | 96 | 2329 | 1.20 | 1.17 | 0.997 | 0.0406 | 0.0271 | 0.916 | power | 1.01 | - |
| bfs | 9 | 288 | 61065 | 1.78 | 1.96 | 0.994 | 0.0274 | 0.0179 | 0.875 | power | 1.50 | 96: 3/4 done (timex1) |
| max_degree | 10 | 288 | 51031 | 1.69 | 1.87 | 0.998 | 0.0268 | 0.0151 | 0.874 | power | 1.44 | 256: 0/4 done (timex4) |
| greedy_max | 7 | 96 | 7446 | 1.61 | 1.68 | 0.994 | 0.0548 | 0.0394 | 0.934 | power | 1.35 | - |
| tree_first | 9 | 192 | 19543 | 1.63 | 1.78 | 0.997 | 0.0342 | 0.0207 | 0.906 | power | 1.37 | 192: 1/4 done (timex3) |
| tree_first_bfs | 9 | 192 | 33647 | 1.79 | 1.93 | 0.997 | 0.0376 | 0.0225 | 0.898 | power | 1.51 | 192: 1/4 done (timex3) |
| shuffle | 9 | 288 | 19687 | 1.41 | 1.50 | 0.999 | 0.0216 | 0.0138 | 0.866 | power | 1.20 | 96: 17/20 done (timex3) |

**tseitin_regular {"d": 4}** (x = n; gmean over instances/shuffles; fits use fully completed sizes only)

| series / order | pts | largest complete n | alloc there (gmean) | power exp b | tail b (last 4) | R2 pow | exp rate bits/var | tail rate | R2 exp | better fit | power exp vs N | first incomplete size |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| natural | 8 | 192 | 17245 | 1.48 | 1.54 | 1.000 | 0.0286 | 0.0187 | 0.904 | power | 1.25 | 128: 0/4 done (timex4) |
| reverse | 8 | 192 | 16572 | 1.48 | 1.60 | 0.998 | 0.0289 | 0.0195 | 0.916 | power | 1.25 | 128: 1/4 done (timex3) |
| min_degree | 8 | 192 | 8104 | 1.23 | 1.25 | 1.000 | 0.0237 | 0.0151 | 0.896 | power | 1.04 | 128: 0/4 done (timex4) |
| min_fill | 8 | 192 | 7651 | 1.21 | 1.24 | 1.000 | 0.0233 | 0.0150 | 0.897 | power | 1.02 | 128: 0/4 done (timex4) |
| greedy_min | 6 | 96 | 3563 | 1.24 | 1.29 | 0.998 | 0.0386 | 0.0314 | 0.951 | power | 1.04 | - |
| bfs | 8 | 192 | 32446 | 1.73 | 1.91 | 0.997 | 0.0338 | 0.0231 | 0.918 | power | 1.46 | 128: 1/4 done (timex3) |
| max_degree | 8 | 192 | 29421 | 1.68 | 1.78 | 0.999 | 0.0327 | 0.0215 | 0.909 | power | 1.42 | 128: 0/4 done (timex4) |
| greedy_max | 6 | 96 | 9010 | 1.64 | 1.72 | 0.999 | 0.0510 | 0.0414 | 0.946 | power | 1.37 | - |
| tree_first | 8 | 192 | 30025 | 1.70 | 1.82 | 0.999 | 0.0331 | 0.0220 | 0.911 | power | 1.43 | 128: 0/4 done (timex4) |
| tree_first_bfs | 8 | 192 | 39074 | 1.78 | 1.90 | 0.999 | 0.0346 | 0.0229 | 0.911 | power | 1.50 | 128: 0/4 done (timex4) |
| shuffle | 8 | 192 | 15532 | 1.44 | 1.53 | 0.999 | 0.0280 | 0.0186 | 0.910 | power | 1.22 | 128: 0/20 done (timex20) |

**tseitin_regular {"d": 5}** (x = n; gmean over instances/shuffles; fits use fully completed sizes only)

| series / order | pts | largest complete n | alloc there (gmean) | power exp b | tail b (last 4) | R2 pow | exp rate bits/var | tail rate | R2 exp | better fit | power exp vs N | first incomplete size |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| natural | 7 | 160 | 13649 | 1.43 | 1.47 | 0.998 | 0.0291 | 0.0203 | 0.925 | power | 1.21 | 96: 0/4 done (timex4) |
| reverse | 7 | 160 | 12555 | 1.40 | 1.42 | 0.999 | 0.0284 | 0.0198 | 0.927 | power | 1.18 | 96: 0/4 done (timex4) |
| min_degree | 7 | 160 | 7853 | 1.20 | 1.19 | 0.999 | 0.0242 | 0.0165 | 0.919 | power | 1.01 | 96: 0/4 done (timex4) |
| min_fill | 7 | 160 | 7496 | 1.18 | 1.17 | 0.999 | 0.0238 | 0.0162 | 0.916 | power | 1.00 | 96: 0/4 done (timex4) |
| greedy_min | 5 | 80 | 3986 | 1.31 | 1.22 | 0.994 | 0.0420 | 0.0346 | 0.948 | power | 1.10 | - |
| bfs | 7 | 160 | 22865 | 1.64 | 1.75 | 0.999 | 0.0337 | 0.0245 | 0.942 | power | 1.39 | 96: 0/4 done (timex4) |
| max_degree | 7 | 160 | 21359 | 1.61 | 1.71 | 0.998 | 0.0329 | 0.0238 | 0.940 | power | 1.36 | 96: 0/4 done (timex4) |
| greedy_max | 5 | 80 | 5494 | 1.45 | 1.49 | 0.999 | 0.0470 | 0.0417 | 0.972 | power | 1.21 | - |
| tree_first | 7 | 160 | 23908 | 1.65 | 1.77 | 0.998 | 0.0338 | 0.0248 | 0.943 | power | 1.39 | 96: 0/4 done (timex4) |
| tree_first_bfs | 7 | 160 | 28070 | 1.72 | 1.81 | 0.999 | 0.0351 | 0.0254 | 0.939 | power | 1.45 | 96: 0/4 done (timex4) |
| shuffle | 7 | 160 | 13988 | 1.41 | 1.49 | 0.999 | 0.0289 | 0.0208 | 0.936 | power | 1.19 | 96: 0/20 done (timex20) |

**tseitin_torus {}** (x = n; gmean over instances/shuffles; fits use fully completed sizes only)

| series / order | pts | largest complete n | alloc there (gmean) | power exp b | tail b (last 4) | R2 pow | exp rate bits/var | tail rate | R2 exp | better fit | power exp vs N | first incomplete size |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| natural | 4 | 72 | 3339 | 1.33 | 1.33 | 1.000 | 0.0480 | 0.0480 | 0.954 | power | 1.11 | - |
| reverse | 4 | 72 | 2629 | 1.24 | 1.24 | 1.000 | 0.0450 | 0.0450 | 0.960 | power | 1.04 | - |
| min_degree | 4 | 72 | 2220 | 1.17 | 1.17 | 0.998 | 0.0424 | 0.0424 | 0.955 | power | 0.98 | - |
| min_fill | 4 | 72 | 2243 | 1.18 | 1.18 | 0.999 | 0.0427 | 0.0427 | 0.960 | power | 0.99 | - |
| greedy_min | 4 | 72 | 2235 | 1.19 | 1.19 | 0.999 | 0.0430 | 0.0430 | 0.950 | power | 1.00 | - |
| bfs | 4 | 72 | 4079 | 1.47 | 1.47 | 1.000 | 0.0532 | 0.0532 | 0.960 | power | 1.23 | - |
| max_degree | 4 | 72 | 4561 | 1.52 | 1.52 | 1.000 | 0.0551 | 0.0551 | 0.959 | power | 1.28 | - |
| greedy_max | 4 | 72 | 4900 | 1.58 | 1.58 | 0.998 | 0.0568 | 0.0568 | 0.942 | power | 1.33 | - |
| shuffle | 4 | 72 | 3485 | 1.38 | 1.38 | 1.000 | 0.0500 | 0.0500 | 0.963 | power | 1.16 | - |

**Worst completed standard order per size (max over instances and all 13 orders)**

| family | pts | largest n | max alloc there | power exp | tail exp | exp rate | better fit |
|---|---|---|---|---|---|---|---|
| tseitin_regular {"d": 3} | 10 | 288 | 77319 | 1.79 | 1.94 | 0.0283 | power |
| tseitin_regular {"d": 4} | 9 | 256 | 51181 | 1.74 | 1.63 | 0.0268 | power |
| tseitin_regular {"d": 5} | 7 | 160 | 29048 | 1.73 | 1.83 | 0.0353 | power |
| tseitin_torus {} | 4 | 72 | 4900 | 1.55 | 1.55 | 0.0556 | power |

Trying to break it (exhaustive / sampled orders on tiny graphs, then hill-climbing for the worst order):

**Distribution of allocated nodes over orders (tiny graphs)**

| family | params | orders | # | min | median | max | answers | disagreements |
|---|---|---|---|---|---|---|---|---|
| tseitin_named | {"graph": "K33", "sat": false, "seed": 1} | random sample | 4000 | 131 | 152.0 | 170 | {"UNSAT": 4000} | 0 |
| tseitin_named | {"graph": "K4", "sat": false, "seed": 1} | ALL orders | 720 | 78 | 85.0 | 89 | {"UNSAT": 720} | 0 |
| tseitin_named | {"graph": "K4", "sat": true, "seed": 1} | ALL orders | 720 | 78 | 85.0 | 89 | {"SAT": 720} | 0 |
| tseitin_named | {"graph": "W4", "sat": false, "seed": 1} | ALL orders | 40320 | 118 | 138.0 | 158 | {"UNSAT": 40320} | 0 |
| tseitin_named | {"graph": "cube", "sat": false, "seed": 1} | random sample | 4000 | 179 | 224.0 | 271 | {"UNSAT": 4000} | 0 |
| tseitin_named | {"graph": "petersen", "sat": false, "seed": 1} | random sample | 4000 | 261 | 306.0 | 369 | {"UNSAT": 4000} | 0 |
| tseitin_named | {"graph": "prism", "sat": false, "seed": 1} | random sample | 4000 | 120 | 149.0 | 174 | {"UNSAT": 4000} | 0 |

**Adversarial search for the WORST order (hill-climb maximising allocated nodes)**

| family | params | n | N | max alloc found | evaluations | worst standard order alloc | which | max/n^2 |
|---|---|---|---|---|---|---|---|---|
| tseitin_regular | {"nv": 8, "d": 3, "seed": 1, "sat": false} | 12 | 1040 | 277 | 3171 | 265 | greedy_max | 1.924 |
| tseitin_regular | {"nv": 12, "d": 3, "seed": 1, "sat": false} | 18 | 1696 | 546 | 2079 | 458 | max_degree | 1.685 |
| tseitin_regular | {"nv": 16, "d": 3, "seed": 1, "sat": false} | 24 | 2400 | 866 | 1113 | 768 | greedy_max | 1.503 |
| tseitin_regular | {"nv": 24, "d": 3, "seed": 1, "sat": false} | 36 | 3888 | 1651 | 462 | 1505 | greedy_max | 1.274 |
| tseitin_regular | {"nv": 32, "d": 3, "seed": 1, "sat": false} | 48 | 5488 | 2509 | 252 | 2303 | tree_first_bfs | 1.089 |
| tseitin_regular | {"nv": 48, "d": 3, "seed": 1, "sat": false} | 72 | 8832 | 5373 | 181 | 4981 | tree_first_bfs | 1.036 |
| tseitin_regular | {"nv": 8, "d": 4, "seed": 1, "sat": false} | 16 | 2880 | 513 | 1386 | 501 | greedy_max | 2.004 |
| tseitin_regular | {"nv": 12, "d": 4, "seed": 1, "sat": false} | 24 | 4736 | 970 | 567 | 909 | tree_first_bfs | 1.684 |
| tseitin_regular | {"nv": 16, "d": 4, "seed": 1, "sat": false} | 32 | 6624 | 1630 | 315 | 1433 | tree_first_bfs | 1.592 |
| tseitin_regular | {"nv": 24, "d": 4, "seed": 1, "sat": false} | 48 | 10848 | 3163 | 189 | 3102 | tree_first_bfs | 1.373 |
| tseitin_complete | {"m": 5, "seed": 1, "sat": false} | 10 | 1648 | 240 | 3171 | - | - | 2.400 |
| tseitin_complete | {"m": 6, "seed": 1, "sat": false} | 15 | 5248 | 540 | 819 | - | - | 2.400 |
| tseitin_complete | {"m": 7, "seed": 1, "sat": false} | 21 | 15936 | 1121 | 189 | - | - | 2.542 |
| tseitin_torus | {"a": 3, "seed": 1, "sat": false} | 18 | 3344 | 633 | 1050 | 582 | shuffle03 | 1.954 |
| tseitin_torus | {"a": 4, "seed": 1, "sat": false} | 32 | 6624 | 1569 | 315 | 1459 | greedy_max | 1.532 |

| family | (n, max alloc found) | power exp | exp rate bits/var | R2 pow | R2 exp | better | local exponents |
|---|---|---|---|---|---|---|---|
| tseitin_complete | [[10, 240], [15, 540], [21, 1121]] | 2.08 | 0.2013 | 0.999 | 0.993 | power | [2.0, 2.17] |
| tseitin_regular d=3 | [[12, 277], [18, 546], [24, 866], [36, 1651], [48, 2509], [72, 5373]] | 1.63 | 0.0676 | 0.999 | 0.942 | power | [1.67, 1.6, 1.59, 1.45, 1.88] |
| tseitin_regular d=4 | [[16, 513], [24, 970], [32, 1630], [48, 3163]] | 1.67 | 0.0805 | 0.999 | 0.974 | power | [1.57, 1.8, 1.64] |
| tseitin_torus | [[18, 633], [32, 1569]] | - | - | - | - | - | null |

**Mechanism test (E7b / E7c, `results/E7b.json`, `results/E7c.json`).** After every forget step the
and/or nodes reachable from the root were grouped by (kind, set of variables mentioned) and the
largest group was recorded. If a merged component is determined by its remaining edges plus one
parity bit, groups must stay small; a trellis-like state space shows up as many different nodes on
one support. Selected rows (all rows in `results/tables.md`):

| family | order | size: max nodes per support / max OR nodes per support | power exp | exp rate per unit size | better fit |
|---|---|---|---|---|---|
| 2-CNF on 4-regular graph, planted (size = n) | bfs | 20: 6/4, 28: 3/2, 40: 12/9, 56: 28/21, 80: 94/76 | 2.24 | 0.077 | exponential |
| 3-XOR m=n planted (size = n) | natural | 16: 8/8, 24: 24/12, 32: 96/48, 40: 208/88, 48: 1792/896, 56: 1152/256 | 4.42 | 0.199 | exponential |
| 3-XOR m=n planted (size = n) | min_degree | 16: 18/9, 24: 16/8, 32: 40/16, 40: 140/69, 48: 162/67, 56: 132/37, 64: 128/64, 72: 128/64, 80: 589/77, 88: 1921/897, 96: 3619/1571, 104: 7936/3841, 112: 2625/577* | 3.04 | 0.088 | exponential |
| 3-XOR m=n planted (size = n) | min_fill | 16: 12/6, 24: 11/7, 32: 44/13, 40: 144/72, 48: 128/57, 56: 101/37, 64: 224/112, 72: 484/229, 80: 656/256, 88: 512/256, 96: 704/256, 104: 1985/961, 112: 1041/512* | 2.63 | 0.072 | power |
| 3-XOR m=n planted (size = n) | shuffle00 | 16: 16/8, 24: 64/32, 32: 64/32, 40: 384/320, 48: 1121/512, 56: CAP | 3.66 | 0.186 | exponential |
| 3-XOR m=n planted (size = n) | shuffle01 | 16: 106/43, 24: 16/8, 32: 128/64, 40: 234/107, 48: 296/128, 56: 1536/384 | 2.34 | 0.117 | exponential |
| 4-XOR, each variable in 2 equations (size = equations) | natural | 8: 10/8, 16: 10/8, 32: 8/8, 64: 26/13 | 0.38 | 0.025 | exponential |
| 4-XOR, each variable in 2 equations (size = equations) | min_degree | 8: 10/8, 16: 8/8, 32: 10/8, 64: 10/8 | 0.03 | 0.002 | exponential |
| PHP(h+1,h) (size = h) | pigeon_major | 3: 6/2, 4: 9/2, 5: 11/4, 6: 14/5, 7: 17/8, 8: CAP, 9: CAP | 1.20 | 0.364 | power |
| PHP(h+1,h) (size = h) | hole_major | 3: 4/3, 4: 4/3, 5: 4/3, 6: 4/3, 7: 4/3, 8: 4/3, 9: CAP | 0.00 | 0.000 | power |
| PHP(h+1,h) (size = h) | min_degree | 3: 9/3, 4: 16/5, 5: 62/16, 6: 361/90, 7: 1048/292 | 5.84 | 1.822 | exponential |
| PHP(h+1,h) (size = h) | min_fill | 3: 5/2, 4: 22/7, 5: 46/15, 6: 191/55, 7: 573/167 | 5.47 | 1.680 | exponential |
| PHP(h+1,h) (size = h) | shuffle00 | 3: 8/5, 4: 27/11, 5: 141/45, 6: 808/252, 7: CAP | 6.61 | 2.236 | exponential |
| Tseitin d=3 (size = vertices) | natural | 8: 8/7, 16: 10/7, 32: 14/7, 64: 14/7, 96: 24/12 | 0.39 | 0.015 | exponential |
| Tseitin d=3 (size = vertices) | min_degree | 8: 10/7, 16: 10/7, 32: 10/6, 64: 10/5, 96: 10/5, 128: 10/5, 160: CAP | 0.00 | 0.000 | power |
| Tseitin d=3 (size = vertices) | bfs | 8: 7/7, 16: 8/7, 32: 18/9, 64: 18/9, 96: 18/9, 128: 28/14, 160: 16/8 | 0.38 | 0.009 | power |
| Tseitin d=3 (size = vertices) | max_degree | 8: 10/7, 16: 18/9, 32: 31/15, 64: 47/23, 96: 67/33, 128: 83/41, 160: 91/45 | 0.74 | 0.019 | power |
| Tseitin d=3 (size = vertices) | tree_first_bfs | 8: 7/7, 16: 12/7, 32: 20/10, 64: 18/9, 96: 20/10, 128: 28/14, 160: CAP | 0.42 | 0.012 | power |
| Tseitin d=3 (size = vertices) | shuffle00 | 8: 14/7, 16: 14/7, 32: 8/6, 64: 12/6, 96: 24/12 | 0.12 | 0.009 | exponential |
| Tseitin d=3 (size = vertices) | shuffle01 | 8: 10/5, 16: 10/6, 32: 10/5, 64: 22/11, 96: 22/11 | 0.37 | 0.016 | exponential |
| Tseitin d=5 (size = vertices) | max_degree | 8: 16/16, 16: 16/16, 24: 23/16, 32: 42/21 | 0.63 | 0.059 | exponential |
| random 3-CNF 4.26 (size = n) | natural | 16: 11/7, 20: 127/70, 24: 49/36, 28: 223/140, 32: 468/307 | 4.70 | 0.291 | power |

For Tseitin the groups stay small: constant (10) under min-degree up to 128 vertices, and growing
sub-linearly in the number of vertices for the worst orders (several nested historical
sub-components can share one support) - never exponentially. The same holds for the 4-XOR control
in which every variable occurs twice. For 3-XOR with m = n the largest group grows by orders of
magnitude, **also under the best orders** (min-degree: 18 at n = 16, 7936 at n = 104), and many of
the values are powers of two or small multiples of them: that is the 2^(state dimension) family of
cosets the lead predicted. PHP under hole-major is the instructive third case: exactly 4 nodes per
support for every h, so the growth there is entirely in the *number of supports* (subsets of
pigeons), consistent with the lead's sum_j C(h+1, j) count.

## 4. E2 - XOR systems (H-XOR3)

**Instances.** Random 3-XOR systems, each equation on 3 distinct random variables, encoded with 4
clauses: (i) m = n equations with right-hand sides from a hidden assignment (always SAT), (ii) m = n+5
with uniformly random right-hand sides (expected answer by GF(2) elimination; almost always UNSAT);
three instances per size. Orders: natural, min_degree, min_fill, greedy_min, and 20 seeded shuffles
(two instances). Control family: 4-XOR systems in which every variable occurs in exactly two
equations (pairing model; parallel pairs allowed, no variable twice in one equation).
**Answers.** 1580 runs, 1408 completed, 1408 checked,
**0 disagreements**; non-completions {"CAP:nodes": 2, "CAP:time": 152, "CAP:task_alarm": 1, "ORDER_TIMEOUT:order:time": 16, "CAP:hard_kill": 1}.

**Fitted exponential rates, m = n planted** (log2 allocated nodes per variable):

- natural: 0.149 bits/var up to n=64 (tail 0.093; power-law exponent 3.67, tail 3.39; R2 exp 0.950 vs pow 0.971)
- shuffle: 0.183 bits/var up to n=48 (tail 0.190; power-law exponent 3.63, tail 4.56; R2 exp 0.994 vs pow 0.963)
- min_degree: 0.072 bits/var up to n=112 (tail 0.087; power-law exponent 2.50, tail 6.00; R2 exp 0.969 vs pow 0.900)
- min_fill: 0.074 bits/var up to n=120 (tail 0.118; power-law exponent 2.71, tail 8.79; R2 exp 0.980 vs pow 0.910)
- greedy_min: 0.063 bits/var up to n=80 (tail 0.069; power-law exponent 1.79, tail 3.18; R2 exp 0.971 vs pow 0.967)

**m = n + 5, random right-hand sides:**

- natural: 0.153 bits/var up to n=56 (tail 0.166; power-law exponent 3.32, tail 4.91; R2 exp 0.984 vs pow 0.931)
- shuffle: 0.149 bits/var up to n=56 (tail 0.171; power-law exponent 3.24, tail 5.05; R2 exp 0.991 vs pow 0.939)
- min_degree: 0.069 bits/var up to n=120 (tail 0.043; power-law exponent 2.59, tail 3.04; R2 exp 0.986 vs pow 0.955)
- min_fill: 0.066 bits/var up to n=120 (tail 0.059; power-law exponent 2.46, tail 4.36; R2 exp 0.980 vs pow 0.953)
- greedy_min: 0.090 bits/var up to n=32 (tail -; power-law exponent 1.45, tail -; R2 exp 0.992 vs pow 1.000)

**Reading.** natural and random orders are cleanly exponential. The heuristic orders (min-degree,
min-fill, DAG-aware greedy) are much better in absolute terms and their growth is irregular
(instance-to-instance noise with three instances per size), but they also accelerate: the
last-four-sizes power-law exponents are far above the whole-range ones, and the exponential model
has the higher R^2. I therefore read H-XOR3 as supported for every order tried, with the honest
qualification that for the best orders the measured range is short (the 30 s wall clock on a loaded
machine stops them near n = 110-150) and a polynomial of degree 6-9 cannot be excluded from these
data alone. The support-multiplicity census (sec. 3, last table) gives independent, mechanism-level
evidence: the number of distinct nodes on one support doubles every few variables for 3-XOR.

**Control (each variable in exactly two equations).** 7/7 order series are better fit by a power law, fitted exponents up to 1.77 (bfs), last-4-sizes exponent up to 1.90, largest completed n = 256 variables. This is the polynomial behaviour
H-TSEITIN's mechanism predicts for a "Tseitin-like hypergraph", including on instances with
parallel hyper-edges.

**xor3 {"extra": 0, "planted": true}: allocated nodes, structured orders (gmean over instances)**

| n | n vars | N bits | natural | min_degree | min_fill | greedy_min |
|---|---|---|---|---|---|---|
| 16 | 16 | 2261 | 354 | 296 | 290 | 268 |
| 24 | 24 | 3736 | 709 | 510 | 470 | 463 |
| 32 | 32 | 5048 | 2929 | 865 | 803 | 758 |
| 40 | 40 | 6688 | 7404 | 1614 | 1661 | 1213 |
| 48 | 48 | 8219 | 16948 | 2439 | 2044 | 1567 |
| 56 | 56 | 9763 | 37542 | 2478 | 2488 | 1973 |
| 64 | 64 | 11259 | 31853 | 2699 | 3166 | 2054 |
| 72 | 72 | 13053 | >233736* (2/3) | 4376 | 6887 | 3804 |
| 80 | 80 | 14907 | >241551* (1/3) | 4898 | 7702 | 5775 |
| 88 | 88 | 16667 | CAP(time) | 12103 | 9421 |  |
| 96 | 96 | 18437 |  | 23153 | 15775 |  |
| 104 | 104 | 20288 |  | 26584 | 24751 |  |
| 112 | 112 | 22061 |  | 57876 | 45923 |  |
| 120 | 120 | 23829 |  | >32320* (2/3) | 114847 |  |
| 136 | 136 | 27952 |  | CAP(time) | CAP(time) |  |

**xor3 {"extra": 0, "planted": true}: 20 random shuffles per instance** (best / median per instance, then gmean over instances; CAP if any instance has it capped)

| n | n | shuffles completed | best of 20 | median of 20 |
|---|---|---|---|---|
| 16 | 16 | 40/40 | 282 | 339 |
| 24 | 24 | 40/40 | 490 | 738 |
| 32 | 32 | 40/40 | 1141 | 2628 |
| 40 | 40 | 40/40 | 2829 | 8093 |
| 48 | 48 | 40/40 | 5555 | 17295 |
| 56 | 56 | 38/40 | 6359 | 27009 |
| 64 | 64 | 35/40 | 5046 | 41707 |
| 72 | 72 | 31/40 | 16872 | 69090 |
| 80 | 80 | 21/40 | 20714 | CAP |
| 88 | 88 | 10/40 | 26667 | CAP |

**xor3 {"extra": 5, "planted": false}: allocated nodes, structured orders (gmean over instances)**

| n | n vars | N bits | natural | min_degree | min_fill | greedy_min |
|---|---|---|---|---|---|---|
| 16 | 16 | 2971 | 433 | 312 | 332 | 270 |
| 24 | 24 | 4389 | 827 | 584 | 545 | 483 |
| 32 | 32 | 5792 | 1672 | 786 | 793 | 736 |
| 40 | 40 | 7491 | 5836 | 1555 | 1327 | >888* (1/3) |
| 48 | 48 | 9059 | 8654 | 2195 | 1509 | CAP(order:time) |
| 56 | 56 | 10632 | 31481 | 3353 | 3283 |  |
| 64 | 64 | 12181 | >42672* (2/3) | 3925 | 4003 |  |
| 72 | 72 | 14093 | >108616* (1/3) | 7357 | 8728 |  |
| 80 | 80 | 15933 | >36902* (1/3) | 8587 | 7950 |  |
| 88 | 88 | 17787 | CAP(time) | 19951 | 12664 |  |
| 96 | 96 | 19560 |  | >12261* (2/3) | 17846 |  |
| 104 | 104 | 21304 |  | 23262 | 15891 |  |
| 112 | 112 | 23195 |  | 39707 | 27441 |  |
| 120 | 120 | 24907 |  | 50490 | 44597 |  |
| 136 | 136 | 28763 |  | >128436* (1/3) | >115497* (1/3) |  |
| 152 | 152 | 32861 |  | CAP(time) | CAP(time) |  |

**xor3 {"extra": 5, "planted": false}: 20 random shuffles per instance** (best / median per instance, then gmean over instances; CAP if any instance has it capped)

| n | n | shuffles completed | best of 20 | median of 20 |
|---|---|---|---|---|
| 16 | 16 | 40/40 | 245 | 357 |
| 24 | 24 | 40/40 | 462 | 874 |
| 32 | 32 | 40/40 | 453 | 1175 |
| 40 | 40 | 40/40 | 1501 | 3375 |
| 48 | 48 | 40/40 | 2607 | 9208 |
| 56 | 56 | 40/40 | 6360 | 24695 |
| 64 | 64 | 35/40 | 9544 | 43124 |
| 72 | 72 | 24/40 | 11130 | 102443 |
| 80 | 80 | 7/40 | 35710 | CAP |

**xor3 {"extra": 0, "planted": true}** (x = n; gmean over instances/shuffles; fits use fully completed sizes only)

| series / order | pts | largest complete n | alloc there (gmean) | power exp b | tail b (last 4) | R2 pow | exp rate bits/var | tail rate | R2 exp | better fit | power exp vs N | first incomplete size |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| natural | 7 | 64 | 31853 | 3.67 | 3.39 | 0.971 | 0.1494 | 0.0933 | 0.950 | power | 3.17 | 72: 2/3 done (nodesx1) |
| min_degree | 13 | 112 | 57876 | 2.50 | 6.00 | 0.900 | 0.0719 | 0.0872 | 0.969 | exponential | 2.15 | 120: 2/3 done (timex1) |
| min_fill | 14 | 120 | 114847 | 2.71 | 8.79 | 0.910 | 0.0739 | 0.1185 | 0.980 | exponential | 2.32 | 136: 0/3 done (timex3) |
| greedy_min | 9 | 80 | 5775 | 1.79 | 3.18 | 0.967 | 0.0633 | 0.0692 | 0.971 | exponential | 1.54 | - |
| shuffle | 5 | 48 | 18705 | 3.63 | 4.56 | 0.963 | 0.1826 | 0.1901 | 0.994 | exponential | 3.12 | 56: 38/40 done (timex2) |

**xor3 {"extra": 5, "planted": false}** (x = n; gmean over instances/shuffles; fits use fully completed sizes only)

| series / order | pts | largest complete n | alloc there (gmean) | power exp b | tail b (last 4) | R2 pow | exp rate bits/var | tail rate | R2 exp | better fit | power exp vs N | first incomplete size |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| natural | 6 | 56 | 31481 | 3.32 | 4.91 | 0.931 | 0.1532 | 0.1659 | 0.984 | exponential | 3.26 | 64: 2/3 done (hard_killx1) |
| min_degree | 13 | 120 | 50490 | 2.59 | 3.04 | 0.955 | 0.0694 | 0.0433 | 0.986 | exponential | 2.43 | 96: 2/3 done (timex1) |
| min_fill | 14 | 120 | 44597 | 2.46 | 4.36 | 0.953 | 0.0658 | 0.0594 | 0.980 | exponential | 2.31 | 136: 1/3 done (timex2) |
| greedy_min | 3 | 32 | 736 | 1.45 | - | 1.000 | 0.0905 | - | 0.992 | power | 1.50 | 40: 1/3 done (order:timex2) |
| shuffle | 6 | 56 | 22691 | 3.24 | 5.05 | 0.939 | 0.1492 | 0.1705 | 0.991 | exponential | 3.19 | 64: 35/40 done (timex5) |

4-XOR with every variable in exactly two equations (Tseitin on a 4-regular multigraph):

**xor_two_occ {"k": 4}: allocated nodes, structured orders (gmean over instances)**

| m_eq | n vars | N bits | natural | reverse | min_degree | min_fill | greedy_min | bfs | max_degree | greedy_max |
|---|---|---|---|---|---|---|---|---|---|---|
| 8 | 16 | 2880 | 365 | 366 | 353 | 342 | 340 | 391 | 425 | 472 |
| 12 | 24 | 4736 | 657 | 710 | 563 | 566 | 562 | 721 | 852 | 888 |
| 16 | 32 | 6624 | 1042 | 1034 | 876 | 862 | 846 | 1239 | 1263 | 1421 |
| 24 | 48 | 10848 | 2073 | 1841 | 1492 | 1424 | >1434* (1/4) | 2701 | 2519 | CAP(order:time) |
| 32 | 64 | 15104 | 3136 | 2559 | 2080 | 1992 | CAP(order:time) | 4002 | 4070 |  |
| 48 | 96 | 24576 | 5833 | 5392 | 3336 | 3236 |  | 8112 | 8570 |  |
| 64 | 128 | 34080 | 8847 | 7693 | 4760 | 4479 |  | 14435 | 13347 |  |
| 96 | 192 | 55072 | 15589 | 14655 | 7913 | 7442 |  | 32038 | 28244 |  |
| 128 | 256 | 76096 | >29646* (3/4) | 24650 | >11029* (3/4) | >10458* (3/4) |  | >55339* (3/4) | >51507* (3/4) |  |

**xor_two_occ {"k": 4}** (x = n; gmean over instances/shuffles; fits use fully completed sizes only)

| series / order | pts | largest complete n | alloc there (gmean) | power exp b | tail b (last 4) | R2 pow | exp rate bits/var | tail rate | R2 exp | better fit | power exp vs N | first incomplete size |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| natural | 8 | 192 | 15589 | 1.53 | 1.46 | 0.999 | 0.0292 | 0.0175 | 0.878 | power | 1.29 | 128: 3/4 done (timex1) |
| reverse | 9 | 256 | 24650 | 1.49 | 1.55 | 0.998 | 0.0234 | 0.0137 | 0.894 | power | 1.26 | - |
| min_degree | 8 | 192 | 7913 | 1.25 | 1.22 | 0.999 | 0.0240 | 0.0147 | 0.881 | power | 1.06 | 128: 3/4 done (timex1) |
| min_fill | 8 | 192 | 7442 | 1.23 | 1.20 | 0.999 | 0.0236 | 0.0144 | 0.879 | power | 1.04 | 128: 3/4 done (timex1) |
| greedy_min | 3 | 32 | 846 | 1.31 | - | 0.999 | 0.0822 | - | 0.997 | power | 1.09 | 24: 1/4 done (order:timex3) |
| bfs | 8 | 192 | 32038 | 1.77 | 1.90 | 0.999 | 0.0343 | 0.0230 | 0.907 | power | 1.49 | 128: 3/4 done (timex1) |
| max_degree | 8 | 192 | 28244 | 1.68 | 1.75 | 0.999 | 0.0326 | 0.0211 | 0.904 | power | 1.42 | 128: 3/4 done (timex1) |
| greedy_max | 3 | 32 | 1421 | 1.59 | - | 1.000 | 0.0993 | - | 0.993 | power | 1.32 | 24: 0/4 done (order:timex4) |
| shuffle | 7 | 128 | 7884 | 1.42 | 1.42 | 1.000 | 0.0361 | 0.0248 | 0.924 | power | 1.20 | - |

## 5. E3 - pigeonhole PHP(h+1, h) (H-PHP)

**Instances.** PHP(h+1, h) with variables x(i,k) = pigeon i in hole k (pigeon-major numbering), clauses
"every pigeon somewhere" and "no two pigeons in a hole" (no functional clauses). Expected answer:
UNSAT (pigeonhole principle). Orders: pigeon_major (= natural), hole_major, reverse, min_degree,
min_fill, max_degree, bfs, greedy_min, greedy_max, 200 seeded random orders per h (30 for h = 7),
a local search for the best order (h = 3..6), and **all** orders of PHP(3,2) and PHP(4,2).
**Answers.** 302 single runs (268 completed) plus the batches:
**0 disagreements**; every one of the 720 + 40320 exhaustive runs answered UNSAT.

**Reading.**
1. In h every order tried grows by a factor >= 2.2 per extra hole. hole-major is the best
   structured order; its ratio decreases slowly (3.65, 2.89, ... 2.42 at h = 10) and alloc / 2^h has
   an almost constant second difference (about 2.6), i.e. alloc is fitted by c * h^2 * 2^h. pigeon-major
   behaves like c * h * 3^h (ratio 4.04 ... 3.41).
2. In the number of variables n = h(h+1) that is 2^Theta(sqrt n): the per-variable rate falls with n
   and the power-law exponent in n keeps rising (see the last column of the growth table). So the
   accurate statement is "super-polynomial, 2^Theta(sqrt n), for the best orders found", not
   "exponential in the input size". Random orders are far worse (their ratio itself grows with h).
3. The minimum over all orders tried (structured, 200 random, greedy, local search) is the last
   column of the first table. Local search improved on hole-major by 23-39% for h = 3..6 but did not
   change the growth pattern; for h >= 7 the minimum is hole-major itself (no search was affordable).
4. Exhaustive enumeration: PHP(3,2) 45..50 nodes (24 optimal orders, e.g. x(0,0), x(1,0), x(1,1),
   x(0,1), x(2,0), x(2,1)); PHP(4,2) 59..82 (576 optimal orders). pigeon-major gives 48 / 64 and
   hole-major 49 / 80 on these two, so neither structured order is optimal even at this size.

| h | n vars | N bits | reverse | pigeon_major | hole_major | min_degree | min_fill | greedy_min | bfs | max_degree | greedy_max | #random | random min | random median | local-search min | MIN over all tried |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 2 | 6 | 174 | 48 | 48 | 49 | 47 | 47 | 47 | 48 | 48 | 49 | 200 | 45 | 48 |  | 45 |
| 3 | 12 | 532 | 194 | 194 | 179 | 166 | 152 | 154 | 192 | 194 | 241 | 200 | 144 | 185 | 137 | 137 |
| 4 | 20 | 1230 | 725 | 725 | 518 | 464 | 518 | 488 | 695 | 725 | 1164 | 200 | 586 | 824 | 375 | 375 |
| 5 | 30 | 2370 | 2717 | 2717 | 1373 | 1722 | 1259 | 1966 | 2152 | 2717 | 5404 | 200 | 2640 | 4640 | 837 | 837 |
| 6 | 42 | 4172 | 10071 | 10071 | 3520 | 7293 | 5436 | 5527 | 6288 | 10071 | 27053 | 200 | 19550 | 33754 | 2648 | 2648 |
| 7 | 56 | 6664 | 35985 | 35985 | 8873 | 29213 | 23297 | CAP:order:time | 17673 | 35985 | CAP:order:greedy chunks exhausted | 30 | 185462 | CAP |  | 8873 |
| 8 | 72 | 10098 | 122603 | 122603 | 22070 | 69944 | 86065 |  | 48068 | 122603 |  |  |  |  |  | 22070 |
| 9 | 90 | 14630 | CAP:time | CAP:time | 54161 | CAP:time | 251242 |  | 126906 | CAP:time |  |  |  |  |  | 54161 |
| 10 | 110 | 20262 |  |  | 131092 |  | CAP:time |  | CAP:time |  |  |  |  |  |  | 131092 |
| 11 | 132 | 27228 |  |  | CAP:time |  |  |  |  |  |  |  |  |  |  |  |

Growth per order (ratio alloc(h+1)/alloc(h); exponential rate in bits per hole and per variable; power-law exponent in n = h(h+1))

| order | h range | successive ratios | bits per h (all) | bits per h (last 5) | bits per var | power exp in n | R2 exp(n) | R2 pow(n) | local power exponents in n |
|---|---|---|---|---|---|---|---|---|---|
| reverse | 2..8 | [4.04, 3.74, 3.75, 3.71, 3.57, 3.41] | 1.887 | 1.853 | 0.1669 | 3.15 | 0.970 | 0.974 | [2.01, 2.58, 3.26, 3.89, 4.43, 4.88] |
| pigeon_major | 2..8 | [4.04, 3.74, 3.75, 3.71, 3.57, 3.41] | 1.887 | 1.853 | 0.1669 | 3.15 | 0.970 | 0.974 | [2.01, 2.58, 3.26, 3.89, 4.43, 4.88] |
| hole_major | 2..10 | [3.65, 2.89, 2.65, 2.56, 2.52, 2.49, 2.45, 2.42] | 1.396 | 1.305 | 0.1034 | 2.70 | 0.951 | 0.977 | [1.87, 2.08, 2.4, 2.8, 3.21, 3.63, 4.02, 4.4] |
| min_degree | 2..8 | [3.53, 2.8, 3.71, 4.24, 4.01, 2.39] | 1.804 | 1.856 | 0.1601 | 3.00 | 0.974 | 0.962 | [1.82, 2.01, 3.23, 4.29, 4.82, 3.47] |
| min_fill | 2..9 | [3.23, 3.41, 2.43, 4.32, 4.29, 3.69, 2.92] | 1.798 | 1.927 | 0.1464 | 3.20 | 0.979 | 0.950 | [1.69, 2.4, 2.19, 4.35, 5.06, 5.2, 4.8] |
| greedy_min | 2..6 | [3.28, 3.17, 4.03, 2.81] | 1.743 | 1.743 | 0.1903 | 2.46 | 0.980 | 0.978 | [1.71, 2.26, 3.44, 3.07] |
| bfs | 2..9 | [4.0, 3.62, 3.1, 2.92, 2.81, 2.72, 2.64] | 1.607 | 1.470 | 0.1290 | 2.91 | 0.950 | 0.983 | [2.0, 2.52, 2.79, 3.19, 3.59, 3.98, 4.35] |
| max_degree | 2..8 | [4.04, 3.74, 3.75, 3.71, 3.57, 3.41] | 1.887 | 1.853 | 0.1669 | 3.15 | 0.970 | 0.974 | [2.01, 2.58, 3.26, 3.89, 4.43, 4.88] |
| greedy_max | 2..6 | [4.92, 4.83, 4.64, 5.01] | 2.271 | 2.270 | 0.2480 | 3.21 | 0.983 | 0.979 | [2.3, 3.08, 3.79, 4.79] |
| random_min | 2..7 | [3.2, 4.07, 4.51, 7.41, 9.49] | 2.385 | 2.572 | 0.2377 | 3.60 | 0.999 | 0.921 | [1.68, 2.75, 3.71, 5.95, 7.82] |
| random_median | 2..6 | [3.85, 4.45, 5.63, 7.27] | 2.356 | 2.356 | 0.2600 | 3.29 | 0.997 | 0.952 | [1.95, 2.92, 4.26, 5.9] |
| search_min | 3..6 | [2.74, 2.23, 3.16] | 1.398 | 1.398 | 0.1391 | 2.30 | 0.994 | 0.982 | [1.97, 1.98, 3.42] |
| MIN_over_all_tried | 2..10 | [3.04, 2.74, 2.23, 3.16, 3.35, 2.49, 2.45, 2.42] | 1.451 | 1.387 | 0.1080 | 2.78 | 0.963 | 0.962 | [1.61, 1.97, 1.98, 3.42, 4.2, 3.63, 4.02, 4.4] |

**Exhaustive enumeration of ALL elimination orders**

| instance | n | orders | min alloc | #orders at min | median | max alloc | #orders at max | min peak reach | max peak reach | answers | disagreements |
|---|---|---|---|---|---|---|---|---|---|---|---|
| PHP(4,2) | 8 | 40320 | 59 | 576 | 72.0 | 82 | 384 | 33 | 33 | {"UNSAT": 40320} | 0 |
| PHP(3,2) | 6 | 720 | 45 | 24 | 48.0 | 50 | 96 | 22 | 22 | {"UNSAT": 720} | 0 |

## 6. E4 - random 3-CNF (H-3CNF)

**Instances.** Uniform random 3-CNF (3 distinct variables per clause, random signs), m = round(density * n),
densities 2.0, 3.0, 4.26; three instances per (density, n) for the structured orders (natural,
min_degree, min_fill, greedy_min) and 20 seeded shuffles on two instances.
**Answers.** 1311 runs, 1138 completed, 1138 checked,
**0 disagreements**. Sources of the expected answers for completed runs:
{"adversarial/oracle.py exhaustive (DPLL cross-checked)": 312, "own complete DPLL (not the project oracle)": 826} - i.e. the project oracle for n <= 20 and my own complete
DPLL (witness-checked for SAT) for larger n; no completed run is left unverified
(0 unverified).

**Fitted exponential rates (bits per variable):**

- density 2.0: natural 0.339 (n<=32, tail 0.336, exponential); shuffle 0.355 (n<=32, tail 0.363, exponential); min_degree 0.225 (n<=52, tail 0.195, exponential); min_fill 0.218 (n<=52, tail 0.208, exponential); greedy_min 0.203 (n<=52, tail 0.209, exponential)
- density 3.0: natural 0.353 (n<=32, tail 0.334, exponential); shuffle 0.352 (n<=32, tail 0.349, exponential); min_degree 0.285 (n<=40, tail 0.307, exponential); min_fill 0.277 (n<=40, tail 0.308, exponential); greedy_min 0.267 (n<=32, tail 0.310, exponential)
- density 4.26: natural 0.311 (n<=36, tail 0.345, exponential); shuffle 0.314 (n<=32, tail 0.310, exponential); min_degree 0.257 (n<=40, tail 0.258, exponential); min_fill 0.256 (n<=40, tail 0.279, exponential); greedy_min 0.257 (n<=32, tail 0.262, exponential)

**Reading.** Every series accelerates on a log-log plot (tail power-law exponents 4-9) and is at
least as well described by an exponential. The rate is highest for natural / random orders
(about 0.3-0.36 bits per variable) and lowest for min-degree / min-fill / greedy_min (about
0.2-0.3); it does not vanish at density 2.0, far below the satisfiability threshold. At 4.26 about
half of the instances are UNSAT and the candidate must still eliminate most variables before the
root collapses to False, so UNSAT instances are not systematically cheaper.

**kcnf {"density": 2.0, "k": 3} fits** (x = n)

| series / order | pts | largest complete n | alloc there (gmean) | power exp b | tail b (last 4) | R2 pow | exp rate bits/var | tail rate | R2 exp | better fit | power exp vs N | first incomplete size |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| natural | 6 | 32 | 29289 | 4.75 | 5.93 | 0.975 | 0.3389 | 0.3364 | 0.999 | exponential | 4.05 | 36: 0/3 done (timex3) |
| min_degree | 10 | 52 | 74118 | 4.26 | 5.91 | 0.947 | 0.2250 | 0.1947 | 0.994 | exponential | 3.58 | 44: 2/3 done (timex1) |
| min_fill | 10 | 52 | 68849 | 4.03 | 6.34 | 0.941 | 0.2177 | 0.2085 | 0.992 | exponential | 3.39 | 48: 2/3 done (timex1) |
| greedy_min | 9 | 52 | 42237 | 3.69 | 5.99 | 0.917 | 0.2031 | 0.2087 | 0.986 | exponential | 3.10 | 44: 2/3 done (order:greedy chunks exhaustedx1) |
| shuffle | 6 | 32 | 36388 | 4.97 | 6.40 | 0.975 | 0.3547 | 0.3635 | 0.999 | exponential | 4.20 | 36: 36/40 done (timex4) |

**kcnf {"density": 3.0, "k": 3} fits** (x = n)

| series / order | pts | largest complete n | alloc there (gmean) | power exp b | tail b (last 4) | R2 pow | exp rate bits/var | tail rate | R2 exp | better fit | power exp vs N | first incomplete size |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| natural | 6 | 32 | 55745 | 4.99 | 5.86 | 0.984 | 0.3535 | 0.3340 | 0.997 | exponential | 4.18 | 36: 0/3 done (timex3) |
| min_degree | 8 | 40 | 79071 | 4.55 | 7.19 | 0.941 | 0.2848 | 0.3068 | 0.985 | exponential | 3.79 | 44: 1/3 done (timex2) |
| min_fill | 8 | 40 | 74014 | 4.43 | 7.23 | 0.946 | 0.2768 | 0.3085 | 0.988 | exponential | 3.69 | 44: 1/3 done (timex2) |
| greedy_min | 6 | 32 | 11437 | 3.70 | 5.44 | 0.929 | 0.2671 | 0.3102 | 0.974 | exponential | 3.10 | 36: 2/3 done (order:greedy chunks exhaustedx1) |
| shuffle | 6 | 32 | 55572 | 4.96 | 6.12 | 0.975 | 0.3525 | 0.3491 | 0.994 | exponential | 4.14 | 36: 24/40 done (timex16) |

**kcnf {"density": 4.26, "k": 3} fits** (x = n)

| series / order | pts | largest complete n | alloc there (gmean) | power exp b | tail b (last 4) | R2 pow | exp rate bits/var | tail rate | R2 exp | better fit | power exp vs N | first incomplete size |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| natural | 7 | 36 | 108247 | 4.68 | 7.00 | 0.953 | 0.3113 | 0.3454 | 0.985 | exponential | 3.90 | 40: 1/3 done (timex2) |
| min_degree | 8 | 40 | 58529 | 4.15 | 5.97 | 0.968 | 0.2573 | 0.2576 | 0.992 | exponential | 3.45 | 44: 1/3 done (timex2) |
| min_fill | 8 | 40 | 64325 | 4.12 | 6.47 | 0.963 | 0.2564 | 0.2790 | 0.994 | exponential | 3.43 | 44: 1/3 done (timex2) |
| greedy_min | 6 | 32 | 11805 | 3.60 | 4.60 | 0.974 | 0.2566 | 0.2618 | 0.998 | exponential | 3.00 | 36: 1/3 done (order:greedy chunks exhaustedx2) |
| shuffle | 6 | 32 | 30975 | 4.42 | 5.48 | 0.982 | 0.3140 | 0.3104 | 0.999 | exponential | 3.68 | 36: 34/40 done (timex6) |

**kcnf {"density": 2.0, "k": 3}: allocated nodes, structured orders (gmean over 3 instances)**

| n | n vars | N bits | natural | min_degree | min_fill | greedy_min |
|---|---|---|---|---|---|---|
| 12 | 12 | 790 | 275 | 202 | 195 | 156 |
| 16 | 16 | 1108 | 601 | 310 | 336 | 239 |
| 20 | 20 | 1451 | 1720 | 621 | 656 | 463 |
| 24 | 24 | 1790 | 4588 | 1005 | 940 | 705 |
| 28 | 28 | 2124 | 10437 | 1839 | 1376 | 891 |
| 32 | 32 | 2503 | 29289 | 3818 | 4298 | 2811 |
| 36 | 36 | 2921 | CAP(time) | 7964 | 7187 | 2894 |
| 40 | 40 | 3305 |  | 20131 | 11584 | 8210 |
| 44 | 44 | 3732 |  | >17753* (2/3) | 27262 | >14904* (2/3) |
| 48 | 48 | 4100 |  | 51298 | >26811* (2/3) | >14162* (1/3) |
| 52 | 52 | 4525 |  | 74118 | 68849 | 42237 |
| 56 | 56 | 4937 |  | CAP(time) | CAP(time) | CAP(order:greedy chunks exhausted) |

**kcnf {"density": 3.0, "k": 3}: allocated nodes, structured orders (gmean over 3 instances)**

| n | n vars | N bits | natural | min_degree | min_fill | greedy_min |
|---|---|---|---|---|---|---|
| 12 | 12 | 1173 | 389 | 346 | 346 | 284 |
| 16 | 16 | 1643 | 1078 | 713 | 717 | 579 |
| 20 | 20 | 2172 | 3544 | 1908 | 1929 | 1023 |
| 24 | 24 | 2677 | 7380 | 2021 | 2276 | 1544 |
| 28 | 28 | 3208 | 19953 | 6146 | 5289 | 6010 |
| 32 | 32 | 3786 | 55745 | 18239 | 18161 | 11437 |
| 36 | 36 | 4408 | CAP(time) | 42329 | 34339 | >28237* (2/3) |
| 40 | 40 | 4973 |  | 79071 | 74014 | CAP(order:greedy chunks exhausted) |
| 44 | 44 | 5602 |  | >134775* (1/3) | >119998* (1/3) |  |
| 48 | 48 | 6174 |  | CAP(time) | >208642* (1/3) |  |
| 52 | 52 | 6788 |  |  | CAP(time) |  |

**kcnf {"density": 4.26, "k": 3}: allocated nodes, structured orders (gmean over 3 instances)**

| n | n vars | N bits | natural | min_degree | min_fill | greedy_min |
|---|---|---|---|---|---|---|
| 12 | 12 | 1657 | 446 | 369 | 386 | 321 |
| 16 | 16 | 2316 | 966 | 800 | 883 | 665 |
| 20 | 20 | 3093 | 3114 | 2048 | 1965 | 1376 |
| 24 | 24 | 3823 | 5490 | 3028 | 3184 | 2425 |
| 28 | 28 | 4566 | 12168 | 7823 | 6968 | 5459 |
| 32 | 32 | 5334 | 22886 | 10774 | 11020 | 11805 |
| 36 | 36 | 6240 | 108247 | 32532 | 32014 | >22773* (1/3) |
| 40 | 40 | 7053 | >98477* (1/3) | 58529 | 64325 | >40255* (2/3) |
| 44 | 44 | 7937 | CAP(time) | >38847* (1/3) | >77473* (1/3) | CAP(order:greedy chunks exhausted) |
| 48 | 48 | 8767 |  | CAP(time) | CAP(time) |  |

**kcnf {"density": 2.0, "k": 3}: random shuffles per instance (best / median)**

| n | n | shuffles completed | best | median |
|---|---|---|---|---|
| 12 | 12 | 40/40 | 180 | 255 |
| 16 | 16 | 40/40 | 473 | 630 |
| 20 | 20 | 40/40 | 815 | 1874 |
| 24 | 24 | 40/40 | 2095 | 4681 |
| 28 | 28 | 40/40 | 3765 | 12600 |
| 32 | 32 | 40/40 | 14837 | 36209 |
| 36 | 36 | 36/40 | 24810 | 73940 |
| 40 | 40 | 8/40 | 83244 | CAP |

**kcnf {"density": 3.0, "k": 3}: random shuffles per instance (best / median)**

| n | n | shuffles completed | best | median |
|---|---|---|---|---|
| 12 | 12 | 40/40 | 275 | 388 |
| 16 | 16 | 40/40 | 731 | 1159 |
| 20 | 20 | 40/40 | 2010 | 3532 |
| 24 | 24 | 40/40 | 2897 | 6058 |
| 28 | 28 | 40/40 | 12594 | 20226 |
| 32 | 32 | 40/40 | 24189 | 65306 |
| 36 | 36 | 24/40 | 58003 | CAP |
| 40 | 40 | 0/40 | CAP | CAP |

**kcnf {"density": 4.26, "k": 3}: random shuffles per instance (best / median)**

| n | n | shuffles completed | best | median |
|---|---|---|---|---|
| 12 | 12 | 40/40 | 292 | 426 |
| 16 | 16 | 40/40 | 649 | 1033 |
| 20 | 20 | 40/40 | 1348 | 2539 |
| 24 | 24 | 40/40 | 3493 | 5280 |
| 28 | 28 | 40/40 | 7247 | 15913 |
| 32 | 32 | 40/40 | 13847 | 33187 |
| 36 | 36 | 34/40 | 37306 | 71278 |
| 40 | 40 | 22/40 | 35364 | CAP |

## 7. E5 - 2-SAT / Horn hunt (H-2SAT)

**Question.** Is there a family in P (2-CNF or Horn) on which the candidate is exponential under every
order tried? **Families** (all with independent answers from an SCC 2-SAT solver / Horn unit
propagation): random 2-CNF at densities 0.9, 1.0, 1.5; one 2-clause on every edge of a random
d-regular graph (d = 3, 4, 5) with random signs (`rand`), signs conditioned on a hidden model
(`planted`), or a randomly directed implication (`impl`, always satisfiable); the same on grids;
implication grids (monotone, with cycles, and an unsatisfiable chain); a ladder; dense bipartite
implication layers; my 2-CNF analogue of the subsumption blocker (`subsume_2cnf`); random definite
Horn 3-CNF at densities 2, 3, 4 (trivially satisfiable), the same with 0.1 n facts and 0.2 n goal
clauses; an AND-grid of Horn rules; and the Horn renaming of G_k (`subsume_horn`).
**Orders.** natural, reverse, min_degree, min_fill, max_degree, bfs, 3 shuffles, greedy_min, and for
2-CNF also scc_topo / scc_topo_rev.
**Answers.** 2629 runs, 2348 completed, 2348 checked,
**0 disagreements**; non-completions {"CAP:time": 257, "ORDER_TIMEOUT:order:greedy chunks exhausted": 24}.

**2-CNF on random regular graphs** (b = power-law exponent, r = exponential rate in bits/variable,
at the largest fully completed n):

- `regular_2cnf {"d": 3, "mode": "impl"}` - greedy_min: 1273 nodes at n=160, b=1.06/tail 0.99, r=0.026 (power); bfs: 12256 nodes at n=160, b=1.62/tail 2.62, r=0.043 (power); scc_topo: 11493 nodes at n=224, b=1.51/tail 1.69, r=0.030 (power); min_degree: 39884 nodes at n=80, b=2.79/tail 3.89, r=0.122 (exponential); min_fill: 22548 nodes at n=80, b=2.46/tail 3.48, r=0.109 (exponential); natural: 65460 nodes at n=112, b=2.63/tail 3.68, r=0.091 (exponential); shuffle: 8532 nodes at n=80, b=2.09/tail 2.58, r=0.089 (exponential)
- `regular_2cnf {"d": 3, "mode": "planted"}` - greedy_min: 1592 nodes at n=224, b=1.05/tail 1.00, r=0.021 (power); bfs: 9986 nodes at n=320, b=1.45/tail 1.72, r=0.022 (power); scc_topo: 10364 nodes at n=112, b=2.08/tail 2.80, r=0.071 (exponential); min_degree: 8599 nodes at n=56, b=2.67/tail 3.67, r=0.147 (exponential); min_fill: 2570 nodes at n=56, b=2.10/tail 2.55, r=0.113 (exponential); natural: 28582 nodes at n=80, b=2.58/tail 3.88, r=0.114 (exponential); shuffle: 16660 nodes at n=80, b=2.36/tail 3.43, r=0.104 (exponential)
- `regular_2cnf {"d": 3, "mode": "rand"}` - greedy_min: 1861 nodes at n=224, b=1.12/tail 1.07, r=0.022 (power); bfs: 16812 nodes at n=224, b=1.77/tail 2.03, r=0.036 (power); scc_topo: 17924 nodes at n=160, b=1.82/tail 2.63, r=0.049 (exponential); min_degree: 39751 nodes at n=80, b=2.86/tail 4.11, r=0.126 (exponential); min_fill: 24264 nodes at n=80, b=2.66/tail 3.88, r=0.118 (exponential); natural: 9263 nodes at n=80, b=2.15/tail 2.95, r=0.094 (exponential); shuffle: 7755 nodes at n=80, b=2.19/tail 2.75, r=0.093 (exponential)
- `regular_2cnf {"d": 4, "mode": "planted"}` - greedy_min: 2920 nodes at n=80, b=1.70/tail 2.21, r=0.072 (power); bfs: 16381 nodes at n=80, b=2.41/tail 3.67, r=0.104 (exponential); scc_topo: 60497 nodes at n=80, b=3.01/tail 4.33, r=0.131 (exponential); min_degree: 12492 nodes at n=56, b=2.75/tail 3.28, r=0.147 (power); min_fill: 28448 nodes at n=56, b=3.15/tail 4.29, r=0.174 (exponential); natural: 16036 nodes at n=56, b=2.74/tail 3.63, r=0.151 (exponential); shuffle: 11470 nodes at n=56, b=2.65/tail 3.27, r=0.144 (exponential)
- `regular_2cnf {"d": 4, "mode": "rand"}` - greedy_min: 1869 nodes at n=224, b=1.02/tail 0.98, r=0.020 (power); bfs: 15345 nodes at n=224, b=1.86/tail 1.50, r=0.037 (power); scc_topo: 30228 nodes at n=112, b=2.27/tail 2.90, r=0.077 (power); min_degree: 10148 nodes at n=80, b=2.21/tail 2.32, r=0.093 (power); min_fill: 18613 nodes at n=80, b=2.73/tail 3.36, r=0.116 (power); natural: 33706 nodes at n=112, b=2.37/tail 2.75, r=0.080 (power); shuffle: 11911 nodes at n=80, b=2.24/tail 2.49, r=0.094 (power)
- `regular_2cnf {"d": 5, "mode": "planted"}` - greedy_min: 1621 nodes at n=80, b=1.47/tail 1.84, r=0.062 (power); bfs: 11399 nodes at n=80, b=2.26/tail 2.52, r=0.095 (power); scc_topo: 44617 nodes at n=80, b=2.80/tail 3.67, r=0.121 (exponential); min_degree: 14574 nodes at n=56, b=2.81/tail 3.23, r=0.150 (power); min_fill: 61714 nodes at n=80, b=3.22/tail 4.39, r=0.139 (exponential); natural: 49960 nodes at n=80, b=2.91/tail 3.85, r=0.126 (exponential); shuffle: 31856 nodes at n=80, b=2.59/tail 3.26, r=0.112 (exponential)

**Random Horn 3-CNF:**

- `random_horn3 {"density": 2.0, "facts": 0, "goals": 0}` - greedy_min: 1767 nodes at n=40, b=1.56/tail 4.38, r=0.099 (exponential); bfs: 10660 nodes at n=32, b=3.89/tail 5.36, r=0.279 (exponential); min_degree: 31350 nodes at n=48, b=3.64/tail 5.55, r=0.207 (exponential); min_fill: 21118 nodes at n=48, b=3.51/tail 4.99, r=0.200 (exponential); natural: 20401 nodes at n=32, b=4.57/tail 6.15, r=0.328 (exponential); shuffle: 17964 nodes at n=32, b=4.42/tail 6.35, r=0.318 (exponential)

**Other 2-CNF / Horn families:**

- `grid_2cnf {"mode": "impl"}` - greedy_min: 2279 nodes at n=144, b=1.36/tail 1.39, r=0.032 (power); bfs: 3861 nodes at n=144, b=1.45/tail 1.60, r=0.035 (power); scc_topo: 4123 nodes at n=144, b=1.55/tail 1.54, r=0.036 (power); min_degree: 11263 nodes at n=100, b=2.43/tail 2.43, r=0.075 (power); min_fill: 29594 nodes at n=144, b=2.44/tail 3.00, r=0.060 (exponential); natural: 4273 nodes at n=144, b=1.48/tail 1.49, r=0.035 (power); shuffle: 16911 nodes at n=100, b=2.55/tail 2.55, r=0.078 (power)
- `grid_2cnf {"mode": "planted"}` - greedy_min: 2131 nodes at n=196, b=1.22/tail 1.12, r=0.022 (power); bfs: 3820 nodes at n=256, b=1.19/tail 1.15, r=0.018 (power); scc_topo: 11173 nodes at n=256, b=1.59/tail 1.04, r=0.023 (power); min_degree: 9557 nodes at n=100, b=2.39/tail 2.39, r=0.075 (power); min_fill: 25881 nodes at n=144, b=2.39/tail 2.87, r=0.059 (exponential); natural: 5968 nodes at n=256, b=1.34/tail 1.26, r=0.020 (power); shuffle: 5582 nodes at n=64, b=2.42/tail -, r=0.102 (exponential)
- `rand2cnf {"density": 0.9}` - greedy_min: 618 nodes at n=160, b=1.09/tail 1.09, r=0.021 (power); bfs: 2693 nodes at n=320, b=1.29/tail 1.21, r=0.015 (power); scc_topo: 4792 nodes at n=320, b=1.44/tail 1.45, r=0.018 (power); min_degree: 1994 nodes at n=320, b=1.17/tail 1.13, r=0.014 (power); min_fill: 1900 nodes at n=320, b=1.15/tail 1.11, r=0.014 (power); natural: 2998 nodes at n=160, b=1.62/tail 1.62, r=0.034 (power); shuffle: 8653 nodes at n=160, b=2.20/tail 2.20, r=0.046 (exponential)
- `rand2cnf {"density": 1.0}` - greedy_min: 682 nodes at n=160, b=1.08/tail 1.08, r=0.021 (power); bfs: 2086 nodes at n=160, b=1.38/tail 1.38, r=0.028 (power); scc_topo: 1665 nodes at n=160, b=1.42/tail 1.42, r=0.028 (power); min_degree: 4482 nodes at n=320, b=1.40/tail 1.42, r=0.017 (power); min_fill: 5236 nodes at n=320, b=1.45/tail 1.51, r=0.018 (power); natural: 6434 nodes at n=160, b=1.82/tail 1.82, r=0.038 (exponential); shuffle: 837 nodes at n=80, b=1.50/tail -, r=0.048 (power)
- `rand2cnf {"density": 1.5}` - greedy_min: 571 nodes at n=160, b=0.79/tail 0.79, r=0.015 (power); bfs: 9820 nodes at n=160, b=1.84/tail 1.84, r=0.041 (exponential); scc_topo: 1104 nodes at n=80, b=1.06/tail -, r=0.032 (power); min_degree: 10034 nodes at n=160, b=1.84/tail 1.84, r=0.039 (exponential); min_fill: 8167 nodes at n=160, b=1.78/tail 1.78, r=0.038 (exponential); natural: 3801 nodes at n=80, b=1.72/tail -, r=0.059 (exponential); shuffle: 1105 nodes at n=80, b=1.20/tail -, r=0.037 (power)

**Reading.**
1. *2-CNF, standard orders: a P-class failure.* On 2-CNFs whose primal graph is a random regular
   graph, the natural order, random orders and - most strikingly - the classical treewidth
   heuristics min-degree and min-fill are exponential-looking and hit the caps by n of the order of
   80-160. These instances are decided in linear time by any 2-SAT algorithm. So the candidate
   *with any fixed standard elimination order* is not polynomial on 2-SAT.
2. *2-CNF, DAG-aware greedy order: no failure found.* The greedy_min order (choose the variable
   whose elimination allocates the fewest new nodes, sampling 12 candidates) stays near-linear on
   every 2-CNF family as far as I could compute it; its fitted exponents are listed above. I
   therefore did **not** find a 2-CNF family that is exponential under every order tried. The
   range of greedy_min is limited by the cost of computing the order (12 trial eliminations per
   step in <= 6 chunks of 16 s on a loaded machine), not by the size of the resulting run.
3. *Induced width is the wrong guide.* On these instances the orders with the smallest induced width
   (min-degree, min-fill) are among the worst, and greedy_min, whose induced width is about twice as
   large, is the best (table "Induced width of the order vs allocated nodes" below). The candidate's cost is not governed by
   the treewidth of the primal graph: what matters is how deep inside the nested OR/AND structure
   the variable being forgotten occurs, because every level above an occurrence is re-created for
   both cofactors.
4. *Order-specific blockers exist inside P.* `subsume_2cnf` (natural order) and `subsume_horn`
   (order x, a_1..a_k) reproduce the 2^k blow-up of G_k on a 2-CNF and on a Horn formula; other
   orders are linear on them.
5. *Horn.* See the per-variant lines above and the overview table: these are the numbers on which
   the Horn half of H-2SAT has to be judged.

**E5 overview.** "best order" = the order that completed at the largest size (ties: fewest nodes there); its own fit is shown, then per-order cells "n<=largest fully completed n: gmean alloc there; b = power exponent, r = exponential rate in bits/variable (better-fitting model)".

| family | fixed params | best order | its largest n | alloc there | power exp | tail power exp | exp rate bits/var | R2 pow | R2 exp | better fit | greedy_min | bfs | min_degree | min_fill | natural | shuffle |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| rand2cnf | {"density": 0.9} | min_fill | 320 | 1900 | 1.15 | 1.11 | 0.0138 | 0.998 | 0.862 | power | n<=160: 618; b=1.09, tail b=1.09, r=0.021 (power) | n<=320: 2693; b=1.29, tail b=1.21, r=0.015 (power) | n<=320: 1994; b=1.17, tail b=1.13, r=0.014 (power) | n<=320: 1900; b=1.15, tail b=1.11, r=0.014 (power) | n<=160: 2998; b=1.62, tail b=1.62, r=0.034 (power) | n<=160: 8653; b=2.20, tail b=2.20, r=0.046 (exponential) |
| rand2cnf | {"density": 1.0} | min_degree | 320 | 4482 | 1.40 | 1.42 | 0.0172 | 0.998 | 0.894 | power | n<=160: 682; b=1.08, tail b=1.08, r=0.021 (power) | n<=160: 2086; b=1.38, tail b=1.38, r=0.028 (power) | n<=320: 4482; b=1.40, tail b=1.42, r=0.017 (power) | n<=320: 5236; b=1.45, tail b=1.51, r=0.018 (power) | n<=160: 6434; b=1.82, tail b=1.82, r=0.038 (exponential) | n<=80: 837; b=1.50, tail b=-, r=0.048 (power) |
| rand2cnf | {"density": 1.5} | greedy_min | 160 | 571 | 0.79 | 0.79 | 0.0155 | 0.852 | 0.750 | power | n<=160: 571; b=0.79, tail b=0.79, r=0.015 (power) | n<=160: 9820; b=1.84, tail b=1.84, r=0.041 (exponential) | n<=160: 10034; b=1.84, tail b=1.84, r=0.039 (exponential) | n<=160: 8167; b=1.78, tail b=1.78, r=0.038 (exponential) | n<=80: 3801; b=1.72, tail b=-, r=0.059 (exponential) | n<=80: 1105; b=1.20, tail b=-, r=0.037 (power) |
| regular_2cnf | {"d": 3, "mode": "impl"} | scc_topo | 224 | 11493 | 1.51 | 1.69 | 0.0305 | 0.984 | 0.892 | power | n<=160: 1273; b=1.06, tail b=0.99, r=0.026 (power) | n<=160: 12256; b=1.62, tail b=2.62, r=0.043 (power) | n<=80: 39884; b=2.79, tail b=3.89, r=0.122 (exponential) | n<=80: 22548; b=2.46, tail b=3.48, r=0.109 (exponential) | n<=112: 65460; b=2.63, tail b=3.68, r=0.091 (exponential) | n<=80: 8532; b=2.09, tail b=2.58, r=0.089 (exponential) |
| regular_2cnf | {"d": 3, "mode": "planted"} | bfs | 320 | 9986 | 1.45 | 1.72 | 0.0225 | 0.983 | 0.867 | power | n<=224: 1592; b=1.05, tail b=1.00, r=0.021 (power) | n<=320: 9986; b=1.45, tail b=1.72, r=0.022 (power) | n<=56: 8599; b=2.67, tail b=3.67, r=0.147 (exponential) | n<=56: 2570; b=2.10, tail b=2.55, r=0.113 (exponential) | n<=80: 28582; b=2.58, tail b=3.88, r=0.114 (exponential) | n<=80: 16660; b=2.36, tail b=3.43, r=0.104 (exponential) |
| regular_2cnf | {"d": 3, "mode": "rand"} | greedy_min | 224 | 1861 | 1.12 | 1.07 | 0.0220 | 0.998 | 0.849 | power | n<=224: 1861; b=1.12, tail b=1.07, r=0.022 (power) | n<=224: 16812; b=1.77, tail b=2.03, r=0.036 (power) | n<=80: 39751; b=2.86, tail b=4.11, r=0.126 (exponential) | n<=80: 24264; b=2.66, tail b=3.88, r=0.118 (exponential) | n<=80: 9263; b=2.15, tail b=2.95, r=0.094 (exponential) | n<=80: 7755; b=2.19, tail b=2.75, r=0.093 (exponential) |
| regular_2cnf | {"d": 4, "mode": "planted"} | greedy_min | 80 | 2920 | 1.70 | 2.21 | 0.0725 | 0.975 | 0.968 | power | n<=80: 2920; b=1.70, tail b=2.21, r=0.072 (power) | n<=80: 16381; b=2.41, tail b=3.67, r=0.104 (exponential) | n<=56: 12492; b=2.75, tail b=3.28, r=0.147 (power) | n<=56: 28448; b=3.15, tail b=4.29, r=0.174 (exponential) | n<=56: 16036; b=2.74, tail b=3.63, r=0.151 (exponential) | n<=56: 11470; b=2.65, tail b=3.27, r=0.144 (exponential) |
| regular_2cnf | {"d": 4, "mode": "rand"} | greedy_min | 224 | 1869 | 1.02 | 0.98 | 0.0196 | 0.994 | 0.809 | power | n<=224: 1869; b=1.02, tail b=0.98, r=0.020 (power) | n<=224: 15345; b=1.86, tail b=1.50, r=0.037 (power) | n<=80: 10148; b=2.21, tail b=2.32, r=0.093 (power) | n<=80: 18613; b=2.73, tail b=3.36, r=0.116 (power) | n<=112: 33706; b=2.37, tail b=2.75, r=0.080 (power) | n<=80: 11911; b=2.24, tail b=2.49, r=0.094 (power) |
| regular_2cnf | {"d": 5, "mode": "planted"} | greedy_min | 80 | 1621 | 1.47 | 1.84 | 0.0621 | 0.975 | 0.954 | power | n<=80: 1621; b=1.47, tail b=1.84, r=0.062 (power) | n<=80: 11399; b=2.26, tail b=2.52, r=0.095 (power) | n<=56: 14574; b=2.81, tail b=3.23, r=0.150 (power) | n<=80: 61714; b=3.22, tail b=4.39, r=0.139 (exponential) | n<=80: 49960; b=2.91, tail b=3.85, r=0.126 (exponential) | n<=80: 31856; b=2.59, tail b=3.26, r=0.112 (exponential) |
| grid_2cnf | {"mode": "impl"} | greedy_min | 144 | 2279 | 1.36 | 1.39 | 0.0320 | 0.999 | 0.925 | power | n<=144: 2279; b=1.36, tail b=1.39, r=0.032 (power) | n<=144: 3861; b=1.45, tail b=1.60, r=0.035 (power) | n<=100: 11263; b=2.43, tail b=2.43, r=0.075 (power) | n<=144: 29594; b=2.44, tail b=3.00, r=0.060 (exponential) | n<=144: 4273; b=1.48, tail b=1.49, r=0.035 (power) | n<=100: 16911; b=2.55, tail b=2.55, r=0.078 (power) |
| grid_2cnf | {"mode": "planted"} | bfs | 256 | 3820 | 1.19 | 1.15 | 0.0180 | 0.999 | 0.874 | power | n<=196: 2131; b=1.22, tail b=1.12, r=0.022 (power) | n<=256: 3820; b=1.19, tail b=1.15, r=0.018 (power) | n<=100: 9557; b=2.39, tail b=2.39, r=0.075 (power) | n<=144: 25881; b=2.39, tail b=2.87, r=0.059 (exponential) | n<=256: 5968; b=1.34, tail b=1.26, r=0.020 (power) | n<=64: 5582; b=2.42, tail b=-, r=0.102 (exponential) |
| random_horn3 | {"density": 2.0, "facts": 0, "goals": 0} | min_fill | 48 | 21118 | 3.51 | 4.99 | 0.1996 | 0.937 | 0.987 | exponential | n<=40: 1767; b=1.56, tail b=4.38, r=0.099 (exponential) | n<=32: 10660; b=3.89, tail b=5.36, r=0.279 (exponential) | n<=48: 31350; b=3.64, tail b=5.55, r=0.207 (exponential) | n<=48: 21118; b=3.51, tail b=4.99, r=0.200 (exponential) | n<=32: 20401; b=4.57, tail b=6.15, r=0.328 (exponential) | n<=32: 17964; b=4.42, tail b=6.35, r=0.318 (exponential) |

**Induced width of the order vs allocated nodes** (2-CNF on random d-regular graphs, all sign modes and seeds pooled; gmean over the runs that completed)

| n | d | order | median induced width | completed | gmean alloc |
|---|---|---|---|---|---|
| 56 | 3 | natural | 18 | 9/9 | 2573 |
| 56 | 3 | reverse | 17 | 9/9 | 2703 |
| 56 | 3 | min_degree | 11 | 9/9 | 6660 |
| 56 | 3 | min_fill | 10 | 9/9 | 2538 |
| 56 | 3 | greedy_min | 16 | 9/9 | 400 |
| 56 | 3 | bfs | 14 | 9/9 | 802 |
| 56 | 3 | scc_topo | 19 | 9/9 | 1103 |
| 56 | 3 | scc_topo_rev | 18 | 9/9 | 1302 |
| 56 | 3 | max_degree | 26 | 9/9 | 2340 |
| 56 | 3 | shuffle | 18 | 27/27 | 2827 |
| 56 | 4 | natural | 25 | 6/6 | 7446 |
| 56 | 4 | reverse | 27 | 6/6 | 5134 |
| 56 | 4 | min_degree | 17 | 6/6 | 8486 |
| 56 | 4 | min_fill | 17 | 6/6 | 19432 |
| 56 | 4 | greedy_min | 26 | 6/6 | 907 |
| 56 | 4 | bfs | 25 | 6/6 | 3107 |
| 56 | 4 | scc_topo | 26 | 6/6 | 7346 |
| 56 | 4 | scc_topo_rev | 26 | 6/6 | 4251 |
| 56 | 4 | max_degree | 36 | 6/6 | 9930 |
| 56 | 4 | shuffle | 26 | 18/18 | 5982 |
| 56 | 5 | natural | 30 | 2/2 | 10328 |
| 56 | 5 | reverse | 29 | 2/2 | 7860 |
| 56 | 5 | min_degree | 22 | 2/2 | 14574 |
| 56 | 5 | min_fill | 20 | 2/2 | 25439 |
| 56 | 5 | greedy_min | 30 | 2/2 | 1107 |
| 56 | 5 | bfs | 28 | 2/2 | 3073 |
| 56 | 5 | scc_topo | 28 | 2/2 | 10659 |
| 56 | 5 | scc_topo_rev | 29 | 2/2 | 10401 |
| 56 | 5 | max_degree | 39 | 2/2 | 21019 |
| 56 | 5 | shuffle | 30 | 6/6 | 5536 |
| 80 | 3 | natural | 26 | 9/9 | 15043 |
| 80 | 3 | reverse | 25 | 9/9 | 13312 |
| 80 | 3 | min_degree | 17 | 8/9 | 41855 |
| 80 | 3 | min_fill | 16 | 8/9 | 22357 |
| 80 | 3 | greedy_min | 24 | 9/9 | 618 |
| 80 | 3 | bfs | 23 | 9/9 | 1375 |
| 80 | 3 | scc_topo | 25 | 9/9 | 3474 |
| 80 | 3 | scc_topo_rev | 26 | 9/9 | 4992 |
| 80 | 3 | max_degree | 37 | 9/9 | 6711 |
| 80 | 3 | shuffle | 25 | 27/27 | 10330 |
| 80 | 4 | natural | 35 | 5/6 | 16992 |
| 80 | 4 | reverse | 35 | 5/6 | 23547 |
| 80 | 4 | min_degree | 24 | 3/6 | 10148 |
| 80 | 4 | min_fill | 22 | 5/6 | 32765 |
| 80 | 4 | greedy_min | 34 | 6/6 | 1418 |
| 80 | 4 | bfs | 35 | 6/6 | 9612 |
| 80 | 4 | scc_topo | 36 | 6/6 | 21692 |
| 80 | 4 | scc_topo_rev | 34 | 6/6 | 10404 |
| 80 | 4 | max_degree | 48 | 4/6 | 42213 |
| 80 | 4 | shuffle | 35 | 15/18 | 20356 |
| 80 | 5 | natural | 42 | 2/2 | 49960 |
| 80 | 5 | reverse | 42 | 2/2 | 19924 |
| 80 | 5 | min_degree | - | 0/2 | all capped |
| 80 | 5 | min_fill | 28 | 2/2 | 61714 |
| 80 | 5 | greedy_min | 48 | 2/2 | 1621 |
| 80 | 5 | bfs | 38 | 2/2 | 11399 |
| 80 | 5 | scc_topo | 45 | 2/2 | 44617 |
| 80 | 5 | scc_topo_rev | 40 | 2/2 | 17395 |
| 80 | 5 | max_degree | 54 | 2/2 | 51192 |
| 80 | 5 | shuffle | 42 | 6/6 | 31856 |

Selected size tables (all others are in `results/tables.md`):

**regular_2cnf {"d": 3, "mode": "rand"}: allocated nodes (gmean over instances / shuffles)**

| nv | n vars | N bits | natural | reverse | min_degree | min_fill | greedy_min | bfs | scc_topo | scc_topo_rev | max_degree | shuffle |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 10 | 10 | 324 | 90 | 85 | 78 | 84 | 62 | 79 | 99 | 91 | 86 | 89 |
| 14 | 14 | 480 | 152 | 157 | 181 | 113 | 89 | 126 | 156 | 108 | 157 | 123 |
| 20 | 20 | 744 | 203 | 286 | 212 | 156 | 114 | 165 | 175 | 227 | 235 | 226 |
| 28 | 28 | 1104 | 383 | 602 | 623 | 386 | 195 | 407 | 372 | 558 | 531 | 435 |
| 40 | 40 | 1698 | 1081 | 684 | 1123 | 1150 | 269 | 432 | 569 | 546 | 974 | 1089 |
| 56 | 56 | 2514 | 2183 | 2713 | 7222 | 3447 | 411 | 874 | 1133 | 1704 | 1934 | 2763 |
| 80 | 80 | 3840 | 9263 | 8526 | 39751 | 24264 | 620 | 2086 | 2344 | 4112 | 15889 | 7755 |
| 112 | 112 | 5664 | >14760* (1/3) | CAP(time) | >56293* (1/3) | >72956* (1/3) | 920 | 4747 | 5675 | 11282 | CAP(time) | >29191* (3/9) |
| 160 | 160 | 8598 |  |  |  |  | 1359 | 9975 | 17924 | >6357* (1/3) |  |  |
| 224 | 224 | 12630 |  |  |  |  | 1861 | 16812 | CAP(time) |  |  |  |
| 320 | 320 | 19068 |  |  |  |  | CAP(order:greedy chunks exhausted) | CAP(time) |  |  |  |  |

**regular_2cnf {"d": 4, "mode": "planted"}: allocated nodes (gmean over instances / shuffles)**

| nv | n vars | N bits | natural | reverse | min_degree | min_fill | greedy_min | bfs | scc_topo | scc_topo_rev | max_degree | shuffle |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 10 | 10 | 432 | 106 | 91 | 104 | 90 | 77 | 99 | 110 | 102 | 109 | 112 |
| 14 | 14 | 640 | 236 | 151 | 276 | 212 | 149 | 232 | 185 | 228 | 223 | 183 |
| 20 | 20 | 992 | 338 | 525 | 433 | 300 | 204 | 417 | 419 | 345 | 523 | 402 |
| 28 | 28 | 1472 | 962 | 1252 | 1266 | 1020 | 310 | 408 | 765 | 834 | 1035 | 840 |
| 40 | 40 | 2264 | 2500 | 3452 | 4321 | 3193 | 559 | 1329 | 1940 | 2545 | 4129 | 2818 |
| 56 | 56 | 3352 | 16036 | 7783 | 12492 | 28448 | 1482 | 7370 | 14635 | 5923 | 20937 | 11470 |
| 80 | 80 | 5120 | >37975* (2/3) | >103542* (2/3) | CAP(time) | >76526* (2/3) | 2920 | 16381 | 60497 | 24971 | >24894* (1/3) | >45478* (6/9) |
| 112 |  |  |  |  |  |  | CAP(order:greedy chunks exhausted) |  |  |  |  |  |

## 8. E6 - the subsumption blocker G_k (H-SUBSUME)

G_k = {(x v a_i v b_i) : i = 1..k} + {(-x v c)}; x = 1, a_i = 1+i, b_i = 1+k+i, c = 2k+2. Orders:
`x_then_a` = x, a_1..a_k, b_1..b_k, c and `a_then_x` = a_1..a_k, x, b_1..b_k, c (plus reverse,
min_degree, min_fill for reference). All answers SAT (explicit witness checked).

Exact counts for k = 2..14 (table below): under `x_then_a` the largest OR node has **2^(k-1) + 2**
children (4, 6, 10, 18, ..., 8194), the number of allocated nodes is **2^(k+1) + 6k + 3**
(first differences 2^(k+1) + 6: 14, 22, 38, ..., 16390), and the peak reachable size is
2^(k-1) + k + 3 for k >= 5. Under `a_then_x` exactly **6k + 7** nodes are allocated and no OR node has
more than 3 children. The lead's prediction "2^k + O(1) children of one OR node" has the right
mechanism (no AND-subset subsumption once the alternative `c` blocks common-factor extraction) but
is off by a factor of two: when the last a_k is cofactored with a_k = 1 the conjunction becomes
empty, the OR collapses to True, and the 2^k-child node is never built; the largest node is the
a_k = 0 cofactor with 2^(k-1) conjunctions plus `c` plus one residual.

| k | n | x,a..: alloc | max OR arity | peak reach | child refs | cofactor cache | a..,x: alloc | max OR arity | peak reach | child refs | cofactor cache | 2^(k-1)+2 | OR arity = 2^(k-1)+2 ? | reverse alloc | min_degree alloc | min_fill alloc |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 2 | 6 | 23 | 4 | 11 | 34 | 60 | 19 | 3 | 11 | 25 | 60 | 4 | yes | 21 | 19 | 21 |
| 3 | 8 | 37 | 6 | 14 | 69 | 102 | 25 | 3 | 14 | 38 | 90 | 6 | yes | 27 | 25 | 27 |
| 4 | 10 | 59 | 10 | 17 | 140 | 160 | 31 | 3 | 17 | 53 | 126 | 10 | yes | 33 | 31 | 33 |
| 5 | 12 | 97 | 18 | 24 | 291 | 242 | 37 | 3 | 20 | 70 | 168 | 18 | yes | 39 | 37 | 39 |
| 6 | 14 | 167 | 34 | 41 | 618 | 364 | 43 | 3 | 23 | 89 | 216 | 34 | yes | 45 | 43 | 45 |
| 7 | 16 | 301 | 66 | 74 | 1329 | 558 | 49 | 3 | 26 | 110 | 270 | 66 | yes | 51 | 49 | 51 |
| 8 | 18 | 563 | 130 | 139 | 2872 | 888 | 55 | 3 | 29 | 133 | 330 | 130 | yes | 57 | 55 | 57 |
| 9 | 20 | 1081 | 258 | 268 | 6207 | 1482 | 61 | 3 | 32 | 158 | 396 | 258 | yes | 63 | 61 | 63 |
| 10 | 22 | 2111 | 514 | 525 | 13382 | 2596 | 67 | 3 | 35 | 185 | 468 | 514 | yes | 69 | 67 | 69 |
| 11 | 24 | 4165 | 1026 | 1038 | 28749 | 4742 | 73 | 3 | 38 | 214 | 546 | 1026 | yes | 75 | 73 | 75 |
| 12 | 26 | 8267 | 2050 | 2063 | 61524 | 8944 | 79 | 3 | 41 | 245 | 630 | 2050 | yes | 81 | 79 | 81 |
| 13 | 28 | 16465 | 4098 | 4112 | 131163 | 17250 | 85 | 3 | 44 | 278 | 720 | 4098 | yes | 87 | 85 | 87 |
| 14 | 30 | 32855 | 8194 | 8209 | 278626 | 33756 | 91 | 3 | 47 | 313 | 816 | 8194 | yes | 93 | 91 | 93 |

x_then_a: exp rate 0.8837 bits per k (tail 0.9933), power exponent in k 3.781, first differences of alloc [14, 22, 38, 70, 134, 262, 518, 1030, 2054, 4102, 8198, 16390]

a_then_x: exp rate 0.1776 bits per k (tail 0.106), power exponent in k 0.818, first differences of alloc [6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6]

## 9. E7 - semantic census

For every instance with at most 16 variables (and PHP(5,4) with 20) the truth table of every node
reachable from the root was computed after every forget step (Python ints as bitmasks over all
2^n assignments). Recorded per step: (a) reachable nodes, (b) semantically distinct functions among
them, the same restricted to and/or nodes, and - added by me - the number of child references that
are *semantically redundant inside their own node* (a child that can be dropped without changing
the node's function, scanning children left to right). For n <= 16 the same count was made over all
allocated nodes. As a by-product the root was compared with the exact existential projection of
the input at every step of every census: all equal (208 censuses), which is an additional
exactness check of the candidate.

Answer to "how much could ANY semantic canonical form save on the same node set?": very little by
merging equal functions. At the peak step the reachable nodes are almost all semantically distinct
(median ratio 1.000 for Tseitin, PHP, 3-XOR, 2-CNF and G_k; about 0.89 for random 3-CNF and Horn);
over all nodes ever allocated the median ratio is 0.69-0.96, i.e. a perfect semantic hash-consing
of the same nodes would save a factor of at most about 1.5 (2.2 in the single worst case). The
exponential families are exponential in the number of *distinct functions*. The G_k blow-up is a
different phenomenon: all 2^(k-1) conjunctions are different functions, but 2^(k-1) - 1 of them are
subsumed children of one OR node (column "max redundant child refs"); only a rule that minimises
a node, not one that merges equal nodes, removes them.

**Per family: distinct functions / nodes** (1.000 = no semantic redundancy at all)

| family | censuses | min b/a at peak | median b/a | min internal ratio | median internal ratio | min ratio over ALL allocated internal nodes | median | median fraction of redundant child refs (worst step) | max fraction |
|---|---|---|---|---|---|---|---|---|---|
| kcnf | 36 | 0.649 | 0.890 | 0.597 | 0.867 | 0.525 | 0.691 | 0.178 | 0.287 |
| php | 14 | 0.878 | 1.000 | 0.863 | 0.929 | 0.679 | 0.734 | 0.108 | 0.182 |
| rand2cnf | 6 | 1.000 | 1.000 | 0.944 | 1.000 | 0.767 | 0.833 | 0.062 | 0.091 |
| random_horn3 | 6 | 0.667 | 0.893 | 0.640 | 0.869 | 0.577 | 0.779 | 0.120 | 0.183 |
| subsume | 8 | 1.000 | 1.000 | 1.000 | 1.000 | 0.935 | 0.958 | 0.153 | 0.226 |
| subsume_2cnf | 2 | 1.000 | 1.000 | 1.000 | 1.000 | 0.927 | 0.943 | 0.115 | 0.188 |
| tseitin_complete | 16 | 1.000 | 1.000 | 0.980 | 1.000 | 0.824 | 0.852 | 0.011 | 0.017 |
| tseitin_regular | 48 | 1.000 | 1.000 | 0.939 | 1.000 | 0.767 | 0.849 | 0.029 | 0.071 |
| xor3 | 72 | 0.659 | 1.000 | 0.555 | 0.987 | 0.450 | 0.814 | 0.178 | 0.620 |

Selected census rows (all rows: `results/tables.md`):

| family | params | order | answer | n | alloc | (a) peak reachable | (b) peak distinct functions | b/a | peak internal (and/or) | distinct internal | ratio | ALL allocated internal | distinct among them | ratio | peak child refs (reachable) | max redundant child refs / refs at that step | root == exact projection at every step |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| php | {"h": 4} | pigeon_major | UNSAT | 20 | 725 | 99 | 93 | 0.939 | 77 | 72 | 0.935 | - | - | - | 271 | 18/258 | ok |
| php | {"h": 4} | hole_major | UNSAT | 20 | 518 | 86 | 86 | 1.000 | 63 | 61 | 0.968 | - | - | - | 178 | 30/177 | ok |
| php | {"h": 4} | min_degree | UNSAT | 20 | 464 | 86 | 86 | 1.000 | 58 | 53 | 0.914 | - | - | - | 171 | 17/171 | ok |
| php | {"h": 4} | min_fill | UNSAT | 20 | 518 | 86 | 86 | 1.000 | 57 | 50 | 0.877 | - | - | - | 168 | 16/168 | ok |
| php | {"h": 4} | shuffle00 | UNSAT | 20 | 1054 | 151 | 139 | 0.921 | 135 | 123 | 0.911 | - | - | - | 384 | 41/308 | ok |
| php | {"h": 4} | shuffle01 | UNSAT | 20 | 851 | 127 | 116 | 0.913 | 113 | 102 | 0.903 | - | - | - | 295 | 31/268 | ok |
| php | {"h": 4} | shuffle02 | UNSAT | 20 | 979 | 131 | 115 | 0.878 | 117 | 101 | 0.863 | - | - | - | 334 | 47/306 | ok |
| kcnf | {"density": 4.26, "k": 3, "n": 16, "seed": 1} | natural | UNSAT | 16 | 580 | 110 | 102 | 0.927 | 90 | 81 | 0.900 | 546 | 411 | 0.753 | 282 | 47/222 | ok |
| kcnf | {"density": 4.26, "k": 3, "n": 16, "seed": 1} | min_degree | UNSAT | 16 | 611 | 109 | 109 | 1.000 | 89 | 89 | 1.000 | 577 | 434 | 0.752 | 268 | 42/268 | ok |
| kcnf | {"density": 4.26, "k": 3, "n": 16, "seed": 1} | min_fill | UNSAT | 16 | 824 | 130 | 113 | 0.869 | 114 | 97 | 0.851 | 790 | 486 | 0.615 | 325 | 42/268 | ok |
| kcnf | {"density": 4.26, "k": 3, "n": 16, "seed": 1} | shuffle00 | UNSAT | 16 | 909 | 165 | 135 | 0.818 | 149 | 117 | 0.785 | 875 | 621 | 0.710 | 465 | 71/465 | ok |
| kcnf | {"density": 4.26, "k": 3, "n": 16, "seed": 1} | shuffle01 | UNSAT | 16 | 700 | 123 | 106 | 0.862 | 105 | 87 | 0.829 | 666 | 497 | 0.746 | 331 | 55/331 | ok |
| kcnf | {"density": 4.26, "k": 3, "n": 16, "seed": 1} | shuffle02 | UNSAT | 16 | 750 | 137 | 121 | 0.883 | 117 | 101 | 0.863 | 716 | 538 | 0.751 | 369 | 53/351 | ok |
| xor3 | {"n": 16, "extra": 0, "planted": true, "seed": 1} | natural | SAT | 16 | 343 | 96 | 96 | 1.000 | 70 | 70 | 1.000 | 309 | 257 | 0.832 | 240 | 28/204 | ok |
| xor3 | {"n": 16, "extra": 0, "planted": true, "seed": 1} | min_degree | SAT | 16 | 275 | 99 | 95 | 0.960 | 79 | 75 | 0.949 | 241 | 210 | 0.871 | 240 | 26/240 | ok |
| xor3 | {"n": 16, "extra": 0, "planted": true, "seed": 1} | min_fill | SAT | 16 | 262 | 99 | 95 | 0.960 | 79 | 75 | 0.949 | 228 | 210 | 0.921 | 240 | 26/240 | ok |
| xor3 | {"n": 16, "extra": 0, "planted": true, "seed": 1} | shuffle00 | SAT | 16 | 302 | 95 | 95 | 1.000 | 72 | 71 | 0.986 | 268 | 243 | 0.907 | 240 | 26/240 | ok |
| xor3 | {"n": 16, "extra": 0, "planted": true, "seed": 1} | shuffle01 | SAT | 16 | 428 | 101 | 101 | 1.000 | 81 | 81 | 1.000 | 394 | 378 | 0.959 | 272 | 26/240 | ok |
| xor3 | {"n": 16, "extra": 0, "planted": true, "seed": 1} | shuffle02 | SAT | 16 | 294 | 96 | 95 | 0.990 | 70 | 69 | 0.986 | 260 | 237 | 0.912 | 240 | 26/240 | ok |
| tseitin_regular | {"nv": 10, "d": 3, "seed": 1, "sat": false} | natural | UNSAT | 15 | 309 | 72 | 72 | 1.000 | 54 | 54 | 1.000 | 277 | 225 | 0.812 | 160 | 2/100 | ok |
| tseitin_regular | {"nv": 10, "d": 3, "seed": 1, "sat": false} | min_degree | UNSAT | 15 | 270 | 73 | 73 | 1.000 | 49 | 49 | 1.000 | 238 | 198 | 0.832 | 160 | 2/102 | ok |
| tseitin_regular | {"nv": 10, "d": 3, "seed": 1, "sat": false} | min_fill | UNSAT | 15 | 274 | 72 | 72 | 1.000 | 46 | 46 | 1.000 | 242 | 197 | 0.814 | 160 | 2/78 | ok |
| tseitin_regular | {"nv": 10, "d": 3, "seed": 1, "sat": false} | shuffle00 | UNSAT | 15 | 305 | 73 | 73 | 1.000 | 55 | 55 | 1.000 | 273 | 230 | 0.842 | 160 | 2/124 | ok |
| tseitin_regular | {"nv": 10, "d": 3, "seed": 1, "sat": false} | shuffle01 | UNSAT | 15 | 279 | 74 | 74 | 1.000 | 59 | 59 | 1.000 | 247 | 203 | 0.822 | 160 | 2/126 | ok |
| tseitin_regular | {"nv": 10, "d": 3, "seed": 1, "sat": false} | shuffle02 | UNSAT | 15 | 300 | 73 | 73 | 1.000 | 55 | 55 | 1.000 | 268 | 217 | 0.810 | 160 | 2/78 | ok |
| tseitin_regular | {"nv": 10, "d": 3, "seed": 1, "sat": false} | max_degree | UNSAT | 15 | 321 | 72 | 72 | 1.000 | 52 | 52 | 1.000 | 289 | 246 | 0.851 | 160 | 2/76 | ok |
| tseitin_regular | {"nv": 10, "d": 3, "seed": 1, "sat": false} | bfs | UNSAT | 15 | 326 | 72 | 72 | 1.000 | 48 | 48 | 1.000 | 294 | 249 | 0.847 | 160 | 2/76 | ok |
| subsume | {"k": 4} | x_then_a | SAT | 10 | 59 | 17 | 17 | 1.000 | 9 | 9 | 1.000 | 46 | 43 | 0.935 | 31 | 7/31 | ok |
| subsume | {"k": 4} | a_then_x | SAT | 10 | 31 | 17 | 17 | 1.000 | 6 | 6 | 1.000 | 18 | 17 | 0.944 | 19 | 1/9 | ok |
| subsume | {"k": 5} | x_then_a | SAT | 12 | 97 | 24 | 24 | 1.000 | 17 | 17 | 1.000 | 82 | 78 | 0.951 | 67 | 15/67 | ok |
| subsume | {"k": 5} | a_then_x | SAT | 12 | 37 | 20 | 20 | 1.000 | 7 | 7 | 1.000 | 22 | 21 | 0.955 | 23 | 1/9 | ok |
| subsume | {"k": 6} | x_then_a | SAT | 14 | 167 | 41 | 41 | 1.000 | 33 | 33 | 1.000 | 150 | 145 | 0.967 | 147 | 31/147 | ok |
| subsume | {"k": 6} | a_then_x | SAT | 14 | 43 | 23 | 23 | 1.000 | 8 | 8 | 1.000 | 26 | 25 | 0.962 | 27 | 1/9 | ok |
| subsume | {"k": 7} | x_then_a | SAT | 16 | 301 | 74 | 74 | 1.000 | 65 | 65 | 1.000 | 282 | 276 | 0.979 | 323 | 63/323 | ok |
| subsume | {"k": 7} | a_then_x | SAT | 16 | 49 | 26 | 26 | 1.000 | 9 | 9 | 1.000 | 30 | 29 | 0.967 | 31 | 1/9 | ok |

## 10. E8 - repaired subclass (`repaired_dag.py`)

`repaired_dag.py` subclasses the candidate (the original file is untouched) and adds one rule in
`junction`, right after the original single-node absorption: among the children of the dual kind
keep only the inclusion-minimal child sets, i.e. OR(AND(X), AND(X u Y)) = AND(X) and
AND(OR(X), OR(X u Y)) = OR(X). Everything else is copied verbatim.
**Validation**: 2000 random small CNFs (1-8 variables, 1-16 clauses of width 0-4, including empty
clauses, duplicate literals and tautologies), random order, full truth-table equality of the root
with the exact projection at every elimination stage, plus an independent `evaluate`-based check
in the style of `residual_dag.check_random` on every tenth formula; the original class was put
through the same test.
**Reruns** of E6, E3 (same random orders as E3) and E4 (same shuffles as E4, 5 per instance) with
the repaired class; greedy orders are recomputed with the repaired class.

**Reading.** The rule does exactly what it was designed for - G_k under the bad order goes from
2^(k+1) + 6k + 3 to 8k + 7 nodes - and nothing else: on PHP and on random 3-CNF the node counts
change by a few percent and the fitted rates are unchanged within noise (table below; rates are
fitted on the sizes both classes completed). Subset subsumption is therefore not the reason for
the growth on those families, in agreement with the census (their nodes are distinct functions).

Validation against brute force at every elimination stage: {"repaired": {"tasks": 40, "formulas": 2000, "stages": 11108, "evaluate_points": 24304, "failures": 0, "crashed": 0}, "original": {"tasks": 40, "formulas": 2000, "stages": 11108, "evaluate_points": 24304, "failures": 0, "crashed": 0}}

G_k under the repaired class:

| k | n | x,a..: alloc | max OR arity | peak reach | child refs | cofactor cache | a..,x: alloc | max OR arity | peak reach | child refs | cofactor cache | 2^(k-1)+2 | OR arity = 2^(k-1)+2 ? | reverse alloc | min_degree alloc | min_fill alloc |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 2 | 6 | 23 | 4 | 11 | 34 | 60 | 19 | 3 | 11 | 25 | 60 | 4 | yes | 21 | 19 | 21 |
| 3 | 8 | 31 | 4 | 14 | 50 | 92 | 25 | 3 | 14 | 38 | 90 | 6 | no | 27 | 25 | 27 |
| 4 | 10 | 39 | 4 | 17 | 68 | 130 | 31 | 3 | 17 | 53 | 126 | 10 | no | 33 | 31 | 33 |
| 5 | 12 | 47 | 4 | 20 | 88 | 174 | 37 | 3 | 20 | 70 | 168 | 18 | no | 39 | 37 | 39 |
| 6 | 14 | 55 | 4 | 23 | 110 | 224 | 43 | 3 | 23 | 89 | 216 | 34 | no | 45 | 43 | 45 |
| 7 | 16 | 63 | 4 | 26 | 134 | 280 | 49 | 3 | 26 | 110 | 270 | 66 | no | 51 | 49 | 51 |
| 8 | 18 | 71 | 4 | 29 | 160 | 342 | 55 | 3 | 29 | 133 | 330 | 130 | no | 57 | 55 | 57 |
| 9 | 20 | 79 | 4 | 32 | 188 | 410 | 61 | 3 | 32 | 158 | 396 | 258 | no | 63 | 61 | 63 |
| 10 | 22 | 87 | 4 | 35 | 218 | 484 | 67 | 3 | 35 | 185 | 468 | 514 | no | 69 | 67 | 69 |
| 11 | 24 | 95 | 4 | 38 | 250 | 564 | 73 | 3 | 38 | 214 | 546 | 1026 | no | 75 | 73 | 75 |
| 12 | 26 | 103 | 4 | 41 | 284 | 650 | 79 | 3 | 41 | 245 | 630 | 2050 | no | 81 | 79 | 81 |
| 13 | 28 | 111 | 4 | 44 | 320 | 742 | 85 | 3 | 44 | 278 | 720 | 4098 | no | 87 | 85 | 87 |
| 14 | 30 | 119 | 4 | 47 | 358 | 840 | 91 | 3 | 47 | 313 | 816 | 8194 | no | 93 | 91 | 93 |

x_then_a: exp rate 0.1853 bits per k (tail 0.1083), power exponent in k 0.856, first differences of alloc [8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8]

a_then_x: exp rate 0.1776 bits per k (tail 0.106), power exponent in k 0.818, first differences of alloc [6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6]

PHP under the repaired class:

| h | n vars | N bits | reverse | pigeon_major | hole_major | min_degree | min_fill | greedy_min | bfs | max_degree | greedy_max | #random | random min | random median | local-search min | MIN over all tried |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 2 | 6 | 174 | 48 | 48 | 49 | 47 | 47 | 47 | 48 | 48 | 49 | 200 | 45 | 48 |  | 45 |
| 3 | 12 | 532 | 194 | 194 | 178 | 162 | 150 | 150 | 192 | 194 | 241 | 200 | 142 | 183 | 137 | 137 |
| 4 | 20 | 1230 | 723 | 723 | 506 | 444 | 511 | 465 | 669 | 723 | 1176 | 200 | 569 | 799 | 353 | 353 |
| 5 | 30 | 2370 | 2712 | 2712 | 1316 | 1674 | 1223 | 1243 | 1992 | 2712 | 5772 | 200 | 2481 | 4527 | 923 | 923 |
| 6 | 42 | 4172 | 10062 | 10062 | 3343 | 7000 | 5323 | 4763 | 5645 | 10062 | CAP:order:greedy chunks exhausted | 60 | 20063 | 31885 | 2432 | 2432 |
| 7 | 56 | 6664 | 35971 | 35971 | 8424 | 28885 | 22815 | CAP:order:greedy chunks exhausted | 15430 | 35971 |  |  |  |  |  | 8424 |
| 8 | 72 | 10098 | CAP:time | CAP:time | 21048 | 67730 | CAP:time |  | 40847 | CAP:time |  |  |  |  |  | 21048 |
| 9 | 90 | 14630 |  |  | CAP:time | CAP:time |  |  | CAP:time |  |  |  |  |  |  |  |

Growth per order (ratio alloc(h+1)/alloc(h); exponential rate in bits per hole and per variable; power-law exponent in n = h(h+1))

## 11. What would falsify the lead's hypotheses, and what I found against them

What would falsify each hypothesis, and what the data say:

- **H-TSEITIN** would be falsified by a single order on a bounded-degree graph whose allocation is
  super-polynomial: local log-log slopes that keep increasing, or a support carrying exponentially
  many nodes. I looked for one with 13 generic orders, two designed adversarial orders, exhaustive
  enumeration on K4 and W4, 4000 random orders on four small cubic graphs, and hill-climbing on 15
  instances. Nothing: every regular-graph series is better fit by a power law with exponent <= 2,
  and the hill-climbed maxima divided by n^2 decrease. Two refinements of the lead's statement:
  (i) "observed about n^1.5" is order-dependent - min-degree / min-fill give about n^1.2, bfs /
  max-degree / tree-first about n^1.9, so the n^2 prediction is essentially attained;
  (ii) the *work* is worse than the node count: cofactor-cache entries (and time and memory) grow
  like n x reachable because every forget re-traverses the whole DAG twice; that, not the node
  cap, limited the sizes.
- **H-XOR3** would be falsified by an order with polynomial growth on 3-XOR with m = n. The best
  orders (min-degree, min-fill, greedy_min) are 1-2 orders of magnitude better than natural and
  their curves are noisy; they still accelerate and are better fit by an exponential, but the
  evidence for them is weaker than for natural / random orders (short range, 3 instances per size).
  Not contradicted; not as solid as the lead's preliminary natural-order numbers suggest.
- **H-PHP** is confirmed as stated in h. What contradicts a careless reading: measured against the
  number of variables or the input length, the best orders are 2^Theta(sqrt n), not 2^Theta(n).
  A polynomial-in-h order would falsify it; local search over orders found 23-39% better orders
  than hole-major for h <= 6 with the same growth pattern.
- **H-3CNF** would be falsified by a density / order with polynomial growth. None found; the
  smallest fitted rate is about 0.2 bits per variable (density 2.0, heuristic orders).
- **H-2SAT** (open question in the brief). Found: a clear P-class failure for *fixed standard
  orders* on 2-CNF over random regular graphs (including min-degree and min-fill), and
  order-specific exponential blockers that are 2-CNF / Horn. Not found: a 2-CNF family that is
  exponential under *every* order tried - the DAG-aware greedy order stays near-linear on all of
  them. This contradicts the tacit expectation that a good bucket-elimination order is a
  small-induced-width order: here small induced width is the worst choice. For Horn see sec. 7.
- **H-SUBSUME**: the mechanism is right, the count is 2^(k-1) + 2, not 2^k + O(1).
- **"A semantic canonical form would fix it"** (the question behind E7): contradicted for PHP,
  3-XOR and random 3-CNF - their nodes are already almost all distinct functions, and adding exact
  subset subsumption (E8) leaves their growth rates unchanged.

## 12. Caveats

1. Everything is finite and empirical. "Exponential", "polynomial", "rate" and "exponent" describe
   least-squares fits over the stated ranges and can be wrong asymptotically in either direction.
2. Machine load: wall-clock caps on a host at load 300-550 mean 1-6 CPU-seconds per run. All CAP
   outcomes in this study are resource caps under those conditions; `cap_reason` is `time` in the
   overwhelming majority of cases and `nodes` (the 400000-node cap) in very few. Largest completed
   sizes are therefore smaller than the brief anticipated and not exactly reproducible; allocation
   counts of completed runs are.
3. Fits use only sizes at which all runs of a series completed; with 2-4 instances per size the
   fitted rates of irregular series (3-XOR and 3-CNF under heuristic orders, 2-CNF under bfs) carry
   visible noise - compare the "tail" columns before trusting a single number.
4. `greedy_min` / `greedy_max` evaluate a random sample of 12 candidates per step once more than 24
   variables remain; they are not the exact greedy orders, and their construction time (several
   chunks) is not part of the measured run.
5. Local search and hill-climbing give upper bounds on the best order and lower bounds on the worst
   order only. "Minimum over all orders tried" is not the minimum over all orders except for
   PHP(3,2), PHP(4,2), K4 and W4, where enumeration was exhaustive.
6. Expected answers for random 3-CNF with n > 20 come from my own DPLL, not from the project oracle.
   Its SAT answers carry a checked witness; its UNSAT answers rest on the correctness of a 100-line
   complete search that agrees with the exhaustive oracle on every instance with n <= 20 in E0/E4.
7. The candidate returns no witness; "SAT" in the tables means "root == 1" and was always compared
   with an independently justified answer (0 disagreements in every experiment).
8. Peak reachable size was sampled adaptively (`reach_exact` in the JSON says when every step was
   sampled); for the larger runs it is a lower bound on the true peak.
9. The first runs of E2 and E3 were made with one retry of load-induced time caps and with
   non-resumable greedy orders; the supplements E2b / E3b (resumable greedy) and the HOLES pass
   are merged by `analyze.py` (a completed record wins over a capped one for the same run).
10. E8 is a stretch item: one added rewrite rule, validated on small formulas only; no claim is made
   about other repairs.

## 13. Reproduction

All commands are run from `work/alg001/fable/dag_analysis/` with Python 3.12 (standard library only).

```
python3 run_experiments.py E0                 # sanity (capped subclass == candidate, verifiers == oracle)
E1_PART=grid python3 run_experiments.py E1    # Tseitin grid            -> results/E1.json
E1_PART=adv  python3 run_experiments.py E1 --tag adv   # exhaustive / sampled / designed / hill-climb -> results/E1.adv.json
python3 run_experiments.py E2                 # XOR systems             -> results/E2.json
python3 run_experiments.py E2b                # + resumable greedy orders -> results/E2b.json
python3 run_experiments.py E3 E3b             # PHP (grid, 200 random, exhaustive, local search)
python3 run_experiments.py E4                 # random 3-CNF
python3 run_experiments.py E5                 # 2-SAT / Horn hunt (E5_ONLY=family,... E5_MATCH=substr to split)
python3 run_experiments.py E6                 # G_k exact counts
python3 run_experiments.py E7 E7b             # semantic census, support-multiplicity census
python3 run_experiments.py E8                 # repaired subclass: validation + reruns of E6/E3/E4
python3 run_experiments.py HOLES E1 E2 E4 E5  # re-run time caps that were caused by load
python3 analyze.py && python3 make_report.py  # results/tables.md, results/summary.json, REPORT.md
python3 run_experiments.py E4 --quick         # any experiment: tiny smoke test -> results/quick/
```

Options: `--workers K`, `--tag T` (write `results/<EXP>.<T>.json`; `analyze.py` merges all files of an
experiment). Caps are constants at the top of `harness.py`. On an idle machine the same commands
reach larger sizes; completed-run node counts are identical.

## 14. Files

- `families.py` - instance generators (Tseitin on regular / torus / complete / named graphs, XOR
  systems, PHP, random k-CNF, G_k, 2-CNF and Horn families).
- `orders.py` - elimination orders. `verify.py` - independent decision procedures.
- `harness.py` - capped wrapper around the unchanged candidate, greedy DAG-aware orders, truth
  tables, process scheduler. `repaired_dag.py` - E8 subclass.
- `run_experiments.py` - experiments E0..E8 (+ supplements E2b, E3b, E5b, E7b, HOLES).
- `analyze.py` - fits and tables; `make_report.py` + `report_text.py` - this report.
- `results/E*.json` - raw records (one JSON per experiment / part), `results/tables.md` - every
  table, `results/summary.json` - every fitted number, `results/quick/` - smoke-test outputs.
- `explore/` - throw-away calibration scripts used while designing the grids (not part of the
  results).
