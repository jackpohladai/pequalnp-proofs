"""Independent decision procedures used ONLY to obtain expected answers.

None of these import the candidate.  Every SAT answer returned here comes with a
witness that has been checked against the original clause list (check_model);
every UNSAT answer is produced by a sound and complete method for its class:
  gf2_solve       Gaussian elimination over GF(2) (XOR systems / Tseitin)
  component_parity  Tseitin: SAT iff every connected component has even charge
  twosat          implication-graph SCC (Kosaraju, iterative)
  horn_sat        unit propagation to the least model
  dpll            complete DPLL with unit propagation (may give UNKNOWN on deadline)
  php             pigeonhole principle (p > h  =>  UNSAT)
"""
import time


def check_model(clauses, assignment):
    """assignment: list[bool] indexed by var-1.  True iff every clause is satisfied."""
    for c in clauses:
        ok = False
        for l in c:
            if assignment[abs(l) - 1] == (l > 0):
                ok = True
                break
        if not ok:
            return False
    return True


# ---------------------------------------------------------------- GF(2) ----
def gf2_solve(n, eqs):
    """eqs: iterable of (vars, rhs).  Returns (consistent, rank, solution|None).
    Rows are ints: bit v (1..n) = coefficient of variable v, bit 0 = rhs."""
    pivots = {}                       # pivot bit -> row
    for vs, rhs in eqs:
        row = rhs & 1
        for v in vs:
            row ^= 1 << v             # a variable repeated twice cancels
        while row >> 1:
            p = row.bit_length() - 1
            if p in pivots:
                row ^= pivots[p]
            else:
                pivots[p] = row
                break
        else:
            if row & 1:
                return False, len(pivots), None
    sol = [0] * (n + 1)
    for p in sorted(pivots):          # increasing pivot: lower variables already fixed
        row = pivots[p]
        val = row & 1
        rest = (row >> 1) & ((1 << (p - 1)) - 1)
        v = 1
        while rest:
            if rest & 1:
                val ^= sol[v]
            rest >>= 1
            v += 1
        sol[p] = val
    return True, len(pivots), [bool(x) for x in sol[1:]]


def component_parity(nv, edges, charges):
    """Tseitin criterion: SAT iff each connected component has even total charge."""
    parent = list(range(nv))

    def find(a):
        while parent[a] != a:
            parent[a] = parent[parent[a]]
            a = parent[a]
        return a
    for a, b in edges:
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[ra] = rb
    tot = {}
    for v in range(nv):
        r = find(v)
        tot[r] = tot.get(r, 0) ^ (charges[v] & 1)
    return 'SAT' if not any(tot.values()) else 'UNSAT'


# ---------------------------------------------------------------- 2-SAT ----
def twosat(n, clauses):
    """Returns ('SAT', assignment) or ('UNSAT', None) for clauses of width <= 2."""
    for c in clauses:
        if len(c) == 0:
            return 'UNSAT', None
        if len(c) > 2:
            raise ValueError('not a 2-CNF')

    def idx(l):                        # literal -> node
        return 2 * (abs(l) - 1) + (0 if l > 0 else 1)
    N = 2 * n
    g = [[] for _ in range(N)]
    gr = [[] for _ in range(N)]
    for c in clauses:
        a, b = (c[0], c[0]) if len(c) == 1 else (c[0], c[1])
        for x, y in ((-a, b), (-b, a)):          # -a -> b, -b -> a
            g[idx(x)].append(idx(y))
            gr[idx(y)].append(idx(x))
    seen = [False] * N
    post = []
    for s in range(N):
        if seen[s]:
            continue
        seen[s] = True
        stack = [(s, 0)]
        while stack:
            v, i = stack.pop()
            if i < len(g[v]):
                stack.append((v, i + 1))
                w = g[v][i]
                if not seen[w]:
                    seen[w] = True
                    stack.append((w, 0))
            else:
                post.append(v)
    comp = [-1] * N
    k = 0
    for s in reversed(post):
        if comp[s] != -1:
            continue
        comp[s] = k
        stack = [s]
        while stack:
            v = stack.pop()
            for w in gr[v]:
                if comp[w] == -1:
                    comp[w] = k
                    stack.append(w)
        k += 1
    assignment = []
    for v in range(n):
        if comp[2 * v] == comp[2 * v + 1]:
            return 'UNSAT', None
        # Kosaraju numbers components in topological order of the condensation;
        # a literal is true iff its component comes later than its negation's.
        assignment.append(comp[2 * v] > comp[2 * v + 1])
    if not check_model(clauses, assignment):
        raise AssertionError('2-SAT witness failed verification')
    return 'SAT', assignment


# ----------------------------------------------------------------- Horn ----
def horn_sat(n, clauses):
    """Least-model unit propagation.  Requires <= 1 positive literal per clause."""
    true = [False] * (n + 1)
    changed = True
    cl = [(tuple(l for l in c if l > 0), tuple(-l for l in c if l < 0)) for c in clauses]
    for pos, neg in cl:
        if len(set(pos)) > 1:
            raise ValueError('not Horn')
    while changed:
        changed = False
        for pos, neg in cl:
            if all(true[v] for v in neg):
                if not pos:
                    return 'UNSAT', None
                if not true[pos[0]]:
                    true[pos[0]] = True
                    changed = True
    assignment = true[1:]
    if not check_model(clauses, assignment):
        raise AssertionError('Horn witness failed verification')
    return 'SAT', assignment


# ----------------------------------------------------------------- DPLL ----
def dpll(n, clauses, time_limit=20.0):
    """Complete DPLL (unit propagation, most-frequent-variable branching).
    Returns ('SAT', assignment) / ('UNSAT', None) / ('UNKNOWN', None) on deadline."""
    deadline = time.perf_counter() + time_limit
    cls = []
    for c in clauses:
        s = set(c)
        if any(-l in s for l in s):
            continue
        cls.append(tuple(s))
    occ = {}
    for i, c in enumerate(cls):
        for l in c:
            occ.setdefault(l, []).append(i)
    val = [None] * (n + 1)
    trail = []
    counter = [0]

    class Deadline(Exception):
        pass

    def value(l):
        v = val[abs(l)]
        return None if v is None else (v == (l > 0))

    def assign(l):
        """Assign literal l true and propagate.  Returns False on conflict."""
        queue = [l]
        while queue:
            x = queue.pop()
            cur = value(x)
            if cur is True:
                continue
            if cur is False:
                return False
            val[abs(x)] = x > 0
            trail.append(abs(x))
            for ci in occ.get(-x, ()):
                unassigned = None
                count = 0
                sat = False
                for y in cls[ci]:
                    vy = value(y)
                    if vy is True:
                        sat = True
                        break
                    if vy is None:
                        unassigned = y
                        count += 1
                if sat:
                    continue
                if count == 0:
                    return False
                if count == 1:
                    queue.append(unassigned)
        return True

    def undo(mark):
        while len(trail) > mark:
            val[trail.pop()] = None

    def solve():
        counter[0] += 1
        if counter[0] % 256 == 0 and time.perf_counter() > deadline:
            raise Deadline()
        best, score = None, {}
        for c in cls:
            sat = False
            free = []
            for y in c:
                vy = value(y)
                if vy is True:
                    sat = True
                    break
                if vy is None:
                    free.append(y)
            if sat:
                continue
            w = 4 if len(free) == 2 else 1
            for y in free:
                score[abs(y)] = score.get(abs(y), 0) + w
        if not score:
            return True
        best = max(score, key=lambda v: (score[v], -v))
        for lit in (best, -best):
            mark = len(trail)
            if assign(lit) and solve():
                return True
            undo(mark)
        return False

    import sys
    sys.setrecursionlimit(max(sys.getrecursionlimit(), 10000))
    try:
        if any(len(c) == 0 for c in clauses):
            return 'UNSAT', None
        for c in cls:
            if len(c) == 1 and not assign(c[0]):
                return 'UNSAT', None
        if not solve():
            return 'UNSAT', None
    except Deadline:
        return 'UNKNOWN', None
    assignment = [bool(v) for v in val[1:]]
    if not check_model(clauses, assignment):
        raise AssertionError('DPLL witness failed verification')
    return 'SAT', assignment
