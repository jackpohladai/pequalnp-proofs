"""Deterministic variable elimination orders (standard library only).

Every function returns a permutation of 1..n.  The greedy orders work on the
primal graph (variables adjacent iff they share a clause) stored as Python-int
bitsets and update it exactly as bucket elimination does: when v is eliminated
its remaining neighbours become a clique.  Ties are broken by smallest variable
index, so each order is a pure function of (n, clauses) (plus a seed for shuffles).
"""
import random
import time


class OrderTimeout(Exception):
    pass


def primal_bitsets(n, clauses):
    adj = [0] * (n + 1)
    for c in clauses:
        mask = 0
        for l in c:
            mask |= 1 << abs(l)
        for l in c:
            adj[abs(l)] |= mask
    for v in range(1, n + 1):
        adj[v] &= ~(1 << v)
    return adj


def _bits(mask):
    out = []
    while mask:
        low = mask & -mask
        out.append(low.bit_length() - 1)
        mask ^= low
    return out


def natural(n, clauses=None):
    return list(range(1, n + 1))


def reverse(n, clauses=None):
    return list(range(n, 0, -1))


def shuffle(n, seed):
    order = list(range(1, n + 1))
    random.Random(seed).shuffle(order)
    return order


def _eliminate(adj, v):
    nb = adj[v]
    vbit = 1 << v
    m = nb
    while m:
        low = m & -m
        u = low.bit_length() - 1
        adj[u] = (adj[u] | nb) & ~(low | vbit)
        m ^= low
    adj[v] = 0
    return nb


def min_degree(n, clauses, deadline=None):
    adj = primal_bitsets(n, clauses)
    alive = set(range(1, n + 1))
    order = []
    while alive:
        if deadline is not None and time.perf_counter() > deadline:
            raise OrderTimeout('min_degree')
        v = min(alive, key=lambda x: (adj[x].bit_count(), x))
        _eliminate(adj, v)
        alive.discard(v)
        order.append(v)
    return order


def max_degree(n, clauses, deadline=None):
    adj = primal_bitsets(n, clauses)
    alive = set(range(1, n + 1))
    order = []
    while alive:
        if deadline is not None and time.perf_counter() > deadline:
            raise OrderTimeout('max_degree')
        v = min(alive, key=lambda x: (-adj[x].bit_count(), x))
        _eliminate(adj, v)
        alive.discard(v)
        order.append(v)
    return order


def _fill(adj, v):
    nb = adj[v]
    deg = nb.bit_count()
    if deg < 2:
        return 0
    present = 0
    m = nb
    while m:
        low = m & -m
        present += (adj[low.bit_length() - 1] & nb).bit_count()
        m ^= low
    return deg * (deg - 1) // 2 - present // 2


def min_fill(n, clauses, deadline=None):
    """Greedy min-fill, ties -> smallest index.  Fill values are cached and only
    recomputed for vertices within distance two of the eliminated vertex."""
    adj = primal_bitsets(n, clauses)
    alive = set(range(1, n + 1))
    fill = {v: _fill(adj, v) for v in alive}
    order = []
    while alive:
        if deadline is not None and time.perf_counter() > deadline:
            raise OrderTimeout('min_fill')
        v = min(alive, key=lambda x: (fill[x], x))
        nb = _eliminate(adj, v)
        alive.discard(v)
        order.append(v)
        del fill[v]
        dirty = nb
        for u in _bits(nb):
            dirty |= adj[u]
        for u in _bits(dirty):
            if u in alive:
                fill[u] = _fill(adj, u)
    return order


def bfs(n, clauses, start=1):
    """Breadth-first order on the primal graph from `start`, neighbours in increasing
    index; restarts from the smallest unvisited variable for further components."""
    adj = primal_bitsets(n, clauses)
    seen = [False] * (n + 1)
    order = []
    for s in [start] + list(range(1, n + 1)):
        if s < 1 or s > n or seen[s]:
            continue
        seen[s] = True
        queue = [s]
        head = 0
        while head < len(queue):
            v = queue[head]
            head += 1
            order.append(v)
            for u in _bits(adj[v]):
                if not seen[u]:
                    seen[u] = True
                    queue.append(u)
    return order


def dfs(n, clauses, start=1):
    """Depth-first preorder on the primal graph (neighbours in increasing index;
    restarts from the smallest unvisited variable).  A LIFO frontier: a variable is
    eliminated soon after it first becomes adjacent to the eliminated region."""
    adj = primal_bitsets(n, clauses)
    seen = [False] * (n + 1)
    order = []
    for s0 in [start] + list(range(1, n + 1)):
        if s0 < 1 or s0 > n or seen[s0]:
            continue
        stack = [s0]
        while stack:
            v = stack.pop()
            if seen[v]:
                continue
            seen[v] = True
            order.append(v)
            for u in reversed(_bits(adj[v])):
                if not seen[u]:
                    stack.append(u)
    return order


def scc_topo(n, clauses, reverse=False):
    """2-CNF only: variables sorted by the position of their POSITIVE literal's
    strongly connected component in a topological order of the implication graph
    (the order a 2-SAT algorithm reasons in); ties -> smallest index.
    reverse=True gives the opposite direction (sinks of the implication graph first)."""
    def idx(l):
        return 2 * (abs(l) - 1) + (0 if l > 0 else 1)
    N = 2 * n
    g = [[] for _ in range(N)]
    gr = [[] for _ in range(N)]
    for c in clauses:
        if len(c) == 0:
            continue
        if len(c) > 2:
            raise ValueError('scc_topo needs a 2-CNF')
        a, b = (c[0], c[0]) if len(c) == 1 else (c[0], c[1])
        for x, y in ((-a, b), (-b, a)):
            g[idx(x)].append(idx(y))
            gr[idx(y)].append(idx(x))
    seen = [False] * N
    post = []
    for s0 in range(N):
        if seen[s0]:
            continue
        seen[s0] = True
        stack = [(s0, 0)]
        while stack:
            v, i = stack.pop()
            if i < len(g[v]):
                stack.append((v, i + 1))
                w = g[v][i]
                if not seen[w]:
                    seen[w] = True
                    stack.append((w, 0))
            else:
                post.append(v)
    comp = [-1] * N
    k = 0
    for s0 in reversed(post):
        if comp[s0] != -1:
            continue
        comp[s0] = k
        stack = [s0]
        while stack:
            v = stack.pop()
            for w in gr[v]:
                if comp[w] == -1:
                    comp[w] = k
                    stack.append(w)
        k += 1
    order = sorted(range(1, n + 1), key=lambda v: (comp[2 * (v - 1)], v))
    return order[::-1] if reverse else order


def tseitin_tree_first(nv, edges, mode='dfs'):
    """Designed adversarial order for Tseitin formulas (variable i+1 = edges[i]).
    First the edges of a spanning forest in discovery order, so that ONE component
    grows by one vertex per elimination (a caterpillar merge tree: the vertex that
    joined first sits under nv-1 later merges); then all chords, those between the
    earliest-joined (deepest) vertices first.  By the lead's own mechanism each
    chord then re-creates the nodes of every merge above its two endpoints."""
    adj = [[] for _ in range(nv)]
    for i, (a, b) in enumerate(edges, 1):
        adj[a].append((b, i))
        adj[b].append((a, i))
    joined = {}
    tree = []
    for root in range(nv):
        if root in joined:
            continue
        joined[root] = len(joined)
        frontier = [root]
        while frontier:
            v = frontier.pop() if mode == 'dfs' else frontier.pop(0)
            for w, i in adj[v]:
                if w not in joined:
                    joined[w] = len(joined)
                    tree.append(i)
                    frontier.append(w)
                    if mode == 'dfs':
                        frontier.append(v)      # come back to v after exploring w
                        break
    in_tree = set(tree)
    chords = [i for i in range(1, len(edges) + 1) if i not in in_tree]
    chords.sort(key=lambda i: (joined[edges[i - 1][0]] + joined[edges[i - 1][1]], i))
    return tree + chords


def php_pigeon_major(p, h):
    """All holes of pigeon 0, then pigeon 1, ... (equals the natural order)."""
    return [i * h + k + 1 for i in range(p) for k in range(h)]


def php_hole_major(p, h):
    """All pigeons of hole 0, then hole 1, ..."""
    return [i * h + k + 1 for k in range(h) for i in range(p)]


def induced_width(n, clauses, order):
    """Induced width of the primal graph along `order` (max clique size - 1 formed)."""
    adj = primal_bitsets(n, clauses)
    width = 0
    for v in order:
        width = max(width, adj[v].bit_count())
        _eliminate(adj, v)
    return width


def make_order(name, n, clauses, meta=None, deadline=None):
    """Order by name: natural, reverse, min_degree, min_fill, max_degree, bfs,
    shuffle<seed>, pigeon_major, hole_major, or an explicit list."""
    if isinstance(name, (list, tuple)):
        return list(name)
    if name == 'natural':
        return natural(n)
    if name == 'reverse':
        return reverse(n)
    if name == 'min_degree':
        return min_degree(n, clauses, deadline)
    if name == 'min_fill':
        return min_fill(n, clauses, deadline)
    if name == 'max_degree':
        return max_degree(n, clauses, deadline)
    if name == 'bfs':
        return bfs(n, clauses)
    if name == 'dfs':
        return dfs(n, clauses)
    if name == 'scc_topo':
        return scc_topo(n, clauses)
    if name == 'scc_topo_rev':
        return scc_topo(n, clauses, reverse=True)
    if name.startswith('shuffle'):
        return shuffle(n, int(name[len('shuffle'):]))
    if name == 'tree_first':
        return tseitin_tree_first(meta['nv'], [tuple(e) for e in meta['edges']], 'dfs')
    if name == 'tree_first_bfs':
        return tseitin_tree_first(meta['nv'], [tuple(e) for e in meta['edges']], 'bfs')
    if name == 'pigeon_major':
        return php_pigeon_major(meta['pigeons'], meta['holes'])
    if name == 'hole_major':
        return php_hole_major(meta['pigeons'], meta['holes'])
    raise ValueError('unknown order ' + str(name))
