import sys, random, json, time
sys.path.insert(0, '../../native-search'); sys.path.insert(0, '../scratch'); sys.path.insert(0, '../theory')
from residual_dag import DAG
from miniscope_dag import MiniDAG
from miniscope_dag_b import MiniDAGb
from h_probe import php
from tseitin_fragility import build
from compare_r0_r1 import W, G
def run(cls, cl, order, cap=400000, tcap=15.0):
    d = cls(); root = d.cnf(cl); t0 = time.time()
    for v in order:
        root = d.forget(root, v)
        if len(d.nodes) > cap or time.time() - t0 > tcap: return 'CAP', len(d.nodes)
    return ('SAT' if root == 1 else 'UNSAT'), len(d.nodes)
out = []
def rec(name, key, cl, order):
    row = dict(family=name, param=key, R0=run(DAG, cl, order), R1=run(MiniDAG, cl, order), R1b=run(MiniDAGb, cl, order))
    out.append(row); print(row, flush=True)
for k in (6, 10, 14):
    cl, o = W(k); rec('W_k', k, cl, o)
    cl, o = G(k); rec('G_k', k, cl, o)
for nv in (16, 24, 32, 40):
    for extra in (0, 1):
        n, cl = build(nv, 1000 + nv, extra); o = list(range(1, n + 1)); random.Random(nv).shuffle(o)
        rec(f'tseitin_cubic_redundant{extra}', n, cl, o)
for h in (5, 6, 7):
    n, cl, var = php(h + 1, h)
    rec('PHP_hole_major', h, cl, [var(i, k) for k in range(h) for i in range(h + 1)])
rng = random.Random(5)
for n in (20, 28, 32):
    cl = [[v * rng.choice((-1, 1)) for v in rng.sample(range(1, n + 1), 3)] for _ in range(round(4.26 * n))]
    rec('rand3cnf_4.26', n, cl, list(range(1, n + 1)))
json.dump(out, open('compare_three.json', 'w'), indent=1)
