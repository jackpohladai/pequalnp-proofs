"""Repair R1b: miniscoping only where it cannot lose R0's set-level coincidences.

forget(or(S), v)  = or(forget(c, v) for c in S)                       (exact distribution)
forget(and(S), v) = and(free, forget(dep0, v))  if exactly ONE child dep0 mentions v
                  = R0 behaviour otherwise: or(and(S)|v=0, and(S)|v=1) with the original
                    whole-conjunction cofactors, so duplicates against `free` still vanish and
                    J5 still extracts the common factor.
Exploratory: no polynomial bound is claimed."""
import sys, random, itertools
sys.path.insert(0, '../../native-search')
sys.setrecursionlimit(1000000)
from miniscope_dag import MiniDAG


class MiniDAGb(MiniDAG):
    def forget(self, node, var):
        if var not in self.support(node):
            return node
        key = (node, var)
        if key in self.forget_cache:
            return self.forget_cache[key]
        kind, data = self.nodes[node]
        if kind == 'lit':
            out = 1
        elif kind == 'or':
            out = self.junction('or', [self.forget(c, var) for c in data])
        else:
            dep = [c for c in data if var in self.support(c)]
            if len(dep) == 1:
                free = [c for c in data if c != dep[0]]
                out = self.junction('and', free + [self.forget(dep[0], var)])
            else:
                out = self.junction('or', [self.cofactor(node, var, False),
                                           self.cofactor(node, var, True)])
        self.forget_cache[key] = out
        return out


def check_random(trials=400, seed=77):
    rng = random.Random(seed); checked = 0
    for _ in range(trials):
        n = rng.randrange(1, 8); clauses = []
        for _ in range(rng.randrange(1, 16)):
            vs = rng.sample(range(1, n + 1), rng.randrange(1, min(4, n) + 1))
            clauses.append([v * rng.choice((-1, 1)) for v in vs])
        d = MiniDAGb(); root = d.cnf(clauses)
        order = list(range(1, n + 1)); rng.shuffle(order); gone = []
        for i in range(n + 1):
            keep = order[i:]
            for vals in itertools.product((False, True), repeat=len(keep)):
                a = dict(zip(keep, vals)); want = False
                for old in itertools.product((False, True), repeat=len(gone)):
                    full = a | dict(zip(gone, old))
                    if all(any(full[abs(l)] == (l > 0) for l in c) for c in clauses):
                        want = True; break
                assert d.evaluate(root, a) == want
                checked += 1
            if i < n:
                root = d.forget(root, order[i]); gone.append(order[i])
    return checked

if __name__ == '__main__':
    print('R1b exactness checks passed:', check_random())
