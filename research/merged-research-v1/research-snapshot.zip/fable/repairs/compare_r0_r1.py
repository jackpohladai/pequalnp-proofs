"""R0 (unchanged residual_dag) vs R1 (miniscoped forget) -- allocated nodes, same instances/orders.
Every run is capped at 20 s / 400k nodes; CAP is not a lower bound proof, just a censored run."""
import sys, time, random, json, itertools
sys.path.insert(0, '../../native-search'); sys.path.insert(0, '../scratch'); sys.path.insert(0, '../theory')
from residual_dag import DAG
from miniscope_dag import MiniDAG
from h_probe import tseitin, php, xor_clauses

def run(cls, clauses, order, cap=400000, tcap=20.0):
    d = cls(); root = d.cnf(clauses); t0 = time.time()
    for v in order:
        root = d.forget(root, v)
        if len(d.nodes) > cap or time.time() - t0 > tcap:
            return ('CAP', len(d.nodes))
    assert root in (0, 1)
    return ('SAT' if root else 'UNSAT', len(d.nodes))

def W(k):
    p = lambda i: 3 + i; q = lambda i: 3 + k + i
    cl = [(-1, 2), (1, 3)] + [(2, p(i), q(i)) for i in range(1, k + 1)]
    return cl, [1] + [p(i) for i in range(1, k + 1)] + [q(i) for i in range(1, k + 1)] + [2, 3]

def G(k):  # (x v a_i v b_i), (-x v c); order x, a_1..a_k, b_1..b_k, c
    x, c = 1, 2; a = lambda i: 2 + i; b = lambda i: 2 + k + i
    cl = [(x, a(i), b(i)) for i in range(1, k + 1)] + [(-x, c)]
    return cl, [x] + [a(i) for i in range(1, k + 1)] + [b(i) for i in range(1, k + 1)] + [c]

if __name__ == '__main__':
    out = {}
    def rec(name, key, r0, r1):
        out.setdefault(name, []).append(dict(param=key, R0=r0, R1=r1)); print(name, key, 'R0', r0, 'R1', r1, flush=True)

    for k in (2, 4, 6, 8, 10, 12, 14):
        cl, order = W(k); rec('W_k', k, run(DAG, cl, order), run(MiniDAG, cl, order))
    for k in (2, 4, 6, 8, 10, 12, 14):
        cl, order = G(k); rec('G_k', k, run(DAG, cl, order), run(MiniDAG, cl, order))
    for h in (3, 4, 5, 6, 7, 8):
        n, cl, var = php(h + 1, h)
        hole = [var(i, k) for k in range(h) for i in range(h + 1)]
        pig = [var(i, k) for i in range(h + 1) for k in range(h)]
        rec('PHP_hole_major', h, run(DAG, cl, hole), run(MiniDAG, cl, hole))
        rec('PHP_pigeon_major', h, run(DAG, cl, pig), run(MiniDAG, cl, pig))
    rng = random.Random(7)
    for nv in (16, 32, 64, 128):
        n, cl = tseitin(nv, rng)
        order = list(range(1, n + 1)); random.Random(nv).shuffle(order)
        rec('Tseitin_cubic_shuffle', n, run(DAG, cl, order), run(MiniDAG, cl, order))
    rng = random.Random(5)
    for n in (16, 20, 24, 28, 32, 36):
        cl = [[v * rng.choice((-1, 1)) for v in rng.sample(range(1, n + 1), 3)] for _ in range(round(4.26 * n))]
        order = list(range(1, n + 1))
        rec('rand3cnf_4.26_natural', n, run(DAG, cl, order), run(MiniDAG, cl, order))
    rng = random.Random(9)
    for n in (24, 40, 56, 72):
        sol = [rng.randrange(2) for _ in range(n + 1)]; cl = []
        for _ in range(n):
            vs = rng.sample(range(1, n + 1), 3); cl += xor_clauses(vs, sum(sol[v] for v in vs) % 2)
        rec('xor3_m=n_natural', n, run(DAG, cl, list(range(1, n + 1))), run(MiniDAG, cl, list(range(1, n + 1))))
    json.dump(out, open('compare_r0_r1.json', 'w'), indent=1)
