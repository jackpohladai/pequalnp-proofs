"""Repair R1 for native-search/residual_dag.py (subclass; the original file is untouched).

Miniscoped existential projection, using only exact identities:
    EXISTS v. (A or B)  =  (EXISTS v. A) or (EXISTS v. B)
    EXISTS v. (A and B) =  A and (EXISTS v. B)          if v does not occur in A
    EXISTS v. lit(v)    =  True
and Shannon expansion only for the conjuncts that really mention v.
Exploratory: no polynomial bound is claimed.
"""
import sys, random, itertools
sys.path.insert(0, '../../native-search')
sys.setrecursionlimit(1000000)
from residual_dag import DAG


class MiniDAG(DAG):
    def __init__(self):
        super().__init__()
        self.support_cache = {}
        self.forget_cache = {}

    def support(self, node):
        s = self.support_cache.get(node)
        if s is None:
            kind, data = self.nodes[node]
            if kind == 'const':
                s = frozenset()
            elif kind == 'lit':
                s = frozenset((abs(data),))
            else:
                s = frozenset().union(*(self.support(c) for c in data))
            self.support_cache[node] = s
        return s

    def forget(self, node, var):
        if var not in self.support(node):
            return node
        key = (node, var)
        if key in self.forget_cache:
            return self.forget_cache[key]
        kind, data = self.nodes[node]
        if kind == 'lit':
            out = 1
        elif kind == 'or':
            out = self.junction('or', [self.forget(c, var) for c in data])
        else:
            dep = [c for c in data if var in self.support(c)]
            free = [c for c in data if var not in self.support(c)]
            if len(dep) == 1:
                inner = self.forget(dep[0], var)
            else:
                inner = self.junction('or', [
                    self.junction('and', [self.cofactor(c, var, b) for c in dep])
                    for b in (False, True)])
            out = self.junction('and', free + [inner])
        self.forget_cache[key] = out
        return out


def check_random(trials=400, seed=2024):
    """Exactness at every elimination stage against brute force (independent of DAG.evaluate
    only in the sense that expected values come from the CNF itself)."""
    rng = random.Random(seed); checked = 0
    for _ in range(trials):
        n = rng.randrange(1, 8)
        clauses = []
        for _ in range(rng.randrange(1, 16)):
            vs = rng.sample(range(1, n + 1), rng.randrange(1, min(4, n) + 1))
            clauses.append([v * rng.choice((-1, 1)) for v in vs])
        d = MiniDAG(); root = d.cnf(clauses)
        order = list(range(1, n + 1)); rng.shuffle(order); gone = []
        for i in range(n + 1):
            keep = order[i:]
            for vals in itertools.product((False, True), repeat=len(keep)):
                a = dict(zip(keep, vals)); want = False
                for old in itertools.product((False, True), repeat=len(gone)):
                    full = a | dict(zip(gone, old))
                    if all(any(full[abs(l)] == (l > 0) for l in c) for c in clauses):
                        want = True; break
                assert d.evaluate(root, a) == want, (clauses, order, i, a)
                checked += 1
            if i < n:
                root = d.forget(root, order[i]); gone.append(order[i])
    return checked


if __name__ == '__main__':
    print('exactness checks passed:', check_random())
