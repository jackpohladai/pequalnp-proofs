"""Apply the island-stage integration to the CFPE engine source (exact, anchored edits).

Usage: python3 integrate_islands.py <engine_source.py> <output.py>

Every edit must match its anchor exactly once, otherwise nothing is written, so the script can
never half-apply. The engine alone remains a complete decision procedure; the island stage
(layers.island_stage) only adds exact polynomial-time decisions in front of it, and the final
verification of a SAT witness against the ORIGINAL clauses is unchanged.
"""
import sys

EDITS = [
    # 0. document the island stage in the module docstring
    ("Pipeline of ``solve(nvars, clauses, budget)``\n"
     "---------------------------------------------\n",
     "Island stage (added by the lead, ``layers.py`` next to this file; ``islands=False`` or a\n"
     "``debug_hook`` switches it off and runs the engine below alone)\n"
     "---------------------------------------------------------------------------------------\n"
     "Before step 0 the input is normalised and unit-propagated, split into connected\n"
     "components, and every component that is Horn / dual-Horn, 2-CNF, or a read-twice degree\n"
     "system (at-least-one / at-most-one / exactly-one / parity groups, each variable in at\n"
     "most two groups) is decided exactly in polynomial time: forward chaining, SCC, or a\n"
     "reduction to perfect matching solved by Edmonds' algorithm.  Additional UNSAT rules\n"
     "(``decided_by``): island:empty_clause, island:unit_conflict, island:horn, island:twosat,\n"
     "island:cardinality (the last only with a Tutte-Berge barrier that is re-verified\n"
     "independently of the matching code).  The engine then runs on the remaining clauses,\n"
     "whose variables are disjoint from the island variables; the final witness is the union\n"
     "and is verified against ALL original clauses exactly as before.  See theory/theory.md,\n"
     "Sections 5 and 6.\n\n"
     "Pipeline of ``solve(nvars, clauses, budget)``\n"
     "---------------------------------------------\n"),
    # 1. import the islands module (same directory as the candidate)
    ("from heapq import heapify, heappop, heappush\nimport time\n",
     "from heapq import heapify, heappop, heappush\nimport time\n\n"
     "# Exact polynomial islands: layers.py from THIS file's directory (loaded by path, so the\n"
     "# result does not depend on sys.path). Without it the engine alone is still a complete\n"
     "# decision procedure; `operations['islands_enabled']` records which one ran.\n"
     "try:\n"
     "    import importlib.util as _ilu\n"
     "    import os as _os\n"
     "    _spec = _ilu.spec_from_file_location(\n"
     "        \"fable_layers\", _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), \"layers.py\"))\n"
     "    _layers = _ilu.module_from_spec(_spec)\n"
     "    _spec.loader.exec_module(_layers)\n"
     "except Exception:\n"
     "    _layers = None\n"),
    # 2. keyword to switch the island stage off (engine-only runs, invariant tests)
    ("def solve(nvars, clauses, budget=None, *, node_cap=DEFAULT_NODE_CAP, time_limit=None,\n"
     "          strategy=None, debug_hook=None):",
     "def solve(nvars, clauses, budget=None, *, node_cap=DEFAULT_NODE_CAP, time_limit=None,\n"
     "          strategy=None, debug_hook=None, islands=True):"),
    # 3. initialise the new bookkeeping
    ("    status = \"UNKNOWN\"\n    reason = None\n    assignment = None\n    try:\n        try:\n",
     "    status = \"UNKNOWN\"\n    reason = None\n    assignment = None\n"
     "    island_values = {}\n    island_ran = False\n    work = clauses\n"
     "    try:\n        try:\n"),
    # 4. run the island stage in front of the engine (never with a debug hook: the hook
    #    instruments the engine on the full formula)
    ("            pre = _preprocess(nvars, clauses, meter)\n",
     "            info[\"islands_enabled\"] = bool(islands and debug_hook is None\n"
     "                                           and _layers is not None)\n"
     "            if info[\"islands_enabled\"]:\n"
     "                for c in clauses:\n"
     "                    for l in c:\n"
     "                        if type(l) is not int or l == 0 or l > nvars or l < -nvars:\n"
     "                            raise ValueError(\"invalid literal %r for nvars=%r\" % (l, nvars))\n"
     "                verdict, work, island_values, ilog = _layers.island_stage(\n"
     "                    nvars, clauses, meter.tick)\n"
     "                island_ran = True\n"
     "                info[\"island_units\"] = ilog[\"units\"]\n"
     "                info[\"island_components\"] = ilog[\"components\"]\n"
     "                info[\"islands\"] = dict(ilog[\"islands\"])\n"
     "                if verdict == \"UNSAT\":\n"
     "                    why = ilog[\"unsat\"]\n"
     "                    info[\"island_certificate\"] = why\n"
     "                    raise _Unsat(\"island:\" + (why if isinstance(why, str) else why[\"layer\"]))\n"
     "            pre = _preprocess(nvars, work, meter)\n"),
    # 5. label runs decided entirely by the islands
    ("                values = {}\n                info[\"decided_by\"] = \"affine_sat\"\n",
     "                values = {}\n"
     "                info[\"decided_by\"] = (\"islands_sat\" if island_ran and not pre.trail\n"
     "                                      and not pre.rowrecs else \"affine_sat\")\n"),
    # 6. merge the island values into the witness BEFORE the final verification against the
    #    original clauses (the island variables are disjoint from the engine's variables)
    ("            meter.tick(\"witness_step\", len(orig))\n"
     "            # (I4) full scan of the ORIGINAL clauses",
     "            meter.tick(\"witness_step\", len(orig))\n"
     "            for v, b in island_values.items():\n"
     "                assignment[v - 1] = bool(b)\n"
     "            meter.tick(\"witness_step\", len(island_values))\n"
     "            # (I4) full scan of the ORIGINAL clauses"),
]


def integrate(src):
    if "_layers.island_stage" in src:
        raise SystemExit("already integrated")
    for old, new in EDITS:
        if src.count(old) != 1:
            raise SystemExit("anchor not found exactly once:\n" + old)
        src = src.replace(old, new)
    return src


if __name__ == "__main__":
    out = integrate(open(sys.argv[1]).read())
    with open(sys.argv[2], "w") as fh:
        fh.write(out)
    print("integrated ->", sys.argv[2])
