# Brief D -- independent adversarial review of the Fable deliverables

Read `COMMON.md` in this directory first. Writable: `work/alg001/fable/review/` only
(do NOT edit the files you review; report defects instead).

You did not write any of the material below. Your job is to REFUTE it. Default to
"not established" whenever a claim is not backed by a proof you checked line by line or by
a computation you re-ran yourself. Be specific: file, line, counterexample, command.

## Material under review (all under `work/alg001/fable/`)
1. `theory/theory.md` -- Theorem A (exponential allocation of `native-search/residual_dag.py`
   on W_k at induced width 2), Proposition 4.1 (Normalisation Lemma ⟺ SAT ∈ P), the Tseitin
   mechanism (explicitly labelled empirical), CFPE complexity statements, and the status labels.
   Scripts: `theory/width2_counterexample.py`, `theory/verify_theoremA_invariant.py`.
2. `repairs/miniscope_dag.py`, `repairs/compare_r0_r1.py` (+ json).
3. `dag_analysis/` (experiments on the unchanged DAG candidate; REPORT.md + results).
4. `candidate.py` (CFPE solver), `tests/`, `experiments/` (corpus report, scaling, report).
5. `lean/` (explicit total SAT decider; REPORT.md, compile/axiom logs).
6. `layers.py` (exact islands: Horn, 2-SAT, and the read-twice cardinality layer solved by
   Edmonds' blossom algorithm with a re-verified Tutte-Berge barrier; `island_stage` front end),
   `tests/test_layers.py`, `tests/test_island_stage.py`, `integrate_islands.py` (the anchored
   edits that put the island stage in front of the engine inside `candidate.py`), and
   Section 6 / Theorem M of `theory/theory.md`.
7. Lead-written Lean files `lean/L_alg001_fable_engine.lean`, `lean/L_alg001_fable_matching.lean`.
8. `review_lead/` (the lead's audit of the other workers' candidates and comparison runs).
9. `findings.txt`, `result.json` if present (the lead's draft conclusions).

## Staging (important)
Two other subagents are still producing material. Work in two stages.
- STAGE 1 (do now): R1, R2, R3 (for theory.md and the preliminary findings.txt), R4b restricted
  to `layers.py` and `layers.island_stage` (NOT `candidate.py`), R6, and R7 if time permits.
- STAGE 2 (only if the file `work/alg001/fable/READY_FOR_STAGE2.txt` exists when you finish
  stage 1): R4, the `candidate.solve` part of R4b, R5, and `dag_analysis/`. If the file does not
  exist, do NOT review those parts; say so in your final answer and stop. The lead will resume
  you later.
Environment notes: the machine is heavily loaded (a Lean compile that takes 100 s unloaded has
taken 15 minutes); budget your Lean re-compiles and run them in the background while you do other
work. Inside `work/alg001/fable/`, shell redirections (`>`, `>>`), `cp`, `rm`, `touch`, `mkdir`
may fail with "operation not permitted"; the Write tool and Python file I/O work, so create
files with those and do not try to work around the restriction in any other way. Subagents
cannot write `.md` report files here: write your report as `review/REVIEW.txt` and your data as
JSON, and put everything important in your final answer.

## Required checks
R1 Theorem A. Re-derive the proof against the actual code of
   `work/alg001/native-search/residual_dag.py` (read `junction`, `cofactor`, `forget` line by
   line; is the J1..J6 model in Section 0 faithful, including the ORDER of the rules and the
   early returns?). Check facts F1-F3. Re-run both scripts. Independently recompute the induced
   width of the order and the treewidth claim. Try to break the theorem: other k, clause/literal
   order permutations, variable renumbering (does the closed form 2^(k+1)+7k+7 survive?).
R2 Proposition 4.1. Attack both directions: is NL stated precisely enough? Is the Σ₂ᵖ
   normaliser really polynomial in |D| under P = NP? Is the circuit-size argument for
   g_i correct for the project's encoding? Is anything circular? State any gap exactly.
R3 Status labels: find every sentence in theory.md / findings.txt / result.json / the REPORTs
   that claims more than its evidence supports (e.g. "polynomial" for something only measured,
   an "all orders" claim backed by a sample, a literature citation used as support).
R4 CFPE soundness. Write YOUR OWN brute-force oracle and fuzz `candidate.py` hard
   (>= 30000 random CNFs, n <= 11, including XOR-rich, equivalence-rich, unit-rich, duplicate and
   tautological clauses, empty clause, unused variables, nvars = 0, and tiny adversarial hand
   cases). Any wrong SAT/UNSAT answer or unverified witness is a critical finding: minimise it
   and save it as JSON. Also check: does a too-small budget ever yield a definite answer that is
   wrong? Does UNKNOWN ever get reported as UNSAT? Re-run the 594-case corpus through
   `work/alg001/adversarial/run_candidate.py --keep-going` writing the report into your directory.
   Review the XOR detection and the "XOR-only variable projection" logic by reading the code.
R4b Islands. Read `layers.py` line by line. Attack the cardinality layer specifically: try to
   construct a component for which it returns a WRONG answer (wrong UNSAT is critical). Ideas:
   groups sharing two or more variables; a positive clause that is a conflict clique inside a
   larger clique; variables in exactly one group; polarity-flipped variables; duplicated or
   subsumed clauses; components that are also 2-CNF or Horn; unit clauses (the layer must refuse
   them); a Tutte barrier that does not verify. Check Theorem M (a)-(e) step by step, in
   particular the copies/dummies gadget and the doubling lemma, and check that `verify_barrier`
   really is independent of the matching code. Fuzz `layers.island_stage` and the integrated
   `candidate.solve` (islands on AND `islands=False`) with your own generators biased towards
   cardinality structure, >= 30000 cases total against your own brute force.
R5 Re-run a sample of the scaling experiments (at least PHP natural + shuffled, random 3-CNF
   at 4.26, 3-XOR, Tseitin) and compare with the reported numbers. Flag irreproducible ones.
R6 Lean. With `source $ROOT/work/lean-local-env.sh; cd $ROOT/work/pequalnp-sparse/lean;
   lake env lean <file>` recompile every `.lean` file in `fable/lean/`; grep for `sorry`,
   `axiom`, `native_decide`, `unsafe`, `implemented_by`, `Classical` in definitions of the
   executable functions; confirm the `#print axioms` output yourself; check that the theorem
   statements say what the REPORT claims (in particular: the decider is exponential-time; the
   classical triviality of the bare existence statement is acknowledged). Never run `lake build`.
R7 (secondary, time permitting) Cross-candidate soundness audit: after skimming each file for
   anything unsafe (file writes outside its dir, network, subprocess), import read-only and fuzz
   `work/alg001/hydrogen/candidate.py`, `work/alg001/neon/candidate.py` and, if it exposes a
   solve function, `work/alg001/native-search/hybrid_solver.py` with the same oracle
   (10000 cases each, 20 s per batch). Report any definite wrong answer with a minimal instance.
   UNKNOWN answers are not errors.

## Deliverables (under `work/alg001/fable/review/`)
`REVIEW.md` (findings ordered by severity: CRITICAL / MAJOR / MINOR / OK, each with evidence
and exact reproduction), your fuzz scripts, any counterexample JSON, and the re-run logs.

Final answer (plain text, read by the lead): the list of findings by severity with evidence,
what you re-ran and whether it reproduced, which claims you consider established, which not.
