# Brief C -- Lean: an explicit, total, axiom-free SAT decider on bit strings

Read `COMMON.md` in this directory first. Writable: `work/alg001/fable/lean/` only.

## Environment
```
source $ROOT/work/lean-local-env.sh
cd $ROOT/work/pequalnp-sparse/lean          # Lean 4.36.0 + pinned Mathlib; DO NOT edit this repo
lake env lean $ROOT/work/alg001/fable/lean/<File>.lean      # compile a standalone file
```
Do not run `lake build`, do not add files to the repo, do not touch `.lake`. Other workers may
hold the build lock; if `lake env` blocks, wait and retry. Built modules you may import:
`PEqualNP.Defs` (Base.lean, Search.lean, TimeAlt.lean ...), `Mathlib.Tactic`,
`PEqualNP.Library.SearchHelpers.Weight` (defines `restrict`),
`PEqualNP.Outside.L_alg001_residual` (source: `$ROOT/work/alg001/formal/L_alg001_residual.lean`;
it defines `budgetSearch : ℕ → CNF → Option Bool`, proves `budgetSearch_correct`,
`budgetSearch_true/false`, `branch_correct`, and declares the structures
`CorrectBitDecider` and `DegreeBound`). Read that file and
`PEqualNP/Defs/Search.lean` (definitions of `CNF`, `Satisfiable`, `encodeLiteral`,
`encodeClause`, `encodeCNF`, `SAT`) before writing anything.

Forbidden: `sorry`, new `axiom`s, `native_decide`, `unsafe`, `implemented_by`, weakening any
standard definition. Every claimed theorem must compile; run `#print axioms` on each main
result and record the output.

## Why this matters (and its honest scope)
`formal/findings.txt` lists as missing: "Total SAT decider on encoded binary inputs, including
malformed-input handling" (`CorrectBitDecider` is not inhabited). Note that the bare statement
`∃ run, ∀ x, x ∈ SAT ↔ run x = true` is classically trivial (`Classical.dec`), so the real
content is an EXPLICIT executable function whose definition uses no classical axiom, plus its
correctness proof. This is decidability with an exponential procedure -- NOT a complexity
result, and must be labelled as such.

## Targets (namespace `PEqualNP.Outside.L_alg001_fable`; file `L_alg001_fable_decider.lean`)
1. Completeness of the existing search:
   `litCount (φ : CNF) : ℕ := (φ.map List.length).sum`  (or an equivalent measure) and
   `theorem budgetSearch_isSome (φ) (fuel) (h : litCount φ ≤ fuel) : (budgetSearch fuel φ).isSome`.
   Key lemma: if `φ = ((x, v) :: c) :: ψ` then `litCount (restrict x b φ) < litCount φ` for both
   `b` (the head clause is deleted or loses its head literal; `filter`/`map filter` never grow).
2. `def decideSat (φ : CNF) : Bool := budgetSearch (litCount φ) φ == some true` and
   `theorem decideSat_correct (φ) : Satisfiable φ ↔ decideSat φ = true`.
3. A decoder for the project's binary encoding (pairs of bits: `[true, d]` digit,
   `[false, true]` end of literal, `[false, false]` end of clause; a literal is its polarity
   digit, then `Nat.bits` of the variable LSB-first, then end-of-literal):
   `def decodeCNF : List Bool → Option CNF` with
   `theorem decodeCNF_encodeCNF (φ : CNF) : decodeCNF (encodeCNF φ) = some φ`.
   Design the decoder so this round trip is easy (e.g. a fold over the bit pairs with a small
   state, or structural recursion on a token list). You need `ofBits (Nat.bits n) = n` for your
   own `ofBits : List Bool → ℕ` (use `Nat.bits`, `Nat.bit`, `Nat.binaryRec` / `Nat.bits_append_bit`
   style lemmas; search Mathlib with `exact?`/grep in `.lake/packages/mathlib`).
   Exactness in the other direction is NOT needed because of the re-encoding check below.
4. `def satRun (x : List Bool) : Bool := match decodeCNF x with
      | some φ => (encodeCNF φ == x) && decideSat φ | none => false`
   `theorem satRun_correct (x : List Bool) : x ∈ SAT ↔ satRun x = true`
   `def satDecider : CorrectBitDecider := ⟨satRun, satRun_correct⟩`
   `#print axioms satRun` must NOT list `Classical.choice` (ideally no axioms at all): this is
   the machine-checkable evidence that the decider is an explicit program. Also add `#eval`
   checks on a few encodings (empty string -> true; `encodeCNF [[]]` -> false; a satisfiable and
   an unsatisfiable 2-variable formula; a malformed odd-length string -> false; a string with a
   non-canonical leading-zero digit -> false) and record the outputs.
5. Honest size statement: define the number of recursive calls of the search and prove an
   explicit bound such as `searchCalls fuel φ ≤ 2 ^ (fuel + 1)` (exponential; label it so).
6. (stretch, only after 1-5 compile) Pin the missing lemma formally:
   `theorem sat_mem_P_of_degreeBound (c : CorrectBitDecider) (d : ℕ) (h : DegreeBound c d) :
      SAT ∈ PEqualNP.Library.P`
   by turning the `TM2ComputableInTime` machine with `time n ≤ scale * n^d + scale` into a
   `TM2ComputableInPolyTime` (weaken the step bound through `TM2OutputsInTime`'s `steps_le_m`
   field; check the exact Mathlib structure fields in
   `.lake/packages/mathlib/Mathlib/Computability/TuringMachine/Computable.lean`).
   This is definitional glue (it does NOT prove SAT ∈ P); it makes "the missing lemma" a single
   Lean proposition: `Nonempty (DegreeBound satDecider 3)`.
7. One final summary theorem whose STATEMENT mentions only library/Defs constants (no auxiliary
   declarations from your file -- the project checker rejects statements that depend on
   new declarations), for example
   `theorem PEqualNP.Outside.L_alg001_fable_decider :
      ∃ search : ℕ → PEqualNP.Search.CNF → Option Bool, ... (the recurrence clauses exactly as in
      formal/statement.txt) ... ∧ (∀ φ, ∃ fuel, search fuel φ ≠ none)`
   i.e. the existing foundation statement strengthened by totality with an explicit fuel bound
   (`fuel = (φ.map List.length).sum` works). Put the exact statement text in
   `fable/lean/statement.txt`.

## Deliverables (under `work/alg001/fable/lean/`)
- `L_alg001_fable_decider.lean` (compiles with zero errors, zero `sorry`), optional
  `RunDecider.lean` with a `main` you execute via `lake env lean --run`.
- `compile.log` (full compiler output of the final file), `axioms.log` (all `#print axioms`
  outputs), `eval.log`, `statement.txt`, `SHA256SUMS`, and `REPORT.md` stating exactly which of
  targets 1-7 are proved, and anything that is not.
Work incrementally: get target 1-2 compiling first, save, then 3-4, etc. If a target resists
after serious effort, deliver the others fully proved and describe the obstacle precisely
rather than leaving a `sorry`.

Final structured answer: per-target status (proved / not attempted / failed + why), axiom lists,
file hashes, exact compile command, caveats.
