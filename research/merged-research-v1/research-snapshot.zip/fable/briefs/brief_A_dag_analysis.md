# Brief A -- decisive structural tests of `native-search/residual_dag.py`

Read `COMMON.md` in this directory first. Your writable directory: `work/alg001/fable/dag_analysis/`.

## What is being tested
The UNCHANGED candidate `residual_dag.DAG` (import it read-only via `sys.path`; never edit it):
`root = d.cnf(clauses); for v in order: root = d.forget(root, v)`; answer = (root == 1).
The lead's analysis says it is *bucket elimination with a syntactic normal form*:
when `v` is forgotten, root children not mentioning `v` are pulled out as the common factor
and all children mentioning `v` merge into one node `OR(AND(S|v=0), AND(S|v=1))`.
Consequences to test (treat each as a hypothesis; try hard to break it):

- H-TSEITIN (positive): on Tseitin formulas (each variable = an edge, in exactly two parity
  constraints) the number of allocated nodes is polynomial (predicted O(n^2 * 2^d), observed
  about n^1.5) for EVERY elimination order, including on expanders (random d-regular graphs),
  because OR children are a sorted set so the cofactor of a merged component depends only on
  (component, set of assigned boundary edges, total parity).
- H-XOR3 (negative): for XOR systems where variables occur in >= 3 equations (random 3-XOR,
  m = n equations on n variables, planted solution; also m = n + 5 with random right-hand
  sides, usually UNSAT), allocation grows exponentially in n under every order tried.
  Preliminary: natural order alloc 4115, 15732, 47328, 160706 at n = 40, 56, 72, 88.
- H-PHP (negative): PHP(h+1 pigeons, h holes) grows exponentially under every order tried.
  Preliminary: hole-major alloc 179, 518, 1373, 3520, 8873, 22070 for h = 3..8 (ratio ~2.5);
  pigeon-major 194, 725, 2717, 10071, 35985, 122603 (ratio ~3.5).
- H-3CNF (negative): random 3-CNF grows exponentially even far below the threshold
  (density 3.0: natural-order alloc 630, 2463, 12865, 13224, 27220, 148907 at n = 16..36).
- H-2SAT: unknown. Random 2-CNF at density 0.9 looked polynomial. Find out whether there are
  2-CNF or Horn families (both in P) on which the candidate is exponential under every order
  you try (e.g. implication grids/ladders, dense bipartite implication structures, random
  2-CNF at densities 0.9 / 1.0 / 1.5, random Horn 3-CNF). A P-class failure would be decisive.
- H-SUBSUME: family G_k = { (x v a_i v b_i) : i=1..k } + { (-x v c) } with order
  x, a_1..a_k, then the rest: predicted 2^k + O(1) children of one OR node (the normal form
  has no AND-subset subsumption), while eliminating the a_i first is linear. Report exact counts.

A scratch probe with generators you may reuse/rewrite: `work/alg001/fable/scratch/h_probe*.py`.

## Required experiments (each run <= 30 s, cap allocated nodes at 400000)
For every run record: family, parameters, seed, order name, result (SAT/UNSAT/CAP),
`len(d.nodes)` (allocated), total stored child references, `len(d.cofactor_cache)`,
`d.factor_steps`, peak reachable (optional, it is slow), seconds, and N = encoded input bits
under the project encoding: sum over literals of (4 + 2*bitlen(var)) plus 2 per clause.

Orders to implement (all deterministic given a seed): natural, reverse, k random shuffles,
min-degree and min-fill on the primal graph (variables adjacent iff they share a clause;
update the graph as in bucket elimination), max-degree, BFS from vertex 1, and for the grid
families the obvious structured orders (pigeon-major / hole-major for PHP).

E1 Tseitin: random d-regular graphs for d in {3,4,5} (retry until simple+connected), plus a
   2D torus and K_m for small m; both a satisfiable charge (even total) and an unsatisfiable
   one (odd total); edges n as large as fits 30 s. All orders above incl. >= 5 shuffles.
   Independent expected answer = parity of the total charge of each connected component.
   Fit log-log slope of allocated nodes vs n for each order. Any order that is not
   polynomial-looking is a major finding: report the exact instance.
E2 XOR systems: 3-XOR with m = n (planted) and m = n + 5 (random rhs; decide the expected
   answer independently by Gaussian elimination over GF(2) on the equations), n up to the cap.
   Orders: natural, min-degree, min-fill, best and median of 20 shuffles. Fit the exponential
   rate (log2 alloc per variable). Also 4-XOR with each variable in exactly 2 equations
   (a Tseitin-like hypergraph: should be polynomial if H-TSEITIN's mechanism is right).
E3 PHP(h+1,h): pigeon-major, hole-major, min-degree, min-fill, 200 random orders
   (report min / median) for h = 2..(largest feasible); exhaustive ALL orders for the 6-variable
   PHP(3,2) and for one 8-variable instance PHP(4,2) (8! = 40320 orders; keep it under the
   cap by batching runs <= 30 s each). Report the minimum over orders and how it scales with h.
E4 Random 3-CNF at densities 2.0, 3.0, 4.26: n grid up to the cap; natural, min-degree,
   min-fill, best of 20 shuffles. Expected answers for n <= 20 from
   `work/alg001/adversarial/oracle.py` (read it to see the API) -- for larger n just record
   the candidate's answer and mark it "unverified". Fit exponential rate per density/order.
E5 2-SAT / Horn hunt as described in H-2SAT. Verify answers with your own independent
   2-SAT SCC implementation / Horn unit propagation.
E6 H-SUBSUME exact counts for k = 2..14 under both orders.
E7 Semantic census (small instances only, total variables <= 16): after each forget step,
   compute the truth table (as a Python int bitmask over all variables) of every node
   reachable from the root and count (a) reachable nodes, (b) semantically distinct functions
   among them. Do this for PHP(4,3), PHP(5,4) if feasible, random 3-CNF n = 14..16 at 4.26,
   3-XOR n = 14..16, Tseitin on a 3-regular graph with 9..10 edges... Report the peak of (a)
   and (b). Purpose: how much could ANY semantic canonical form save on the same node set?
E8 (stretch) A repaired subclass in YOUR directory (`repaired_dag.py`, subclassing DAG, not
   editing the original) adding exact AND-subset subsumption inside OR
   (OR(AND(X), AND(X u Y)) = AND(X)) and its dual; validate it against brute force on 2000
   random small CNFs at every elimination stage (same style as `residual_dag.check_random`);
   rerun E3/E4/E6 and report whether growth RATES change (not just constants).

## Deliverables (all under `work/alg001/fable/dag_analysis/`)
- `families.py`, `orders.py`, `run_experiments.py` (re-runnable: `python3 run_experiments.py E1` etc.),
  `results/E*.json`, and `REPORT.md` with one table per experiment, fitted rates, exact
  reproduction commands, and a "what would falsify the lead's hypotheses" paragraph listing
  anything you found that contradicts H-*.
- Final structured answer: per-hypothesis verdict (supported / contradicted / inconclusive)
  with the key numbers, list of files, caveats.
