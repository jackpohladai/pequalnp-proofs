# Brief B -- implement and stress the Fable candidate "CFPE"

Read `COMMON.md` in this directory first. Writable: `work/alg001/fable/candidate.py`,
`work/alg001/fable/tests/`, `work/alg001/fable/experiments/`.

## Idea (canonical-factor projective elimination)
`native-search/residual_dag.py` computes exact existential projections but identifies nodes
only syntactically, so it blows up on PHP, random 3-CNF and XOR systems with >= 3 occurrences.
CFPE keeps the SAME exact invariant but stores every factor in a semantic canonical form
(reduced ordered BDD) and adds an algebraic GF(2) layer. It is a complete decision procedure;
no polynomial worst-case bound is claimed or expected. Your job: a correct, fully metered
implementation plus an honest search for where it breaks.

## Algorithm (single file `candidate.py`, stdlib only, deterministic)
`solve(nvars, clauses, budget)`:
0. Normalise: dedupe literals, drop tautological clauses, dedupe clauses; empty clause -> UNSAT.
1. Unit propagation to fixpoint, recording forced values (conflict -> UNSAT).
2. Affine layer.
   a. XOR detection: group clauses by variable set S (2 <= |S| <= 6, no repeated variable).
      A clause forbids exactly one assignment of S (positive literal -> 0, negative -> 1).
      The constraint "XOR of S = p" is present iff all 2^(|S|-1) clauses forbidding the
      assignments of parity 1-p are present. (Units are rows of width 1.)
   b. Gauss-Jordan over GF(2) with Python-int bitmask rows. `0 = 1` -> UNSAT (sound: every
      row is implied by input clauses).
   c. Rows of width 1 / 2 give forced values / literal equivalences: substitute into all
      clauses, renormalise, repeat 1-2 to fixpoint.
   d. Exact projection of XOR-only variables: let U = variables occurring in no clause outside
      the detected XOR groups. Put U first in the pivot order; in the reduced echelon form the
      rows whose pivot lies outside U vanish on U and span exactly {w in rowspace : w_U = 0},
      so the rows with pivot in U can be dropped (each is satisfied by choosing its pivot) and
      are recorded for witness reconstruction. If every remaining constraint is affine the
      instance is decided here in polynomial time with a witness from the echelon form.
      The surviving rows replace the clause groups they came from.
3. Factors: one ROBDD per remaining clause and per remaining XOR row (a parity BDD has
   2k+1 nodes), all in one shared unique table with a global variable order.
4. Bucket elimination: repeatedly pick a variable v (heuristic), B_v := AND of all factors
   mentioning v (smallest first; FALSE -> UNSAT), new factor := EXISTS v. B_v (drop if TRUE),
   remember B_v. When no variable is left: SAT (no FALSE factor can remain).
5. Witness: go through eliminated variables in reverse; for each v choose a value making B_v
   true under the already chosen values of its other scope variables (must exist; if not,
   raise an internal error -> status ERROR, never SAT); then undo step 2 (echelon rows,
   equivalences, units); unused variables False. VERIFY against the ORIGINAL clauses before
   returning SAT; a failed verification returns status "ERROR".
6. Ordering: the BDD variable order and the elimination order must be computed from the
   clause structure by a fixed documented rule (not from variable indices alone) -- try a few
   (e.g. min-degree / min-fill elimination; BDD order from a BFS/"widest clause first"/FORCE
   style placement) and combine them as a deterministic portfolio with a fixed budget split if
   useful. State clearly which rule the shipped `solve` uses.
7. Metering: call `budget.tick(category, amount)` for every primitive: each unique-table
   insertion, each apply/exists cache miss, each clause literal scanned, each row XOR
   (amount = number of 64-bit words touched), each witness evaluation step. Let
   `BudgetExceeded` propagate OR catch it and return `{"status": "UNKNOWN", ...}`; never guess.
   Also provide `solve_capped(nvars, clauses, C=..., d=3)` which builds its own Budget with
   maximum C * N^d, N = encoded bit length = sum over literals of (4 + 2*bitlen(var)) + 2 per
   clause (the Lean `encodeCNF` length with 1-based indices). Return `operations` with the
   category totals, peak/total BDD nodes, and `bit_cost_upper = total_ticks * ceil(log2(max(2, nodes)))`.

Invariants to document in the module docstring and to assert in tests:
 (I1) preprocessing preserves satisfiability and models translate back exactly;
 (I2) at every stage, for every assignment a of the retained variables, AND(factors)(a) = 1
      iff a extends to a model of the original formula (exact projection);
 (I3) UNSAT is returned only on: empty clause, unit conflict, 0 = 1 row, or a FALSE BDD;
 (I4) SAT is returned only with a verified witness.

## Tests (write them; they must be independent of candidate internals)
T1 Corpus: from `work/alg001/adversarial/` run
   `python3 run_candidate.py --candidate <abs path to fable/candidate.py> --keep-going --output <abs path to fable/experiments/corpus-report.json>`
   Target 594/594 correct with verified witnesses. Report exactly what you get.
T2 Differential fuzz in `tests/test_candidate.py`: >= 20000 random small CNFs (n <= 10; mixed
   widths 0..5; units, duplicates, tautologies, empty clauses, unused variables; a share with
   embedded XOR constraints and with random literal equivalences) against your own brute-force
   oracle; plus an (I2) projection check on n <= 8 by exposing a debug hook that yields the
   factor list after each elimination and evaluating BDDs on all assignments.
T3 Mutation sanity: confirm the test suite fails if you deliberately break one rule (e.g. flip
   the XOR parity test) -- then restore. Report which mutation you tried.

## Scaling experiments -> `experiments/scaling.json` + `experiments/CANDIDATE_REPORT.md`
For each family record ticks by category, peak BDD nodes, seconds, status, N; each run <= 30 s
(cap BDD nodes at about 1.5 million; on cap return UNKNOWN and record it as CAP).
 S1 PHP(h+1,h) with natural indices var(i,k)=i*h+k+1, and with 5 seeded random variable
    renamings + clause shuffles. Largest h solved; growth fit. Does any fixed structural
    ordering rule make it polynomial-looking under renaming? Be honest if not.
 S2 Tseitin on random 3-regular graphs (odd charge, UNSAT), natural + shuffled.
 S3 3-XOR m = n planted and m = n + 5 random (expected answer by your own GF(2) elimination).
 S4 Mixed: PHP(h+1,h) with every variable replaced by the XOR of two fresh variables
    (expand clauses), and Tseitin + a few random 3-clauses.
 S5 Random 3-CNF at density 4.26 and 3.0, n = 20, 30, ... until CAP; fit the exponential rate.
 S6 Selector family AND_i[(x_i v y_i) & (-x_i v z_i)], random 2-CNF (0.9, 1.5), random Horn.
 S7 Harness bound test on the corpus: `--bound-degree 3 --bound-constant 1 --bound-size dimacs_bytes`
    and `--bound-degree 2 --bound-constant 10 --bound-size dimacs_bytes` (see the README there).
For comparison include the unchanged `residual_dag` (natural order, 400k node cap) on the same
instances where cheap.

Report: which families look polynomial, which are exponential (with fitted rate), and the single
most damaging family for CFPE ("next obstacle") with exact reproduction command. Include the
SHA256 of the final `candidate.py`.

Final structured answer: corpus score, fuzz counts, mutation result, per-family verdicts with
numbers, the next-obstacle family, files, caveats.
