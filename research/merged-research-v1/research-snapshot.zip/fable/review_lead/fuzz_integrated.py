"""Differential fuzz of an integrated candidate (islands + CFPE) against brute force.
Usage: python3 fuzz_integrated.py <dir containing candidate.py and layers.py> [seconds] [seed]"""
import sys, random, itertools, time, json
sys.dont_write_bytecode = True
from pathlib import Path
target = Path(sys.argv[1]).resolve(); seconds = float(sys.argv[2]) if len(sys.argv) > 2 else 25; seed = int(sys.argv[3]) if len(sys.argv) > 3 else 1
sys.path.insert(0, str(target)); sys.path.insert(0, str(Path(__file__).resolve().parent)); sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'tests'))
import candidate as C
from fuzz_others import gen as gen_mixed, brute
import test_layers as T

def gen(rng):
    k = rng.randrange(9)
    if k < 5: return gen_mixed(rng)
    f = {5: T.random_group_formula, 6: T.random_graph_factor, 7: T.random_tight_groups, 8: T.random_horn}[k](rng) or []
    f = [list(c) for c in f]
    if rng.random() < 0.5:                       # glue a random part sharing variables
        n0 = max([abs(l) for c in f for l in c], default=1)
        for _ in range(rng.randrange(1, 4)):
            w = rng.randrange(1, min(3, n0) + 1)
            f.append([v * rng.choice((-1, 1)) for v in rng.sample(range(1, n0 + 1), w)])
    n = max([abs(l) for c in f for l in c], default=0) + rng.randrange(0, 2)
    return n, f

rng = random.Random(seed); t0 = time.time()
st = dict(cases=0, SAT=0, UNSAT=0, UNKNOWN=0, ERROR=0, decided_by={})
bad = []
while time.time() - t0 < seconds:
    n, f = gen(rng)
    if n > 12: continue
    truth = brute(n, f); st['cases'] += 1
    for kw in ({}, {'islands': False}):
        r = C.solve(n, [tuple(c) for c in f], None, **kw)
        s = r['status']
        if not kw:
            st[s] = st.get(s, 0) + 1
            d = str(r['operations'].get('decided_by')); st['decided_by'][d] = st['decided_by'].get(d, 0) + 1
        ok = (s == 'SAT' and truth and len(r['assignment']) == n and all(any(r['assignment'][abs(l) - 1] == (l > 0) for l in c) for c in f)) or (s == 'UNSAT' and not truth)
        if not ok:
            bad.append(dict(kw=kw, nvars=n, clauses=f, truth=truth, status=s, reason=r.get('reason')))
            if len(bad) >= 5: break
    if len(bad) >= 5: break
print(json.dumps(st)); print('FAILURES:', len(bad))
for b in bad: print(json.dumps(b)[:500])
json.dump(dict(stats=st, failures=bad, target=str(target), seed=seed), open(Path(__file__).with_name('fuzz_integrated_%d.json' % seed), 'w'), indent=1)
sys.exit(1 if bad else 0)
