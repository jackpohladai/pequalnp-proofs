"""CFPE engine (candidate.py as written by subagent B, before island integration) on the
structured families. One call per instance with the solver's own 25 s deadline."""
import sys, json, time
from pathlib import Path
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent)); sys.dont_write_bytecode = True
import importlib.util
spec = importlib.util.spec_from_file_location('cfpe_engine_snapshot', HERE.parent / 'candidate.py')
cand = importlib.util.module_from_spec(spec); spec.loader.exec_module(cand)
from hard_families import catalogue
if __name__ == '__main__':
    out = {}
    for name, (n, cl, exp) in catalogue().items():
        t0 = time.time()
        r = cand.solve(n, [tuple(c) for c in cl], None, time_limit=25)
        ops = r.get('operations', {})
        row = dict(nvars=n, clauses=len(cl), expected=exp, status=r['status'], reason=r.get('reason'),
                   seconds=round(time.time() - t0, 2), ticks=ops.get('total_ticks'), bdd_nodes_total=ops.get('bdd_nodes_total'),
                   decided_by=ops.get('decided_by'))
        assert r['status'] not in ('SAT', 'UNSAT') or r['status'] == exp, (name, r['status'], exp)
        out[name] = row; print(f'{name:36s}', {k: row[k] for k in ('expected', 'status', 'seconds', 'ticks', 'bdd_nodes_total', 'decided_by')}, flush=True)
        json.dump(out, open(HERE / 'engine_on_hard.json', 'w'), indent=1)
