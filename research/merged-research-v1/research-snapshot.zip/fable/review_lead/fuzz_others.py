"""Lead reviewer: differential fuzz of OTHER workers' current candidates (read-only import)
against an independent brute-force oracle. UNKNOWN is never counted as an error.
Each batch is time-boxed. Nothing is written outside this directory."""
import sys, importlib.util, random, itertools, json, time, hashlib
sys.dont_write_bytecode = True
sys.setrecursionlimit(100000)
from pathlib import Path
BASE = Path(__file__).resolve().parents[2]

def load(name, rel, extra_path=None):
    path = BASE / rel
    if extra_path: sys.path.insert(0, str(BASE / extra_path))
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
    return mod, hashlib.sha256(path.read_bytes()).hexdigest()

def brute(n, clauses):
    for bits in itertools.product((False, True), repeat=n):
        if all(any(bits[abs(l) - 1] == (l > 0) for l in c) for c in clauses):
            return True
    return False

def xor_clauses(vs, rhs):
    out = []
    for bits in itertools.product((0, 1), repeat=len(vs)):
        if sum(bits) % 2 != rhs: out.append([v if b == 0 else -v for v, b in zip(vs, bits)])
    return out

def gen(rng):
    n = rng.randrange(1, 10); kind = rng.randrange(6); cl = []
    if kind == 0:      # plain random mixed width
        for _ in range(rng.randrange(0, 4 * n + 2)):
            w = rng.randrange(1, min(4, n) + 1)
            cl.append([v * rng.choice((-1, 1)) for v in rng.sample(range(1, n + 1), w)])
    elif kind == 1:    # XOR rich
        for _ in range(rng.randrange(1, n + 2)):
            w = rng.randrange(2, min(4, n) + 1) if n >= 2 else 1
            cl += xor_clauses(rng.sample(range(1, n + 1), w), rng.randrange(2))
        for _ in range(rng.randrange(0, 4)):
            cl.append([v * rng.choice((-1, 1)) for v in rng.sample(range(1, n + 1), min(n, rng.randrange(1, 4)))])
    elif kind == 2:    # 2-CNF / equivalence rich
        for _ in range(rng.randrange(0, 3 * n)):
            if n >= 2: cl.append([v * rng.choice((-1, 1)) for v in rng.sample(range(1, n + 1), 2)])
    elif kind == 3:    # small pigeonhole-like blocks plus noise
        p, h = rng.choice(((2, 1), (3, 2), (2, 2), (3, 3), (4, 2)))
        if p * h <= 9:
            n = max(n, p * h); var = lambda i, k: i * h + k + 1
            cl = [[var(i, k) for k in range(h)] for i in range(p)]
            for k in range(h):
                for i in range(p):
                    for j in range(i + 1, p): cl.append([-var(i, k), -var(j, k)])
            perm = list(range(1, n + 1)); rng.shuffle(perm)
            cl = [[(perm[abs(l) - 1]) * (1 if l > 0 else -1) for l in c] for c in cl]
            if rng.random() < 0.5 and cl: cl.pop(rng.randrange(len(cl)))
    elif kind == 4:    # degenerate: duplicates, tautologies, repeated literals, units
        for _ in range(rng.randrange(0, 2 * n + 2)):
            w = rng.randrange(1, 5)
            cl.append([rng.randrange(1, n + 1) * rng.choice((-1, 1)) for _ in range(w)])
        if cl and rng.random() < 0.5: cl.append(list(cl[0]))
    else:              # dense 3-CNF near unsat
        if n >= 3:
            for _ in range(rng.randrange(3 * n, 6 * n)):
                cl.append([v * rng.choice((-1, 1)) for v in rng.sample(range(1, n + 1), 3)])
    return n, cl

def call(name, mod, n, cl):
    if name == 'native_hybrid':
        return mod.solve(n, tuple(tuple(c) for c in cl), None)
    return mod.solve(n, [list(c) for c in cl], 200000)

def fuzz(name, mod, seconds=20.0, seed=4242, limit=10000):
    rng = random.Random(seed); t0 = time.time(); stats = dict(cases=0, SAT=0, UNSAT=0, UNKNOWN=0, other=0)
    bad = []
    while time.time() - t0 < seconds and stats['cases'] < limit:
        n, cl = gen(rng); truth = brute(n, cl); stats['cases'] += 1
        try:
            r = call(name, mod, n, cl)
        except Exception as e:                      # crash = finding, not a wrong answer
            stats['other'] += 1
            if len(bad) < 5: bad.append(dict(kind='exception', error=f'{type(e).__name__}: {e}', nvars=n, clauses=cl))
            continue
        s = r.get('status')
        if s == 'SAT':
            stats['SAT'] += 1
            a = r.get('assignment')
            ok = truth and (a is None or (len(a) == n and all(any(bool(a[abs(l) - 1]) == (l > 0) for l in c) for c in cl)))
            if not ok and len(bad) < 5: bad.append(dict(kind='wrong_SAT_or_bad_witness', nvars=n, clauses=cl, truth=truth, response=str(r)[:300]))
        elif s == 'UNSAT':
            stats['UNSAT'] += 1
            if truth and len(bad) < 5: bad.append(dict(kind='wrong_UNSAT', nvars=n, clauses=cl, response=str(r)[:300]))
        elif s == 'UNKNOWN':
            stats['UNKNOWN'] += 1
        else:
            stats['other'] += 1
            if len(bad) < 5: bad.append(dict(kind='bad_status', nvars=n, clauses=cl, response=str(r)[:300]))
    return stats, bad

if __name__ == '__main__':
    targets = [('hydrogen', 'hydrogen/candidate.py', None), ('neon', 'neon/candidate.py', None),
               ('native_hybrid', 'native-search/hybrid_solver.py', 'native-search')]
    report = {}
    for name, rel, extra in targets:
        try:
            mod, sha = load(name, rel, extra)
        except Exception as e:
            report[name] = dict(load_error=f'{type(e).__name__}: {e}'); print(name, report[name]); continue
        stats, bad = fuzz(name, mod)
        report[name] = dict(sha256=sha, stats=stats, findings=bad)
        print(name, sha[:12], stats, 'findings:', len(bad), flush=True)
        for b in bad[:3]: print('   ', json.dumps(b)[:400])
    json.dump(report, open(Path(__file__).with_name('fuzz_others.json'), 'w'), indent=1)
