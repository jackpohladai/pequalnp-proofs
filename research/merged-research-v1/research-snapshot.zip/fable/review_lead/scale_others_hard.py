"""Lead reviewer: other workers' candidates on structured families with known answers.
A definite answer different from `expected` is a soundness bug; UNKNOWN/TIMEOUT is not."""
import sys, json, subprocess
from pathlib import Path
HERE = Path(__file__).resolve().parent
from hard_families import catalogue
from scale_others import WORKER, TARGETS
if __name__ == '__main__':
    out = {}; wrong = []
    for inst, (n, cl, exp) in catalogue().items():
        row = {}
        for name, path, extra in TARGETS:
            try:
                p = subprocess.run([sys.executable, '-c', WORKER, name, str(path), extra], input=json.dumps(dict(n=n, cl=cl)),
                                   capture_output=True, text=True, timeout=30, env={'PYTHONDONTWRITEBYTECODE': '1', 'PATH': '/usr/bin:/bin'})
                row[name] = json.loads(p.stdout.strip().splitlines()[-1]) if p.returncode == 0 and p.stdout.strip() else dict(status='ERROR', err=p.stderr[-300:])
            except subprocess.TimeoutExpired:
                row[name] = dict(status='TIMEOUT_30s')
            s = row[name].get('status')
            if s in ('SAT', 'UNSAT') and s != exp: wrong.append((inst, name, s, exp))
            if s == 'SAT' and row[name].get('witness_ok') is False: wrong.append((inst, name, 'bad witness', exp))
        out[inst] = dict(nvars=n, clauses=len(cl), expected=exp, **row)
        print(f'{inst:36s} exp={exp:5s}', {k: (v.get('status'), v.get('seconds')) for k, v in row.items()}, flush=True)
        json.dump(dict(results=out, wrong_answers=wrong), open(HERE / 'scale_others_hard.json', 'w'), indent=1)
    print('WRONG ANSWERS:', wrong)
