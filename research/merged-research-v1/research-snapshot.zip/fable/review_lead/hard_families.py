"""Structured families with mathematically known answers (no solver needed for ground truth).
Each generator returns (nvars, clauses, expected) with expected in {'SAT','UNSAT'}."""
import itertools, random

def _amo(vs):
    return [[-a, -b] for a, b in itertools.combinations(vs, 2)]

def php(p, h):
    var = lambda i, k: i * h + k + 1
    cl = [[var(i, k) for k in range(h)] for i in range(p)]
    for k in range(h): cl += _amo([var(i, k) for i in range(p)])
    return p * h, cl, ('SAT' if p <= h else 'UNSAT')

def xorify2(n, clauses, expected):
    """Replace every variable x by (x' XOR x''). Satisfiability is preserved exactly."""
    out = []
    for c in clauses:
        # literal x>0 true iff a^b = 1 ; forbidden assignments of the lifted clause: all literals false
        choices = []
        for l in c:
            a, b = 2 * abs(l) - 1, 2 * abs(l)
            # literal false:  (l>0) -> a^b = 0 -> (a,b) in {00,11};  (l<0) -> a^b = 1 -> {01,10}
            choices.append([(a, b, 0, 0), (a, b, 1, 1)] if l > 0 else [(a, b, 0, 1), (a, b, 1, 0)])
        for combo in itertools.product(*choices):
            lits = []
            for a, b, va, vb in combo:
                lits += [a if va == 0 else -a, b if vb == 0 else -b]
            out.append(lits)
    return 2 * n, out, expected

def hidden_hall(n_pigeons, n_holes, k, deg, seed):
    """Bipartite 'pigeon i may use hole j' instance with n_pigeons <= n_holes but a planted Hall
    violator: pigeons 0..k all restricted to holes 0..k-1. UNSAT by Hall's theorem."""
    rng = random.Random(seed)
    nbr = {}
    for i in range(n_pigeons):
        if i <= k: nbr[i] = sorted(rng.sample(range(k), min(deg, k)))
        else: nbr[i] = sorted(rng.sample(range(n_holes), deg))
    ids = {}
    def var(i, j):
        return ids.setdefault((i, j), len(ids) + 1)
    cl = [[var(i, j) for j in nbr[i]] for i in range(n_pigeons)]
    for j in range(n_holes):
        cl += _amo([var(i, j) for i in range(n_pigeons) if j in nbr[i]])
    # scramble names and clause order so that no index pattern survives
    n = len(ids); perm = list(range(1, n + 1)); rng.shuffle(perm)
    cl = [[perm[abs(l) - 1] * (1 if l > 0 else -1) for l in c] for c in cl]; rng.shuffle(cl)
    return n, cl, 'UNSAT'

def perfect_matching_clique(m):
    """Every vertex of K_m is covered by exactly one chosen edge. UNSAT iff m is odd."""
    ids = {}
    def var(a, b):
        return ids.setdefault((min(a, b), max(a, b)), len(ids) + 1)
    cl = []
    for v in range(m):
        inc = [var(v, u) for u in range(m) if u != v]
        cl.append(inc); cl += _amo(inc)
    return len(ids), cl, ('UNSAT' if m % 2 else 'SAT')

def mutilated_chessboard(s, mutilated=True):
    """Domino tiling of an s x s board with two opposite corners removed (UNSAT for even s)."""
    cells = {(r, c) for r in range(s) for c in range(s)}
    if mutilated: cells -= {(0, 0), (s - 1, s - 1)}
    ids = {}
    def var(a, b):
        return ids.setdefault((min(a, b), max(a, b)), len(ids) + 1)
    cl = []
    for (r, c) in sorted(cells):
        inc = [var((r, c), nb) for nb in ((r + 1, c), (r - 1, c), (r, c + 1), (r, c - 1)) if nb in cells]
        cl.append(inc); cl += _amo(inc)
    exp = 'UNSAT' if mutilated else ('SAT' if s % 2 == 0 else 'UNSAT')
    return len(ids), cl, exp

def catalogue():
    out = {}
    for h in (2, 3, 4, 5):
        out[f'php{h+1}_{h}_xor2'] = xorify2(*php(h + 1, h))
        out[f'php{h}_{h}_xor2_SATcontrol'] = xorify2(*php(h, h))
    for (P, H, k, d, s) in ((12, 14, 4, 3, 1), (20, 24, 6, 3, 2), (30, 36, 8, 4, 3), (40, 48, 10, 4, 4)):
        out[f'hidden_hall_P{P}_H{H}_k{k}_d{d}'] = hidden_hall(P, H, k, d, s)
    for m in (5, 6, 7, 9, 11, 12, 13):
        out[f'perfect_matching_K{m}'] = perfect_matching_clique(m)
    for s in (4, 6, 8):
        out[f'mutilated_chessboard_{s}x{s}'] = mutilated_chessboard(s)
    out['chessboard_6x6_SATcontrol'] = mutilated_chessboard(6, mutilated=False)
    return out

if __name__ == '__main__':
    import sys
    # self-check of the claimed answers by brute force where tiny enough
    def brute(n, cl):
        for bits in itertools.product((False, True), repeat=n):
            if all(any(bits[abs(l) - 1] == (l > 0) for l in c) for c in cl): return 'SAT'
        return 'UNSAT'
    for name, (n, cl, exp) in catalogue().items():
        tag = brute(n, cl) if n <= 20 else 'not-bruteforced'
        assert tag in (exp, 'not-bruteforced'), (name, tag, exp)
        print(f'{name:38s} n={n:4d} m={len(cl):5d} expected={exp:5s} brute={tag}')
