"""Lead reviewer: where do the OTHER workers' candidates stand on the families used in this
report? One subprocess per (candidate, instance), 30 s wall timeout, 512 MB is not enforceable
on macOS so node/op budgets are used. TIMEOUT / UNKNOWN are censored observations only."""
import sys, json, subprocess, random, itertools, time
from pathlib import Path
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / 'scratch'))
from h_probe import php, xor_clauses, random_regular

def W(k):
    p = lambda i: 3 + i; q = lambda i: 3 + k + i
    return 3 + 2 * k, [(-1, 2), (1, 3)] + [(2, p(i), q(i)) for i in range(1, k + 1)]
def shuffled(n, cl, seed):
    rng = random.Random(seed); perm = list(range(1, n + 1)); rng.shuffle(perm)
    out = [[perm[abs(l) - 1] * (1 if l > 0 else -1) for l in c] for c in cl]
    rng.shuffle(out); return n, out
def tseitin(nv, seed):
    rng = random.Random(seed); edges = random_regular(nv, 3, rng)
    inc = {v: [] for v in range(nv)}
    for i, (a, b) in enumerate(edges, 1): inc[a].append(i); inc[b].append(i)
    cl = []
    for v in range(nv): cl += xor_clauses(inc[v], 1 if v == 0 else 0)
    return len(edges), cl
def xor3(n, m, seed, planted=True):
    rng = random.Random(seed); sol = [rng.randrange(2) for _ in range(n + 1)]; cl = []
    for _ in range(m):
        vs = rng.sample(range(1, n + 1), 3)
        cl += xor_clauses(vs, sum(sol[v] for v in vs) % 2 if planted else rng.randrange(2))
    return n, cl
def rand3(n, seed, dens=4.26):
    rng = random.Random(seed)
    return n, [[v * rng.choice((-1, 1)) for v in rng.sample(range(1, n + 1), 3)] for _ in range(round(dens * n))]

INSTANCES = {}
for k in (14, 40): INSTANCES[f'W_{k}'] = W(k)
for h in (6, 8, 10):
    n, cl, _ = php(h + 1, h); INSTANCES[f'php_{h+1}_{h}_natural'] = (n, cl)
    INSTANCES[f'php_{h+1}_{h}_shuffled'] = shuffled(n, cl, 999)
for nv in (32, 64): INSTANCES[f'tseitin_cubic_{nv}v'] = tseitin(nv, 31 + nv)
for n in (40, 80): INSTANCES[f'xor3_planted_n{n}'] = xor3(n, n, 17 + n)
INSTANCES['xor3_random_rhs_n60_m65'] = xor3(60, 65, 5, planted=False)
for n in (40, 60, 80): INSTANCES[f'rand3cnf_4.26_n{n}'] = rand3(n, 100 + n)

WORKER = r'''
import sys, json, importlib.util, time
sys.dont_write_bytecode = True; sys.setrecursionlimit(1000000)
name, path, extra = sys.argv[1], sys.argv[2], sys.argv[3]
if extra != '-': sys.path.insert(0, extra)
req = json.loads(sys.stdin.read())
spec = importlib.util.spec_from_file_location('cand', path); mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
n, cl = req['n'], req['cl']
t0 = time.time()
if name == 'native_hybrid': r = mod.solve(n, tuple(tuple(c) for c in cl), None)
else: r = mod.solve(n, [list(c) for c in cl], 3000000)
a = r.get('assignment'); ok = None
if r.get('status') == 'SAT' and a is not None:
    ok = len(a) == n and all(any(bool(a[abs(l)-1]) == (l > 0) for l in c) for c in cl)
print(json.dumps(dict(status=r.get('status'), witness_ok=ok, seconds=round(time.time()-t0, 2))))
'''
BASE = HERE.parents[1]
TARGETS = [('hydrogen', BASE / 'hydrogen/candidate.py', '-'), ('neon', BASE / 'neon/candidate.py', '-'),
           ('native_hybrid', BASE / 'native-search/hybrid_solver.py', str(BASE / 'native-search'))]
if __name__ == '__main__':
    out = {}
    for inst, (n, cl) in INSTANCES.items():
        row = {}
        for name, path, extra in TARGETS:
            try:
                p = subprocess.run([sys.executable, '-c', WORKER, name, str(path), extra], input=json.dumps(dict(n=n, cl=cl)),
                                   capture_output=True, text=True, timeout=30, env={'PYTHONDONTWRITEBYTECODE': '1', 'PATH': '/usr/bin:/bin'})
                row[name] = json.loads(p.stdout.strip().splitlines()[-1]) if p.returncode == 0 and p.stdout.strip() else dict(status='ERROR', err=p.stderr[-200:])
            except subprocess.TimeoutExpired:
                row[name] = dict(status='TIMEOUT_30s')
        out[inst] = dict(nvars=n, clauses=len(cl), **row)
        print(inst, n, len(cl), {k: (v.get('status'), v.get('seconds')) for k, v in row.items()}, flush=True)
        json.dump(out, open(HERE / 'scale_others.json', 'w'), indent=1)
