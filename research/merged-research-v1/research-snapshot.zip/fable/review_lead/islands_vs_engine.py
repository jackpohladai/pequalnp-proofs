"""Islands + CFPE versus the CFPE engine alone on structured families with known answers.
Usage: python3 islands_vs_engine.py <dir with candidate.py + layers.py> <out.json>
Each run has the solver's own 25 s deadline; UNKNOWN is a censored observation."""
import sys, json, time, random
sys.dont_write_bytecode = True
from pathlib import Path
target = Path(sys.argv[1]).resolve(); out_path = Path(sys.argv[2]).resolve()
sys.path.insert(0, str(target)); sys.path.insert(0, str(Path(__file__).resolve().parent))
import candidate as C
from hard_families import php, hidden_hall, perfect_matching_clique, mutilated_chessboard, xorify2

def renamed(n, cl, seed):
    rng = random.Random(seed); perm = list(range(1, n + 1)); rng.shuffle(perm)
    flip = [rng.choice((1, -1)) for _ in range(n + 1)]
    out = [[perm[abs(l) - 1] * (1 if l > 0 else -1) * flip[perm[abs(l) - 1]] for l in c] for c in cl]
    rng.shuffle(out); return out

cases = []
for h in (6, 8, 10, 12, 14):
    n, cl, exp = php(h + 1, h); cases.append((f'php_{h+1}_{h}', n, cl, exp))
    cases.append((f'php_{h+1}_{h}_renamed_flipped', n, renamed(n, cl, h), exp))
for m in (13, 15, 17, 19, 21): cases.append((f'perfect_matching_K{m}',) + perfect_matching_clique(m))
for s in (8, 10, 12, 14, 16): cases.append((f'mutilated_chessboard_{s}x{s}',) + mutilated_chessboard(s))
for a in ((40, 48, 10, 4, 4), (80, 96, 12, 4, 5), (120, 140, 14, 4, 7)): cases.append(('hidden_hall_P%d_H%d' % a[:2],) + hidden_hall(*a))
for h in (5, 6, 7): cases.append((f'php_{h+1}_{h}_xor2',) + xorify2(*php(h + 1, h)))

if __name__ == '__main__':
    rows = {}
    for name, n, cl, exp in cases:
        cl = [tuple(c) for c in cl]; row = dict(nvars=n, clauses=len(cl), N=C.encoded_bit_length(cl), expected=exp)
        for label, kw in (('islands_on', {}), ('engine_only', {'islands': False})):
            t0 = time.time(); r = C.solve(n, cl, None, time_limit=25, **kw); ops = r['operations']
            assert r['status'] not in ('SAT', 'UNSAT') or r['status'] == exp, (name, label, r['status'], exp)
            row[label] = dict(status=r['status'], seconds=round(time.time() - t0, 2), ticks=ops['total_ticks'],
                              bdd_nodes_total=ops['bdd_nodes_total'], decided_by=ops.get('decided_by'), reason=r.get('reason'))
        rows[name] = row
        print(f'{name:34s} N={row["N"]:6d} on:', (row['islands_on']['status'], row['islands_on']['seconds'], row['islands_on']['ticks']),
              'engine:', (row['engine_only']['status'], row['engine_only']['seconds'], row['engine_only']['ticks'], row['engine_only']['reason']), flush=True)
        json.dump(rows, open(out_path, 'w'), indent=1)
