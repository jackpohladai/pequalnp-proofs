"""Exact polynomial-time islands for the Fable candidate (L-alg-001 local research).

Each layer takes ONE connected component of a normalised CNF (tuples of signed ints, no
tautologies, no repeated literals, no empty clause) and returns
    None                      -- layer not applicable (say nothing)
    ('SAT', {var: bool})      -- a model of the component (callers must still verify it)
    ('UNSAT', certificate)    -- only with a sound, complete argument described below
No layer ever guesses. Inputs outside that contract are handled defensively: an empty clause
makes every layer answer UNSAT, unit clauses make the degree layer decline, and repeated
literals, tautologies, duplicate clauses or several components at once either are treated
exactly or make the layer decline (tests/test_layers_raw_misuse.py). None of this is a
general SAT algorithm; the classes are:

  horn_layer         Horn or dual-Horn component: forward chaining (unit resolution).
  twosat_layer       every clause has <= 2 literals: implication-graph SCC.
  cardinality_layer  "read-twice cardinality" component: after a consistent polarity
                     normalisation every clause is an at-least-one group (a clause of
                     normal literals) or an at-most-one pair (two negated normal literals),
                     the pairs form at-most-one groups, and every variable lies in at most
                     two groups. This is a degree-constrained subgraph problem; it is reduced
                     to perfect matching and decided by Edmonds' blossom algorithm. UNSAT is
                     reported only together with a Tutte-Berge barrier that is re-verified
                     independently of the matching code. Covers pigeonhole (any renaming,
                     any polarity pattern), functional PHP, hidden Hall violators, perfect
                     matching on odd cliques, mutilated chessboards, ...

Cost model: `tick(category, amount)` is called for every primitive step. Bounds (V, E are the
vertex / edge numbers of the constructed graph, both O(input size)):
  horn / 2-SAT: O(total literal occurrences);  cardinality: O(V^3) for the matching plus
  O(V * E) for the barrier, i.e. O(N^3) word operations on O(log N)-bit integers.
"""
from collections import defaultdict


def _no_tick(category, amount=1):
    return None


# --------------------------------------------------------------------------- components
def split_components(clauses):
    """Partition clauses into variable-connected components (union-find)."""
    parent = {}

    def find(x):
        root = x
        while parent[root] != root:
            root = parent[root]
        while parent[x] != root:
            parent[x], x = root, parent[x]
        return root

    for c in clauses:
        vs = [abs(l) for l in c]
        for v in vs:
            parent.setdefault(v, v)
        for v in vs[1:]:
            a, b = find(vs[0]), find(v)
            if a != b:
                parent[a] = b
    groups = defaultdict(list)
    empties = []
    for c in clauses:
        if len(c) == 0:
            empties.append(c)                          # outside the contract: own component
        else:
            groups[find(abs(c[0]))].append(c)
    out = [groups[k] for k in sorted(groups)]
    if empties:
        out.append(empties)
    return out


_EMPTY = ('UNSAT', {'kind': 'empty_clause'})


def _has_empty(clauses):
    """The layers are specified for clause sets without the empty clause. If one is passed
    anyway the only sound answer is UNSAT, and every layer gives it (defensive guard)."""
    return any(len(c) == 0 for c in clauses)


# --------------------------------------------------------------------------- Horn
def horn_layer(clauses, tick=_no_tick):
    """Horn (<= 1 positive literal per clause) or dual-Horn component."""
    if _has_empty(clauses):
        return _EMPTY
    if all(sum(1 for l in c if l > 0) <= 1 for c in clauses):
        sign = 1
    elif all(sum(1 for l in c if l < 0) <= 1 for c in clauses):
        sign = -1
    else:
        return None
    cls = [tuple(sign * l for l in c) for c in clauses]          # now Horn
    variables = sorted({abs(l) for c in cls for l in c})
    true = set()
    need = []                       # number of negative literals not yet satisfied-by-true
    watch = defaultdict(list)
    queue = []
    for i, c in enumerate(cls):
        tick('horn_scan', len(c))
        negs = [-l for l in c if l < 0]
        need.append(len(negs))
        for v in negs:
            watch[v].append(i)
        if not negs:
            queue.append(i)
    head = lambda c: next((l for l in c if l > 0), None)
    while queue:
        i = queue.pop()
        tick('horn_fire')
        p = head(cls[i])
        if p is None:
            # all body atoms are forced true and there is no head: unit-resolution refutation
            return ('UNSAT', {'kind': 'horn_forward_chaining', 'falsified_clause': list(clauses[i])})
        if p in true:
            continue
        true.add(p)
        for j in watch[p]:
            tick('horn_watch')
            need[j] -= 1
            if need[j] == 0:
                queue.append(j)
    model = {v: (v in true) if sign == 1 else (v not in true) for v in variables}
    return ('SAT', model)


# --------------------------------------------------------------------------- 2-SAT
def twosat_layer(clauses, tick=_no_tick):
    if _has_empty(clauses):
        return _EMPTY
    if any(len(c) > 2 for c in clauses):
        return None
    variables = sorted({abs(l) for c in clauses for l in c})
    idx = {v: i for i, v in enumerate(variables)}
    n = len(variables)
    node = lambda l: 2 * idx[abs(l)] + (0 if l > 0 else 1)      # literal -> node
    adj = [[] for _ in range(2 * n)]
    for c in clauses:
        tick('twosat_scan', len(c))
        a, b = (c[0], c[0]) if len(c) == 1 else c
        adj[node(-a)].append(node(b))
        adj[node(-b)].append(node(a))
    # iterative Tarjan
    index = [-1] * (2 * n); low = [0] * (2 * n); comp = [-1] * (2 * n)
    on = [False] * (2 * n); stack = []; counter = 0; ncomp = 0
    for s in range(2 * n):
        if index[s] != -1:
            continue
        work = [(s, 0)]
        index[s] = low[s] = counter; counter += 1; stack.append(s); on[s] = True
        while work:
            v, i = work[-1]
            tick('twosat_step')
            if i < len(adj[v]):
                work[-1] = (v, i + 1)
                w = adj[v][i]
                if index[w] == -1:
                    index[w] = low[w] = counter; counter += 1; stack.append(w); on[w] = True
                    work.append((w, 0))
                elif on[w]:
                    low[v] = min(low[v], index[w])
            else:
                work.pop()
                if work:
                    u = work[-1][0]
                    low[u] = min(low[u], low[v])
                if low[v] == index[v]:
                    while True:
                        w = stack.pop(); on[w] = False; comp[w] = ncomp
                        if w == v:
                            break
                    ncomp += 1
    model = {}
    for v in variables:
        p, q = comp[2 * idx[v]], comp[2 * idx[v] + 1]
        if p == q:
            return ('UNSAT', {'kind': 'twosat_scc', 'variable': v})
        model[v] = p < q            # Tarjan numbers components in reverse topological order
    return ('SAT', model)


# --------------------------------------------------------------------------- matching
def max_matching(n, adj, tick=_no_tick):
    """Edmonds' blossom algorithm (cardinality), O(n^3). adj: list of neighbour lists."""
    match = [-1] * n
    for v in range(n):                                   # greedy start
        if match[v] == -1:
            for u in adj[v]:
                if match[u] == -1:
                    match[v] = u; match[u] = v
                    break
    for v in range(n):
        if match[v] == -1:
            u, parent, _ = _find_augmenting(n, adj, match, v, -1, tick)
            while u != -1:
                pv = parent[u]; ppv = match[pv]
                match[u] = pv; match[pv] = u
                u = ppv
    return match


def _find_augmenting(n, adj, match, root, banned, tick):
    """BFS for an augmenting path from the exposed vertex `root`, shrinking blossoms.
    Returns (endpoint or -1, parent array). Vertex `banned` is treated as deleted."""
    used = [False] * n
    parent = [-1] * n
    base = list(range(n))
    used[root] = True
    queue = [root]
    qi = 0

    def lca(a, b):
        seen = set()
        while True:
            a = base[a]; seen.add(a)
            if match[a] == -1:
                break
            a = parent[match[a]]
        while True:
            b = base[b]
            if b in seen:
                return b
            b = parent[match[b]]

    def mark_path(v, b, child, blossom):
        while base[v] != b:
            blossom.add(base[v]); blossom.add(base[match[v]])
            parent[v] = child
            child = match[v]
            v = parent[match[v]]

    while qi < len(queue):
        v = queue[qi]; qi += 1
        for to in adj[v]:
            tick('matching_edge_scan')
            if to == banned or base[v] == base[to] or match[v] == to:
                continue
            if to == root or (match[to] != -1 and parent[match[to]] != -1):
                cur = lca(v, to)
                blossom = set()
                mark_path(v, cur, to, blossom)
                mark_path(to, cur, v, blossom)
                tick('matching_blossom', n)
                for i in range(n):
                    if base[i] in blossom:
                        base[i] = cur
                        if not used[i]:
                            used[i] = True
                            queue.append(i)
            elif parent[to] == -1:
                parent[to] = v
                if match[to] == -1:
                    return to, parent, used
                used[match[to]] = True
                queue.append(match[to])
    return -1, parent, used


def tutte_berge_barrier(n, adj, match, tick=_no_tick, slow=False):
    """Gallai-Edmonds: D = vertices missed by SOME maximum matching, A = N(D) \\ D.
    Fast variant: D is the union of the outer vertices of the (failed) alternating searches
    from the exposed vertices. Slow variant (`slow=True`): test every matched vertex by
    deleting it. The caller must re-verify the barrier with `verify_barrier`; nothing here is
    trusted, so an error in either variant can only make the layer decline to answer."""
    in_d = [match[v] == -1 for v in range(n)]
    if not slow:
        for r in range(n):
            if match[r] != -1:
                continue
            end, _, used = _find_augmenting(n, adj, match, r, -1, tick)
            if end != -1:
                return None                            # matching was not maximum: no barrier
            for v in range(n):
                if used[v]:
                    in_d[v] = True
    else:
        for v in range(n):
            u = match[v]
            if u == -1:
                continue
            match[v] = -1; match[u] = -1               # delete v: is u still coverable?
            end, _, _ = _find_augmenting(n, adj, match, u, v, tick)
            match[v] = u; match[u] = v
            if end != -1:
                in_d[v] = True
    barrier = set()
    for v in range(n):
        if in_d[v]:
            for u in adj[v]:
                if not in_d[u]:
                    barrier.add(u)
    return barrier


def verify_barrier(n, adj, barrier):
    """Independent check: number of odd components of G - barrier exceeds |barrier|.
    If so, every matching leaves a vertex uncovered (the easy direction of Tutte's theorem:
    each odd component needs its own distinct barrier vertex)."""
    seen = [v in barrier for v in range(n)]
    odd = 0
    for s in range(n):
        if seen[s]:
            continue
        seen[s] = True; stack = [s]; size = 0
        while stack:
            v = stack.pop(); size += 1
            for u in adj[v]:
                if not seen[u]:
                    seen[u] = True; stack.append(u)
        odd += size & 1
    return odd > len(barrier), odd


# --------------------------------------------------------------------------- cardinality
def cardinality_layer(clauses, tick=_no_tick):
    """Read-twice degree system -> degree-constrained subgraph -> perfect matching."""
    if _has_empty(clauses):
        return _EMPTY
    if any(len(c) == 1 for c in clauses):
        return None                                    # units are the caller's business
    # ---- parity groups: a variable set S (|S| >= 3) whose clauses are exactly the 2^(|S|-1)
    #      clauses over S with a fixed parity q of negative literals encodes XOR(S) = 1 - q
    by_set = defaultdict(list)
    for c in clauses:
        by_set[frozenset(abs(l) for l in c)].append(c)
    parity_groups = []                                 # (frozenset of vars, parity of XOR)
    rest_clauses = []
    for S, cs in by_set.items():
        tick('card_scan', sum(len(c) for c in cs))
        if len(S) >= 3 and len(cs) == 1 << (len(S) - 1) and all(len(c) == len(S) for c in cs) \
                and len({sum(1 for l in c if l < 0) & 1 for c in cs}) == 1 and len(set(cs)) == len(cs):
            parity_groups.append((S, 1 - (sum(1 for l in cs[0] if l < 0) & 1)))
        else:
            rest_clauses.extend(cs)
    all_clauses = clauses
    clauses = rest_clauses
    wide = [c for c in clauses if len(c) != 2]
    # ---- polarity normalisation: s[x] = sign of the "normal" literal of x
    s = {}
    for c in wide:
        tick('card_scan', len(c))
        for l in c:
            v, sg = abs(l), (1 if l > 0 else -1)
            if s.setdefault(v, sg) != sg:
                return None
    binary = [c for c in clauses if len(c) == 2]
    changed = True
    pending = list(binary)
    while changed:                                     # propagate through binary clauses
        changed = False
        rest = []
        for a, b in pending:
            tick('card_scan', 2)
            va, vb = abs(a), abs(b)
            ka = s.get(va); kb = s.get(vb)
            if ka is None and kb is None:
                rest.append((a, b)); continue
            if ka is None:
                # both literals normal or both anti-normal: sign(a)*s[va] == sign(b)*s[vb]
                s[va] = (1 if a > 0 else -1) * (1 if b > 0 else -1) * kb; changed = True
            elif kb is None:
                s[vb] = (1 if a > 0 else -1) * (1 if b > 0 else -1) * ka; changed = True
            elif (1 if a > 0 else -1) * ka != (1 if b > 0 else -1) * kb:
                return None
        pending = rest
    while pending:                                     # classes not anchored by a wide clause:
        a0 = pending[0][0]                             # either orientation is a valid reading,
        s[abs(a0)] = 1                                 # take the natural one and propagate
        changed = True
        while changed:
            changed = False
            rest = []
            for a, b in pending:
                tick('card_scan', 2)
                va, vb = abs(a), abs(b)
                ka = s.get(va); kb = s.get(vb)
                if ka is None and kb is None:
                    rest.append((a, b)); continue
                if ka is None:
                    s[va] = (1 if a > 0 else -1) * (1 if b > 0 else -1) * kb; changed = True
                elif kb is None:
                    s[vb] = (1 if a > 0 else -1) * (1 if b > 0 else -1) * ka; changed = True
                elif (1 if a > 0 else -1) * ka != (1 if b > 0 else -1) * kb:
                    return None
            pending = rest
    for S, _ in parity_groups:                         # variables seen only in parity groups
        for v in S:
            s.setdefault(v, 1)
    norm = lambda l: (abs(l) if (1 if l > 0 else -1) == s[abs(l)] else -abs(l))
    pos_groups = []                                    # at-least-one groups (sets of vars)
    conflict = defaultdict(set)                        # at-most-one pairs
    for c in clauses:
        nc = [norm(l) for l in c]
        if all(l > 0 for l in nc):
            pos_groups.append(frozenset(nc))
        elif len(nc) == 2 and nc[0] < 0 and nc[1] < 0:
            a, b = -nc[0], -nc[1]
            conflict[a].add(b); conflict[b].add(a)
        else:
            return None
    # ---- groups: X = positive clause that is a conflict clique, L = other positive clause,
    #              U = connected components of the remaining conflict edges (must be cliques)
    groups = []                                        # (type, frozenset of vars)
    covered = defaultdict(set)
    for g in pos_groups:
        tick('card_group', len(g) * len(g))
        if len(g) >= 2 and all((g - {a}) <= conflict[a] for a in g):
            groups.append(('X', g))
            for a in g:
                covered[a] |= g - {a}
        else:
            groups.append(('L', g))
    rest = {a: conflict[a] - covered[a] for a in conflict}
    seen = set()
    for a in sorted(rest):
        if a in seen or not rest[a]:
            continue
        comp = {a}; stack = [a]
        while stack:
            x = stack.pop()
            for y in rest[x]:
                if y not in comp:
                    comp.add(y); stack.append(y)
        seen |= comp
        tick('card_group', len(comp) * len(comp))
        if any(rest[x] != comp - {x} for x in comp):
            return None                                # leftover conflicts are not a clique
        groups.append(('U', frozenset(comp)))
    ptarget = {}
    for S, par in parity_groups:
        ptarget[len(groups)] = par ^ (sum(1 for v in S if s[v] == -1) & 1)
        groups.append(('P', S))
    member = defaultdict(list)
    for gi, (_, g) in enumerate(groups):
        for a in g:
            member[a].append(gi)
    clauses = all_clauses
    variables = sorted({abs(l) for c in clauses for l in c})
    if any(len(member[v]) > 2 or not member[v] for v in variables):
        return None
    # ---- exactness self-check: the groups regenerate exactly the normalised clause set
    regenerated = set()
    for t, g in groups:
        if t in ('L', 'X'):
            regenerated.add(frozenset(g))
        if t in ('U', 'X'):
            gs = sorted(g)
            for i in range(len(gs)):
                for j in range(i + 1, len(gs)):
                    regenerated.add(frozenset((-gs[i], -gs[j])))
    for gi, (t, g) in enumerate(groups):
        if t != 'P':
            continue
        gs = sorted(g)
        tick('card_group', len(gs) << len(gs))
        for bits in range(1 << len(gs)):               # forbid every assignment of wrong parity
            if (bin(bits).count('1') & 1) != ptarget[gi]:
                regenerated.add(frozenset((-v if (bits >> i) & 1 else v) for i, v in enumerate(gs)))
    if regenerated != {frozenset(norm(l) for l in c) for c in clauses}:
        return None
    # ---- graph G: capacity-1 vertex per X/U group; per L group one copy per member plus
    #      (size-1) dummies; a private optional vertex for a variable lying in one group only
    vid = {}
    required = []

    def new_vertex(key, req):
        vid[key] = len(vid); required.append(req)
        return vid[key]

    for gi, (t, g) in enumerate(groups):
        if t == 'L':
            for a in sorted(g):
                new_vertex(('copy', gi, a), True)
            for d in range(len(g) - 1):
                new_vertex(('dummy', gi, d), False)
        elif t == 'P':
            # copies are matched through their variable or pairwise inside the group, so the
            # number matched through variables is |g| minus an even number, minus one more if
            # the single required helper vertex is present
            for a in sorted(g):
                new_vertex(('copy', gi, a), True)
            if (len(g) - ptarget[gi]) & 1:
                new_vertex(('phelper', gi), True)
        else:
            new_vertex(('cap', gi), t == 'X')
    edge_var = {}

    def rep(gi, a):
        return vid[('copy', gi, a)] if groups[gi][0] in ('L', 'P') else vid[('cap', gi)]

    for v in variables:
        gs = member[v]
        p = rep(gs[0], v)
        q = rep(gs[1], v) if len(gs) == 2 else new_vertex(('pendant', v), False)
        if p == q:
            return None
        edge_var.setdefault((min(p, q), max(p, q)), v)   # parallel variables: keep one
    n1 = len(vid)
    adj1 = [set() for _ in range(n1)]
    for (p, q) in edge_var:
        adj1[p].add(q); adj1[q].add(p)
    for gi, (t, g) in enumerate(groups):
        if t == 'L':
            for d in range(len(g) - 1):
                x = vid[('dummy', gi, d)]
                for a in g:
                    y = vid[('copy', gi, a)]
                    adj1[x].add(y); adj1[y].add(x)
        elif t == 'P':
            cs = [vid[('copy', gi, a)] for a in sorted(g)]
            if ('phelper', gi) in vid:
                cs.append(vid[('phelper', gi)])
            for i in range(len(cs)):                   # clique on the copies (and the helper)
                for j in range(i + 1, len(cs)):
                    adj1[cs[i]].add(cs[j]); adj1[cs[j]].add(cs[i])
    # ---- doubling: a matching of G covering all required vertices exists iff the graph made
    #      of two copies of G plus an edge o -- o' for every optional vertex o is perfect
    n2 = 2 * n1
    adj = [sorted(adj1[v]) for v in range(n1)] + [sorted(u + n1 for u in adj1[v]) for v in range(n1)]
    for v in range(n1):
        if not required[v]:
            adj[v].append(v + n1); adj[v + n1].append(v)
    tick('card_graph', n2 + sum(len(a) for a in adj))
    ok, odd = verify_barrier(n2, adj, set())           # an odd component: nothing to search
    if ok:
        return ('UNSAT', {'kind': 'tutte_berge', 'graph_vertices': n2, 'barrier_size': 0,
                          'odd_components': odd, 'groups': len(groups)})
    match = max_matching(n2, adj, tick)
    if all(m != -1 for m in match):
        chosen = set()
        for (p, q), v in edge_var.items():
            if match[p] == q:
                chosen.add(v)
        model = {v: ((v in chosen) == (s[v] == 1)) for v in variables}
        return ('SAT', model)
    barrier = tutte_berge_barrier(n2, adj, match, tick)
    ok, odd = verify_barrier(n2, adj, barrier) if barrier is not None else (False, 0)
    if not ok:
        barrier = tutte_berge_barrier(n2, adj, match, tick, slow=True)
        ok, odd = verify_barrier(n2, adj, barrier)
    if not ok:
        return None                                    # no certificate -> say nothing
    return ('UNSAT', {'kind': 'tutte_berge', 'graph_vertices': n2, 'barrier_size': len(barrier),
                      'odd_components': odd, 'groups': len(groups)})


LAYERS = (('horn', horn_layer), ('twosat', twosat_layer), ('cardinality', cardinality_layer))


def try_layers(clauses, tick=_no_tick):
    """First applicable island for one connected component, or None."""
    for name, layer in LAYERS:
        r = layer(clauses, tick)
        if r is not None:
            return name, r
    return None


# --------------------------------------------------------------------------- island stage
def island_stage(nvars, clauses, tick=_no_tick):
    """Front end of the Fable candidate: normalise, unit-propagate, split into connected
    components and decide every component lying in one of the islands above.

    Returns (verdict, residual, values, log):
      verdict == 'UNSAT'  the formula is unsatisfiable; `log['unsat']` names the argument
                          (empty clause, unit-propagation conflict, or a layer certificate).
      verdict is None     `values` (dict original variable -> bool) fixes the propagated
                          units and a model of every island component; `residual` is the list
                          of remaining clauses (tuples), whose variables are disjoint from
                          `values`. The input is satisfiable iff `residual` is, and any model
                          of `residual` joined with `values` satisfies every input clause.
    The caller must still verify the final assignment against the input clauses."""
    log = {'units': 0, 'components': 0, 'islands': {}, 'unsat': None}
    cls = []
    seen = set()
    for c in clauses:
        s = set(c)
        tick('island_scan', len(c) + 1)
        if any(-l in s for l in s):
            continue
        if not s:
            log['unsat'] = 'empty_clause'
            return 'UNSAT', [], {}, log
        key = frozenset(s)
        if key not in seen:
            seen.add(key); cls.append(sorted(s, key=abs))
    # ---- unit propagation with counters: O(total literal occurrences)
    occ = defaultdict(list)
    for i, c in enumerate(cls):
        for l in c:
            occ[l].append(i)
    value = {}
    satisfied = [False] * len(cls)
    remaining = [len(c) for c in cls]
    queue = [c[0] for c in cls if len(c) == 1]
    while queue:
        l = queue.pop()
        v, b = abs(l), l > 0
        tick('island_bcp')
        if v in value:
            if value[v] != b:
                log['unsat'] = 'unit_conflict'
                return 'UNSAT', [], {}, log
            continue
        value[v] = b
        for i in occ[l]:
            satisfied[i] = True
        for i in occ[-l]:
            tick('island_bcp')
            if satisfied[i]:
                continue
            remaining[i] -= 1
            if remaining[i] == 0:
                log['unsat'] = 'unit_conflict'
                return 'UNSAT', [], {}, log
            if remaining[i] == 1:
                tick('island_scan', len(cls[i]))
                for x in cls[i]:
                    if abs(x) not in value:
                        queue.append(x)
                        break
                else:                                # its last literal is already queued true
                    if not any(value.get(abs(x)) == (x > 0) for x in cls[i]):
                        log['unsat'] = 'unit_conflict'
                        return 'UNSAT', [], {}, log
    log['units'] = len(value)
    reduced = set()
    for i, c in enumerate(cls):
        if satisfied[i] or any(value.get(abs(l)) == (l > 0) for l in c):
            continue
        r = tuple(l for l in c if abs(l) not in value)
        tick('island_scan', len(c))
        if not r:
            log['unsat'] = 'unit_conflict'
            return 'UNSAT', [], {}, log
        reduced.add(r)
    residual = []
    values = dict(value)
    comps = split_components(sorted(reduced, key=lambda c: (len(c), [abs(l) for l in c], c)))
    log['components'] = len(comps)
    for comp in comps:
        r = try_layers(comp, tick)
        if r is None:
            residual.extend(comp)
            continue
        name, (verdict, payload) = r
        if verdict == 'UNSAT':
            log['unsat'] = {'layer': name, 'certificate': payload}
            return 'UNSAT', [], {}, log
        if not all(any(payload[abs(l)] == (l > 0) for l in c) for c in comp):
            residual.extend(comp)                    # never trust an unverified model
            continue
        tick('island_scan', sum(len(c) for c in comp))
        log['islands'][name] = log['islands'].get(name, 0) + 1
        values.update(payload)
    return None, residual, values, log
