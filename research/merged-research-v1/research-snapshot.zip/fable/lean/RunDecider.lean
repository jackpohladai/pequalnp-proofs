import PEqualNP.Outside.L_alg001_residual

/-!
# L-alg-001, Fable brief C: an explicit, total, axiom-free SAT decider on bit strings

Local research foundation. NOT a proof that SAT is in P, and not a complexity result at all.

What is here
* `satRun : List Bool → Bool`, an explicit executable function, total on ALL bit strings
  (malformed and non-canonical strings are rejected), with `satRun_correct :
  x ∈ SAT ↔ satRun x = true` for the project's language `PEqualNP.Search.SAT`.
  `#print axioms satRun` reports no axioms: the function is a program, not a classical choice.
* `satDecider : CorrectBitDecider`, the first inhabitant of the interface declared in
  `L_alg001_residual.lean`.
* The procedure is EXPONENTIAL. `searchCalls_le` bounds the number of calls of the search by
  `2 ^ (fuel + 1)`, and `exponential_family` exhibits inputs of at most `n * (4 * n + 10)` bits
  on which exactly `2 ^ (n + 1) - 1` calls are made.
* `sat_mem_P_of_degreeBound` is definitional glue. `sat_mem_P_iff_degreeBound` shows that the
  remaining obligation, a degree bound for `satDecider`, is EQUIVALENT to `SAT ∈ P`: the explicit
  decider removes the decidability obligation and nothing else.

Why there are twin definitions
`#print axioms` of the repository's `restrict` (hence of `budgetSearch`) lists
`Classical.choice`: the `Decidable ((x, v) ∉ c)` instance found by Mathlib carries a proof of
`LawfulBEq (ℕ × Bool)` that is derived classically, and `Nat.bits` (hence `encodeCNF`) lists
`propext` and `Quot.sound`. These are proof terms inside executable definitions; they do not
affect evaluation, but they would make the axiom audit of the decider uninformative. So the
executable path of `satRun` uses twins written with Boolean tests and structural recursion only
(`restrictX`, `combineX`, `searchX`, `bitsX`, `encodeCNFX`), each proved equal to the
repository's function (`restrictX_eq`, `combineX_eq`, `searchX_eq`, `bitsX_eq`,
`encodeCNFX_eq`). `satRun_eq_ref` states that `satRun` is the function written literally with
`encodeCNF` and `budgetSearch`.
-/

set_option autoImplicit false

namespace PEqualNP.Outside.L_alg001_fable

open PEqualNP.Search
open PEqualNP.Library.SearchHelpers (restrict)
open PEqualNP.Outside.L_alg001_residual

/-! ## 0. Axiom-free executable twins of the repository's search -/

/-- Number of literal occurrences of a formula: the fuel that always suffices. -/
def litCount : CNF → ℕ
  | [] => 0
  | c :: φ => c.length + litCount φ

/-- Boolean test for `(x, v) ∈ c`. -/
def hasLit (x : ℕ) (v : Bool) (c : Clause) : Bool :=
  c.any fun l => l.1 == x && l.2 == v

/-- Twin of `restrict`: delete the clauses containing `(x, v)`, then delete the literals on
`x` from the others. -/
def restrictX (x : ℕ) (v : Bool) (φ : CNF) : CNF :=
  (φ.filter fun c => !hasLit x v c).map fun c => c.filter fun l => !(l.1 == x)

/-- Twin of `combine`. -/
def combineX (a b : Option Bool) : Option Bool :=
  if a == some true || b == some true then some true
  else if a == some false && b == some false then some false else none

/-- Twin of `budgetSearch`: branch on the variable of the first literal of the first clause;
both branches are always explored. -/
def searchX : ℕ → CNF → Option Bool
  | 0, φ =>
    (match φ with
    | [] => some true
    | cl :: _ =>
      (match cl with
      | [] => some false
      | _ :: _ => none))
  | fuel + 1, φ =>
    (match φ with
    | [] => some true
    | cl :: _ =>
      (match cl with
      | [] => some false
      | l :: _ =>
        combineX (searchX fuel (restrictX l.1 false φ)) (searchX fuel (restrictX l.1 true φ))))

/-! ## 1. Completeness of the existing search -/

theorem litCount_eq_sum (φ : CNF) : litCount φ = (φ.map List.length).sum := by
  induction φ with
  | nil => rfl
  | cons c φ ih => simp [litCount, ih]

theorem restrict_cons_of_mem {x : ℕ} {b : Bool} {cl : Clause} (φ : CNF) (h : (x, b) ∈ cl) :
    restrict x b (cl :: φ) = restrict x b φ := by
  simp [restrict, h]

theorem restrict_cons_of_not_mem {x : ℕ} {b : Bool} {cl : Clause} (φ : CNF) (h : (x, b) ∉ cl) :
    restrict x b (cl :: φ) = (cl.filter fun l => decide (l.1 ≠ x)) :: restrict x b φ := by
  simp [restrict, h]

/-- `filter` and `map filter` never grow. -/
theorem litCount_restrict_le (x : ℕ) (b : Bool) (φ : CNF) :
    litCount (restrict x b φ) ≤ litCount φ := by
  induction φ with
  | nil => simp [restrict, litCount]
  | cons cl φ ih =>
    by_cases h : (x, b) ∈ cl
    · rw [restrict_cons_of_mem φ h]
      simp only [litCount]
      omega
    · rw [restrict_cons_of_not_mem φ h]
      simp only [litCount]
      have := List.length_filter_le (fun l : Literal => decide (l.1 ≠ x)) cl
      omega

/-- Key lemma: branching on the variable of the head literal strictly decreases the number of
literal occurrences, for both values. The head clause is deleted or loses its head literal. -/
theorem litCount_restrict_lt (x : ℕ) (v b : Bool) (c : Clause) (φ : CNF) :
    litCount (restrict x b (((x, v) :: c) :: φ)) < litCount (((x, v) :: c) :: φ) := by
  have hle := litCount_restrict_le x b φ
  by_cases h : (x, b) ∈ (x, v) :: c
  · rw [restrict_cons_of_mem φ h]
    simp only [litCount, List.length_cons]
    omega
  · rw [restrict_cons_of_not_mem φ h]
    have hf : ((x, v) :: c).filter (fun l : Literal => decide (l.1 ≠ x)) =
        c.filter (fun l : Literal => decide (l.1 ≠ x)) := by
      apply List.filter_cons_of_neg
      simp
    rw [hf]
    simp only [litCount, List.length_cons]
    have := List.length_filter_le (fun l : Literal => decide (l.1 ≠ x)) c
    omega

theorem combine_isSome {a b : Option Bool} (ha : a.isSome) (hb : b.isSome) :
    (combine a b).isSome := by
  cases a with
  | none => simp at ha
  | some a =>
    cases b with
    | none => simp at hb
    | some b => cases a <;> cases b <;> rfl

/-- Target 1. With fuel at least the number of literal occurrences, the search of the
foundation file always returns a definite answer. -/
theorem budgetSearch_isSome (φ : CNF) (fuel : ℕ) (h : litCount φ ≤ fuel) :
    (budgetSearch fuel φ).isSome := by
  induction fuel generalizing φ with
  | zero =>
    cases φ with
    | nil => rfl
    | cons c φ =>
      cases c with
      | nil => rfl
      | cons l c => simp [litCount] at h
  | succ fuel ih =>
    cases φ with
    | nil => rfl
    | cons c φ =>
      cases c with
      | nil => rfl
      | cons l c =>
        obtain ⟨x, v⟩ := l
        simp only [budgetSearch]
        apply combine_isSome
        · apply ih
          have := litCount_restrict_lt x v false c φ
          omega
        · apply ih
          have := litCount_restrict_lt x v true c φ
          omega

/-! ## 2. The CNF-level decider -/

theorem hasLit_eq (x : ℕ) (v : Bool) (c : Clause) : hasLit x v c = decide ((x, v) ∈ c) := by
  apply Bool.eq_iff_iff.mpr
  simp only [hasLit, List.any_eq_true, Bool.and_eq_true, beq_iff_eq, decide_eq_true_eq]
  constructor
  · rintro ⟨⟨y, w⟩, hl, h1, h2⟩
    simp only at h1 h2
    subst h1 h2
    exact hl
  · intro h
    exact ⟨(x, v), h, rfl, rfl⟩

theorem restrictX_eq (x : ℕ) (v : Bool) (φ : CNF) : restrictX x v φ = restrict x v φ := by
  have h1 : (fun c : Clause => !hasLit x v c) = (fun c : Clause => decide ((x, v) ∉ c)) := by
    funext c
    rw [hasLit_eq]
    simp
  have h2 : (fun l : Literal => !(l.1 == x)) = (fun l : Literal => decide (l.1 ≠ x)) := by
    funext l
    by_cases hx : l.1 = x <;> simp [hx]
  simp only [restrictX, restrict, h1, h2]

theorem combineX_eq (a b : Option Bool) : combineX a b = combine a b := by
  cases a with
  | none =>
    cases b with
    | none => rfl
    | some b => cases b <;> rfl
  | some a =>
    cases b with
    | none => cases a <;> rfl
    | some b => cases a <;> cases b <;> rfl

/-- The twin search is the search of the foundation file. -/
theorem searchX_eq (fuel : ℕ) (φ : CNF) : searchX fuel φ = budgetSearch fuel φ := by
  induction fuel generalizing φ with
  | zero =>
    cases φ with
    | nil => rfl
    | cons c φ => cases c <;> rfl
  | succ fuel ih =>
    cases φ with
    | nil => rfl
    | cons c φ =>
      cases c with
      | nil => rfl
      | cons l c =>
        obtain ⟨x, v⟩ := l
        simp only [searchX, budgetSearch, ih, restrictX_eq, combineX_eq]

/-- Target 2. The explicit CNF-level decider: run the search with fuel `litCount φ`.
By `decideSat_eq_budgetSearch` it is `budgetSearch (litCount φ) φ == some true`. -/
def decideSat (φ : CNF) : Bool := searchX (litCount φ) φ == some true

theorem decideSat_eq_budgetSearch (φ : CNF) :
    decideSat φ = (budgetSearch (litCount φ) φ == some true) := by
  simp only [decideSat, searchX_eq]

/-- Target 2. `decideSat` decides satisfiability of every CNF formula. -/
theorem decideSat_correct (φ : CNF) : Satisfiable φ ↔ decideSat φ = true := by
  rw [decideSat_eq_budgetSearch]
  have hsome := budgetSearch_isSome φ (litCount φ) le_rfl
  have hc := budgetSearch_correct (litCount φ) φ
  cases hres : budgetSearch (litCount φ) φ with
  | none => rw [hres] at hsome; simp at hsome
  | some b =>
    rw [hres] at hc
    simp only [AnswerCorrect] at hc
    rw [hc]
    cases b <;> simp

/-- The brief's literal definition, with the repository's `budgetSearch` and the sum of the
clause lengths as fuel. Same function as `decideSat` (`decideSat_eq_ref`); its axiom list
contains `Classical.choice` only because of the instance proof inside `restrict`. -/
def decideSatRef (φ : CNF) : Bool := budgetSearch (φ.map List.length).sum φ == some true

theorem decideSat_eq_ref (φ : CNF) : decideSat φ = decideSatRef φ := by
  rw [decideSat_eq_budgetSearch, decideSatRef, litCount_eq_sum]

/-! ## 3. Decoder for the project's binary encoding -/

/-- Value of a list of binary digits, least significant first. -/
def ofBits : List Bool → ℕ
  | [] => 0
  | b :: bs => Nat.bit b (ofBits bs)

theorem ofBits_bits (n : ℕ) : ofBits (Nat.bits n) = n := by
  induction n using Nat.binaryRec' with
  | zero => simp [ofBits]
  | bit b n h ih => rw [Nat.bits_append_bit n b h, ofBits, ih]

/-- The decoder loop. The input is read in pairs of bits: `[true, d]` is a digit `d`,
`[false, true]` ends a literal, `[false, false]` ends a clause. State: `none` between literals,
`some (p, ds)` inside a literal with polarity `p` whose variable digits read so far are `ds`
(least significant first); `cl` holds the literals of the current clause read so far.
`none` is returned on an odd number of bits, on an end-of-literal outside a literal, on an
end-of-clause inside a literal, and at the end of the input inside a clause. -/
def decodeGo : List Bool → Option (Bool × List Bool) → Clause → Option CNF
  | [], st, cl =>
    (match st with
    | none =>
      (match cl with
      | [] => some []
      | _ :: _ => none)
    | some _ => none)
  | [_], _, _ => none
  | b :: d :: rest, st, cl =>
    (match b with
    | true =>
      (match st with
      | none => decodeGo rest (some (d, [])) cl
      | some pd => decodeGo rest (some (pd.1, pd.2 ++ [d])) cl)
    | false =>
      (match d with
      | true =>
        (match st with
        | none => none
        | some pd => decodeGo rest none (cl ++ [(ofBits pd.2, pd.1)]))
      | false =>
        (match st with
        | none => (decodeGo rest none []).map (fun φ => cl :: φ)
        | some _ => none)))

/-- Target 3. The decoder: total on all bit strings, `none` on malformed input. It accepts
digit strings with leading zeros; `satRun` and `decodeExact` reject them by re-encoding. -/
def decodeCNF (x : List Bool) : Option CNF := decodeGo x none []

theorem decodeGo_digit_none (d : Bool) (rest : List Bool) (cl : Clause) :
    decodeGo (true :: d :: rest) none cl = decodeGo rest (some (d, [])) cl := rfl

theorem decodeGo_digit_some (d p : Bool) (ds rest : List Bool) (cl : Clause) :
    decodeGo (true :: d :: rest) (some (p, ds)) cl = decodeGo rest (some (p, ds ++ [d])) cl := rfl

theorem decodeGo_endLit (p : Bool) (ds rest : List Bool) (cl : Clause) :
    decodeGo (false :: true :: rest) (some (p, ds)) cl =
      decodeGo rest none (cl ++ [(ofBits ds, p)]) := rfl

theorem decodeGo_endClause (rest : List Bool) (cl : Clause) :
    decodeGo (false :: false :: rest) none cl =
      (decodeGo rest none []).map (fun φ => cl :: φ) := rfl

theorem decodeGo_digits (ds' : List Bool) (p : Bool) (ds rest : List Bool) (cl : Clause) :
    decodeGo ((ds'.flatMap fun d => [true, d]) ++ rest) (some (p, ds)) cl =
      decodeGo rest (some (p, ds ++ ds')) cl := by
  induction ds' generalizing ds with
  | nil => simp
  | cons d ds' ih =>
    rw [List.flatMap_cons]
    show decodeGo (true :: d :: ((ds'.flatMap fun d => [true, d]) ++ rest)) (some (p, ds)) cl = _
    rw [decodeGo_digit_some, ih]
    simp

theorem decodeGo_literal (l : Literal) (rest : List Bool) (cl : Clause) :
    decodeGo (encodeLiteral l ++ rest) none cl = decodeGo rest none (cl ++ [l]) := by
  obtain ⟨i, p⟩ := l
  show decodeGo (true :: p :: (((Nat.bits i).flatMap fun d => [true, d]) ++ [false, true]) ++ rest)
    none cl = _
  rw [List.cons_append, List.cons_append, List.append_assoc, decodeGo_digit_none, decodeGo_digits]
  show decodeGo (false :: true :: rest) (some (p, [] ++ Nat.bits i)) cl = _
  rw [decodeGo_endLit, List.nil_append, ofBits_bits]

theorem decodeGo_literals (c : Clause) (rest : List Bool) (cl : Clause) :
    decodeGo (c.flatMap encodeLiteral ++ rest) none cl = decodeGo rest none (cl ++ c) := by
  induction c generalizing cl with
  | nil => simp
  | cons l c ih =>
    rw [List.flatMap_cons, List.append_assoc, decodeGo_literal, ih]
    simp

theorem decodeGo_clause (c : Clause) (rest : List Bool) :
    decodeGo (encodeClause c ++ rest) none [] =
      (decodeGo rest none []).map (fun φ => c :: φ) := by
  rw [encodeClause, List.append_assoc, decodeGo_literals]
  show decodeGo (false :: false :: rest) none ([] ++ c) = _
  rw [decodeGo_endClause, List.nil_append]

/-- Target 3. The decoder inverts the project's encoder. -/
theorem decodeCNF_encodeCNF (φ : CNF) : decodeCNF (encodeCNF φ) = some φ := by
  unfold decodeCNF
  induction φ with
  | nil => rfl
  | cons c φ ih =>
    have h : encodeCNF (c :: φ) = encodeClause c ++ encodeCNF φ := by
      simp [encodeCNF]
    rw [h, decodeGo_clause, ih]
    rfl

/-! ## 4. The total decider on bit strings -/

/-- Binary digits of `n`, least significant first, no leading zeros, by explicit fuel.
Twin of `Nat.bits` (`bitsX_eq`). -/
def bitsAux : ℕ → ℕ → List Bool
  | 0, _ => []
  | fuel + 1, n => if n = 0 then [] else (n % 2 == 1) :: bitsAux fuel (n / 2)

/-- Twin of `Nat.bits`. -/
def bitsX (n : ℕ) : List Bool := bitsAux n n

/-- Twin of `encodeLiteral`. -/
def encodeLiteralX (l : Literal) : List Bool :=
  [true, l.2] ++ ((bitsX l.1).flatMap fun d => [true, d]) ++ [false, true]

/-- Twin of `encodeClause`. -/
def encodeClauseX (c : Clause) : List Bool :=
  c.flatMap encodeLiteralX ++ [false, false]

/-- Twin of `encodeCNF`. -/
def encodeCNFX (φ : CNF) : List Bool :=
  φ.flatMap encodeClauseX

theorem bitsAux_eq (fuel n : ℕ) (h : n ≤ fuel) : bitsAux fuel n = Nat.bits n := by
  induction fuel generalizing n with
  | zero =>
    obtain rfl : n = 0 := by omega
    simp [bitsAux]
  | succ fuel ih =>
    by_cases hn : n = 0
    · subst hn
      simp [bitsAux]
    · have h2 : n / 2 ≤ fuel := by omega
      have hbit : Nat.bit (n % 2 == 1) (n / 2) = n := by
        rcases Nat.mod_two_eq_zero_or_one n with h0 | h1
        · rw [h0]
          show 2 * (n / 2) = n
          omega
        · rw [h1]
          show 2 * (n / 2) + 1 = n
          omega
      have hb : n / 2 = 0 → (n % 2 == 1) = true := by
        intro h0
        have h1 : n % 2 = 1 := by omega
        rw [h1]
        rfl
      show (if n = 0 then [] else (n % 2 == 1) :: bitsAux fuel (n / 2)) = Nat.bits n
      rw [ite_eq_right hn, ih _ h2, ← Nat.bits_append_bit _ _ hb, hbit]

theorem bitsX_eq (n : ℕ) : bitsX n = Nat.bits n := bitsAux_eq n n le_rfl

theorem encodeLiteralX_eq (l : Literal) : encodeLiteralX l = encodeLiteral l := by
  simp only [encodeLiteralX, encodeLiteral, bitsX_eq]

theorem encodeClauseX_eq (c : Clause) : encodeClauseX c = encodeClause c := by
  have h : encodeLiteralX = encodeLiteral := funext encodeLiteralX_eq
  simp only [encodeClauseX, encodeClause, h]

/-- The twin encoder is the project's encoder. -/
theorem encodeCNFX_eq (φ : CNF) : encodeCNFX φ = encodeCNF φ := by
  have h : encodeClauseX = encodeClause := funext encodeClauseX_eq
  simp only [encodeCNFX, encodeCNF, h]

/-- Target 4. The explicit total decider on bit strings. Decode (malformed strings are
rejected); re-encode and compare (every non-canonical string is rejected); decide the formula.
By `satRun_eq_ref` this is the brief's function, written with `encodeCNF` and `budgetSearch`. -/
def satRun (x : List Bool) : Bool :=
  match decodeCNF x with
  | some φ => (encodeCNFX φ == x) && decideSat φ
  | none => false

/-- The brief's literal definition of the bit-level decider. Same function as `satRun`
(`satRun_eq_ref`); its axiom list is not empty only because of `Nat.bits` and `restrict`. -/
def satRunRef (x : List Bool) : Bool :=
  match decodeCNF x with
  | some φ => (encodeCNF φ == x) && decideSatRef φ
  | none => false

theorem satRun_eq_ref (x : List Bool) : satRun x = satRunRef x := by
  unfold satRun satRunRef
  cases decodeCNF x with
  | none => rfl
  | some φ => simp only [encodeCNFX_eq, decideSat_eq_ref]

/-- `satRun`, stated with the project's own `encodeCNF` and `budgetSearch`. -/
theorem satRun_eq_spec (x : List Bool) :
    satRun x =
      (match decodeCNF x with
      | some φ => (encodeCNF φ == x) && (budgetSearch (litCount φ) φ == some true)
      | none => false) := by
  unfold satRun
  cases decodeCNF x with
  | none => rfl
  | some φ => simp only [encodeCNFX_eq, decideSat_eq_budgetSearch]

/-- Target 4. Correctness on ALL bit strings, including malformed and non-canonical ones. -/
theorem satRun_correct (x : List Bool) : x ∈ SAT ↔ satRun x = true := by
  constructor
  · rintro ⟨φ, rfl, hsat⟩
    unfold satRun
    rw [decodeCNF_encodeCNF]
    simp [encodeCNFX_eq, (decideSat_correct φ).mp hsat]
  · intro h
    unfold satRun at h
    cases hd : decodeCNF x with
    | none =>
      rw [hd] at h
      simp at h
    | some φ =>
      rw [hd] at h
      simp only [Bool.and_eq_true, beq_iff_eq] at h
      exact ⟨φ, by rw [← encodeCNFX_eq]; exact h.1, (decideSat_correct φ).mpr h.2⟩

/-- Target 4. The candidate interface of the foundation file is inhabited. This is
decidability by an exponential procedure, not a complexity result. -/
def satDecider : CorrectBitDecider := ⟨satRun, satRun_correct⟩

theorem satDecider_run : satDecider.run = satRun := rfl

/-- Every correct bit decider computes the same function as `satDecider`. -/
theorem run_eq_satRun (c : CorrectBitDecider) : c.run = satRun := by
  funext x
  exact Bool.eq_iff_iff.mpr ((c.correct x).symm.trans (satRun_correct x))

/-! ## 5. Honest size statement: the procedure is exponential -/

/-- Number of calls of the search on `(fuel, φ)`, the root call included. It has the recursion
of `budgetSearch`: both branches are always explored. -/
def searchCalls : ℕ → CNF → ℕ
  | _, [] => 1
  | _, [] :: _ => 1
  | 0, (_ :: _) :: _ => 1
  | fuel + 1, ((x, v) :: c) :: φ =>
      1 + searchCalls fuel (restrict x false (((x, v) :: c) :: φ))
        + searchCalls fuel (restrict x true (((x, v) :: c) :: φ))

/-- The search instrumented with a call counter. -/
def budgetSearchCounted : ℕ → CNF → Option Bool × ℕ
  | _, [] => (some true, 1)
  | _, [] :: _ => (some false, 1)
  | 0, (_ :: _) :: _ => (none, 1)
  | fuel + 1, ((x, v) :: c) :: φ =>
      (combine (budgetSearchCounted fuel (restrict x false (((x, v) :: c) :: φ))).1
          (budgetSearchCounted fuel (restrict x true (((x, v) :: c) :: φ))).1,
        1 + (budgetSearchCounted fuel (restrict x false (((x, v) :: c) :: φ))).2
          + (budgetSearchCounted fuel (restrict x true (((x, v) :: c) :: φ))).2)

/-- The instrumented search returns the answer of `budgetSearch` and the count `searchCalls`. -/
theorem budgetSearchCounted_eq (fuel : ℕ) (φ : CNF) :
    budgetSearchCounted fuel φ = (budgetSearch fuel φ, searchCalls fuel φ) := by
  induction fuel generalizing φ with
  | zero =>
    cases φ with
    | nil => rfl
    | cons c φ => cases c <;> rfl
  | succ fuel ih =>
    cases φ with
    | nil => rfl
    | cons c φ =>
      cases c with
      | nil => rfl
      | cons l c =>
        obtain ⟨x, v⟩ := l
        simp only [budgetSearchCounted, budgetSearch, searchCalls, ih]

theorem searchCalls_lt (fuel : ℕ) (φ : CNF) : searchCalls fuel φ < 2 ^ (fuel + 1) := by
  induction fuel generalizing φ with
  | zero =>
    cases φ with
    | nil => simp [searchCalls]
    | cons c φ => cases c <;> simp [searchCalls]
  | succ fuel ih =>
    have hpos : 0 < 2 ^ (fuel + 1) := by positivity
    have hpow : 2 ^ (fuel + 1 + 1) = 2 * 2 ^ (fuel + 1) := by ring
    cases φ with
    | nil =>
      simp only [searchCalls]
      omega
    | cons c φ =>
      cases c with
      | nil =>
        simp only [searchCalls]
        omega
      | cons l c =>
        obtain ⟨x, v⟩ := l
        simp only [searchCalls]
        have h1 := ih (restrict x false (((x, v) :: c) :: φ))
        have h2 := ih (restrict x true (((x, v) :: c) :: φ))
        omega

/-- Target 5. EXPONENTIAL upper bound on the number of calls (not a polynomial bound). -/
theorem searchCalls_le (fuel : ℕ) (φ : CNF) : searchCalls fuel φ ≤ 2 ^ (fuel + 1) :=
  (searchCalls_lt fuel φ).le

theorem length_flatMap_digit (ds : List Bool) :
    (ds.flatMap fun d => [true, d]).length = 2 * ds.length := by
  induction ds with
  | nil => rfl
  | cons d ds ih =>
    rw [List.flatMap_cons, List.length_append, ih]
    simp only [List.length_cons, List.length_nil]
    omega

theorem length_encodeLiteral (l : Literal) :
    (encodeLiteral l).length = 2 * (Nat.bits l.1).length + 4 := by
  simp only [encodeLiteral, List.length_append, length_flatMap_digit, List.length_cons,
    List.length_nil]
  omega

theorem four_mul_length_le_flatMap (c : Clause) :
    4 * c.length ≤ (c.flatMap encodeLiteral).length := by
  induction c with
  | nil => simp
  | cons l c ih =>
    rw [List.flatMap_cons, List.length_append, length_encodeLiteral, List.length_cons]
    omega

/-- Every literal occurrence costs at least four input bits. -/
theorem four_mul_litCount_le_length (φ : CNF) : 4 * litCount φ ≤ (encodeCNF φ).length := by
  induction φ with
  | nil => simp [litCount]
  | cons c φ ih =>
    have h : encodeCNF (c :: φ) = encodeClause c ++ encodeCNF φ := by
      simp [encodeCNF]
    have hc := four_mul_length_le_flatMap c
    rw [h, List.length_append, encodeClause, List.length_append]
    simp only [litCount]
    omega

/-- EXPONENTIAL upper bound in the input bit length `n = (encodeCNF φ).length`: the search of
the decider makes at most `2 ^ (n / 4 + 1)` calls. -/
theorem searchCalls_le_two_pow_length (φ : CNF) :
    searchCalls (litCount φ) φ ≤ 2 ^ ((encodeCNF φ).length / 4 + 1) := by
  have h := four_mul_litCount_le_length φ
  have h2 : litCount φ + 1 ≤ (encodeCNF φ).length / 4 + 1 := by omega
  exact (searchCalls_le _ _).trans (Nat.pow_le_pow_right (by norm_num) h2)

/-- A family of trivially satisfiable formulas: `n` tautological clauses on distinct variables. -/
def tautFamily : ℕ → CNF
  | 0 => []
  | n + 1 => [(n, true), (n, false)] :: tautFamily n

theorem tautFamily_satisfiable (n : ℕ) : Satisfiable (tautFamily n) := by
  refine ⟨fun _ => true, ?_⟩
  induction n with
  | zero => rfl
  | succ n ih =>
    show (Clause.eval (fun _ => true) [(n, true), (n, false)] &&
      CNF.eval (fun _ => true) (tautFamily n)) = true
    rw [ih]
    rfl

theorem litCount_tautFamily (n : ℕ) : litCount (tautFamily n) = 2 * n := by
  induction n with
  | zero => rfl
  | succ n ih =>
    simp only [tautFamily, litCount, ih, List.length_cons, List.length_nil]
    omega

theorem restrict_tautFamily (n x : ℕ) (b : Bool) (h : n ≤ x) :
    restrict x b (tautFamily n) = tautFamily n := by
  induction n with
  | zero => simp [tautFamily, restrict]
  | succ n ih =>
    have hne : n ≠ x := by omega
    have hmem : (x, b) ∉ [(n, true), (n, false)] := by
      simp only [List.mem_cons, Prod.mk.injEq, List.not_mem_nil, or_false, not_or, not_and]
      exact ⟨fun hx => absurd hx.symm hne, fun hx => absurd hx.symm hne⟩
    have hfil : [(n, true), (n, false)].filter (fun l : Literal => decide (l.1 ≠ x)) =
        [(n, true), (n, false)] := by
      simp [hne]
    show restrict x b ([(n, true), (n, false)] :: tautFamily n) = _
    rw [restrict_cons_of_not_mem _ hmem, hfil, ih (by omega)]
    rfl

/-- On `n` tautological clauses the search makes exactly `2 ^ (n + 1) - 1` calls, for every
fuel that suffices. -/
theorem searchCalls_tautFamily (n fuel : ℕ) (h : n ≤ fuel) :
    searchCalls fuel (tautFamily n) = 2 ^ (n + 1) - 1 := by
  induction n generalizing fuel with
  | zero => cases fuel <;> rfl
  | succ n ih =>
    obtain ⟨fuel, rfl⟩ : ∃ k, fuel = k + 1 := ⟨fuel - 1, by omega⟩
    have hmem : ∀ b : Bool, (n, b) ∈ [(n, true), (n, false)] := by
      intro b
      cases b <;> simp
    have hres : ∀ b : Bool,
        restrict n b ([(n, true), (n, false)] :: tautFamily n) = tautFamily n := by
      intro b
      rw [restrict_cons_of_mem _ (hmem b), restrict_tautFamily n n b le_rfl]
    show searchCalls (fuel + 1) ([(n, true), (n, false)] :: tautFamily n) = _
    simp only [searchCalls, hres, ih fuel (by omega)]
    have hpos : 0 < 2 ^ (n + 1) := by positivity
    have hpow : 2 ^ (n + 1 + 1) = 2 * 2 ^ (n + 1) := by ring
    omega

theorem searchCalls_decider_tautFamily (n : ℕ) :
    searchCalls (litCount (tautFamily n)) (tautFamily n) = 2 ^ (n + 1) - 1 :=
  searchCalls_tautFamily n _ (by rw [litCount_tautFamily]; omega)

theorem bits_length_le (i : ℕ) : (Nat.bits i).length ≤ i := by
  rw [Nat.size_eq_bits_len]
  exact Nat.size_le.mpr Nat.lt_two_pow_self

theorem length_encode_tautFamily (n : ℕ) :
    (encodeCNF (tautFamily n)).length ≤ n * (4 * n + 10) := by
  induction n with
  | zero => simp [tautFamily, encodeCNF]
  | succ n ih =>
    have hb := bits_length_le n
    have h : encodeCNF (tautFamily (n + 1)) =
        encodeClause [(n, true), (n, false)] ++ encodeCNF (tautFamily n) := by
      simp [tautFamily, encodeCNF]
    have h1 : (encodeCNF (tautFamily (n + 1))).length =
        (2 * (Nat.bits n).length + 4) + (2 * (Nat.bits n).length + 4) + 2 +
          (encodeCNF (tautFamily n)).length := by
      simp only [h, encodeClause, List.flatMap_cons, List.flatMap_nil, List.length_append,
        length_encodeLiteral, List.length_cons, List.length_nil]
    have hring : (n + 1) * (4 * (n + 1) + 10) = n * (4 * n + 10) + 8 * n + 14 := by ring
    rw [h1, hring]
    omega

/-- EXPONENTIAL lower bound for THIS procedure in terms of the input bit length: for every `n`
there is a satisfiable input of at most `n * (4 * n + 10)` bits, accepted by `satRun`, on which
the search of the decider makes exactly `2 ^ (n + 1) - 1` calls. This is a statement about this
procedure only; it is not a lower bound for SAT. -/
theorem exponential_family (n : ℕ) :
    (encodeCNF (tautFamily n)).length ≤ n * (4 * n + 10) ∧
      satRun (encodeCNF (tautFamily n)) = true ∧
      searchCalls (litCount (tautFamily n)) (tautFamily n) = 2 ^ (n + 1) - 1 :=
  ⟨length_encode_tautFamily n,
    (satRun_correct _).mp ⟨tautFamily n, rfl, tautFamily_satisfiable n⟩,
    searchCalls_decider_tautFamily n⟩

/-! ## 6. Definitional glue: the missing lemma as one proposition -/

/-- Target 6. A degree bound for a correct bit decider puts SAT in P. This is glue: it does NOT
prove `SAT ∈ P`, and no `DegreeBound` is constructed anywhere in this file. -/
theorem sat_mem_P_of_degreeBound (c : CorrectBitDecider) (d : ℕ) (h : DegreeBound c d) :
    SAT ∈ PEqualNP.Library.P := by
  refine ⟨c.run, c.correct, ⟨⟨h.machine.toTM2ComputableAux,
    Polynomial.C h.scale * Polynomial.X ^ d + Polynomial.C h.scale, fun a => ?_⟩⟩⟩
  refine ⟨(h.machine.outputsFun a).toEvalsTo,
    (h.machine.outputsFun a).steps_le_m.trans ((h.bound _).trans ?_)⟩
  simp

/-- The missing lemma as a single proposition about the explicit decider of this file. -/
theorem sat_mem_P_of_missing_lemma (h : Nonempty (DegreeBound satDecider 3)) :
    SAT ∈ PEqualNP.Library.P :=
  h.elim fun b => sat_mem_P_of_degreeBound satDecider 3 b

/-- A polynomial with natural coefficients is bounded by `s * n ^ d + s`, with `d` its degree
and `s` the sum of its coefficients. -/
theorem poly_eval_le (p : Polynomial ℕ) (n : ℕ) :
    p.eval n ≤ p.eval 1 * n ^ p.natDegree + p.eval 1 := by
  have hpow : ∀ i ∈ Finset.range (p.natDegree + 1), n ^ i ≤ n ^ p.natDegree + 1 := by
    intro i hi
    have hi' : i ≤ p.natDegree := Nat.lt_succ_iff.mp (Finset.mem_range.mp hi)
    rcases Nat.eq_zero_or_pos n with rfl | hn
    · rcases Nat.eq_zero_or_pos i with rfl | hi0
      · simp
      · simp [Nat.pos_iff_ne_zero.mp hi0]
    · exact (Nat.pow_le_pow_right hn hi').trans (Nat.le_succ _)
  calc p.eval n = ∑ i ∈ Finset.range (p.natDegree + 1), p.coeff i * n ^ i :=
        Polynomial.eval_eq_sum_range n
    _ ≤ ∑ i ∈ Finset.range (p.natDegree + 1), p.coeff i * (n ^ p.natDegree + 1) :=
        Finset.sum_le_sum fun i hi => Nat.mul_le_mul_left _ (hpow i hi)
    _ = (∑ i ∈ Finset.range (p.natDegree + 1), p.coeff i) * (n ^ p.natDegree + 1) := by
        rw [Finset.sum_mul]
    _ = p.eval 1 * (n ^ p.natDegree + 1) := by
        rw [Polynomial.eval_eq_sum_range]
        simp
    _ = p.eval 1 * n ^ p.natDegree + p.eval 1 := by ring

/-- Honest scope of the missing lemma: a degree bound for the explicit decider exists, for some
degree, exactly when `SAT ∈ P`. The explicit decider therefore adds NO complexity content: what
remains to be proved is equivalent to the open statement itself. -/
theorem sat_mem_P_iff_degreeBound :
    SAT ∈ PEqualNP.Library.P ↔ ∃ d : ℕ, Nonempty (DegreeBound satDecider d) := by
  constructor
  · rintro ⟨f, hf, ⟨m⟩⟩
    have hfe : f = satRun := by
      funext x
      exact Bool.eq_iff_iff.mpr ((hf x).symm.trans (satRun_correct x))
    subst hfe
    exact ⟨m.time.natDegree,
      ⟨⟨m.toTM2ComputableInTime, m.time.eval 1, fun n => poly_eval_le m.time n⟩⟩⟩
  · rintro ⟨d, ⟨h⟩⟩
    exact sat_mem_P_of_degreeBound satDecider d h

/-! ## 7. Ingredients of the summary theorem -/

/-- Totality with an explicit fuel bound. -/
theorem budgetSearch_ne_none (fuel : ℕ) (φ : CNF) (h : (φ.map List.length).sum ≤ fuel) :
    budgetSearch fuel φ ≠ none := by
  intro hnone
  have hsome := budgetSearch_isSome φ fuel (by rw [litCount_eq_sum]; exact h)
  rw [hnone] at hsome
  simp at hsome

theorem satisfiable_iff_budgetSearch (φ : CNF) :
    Satisfiable φ ↔ budgetSearch (φ.map List.length).sum φ = some true := by
  rw [← litCount_eq_sum, decideSat_correct, decideSat_eq_budgetSearch]
  simp

/-- Exact decoder: `some φ` exactly on the canonical encoding of `φ`, and `none` on every other
bit string, malformed or non-canonical. -/
def decodeExact (x : List Bool) : Option CNF :=
  match decodeCNF x with
  | some φ => if encodeCNFX φ == x then some φ else none
  | none => none

theorem decodeExact_eq_some_iff (x : List Bool) (φ : CNF) :
    decodeExact x = some φ ↔ encodeCNF φ = x := by
  constructor
  · intro h
    unfold decodeExact at h
    cases hd : decodeCNF x with
    | none =>
      rw [hd] at h
      simp at h
    | some ψ =>
      rw [hd] at h
      by_cases hx : encodeCNFX ψ = x
      · simp only [hx, beq_self_eq_true, ite_true, Option.some.injEq] at h
        subst h
        rw [← encodeCNFX_eq]
        exact hx
      · simp [hx] at h
  · rintro rfl
    unfold decodeExact
    rw [decodeCNF_encodeCNF]
    simp [encodeCNFX_eq]

theorem mem_SAT_iff_decodeExact (x : List Bool) :
    x ∈ SAT ↔ ∃ φ, decodeExact x = some φ ∧
      budgetSearch (φ.map List.length).sum φ = some true := by
  constructor
  · rintro ⟨φ, rfl, hsat⟩
    exact ⟨φ, (decodeExact_eq_some_iff _ φ).mpr rfl, (satisfiable_iff_budgetSearch φ).mp hsat⟩
  · rintro ⟨φ, hdec, hs⟩
    exact ⟨φ, (decodeExact_eq_some_iff x φ).mp hdec, (satisfiable_iff_budgetSearch φ).mpr hs⟩

/-- `satRun` is the exact decoder followed by the CNF-level decider. -/
theorem satRun_eq_decodeExact (x : List Bool) :
    satRun x = (match decodeExact x with
      | some φ => decideSat φ
      | none => false) := by
  unfold satRun decodeExact
  cases decodeCNF x with
  | none => rfl
  | some φ =>
    by_cases hx : encodeCNFX φ = x
    · simp [hx]
    · simp [hx]

/-! ## Kernel-checked evaluations (no compiler in the trusted base) -/

example : satRun [] = true := by decide
example : satRun [false, false] = false := by decide
example : satRun [true] = false := by decide
example : satRun [true, true, false, true, false, false] = true := by decide
example : satRun [true, true, true, false, false, true, false, false] = false := by decide
example : satRun [true, true, true, true, true, false, false, true, false, false] = false := by
  decide
example : satRun [true, true, false, true] = false := by decide
example : satRun [false, true, false, false] = false := by decide
example : satRun [true, true, false, false] = false := by decide
example : satRun (encodeCNFX [[(0, true), (1, true)], [(0, false), (1, false)]]) = true := by
  decide
example : satRun (encodeCNFX [[(0, true), (1, true)], [(0, true), (1, false)],
    [(0, false), (1, true)], [(0, false), (1, false)]]) = false := by
  decide

end PEqualNP.Outside.L_alg001_fable

/-- Summary: decidability of SAT by an explicit EXPONENTIAL procedure. NOT a complexity result
and NOT `SAT ∈ P`. The search of the foundation statement, with the same recurrence, is total
with the explicit fuel `(φ.map List.length).sum`, so it decides satisfiability of every CNF
formula; and there is an exact decoder for the binary encoding, so membership of an arbitrary
bit string in `SAT` is `decode` followed by `search`. -/
theorem PEqualNP.Outside.L_alg001_fable_decider :
    ∃ search : ℕ → PEqualNP.Search.CNF → Option Bool,
      (∀ fuel, search fuel [] = some true) ∧
      (∀ fuel φ, search fuel ([] :: φ) = some false) ∧
      (∀ x v c φ, search 0 (((x, v) :: c) :: φ) = none) ∧
      (∀ fuel x v c φ,
        search (fuel + 1) (((x, v) :: c) :: φ) =
          let left := search fuel
              (((((x, v) :: c) :: φ).filter fun d => decide ((x, false) ∉ d)).map
                fun d => d.filter fun l => decide (l.1 ≠ x))
          let right := search fuel
              (((((x, v) :: c) :: φ).filter fun d => decide ((x, true) ∉ d)).map
                fun d => d.filter fun l => decide (l.1 ≠ x))
          if left = some true ∨ right = some true then some true
          else if left = some false ∧ right = some false then some false else none) ∧
      (∀ fuel φ, search fuel φ = some true → PEqualNP.Search.Satisfiable φ) ∧
      (∀ fuel φ, search fuel φ = some false → ¬ PEqualNP.Search.Satisfiable φ) ∧
      (∀ (fuel : ℕ) (φ : PEqualNP.Search.CNF),
        (φ.map List.length).sum ≤ fuel → search fuel φ ≠ none) ∧
      (∀ φ, ∃ fuel, search fuel φ ≠ none) ∧
      (∀ φ : PEqualNP.Search.CNF,
        PEqualNP.Search.Satisfiable φ ↔ search (φ.map List.length).sum φ = some true) ∧
      ∃ decode : List Bool → Option PEqualNP.Search.CNF,
        (∀ (x : List Bool) (φ : PEqualNP.Search.CNF),
          decode x = some φ ↔ PEqualNP.Search.encodeCNF φ = x) ∧
        (∀ x : List Bool, x ∈ PEqualNP.Search.SAT ↔
          ∃ φ : PEqualNP.Search.CNF,
            decode x = some φ ∧ search (φ.map List.length).sum φ = some true) := by
  refine ⟨PEqualNP.Outside.L_alg001_residual.budgetSearch, ?_, ?_, ?_, ?_,
    PEqualNP.Outside.L_alg001_residual.budgetSearch_true,
    PEqualNP.Outside.L_alg001_residual.budgetSearch_false,
    PEqualNP.Outside.L_alg001_fable.budgetSearch_ne_none, ?_,
    PEqualNP.Outside.L_alg001_fable.satisfiable_iff_budgetSearch,
    PEqualNP.Outside.L_alg001_fable.decodeExact,
    PEqualNP.Outside.L_alg001_fable.decodeExact_eq_some_iff,
    PEqualNP.Outside.L_alg001_fable.mem_SAT_iff_decodeExact⟩
  · intro fuel; cases fuel <;> rfl
  · intro fuel φ; cases fuel <;> rfl
  · intros; rfl
  · intros; exact PEqualNP.Outside.L_alg001_residual.combine_eq _ _
  · intro φ
    exact ⟨(φ.map List.length).sum,
      PEqualNP.Outside.L_alg001_fable.budgetSearch_ne_none _ φ le_rfl⟩

/-! ## Recorded evaluations (compiled code; see the kernel-checked `example`s above) -/

open PEqualNP.Search PEqualNP.Outside.L_alg001_fable in
#eval ("E01 empty string (= encodeCNF [])", satRun [])
open PEqualNP.Search PEqualNP.Outside.L_alg001_fable in
#eval ("E02 encodeCNF [[]] (empty clause)", encodeCNF [[]], satRun (encodeCNF [[]]))
open PEqualNP.Search PEqualNP.Outside.L_alg001_fable in
#eval ("E03 satisfiable 2-variable formula (x0 or x1) and (not x0 or not x1)",
  satRun (encodeCNF [[(0, true), (1, true)], [(0, false), (1, false)]]))
open PEqualNP.Search PEqualNP.Outside.L_alg001_fable in
#eval ("E04 unsatisfiable 2-variable formula (all four sign patterns)",
  satRun (encodeCNF [[(0, true), (1, true)], [(0, true), (1, false)],
    [(0, false), (1, true)], [(0, false), (1, false)]]))
open PEqualNP.Search PEqualNP.Outside.L_alg001_fable in
#eval ("E05 malformed: odd length [true]", satRun [true])
open PEqualNP.Search PEqualNP.Outside.L_alg001_fable in
#eval ("E06 canonical encoding of [[(0, true)]]", encodeCNF [[(0, true)]],
  satRun (encodeCNF [[(0, true)]]))
open PEqualNP.Search PEqualNP.Outside.L_alg001_fable in
#eval ("E07 non-canonical: variable 0 written with one digit 0",
  decodeCNF [true, true, true, false, false, true, false, false],
  satRun [true, true, true, false, false, true, false, false])
open PEqualNP.Search PEqualNP.Outside.L_alg001_fable in
#eval ("E08 canonical encoding of [[(1, true)]]", encodeCNF [[(1, true)]],
  satRun (encodeCNF [[(1, true)]]))
open PEqualNP.Search PEqualNP.Outside.L_alg001_fable in
#eval ("E09 non-canonical: variable 1 written as digits 1,0 (leading zero)",
  decodeCNF [true, true, true, true, true, false, false, true, false, false],
  satRun [true, true, true, true, true, false, false, true, false, false])
open PEqualNP.Search PEqualNP.Outside.L_alg001_fable in
#eval ("E10 malformed: literal without end of clause", satRun [true, true, false, true])
open PEqualNP.Search PEqualNP.Outside.L_alg001_fable in
#eval ("E11 malformed: end of literal outside a literal", satRun [false, true, false, false])
open PEqualNP.Search PEqualNP.Outside.L_alg001_fable in
#eval ("E12 malformed: end of clause inside a literal", satRun [true, true, false, false])
open PEqualNP.Search PEqualNP.Outside.L_alg001_fable in
#eval ("E13 contradictory units on variable 1000000",
  satRun (encodeCNF [[(1000000, true)], [(1000000, false)]]))
open PEqualNP.Search PEqualNP.Outside.L_alg001_fable in
#eval ("E14 tautological clause", satRun (encodeCNF [[(0, true), (0, false)]]))
open PEqualNP.Search PEqualNP.Outside.L_alg001_fable in
#eval ("E15 satRun agrees with satRunRef on E01..E14 inputs",
  ([[], encodeCNF [[]], encodeCNF [[(0, true), (1, true)], [(0, false), (1, false)]],
    encodeCNF [[(0, true), (1, true)], [(0, true), (1, false)], [(0, false), (1, true)],
      [(0, false), (1, false)]], [true], encodeCNF [[(0, true)]],
    [true, true, true, false, false, true, false, false], encodeCNF [[(1, true)]],
    [true, true, true, true, true, false, false, true, false, false],
    [true, true, false, true], [false, true, false, false], [true, true, false, false],
    encodeCNF [[(1000000, true)], [(1000000, false)]],
    encodeCNF [[(0, true), (0, false)]]] : List (List Bool)).all
      fun x => satRun x == satRunRef x)
open PEqualNP.Search PEqualNP.Outside.L_alg001_fable in
#eval ("E16 calls of the search on tautFamily n, n = 0..10 (= 2^(n+1) - 1)",
  (List.range 11).map fun n => (budgetSearchCounted (litCount (tautFamily n)) (tautFamily n)).2)
open PEqualNP.Search PEqualNP.Outside.L_alg001_fable in
#eval ("E17 input bits of encodeCNF (tautFamily n), n = 0..10",
  (List.range 11).map fun n => (encodeCNF (tautFamily n)).length)

/-! ## Axiom audit -/

-- Executable definitions on the path of `satRun`: expected to depend on no axioms.
#print axioms PEqualNP.Outside.L_alg001_fable.litCount
#print axioms PEqualNP.Outside.L_alg001_fable.restrictX
#print axioms PEqualNP.Outside.L_alg001_fable.combineX
#print axioms PEqualNP.Outside.L_alg001_fable.searchX
#print axioms PEqualNP.Outside.L_alg001_fable.decideSat
#print axioms PEqualNP.Outside.L_alg001_fable.ofBits
#print axioms PEqualNP.Outside.L_alg001_fable.decodeGo
#print axioms PEqualNP.Outside.L_alg001_fable.decodeCNF
#print axioms PEqualNP.Outside.L_alg001_fable.bitsX
#print axioms PEqualNP.Outside.L_alg001_fable.encodeCNFX
#print axioms PEqualNP.Outside.L_alg001_fable.satRun
#print axioms PEqualNP.Outside.L_alg001_fable.decodeExact
-- The repository's functions and the literal definitions built on them, for comparison.
#print axioms PEqualNP.Library.SearchHelpers.restrict
#print axioms PEqualNP.Outside.L_alg001_residual.budgetSearch
#print axioms PEqualNP.Search.encodeCNF
#print axioms PEqualNP.Outside.L_alg001_fable.decideSatRef
#print axioms PEqualNP.Outside.L_alg001_fable.satRunRef
-- Theorems.
#print axioms PEqualNP.Outside.L_alg001_fable.litCount_restrict_lt
#print axioms PEqualNP.Outside.L_alg001_fable.budgetSearch_isSome
#print axioms PEqualNP.Outside.L_alg001_fable.searchX_eq
#print axioms PEqualNP.Outside.L_alg001_fable.decideSat_eq_budgetSearch
#print axioms PEqualNP.Outside.L_alg001_fable.decideSat_eq_ref
#print axioms PEqualNP.Outside.L_alg001_fable.decideSat_correct
#print axioms PEqualNP.Outside.L_alg001_fable.ofBits_bits
#print axioms PEqualNP.Outside.L_alg001_fable.decodeCNF_encodeCNF
#print axioms PEqualNP.Outside.L_alg001_fable.encodeCNFX_eq
#print axioms PEqualNP.Outside.L_alg001_fable.satRun_eq_ref
#print axioms PEqualNP.Outside.L_alg001_fable.satRun_eq_spec
#print axioms PEqualNP.Outside.L_alg001_fable.satRun_correct
#print axioms PEqualNP.Outside.L_alg001_fable.satDecider
#print axioms PEqualNP.Outside.L_alg001_fable.run_eq_satRun
#print axioms PEqualNP.Outside.L_alg001_fable.budgetSearchCounted_eq
#print axioms PEqualNP.Outside.L_alg001_fable.searchCalls_le
#print axioms PEqualNP.Outside.L_alg001_fable.searchCalls_le_two_pow_length
#print axioms PEqualNP.Outside.L_alg001_fable.exponential_family
#print axioms PEqualNP.Outside.L_alg001_fable.sat_mem_P_of_degreeBound
#print axioms PEqualNP.Outside.L_alg001_fable.sat_mem_P_of_missing_lemma
#print axioms PEqualNP.Outside.L_alg001_fable.sat_mem_P_iff_degreeBound
#print axioms PEqualNP.Outside.L_alg001_fable.decodeExact_eq_some_iff
#print axioms PEqualNP.Outside.L_alg001_fable.mem_SAT_iff_decodeExact
#print axioms PEqualNP.Outside.L_alg001_fable_decider

/-! # Test harness

Everything above this line is a verbatim copy of `L_alg001_fable_decider.lean`. The harness below
executes the decider (compiled/interpreted code, not kernel reduction):

* on every bit string of length at most `maxLen` (default 14), tallying how many strings decode,
  how many are canonical encodings, how many are accepted, and whether `satRun` and the literal
  reference `satRunRef` ever differ;
* on the adversarial corpus (`corpus.jsonl`, read-only), comparing `decideSat`, `decideSatRef`
  and `satRun ∘ encodeCNF` with the status recorded by the independent exhaustive oracle.

Correctness is proved above; this is a sanity check of the executed code and of the corpus.
-/

namespace PEqualNP.Outside.L_alg001_fable_run

open PEqualNP.Search PEqualNP.Outside.L_alg001_fable

/-- All bit strings of a given length, in lexicographic order (`false < true`). -/
def allStrings : Nat → List (List Bool)
  | 0 => [[]]
  | n + 1 => (allStrings n).map (fun x => false :: x) ++ (allStrings n).map (fun x => true :: x)

structure Tally where
  total : Nat := 0
  decodable : Nat := 0
  canonical : Nat := 0
  sat : Nat := 0
  refMismatch : Nat := 0
  hash : Nat := 0

def tallyStep (t : Tally) (x : List Bool) : Tally :=
  let dec := (decodeCNF x).isSome
  let can := (decodeExact x).isSome
  let s := satRun x
  let r := satRunRef x
  { total := t.total + 1
    decodable := t.decodable + (if dec then 1 else 0)
    canonical := t.canonical + (if can then 1 else 0)
    sat := t.sat + (if s then 1 else 0)
    refMismatch := t.refMismatch + (if s == r then 0 else 1)
    hash := (t.hash * 31 + (if s then 2 else 1) + (if can then 4 else 0)) % 1000000007 }

def runStrings (maxLen : Nat) : IO Nat := do
  let mut total := 0
  let mut decodable := 0
  let mut canonical := 0
  let mut sat := 0
  let mut mismatch := 0
  for len in [0:maxLen + 1] do
    let t := (allStrings len).foldl tallyStep {}
    IO.println s!"STRINGS len={len} total={t.total} decodable={t.decodable} canonical={t.canonical} sat={t.sat} ref_mismatch={t.refMismatch} hash={t.hash}"
    total := total + t.total
    decodable := decodable + t.decodable
    canonical := canonical + t.canonical
    sat := sat + t.sat
    mismatch := mismatch + t.refMismatch
  IO.println s!"STRINGS_TOTAL max_len={maxLen} total={total} decodable={decodable} canonical={canonical} sat={sat} unsat_canonical={canonical - sat} ref_mismatch={mismatch}"
  return mismatch

/-- One corpus line: identifier, oracle status (`true` for SAT), formula. A signed non-zero
integer `k` becomes the literal `(|k|, 0 < k)`. -/
def parseCase (line : String) : Except String (String × Bool × CNF) := do
  let j ← Lean.Json.parse line
  let id ← j.getObjValAs? String "id"
  let oracle ← j.getObjVal? "oracle"
  let status ← oracle.getObjValAs? String "status"
  let clausesJ ← j.getObjVal? "clauses"
  let clauses ← clausesJ.getArr?
  let mut φ : CNF := []
  for cj in clauses do
    let lits ← cj.getArr?
    let mut c : Clause := []
    for lj in lits do
      let k ← lj.getInt?
      if k == 0 then throw "zero literal"
      c := c ++ [(k.natAbs, decide (0 < k))]
    φ := φ ++ [c]
  if status == "SAT" then return (id, true, φ)
  else if status == "UNSAT" then return (id, false, φ)
  else throw s!"unexpected oracle status {status}"

def runCorpus (path : System.FilePath) : IO Nat := do
  let text ← IO.FS.readFile path
  let lines := (text.splitOn "\n").filter (fun l => l != "")
  let mut agree := 0
  let mut disagree := 0
  let mut sat := 0
  let mut unsat := 0
  let mut bad := 0
  let mut maxCalls := 0
  let mut maxLits := 0
  let mut maxBits := 0
  for line in lines do
    match parseCase line with
    | .error e =>
      bad := bad + 1
      IO.println s!"CORPUS_PARSE_ERROR {e}"
    | .ok (id, expected, φ) =>
      let x := encodeCNF φ
      let a := decideSat φ
      let b := satRun x
      let c := decideSatRef φ
      if a == expected && b == expected && c == expected then
        agree := agree + 1
      else
        disagree := disagree + 1
        IO.println s!"CORPUS_DISAGREE id={id} oracle={expected} decideSat={a} satRun={b} decideSatRef={c}"
      if expected then sat := sat + 1 else unsat := unsat + 1
      maxCalls := max maxCalls (budgetSearchCounted (litCount φ) φ).2
      maxLits := max maxLits (litCount φ)
      maxBits := max maxBits x.length
  IO.println s!"CORPUS cases={lines.length} parse_errors={bad} agree={agree} disagree={disagree} oracle_sat={sat} oracle_unsat={unsat} max_literal_occurrences={maxLits} max_input_bits={maxBits} max_search_calls={maxCalls}"
  return disagree + bad

end PEqualNP.Outside.L_alg001_fable_run

/-- usage: `lake env lean --run RunDecider.lean <corpus.jsonl> [maxLen]` -/
def main (args : List String) : IO UInt32 := do
  let maxLen := (args.getD 1 "14").toNat!
  let m ← PEqualNP.Outside.L_alg001_fable_run.runStrings maxLen
  let d ← match args.head? with
    | some path => PEqualNP.Outside.L_alg001_fable_run.runCorpus path
    | none => do
      IO.println "CORPUS skipped (no path given)"
      pure 0
  if m == 0 && d == 0 then
    IO.println "RUN_DECIDER_RESULT PASS"
    return 0
  else
    IO.println "RUN_DECIDER_RESULT FAIL"
    return 1
