#!/usr/bin/env python3
"""Independent Python re-implementation of the project's binary CNF encoding, written from the
docstrings of PEqualNP/Defs/Search.lean (not from the Lean decoder), used to cross-check the
tallies printed by RunDecider.lean on ALL bit strings of length <= MAXLEN.

Encoding (pairs of bits): [1, d] digit d; [0, 1] end of literal; [0, 0] end of clause.
A literal is its polarity digit, then the binary digits of the variable, least significant
first, no leading zeros (0 has no digits), then end-of-literal. A clause is its literals, then
end-of-clause. A formula is its clauses.

For each length the script prints
  STRINGS len=L total=2^L decodable=D canonical=C sat=S hash=H
where `decodable` uses the lenient grammar (leading zeros allowed, as the Lean `decodeCNF`),
`canonical` the strict one (exactly the image of the encoder, as the Lean `decodeExact`), `sat`
counts canonical strings whose formula is satisfiable (brute force over all assignments of the
occurring variables), and `hash` folds, in lexicographic order with 0 < 1,
  h := (h * 31 + (2 if sat else 1) + (4 if canonical else 0)) mod 1000000007.
Standard library only, deterministic, no randomness. Finite check; proves nothing by itself.

usage: python3 crosscheck_strings.py [MAXLEN=14] [OUT.json]
"""
import json
import sys
import time

DEADLINE_S = 25.0


def encode_literal(var, pol):
    out = [1, 1 if pol else 0]
    n = var
    while n:
        out += [1, n & 1]
        n >>= 1
    out += [0, 1]
    return out


def encode_cnf(cnf):
    out = []
    for clause in cnf:
        for var, pol in clause:
            out += encode_literal(var, pol)
        out += [0, 0]
    return out


def parse(bits, strict):
    """Formula encoded by `bits`, or None. strict=True rejects leading-zero digit strings."""
    if len(bits) % 2:
        return None
    toks = [(bits[i], bits[i + 1]) for i in range(0, len(bits), 2)]
    cnf, clause, i = [], [], 0
    while i < len(toks):
        tok = toks[i]
        if tok == (0, 0):
            cnf.append(clause)
            clause = []
            i += 1
            continue
        if tok == (0, 1):
            return None  # end of literal outside a literal
        pol = bool(tok[1])
        i += 1
        digits = []
        while i < len(toks) and toks[i][0] == 1:
            digits.append(toks[i][1])
            i += 1
        if i >= len(toks) or toks[i] != (0, 1):
            return None  # literal not closed (end of input or end of clause inside a literal)
        i += 1
        if strict and digits and digits[-1] != 1:
            return None  # leading zero: the last digit is the most significant one
        clause.append((sum(d << k for k, d in enumerate(digits)), pol))
    if clause:
        return None  # end of input inside a clause
    return cnf


def satisfiable(cnf):
    variables = sorted({v for clause in cnf for v, _ in clause})
    for mask in range(1 << len(variables)):
        val = {v: bool((mask >> k) & 1) for k, v in enumerate(variables)}
        if all(any(val[v] == p for v, p in clause) for clause in cnf):
            return True
    return False


def main():
    maxlen = int(sys.argv[1]) if len(sys.argv) > 1 else 14
    out_path = sys.argv[2] if len(sys.argv) > 2 else None
    t0 = time.time()
    rows = []
    totals = {"total": 0, "decodable": 0, "canonical": 0, "sat": 0}
    for length in range(maxlen + 1):
        dec = can = sat = 0
        h = 0
        for k in range(1 << length):
            if time.time() - t0 > DEADLINE_S:
                raise SystemExit("DEADLINE exceeded; no result reported")
            bits = [(k >> (length - 1 - i)) & 1 for i in range(length)]
            lenient = parse(bits, strict=False)
            strict = parse(bits, strict=True)
            is_can = strict is not None
            if is_can:
                assert lenient == strict and encode_cnf(strict) == bits
            elif lenient is not None:
                assert encode_cnf(lenient) != bits
            is_sat = is_can and satisfiable(strict)
            dec += lenient is not None
            can += is_can
            sat += is_sat
            h = (h * 31 + (2 if is_sat else 1) + (4 if is_can else 0)) % 1000000007
        row = {"len": length, "total": 1 << length, "decodable": dec, "canonical": can,
               "sat": sat, "hash": h}
        rows.append(row)
        for key in totals:
            totals[key] += row[key]
        print(f"STRINGS len={length} total={1 << length} decodable={dec} canonical={can} "
              f"sat={sat} hash={h}")
    print(f"STRINGS_TOTAL max_len={maxlen} total={totals['total']} "
          f"decodable={totals['decodable']} canonical={totals['canonical']} sat={totals['sat']} "
          f"unsat_canonical={totals['canonical'] - totals['sat']}")
    result = {"max_len": maxlen, "rows": rows, "totals": totals,
              "seconds": round(time.time() - t0, 3)}
    if out_path:
        with open(out_path, "w") as f:
            json.dump(result, f, indent=1)
            f.write("\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
