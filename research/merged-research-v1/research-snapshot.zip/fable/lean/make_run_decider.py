#!/usr/bin/env python3
"""Regenerate RunDecider.lean = verbatim L_alg001_fable_decider.lean + RunDecider.tail.lean,
or (with --check) verify that RunDecider.lean is exactly that concatenation.
Standard library only. usage: python3 make_run_decider.py [--check]"""
import hashlib
import os
import sys

here = os.path.dirname(os.path.abspath(__file__))
main = open(os.path.join(here, "L_alg001_fable_decider.lean"), "rb").read()
tail = open(os.path.join(here, "RunDecider.tail.lean"), "rb").read()
target = os.path.join(here, "RunDecider.lean")
if "--check" in sys.argv:
    cur = open(target, "rb").read()
    ok = cur == main + tail
    print("prefix_sha256", hashlib.sha256(cur[: len(main)]).hexdigest())
    print("main_sha256  ", hashlib.sha256(main).hexdigest())
    print("RunDecider.lean == main + tail:", ok)
    sys.exit(0 if ok else 1)
with open(target, "wb") as f:
    f.write(main + tail)
print("wrote", target, "bytes", len(main) + len(tail), "prefix sha256", hashlib.sha256(main).hexdigest())
