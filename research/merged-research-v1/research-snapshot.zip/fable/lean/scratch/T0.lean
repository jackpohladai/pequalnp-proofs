import PEqualNP.Outside.L_alg001_residual
open PEqualNP.Search
open PEqualNP.Outside.L_alg001_residual
#check @budgetSearch
#check @budgetSearch_correct
#print axioms budgetSearch
#print axioms budgetSearch_correct
#print axioms encodeCNF
#print axioms PEqualNP.Library.SearchHelpers.restrict
#check @Turing.TM2ComputableInPolyTime
#print Turing.TM2ComputableInPolyTime
#print Turing.TM2ComputableInTime
#print Turing.TM2OutputsInTime
#print Turing.TM2Outputs
#print Turing.TM2ComputableAux
#print Turing.TM2Computable
#print Turing.EvalsToInTime
#print Turing.EvalsTo
