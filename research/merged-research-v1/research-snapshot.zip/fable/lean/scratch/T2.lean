import PEqualNP.Outside.L_alg001_residual
#check 1
