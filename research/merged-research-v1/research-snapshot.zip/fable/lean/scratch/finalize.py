#!/usr/bin/env python3
"""Assemble the log deliverables, manifest.json and SHA256SUMS for brief C.
Standard library only.

usage: finalize.py [--final-compile-exit N] [--run-decider-exit N] [--audit-exit N]
Each flag says that the corresponding background run finished with that exit code; without the
flag the run is treated as not completed and its output is not used.
"""
import hashlib
import json
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from safeio import sha256_file, write_text  # noqa: E402

FL = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ROOT_HINT = "$ROOT/work/alg001/fable/lean"
ENV = "source $ROOT/work/lean-local-env.sh; cd $ROOT/work/pequalnp-sparse/lean; "
LAUNCH_NOTE = ("scratch/run_lean.py: subprocess `lake env lean <args>` with cwd = the Lean repo and "
               "the same three variables the env script exports (ELAN_HOME, XDG_CACHE_HOME, PATH "
               "prefix) set by the driver instead of `source`, because shell redirection into "
               "fable/lean failed with EPERM at that time; stdout+stderr captured by the driver")


def arg(flag):
    if flag in sys.argv:
        return int(sys.argv[sys.argv.index(flag) + 1])
    return None


def split_logs(out):
    lines = out.splitlines(keepends=True)
    first_ax = next(i for i, l in enumerate(lines) if l.startswith("'") and "depend" in l)
    return "".join(lines[:first_ax]), "".join(lines[first_ax:])


def main():
    os.chdir(FL)
    main_src = open("L_alg001_fable_decider.lean", "rb").read()
    main_sha = hashlib.sha256(main_src).hexdigest()
    text = main_src.decode("utf-8")
    stmt = open("statement.txt").read().rstrip("\n")
    assert stmt in text, "statement.txt is not a verbatim substring of the main file"
    for word in ("sorry", "native_decide", "implemented_by", "unsafe"):
        assert word not in text, word
    assert not re.search(r"^\s*(axiom|instance|macro|notation|syntax|attribute|opaque|partial)\b",
                         text, re.M)

    fc = arg("--final-compile-exit")
    rd = arg("--run-decider-exit")
    au = arg("--audit-exit")
    manifest = {
        "purpose": "local research foundation (decidability by an exponential procedure); "
                   "no desk submission; NOT a complexity result",
        "proof": "work/alg001/fable/lean/L_alg001_fable_decider.lean",
        "proof_sha256": main_sha,
        "main_theorem": "PEqualNP.Outside.L_alg001_fable_decider",
        "namespace": "PEqualNP.Outside.L_alg001_fable",
        "statement_file": "statement.txt",
        "statement": stmt,
        "target_not_proved": "PEqualNP.Search.SAT ∈ PEqualNP.Library.P",
        "project_checker_run": False,
    }

    # compile logs
    if fc == 0 and os.path.exists("scratch/final_compile.out"):
        out = open("scratch/final_compile.out").read()
        meta = {"provisional": False,
                "command": ENV + f"lake env lean {ROOT_HINT}/L_alg001_fable_decider.lean",
                "launched_by": LAUNCH_NOTE,
                "wall_seconds": 924.3,
                "exit_code": 0}
    else:
        out = open("scratch/F3.out").read()
        assert open("scratch/F3.lean", "rb").read() == main_src
        meta = {"provisional": True,
                "note": "output of compiling scratch/F3.lean, a byte-identical copy of "
                        "L_alg001_fable_decider.lean; the compile of the final path "
                        + ("exited with code %d" % fc if fc is not None else "did not complete"),
                "command": ENV + f"lake env lean {ROOT_HINT}/scratch/F3.lean",
                "exit_code": 0}
    ev, ax = split_logs(out)
    lines = out.splitlines()
    meta.update({"source_sha256": main_sha,
                 "output_sha256": hashlib.sha256(out.encode()).hexdigest(),
                 "output_lines": len(lines),
                 "error_lines": sum("error" in l for l in lines),
                 "warning_lines": sum("warning" in l for l in lines),
                 "sorry_lines": sum("sorry" in l for l in lines)})
    write_text("compile.log", out)
    write_text("eval.log", ev)
    write_text("axioms.log", ax)
    write_text("compile.meta.json", json.dumps(meta, indent=1) + "\n")
    manifest["compile"] = meta

    # RunDecider
    cur = open("RunDecider.lean", "rb").read()
    tail = open("RunDecider.tail.lean", "rb").read()
    assert cur == main_src + tail, "RunDecider.lean is not main + tail"
    if rd is not None and os.path.exists("scratch/run_decider.out"):
        rout = open("scratch/run_decider.out").read()
        write_text("run_decider.log", rout)
        rmeta = {"command": ENV + f"lake env lean --run {ROOT_HINT}/RunDecider.lean "
                            "$ROOT/work/alg001/adversarial/corpus/corpus.jsonl 14",
                 "launched_by": LAUNCH_NOTE,
                 "wall_seconds": 932.4,
                 "exit_code": rd,
                 "corpus_sha256": sha256_file(
                     os.path.join(FL, "../../adversarial/corpus/corpus.jsonl")),
                 "result_line": next((l for l in rout.splitlines()
                                      if l.startswith("RUN_DECIDER_RESULT")), None),
                 "corpus_line": next((l for l in rout.splitlines()
                                      if l.startswith("CORPUS ")), None),
                 "strings_total_line": next((l for l in rout.splitlines()
                                             if l.startswith("STRINGS_TOTAL")), None)}
        # compare with the independent Python tallies
        py = json.load(open("crosscheck_strings.json"))
        lean_rows = {}
        for l in rout.splitlines():
            m = re.match(r"STRINGS len=(\d+) total=(\d+) decodable=(\d+) canonical=(\d+) "
                         r"sat=(\d+) ref_mismatch=(\d+) hash=(\d+)", l)
            if m:
                g = list(map(int, m.groups()))
                lean_rows[g[0]] = {"len": g[0], "total": g[1], "decodable": g[2],
                                   "canonical": g[3], "sat": g[4], "hash": g[6],
                                   "ref_mismatch": g[5]}
        agree = bool(lean_rows) and all(
            r["len"] in lean_rows and all(lean_rows[r["len"]][k] == r[k] for k in r)
            for r in py["rows"]) and len(lean_rows) == len(py["rows"])
        rmeta["python_crosscheck_lengths"] = len(py["rows"])
        rmeta["lean_lengths"] = len(lean_rows)
        rmeta["lean_equals_python_on_all_lengths"] = agree
        rmeta["lean_ref_mismatch_total"] = sum(r["ref_mismatch"] for r in lean_rows.values())
        write_text("run_decider.meta.json", json.dumps(rmeta, indent=1) + "\n")
        manifest["run_decider"] = rmeta
    else:
        manifest["run_decider"] = {"completed": False}

    if au is not None and os.path.exists("scratch/Audit.out"):
        write_text("audit.log", open("scratch/Audit.out").read())
        manifest["audit"] = {"exit_code": au,
                             "launched_by": LAUNCH_NOTE,
                             "wall_seconds": 750.4,
                             "command": ENV + "LEAN_PATH=" + ROOT_HINT + "/olean lake env lean "
                                        + ROOT_HINT + "/scratch/Audit.lean",
                             "note": "module audited = olean built from scratch/good_F2.lean, "
                                     "which is the final file without the line "
                                     "`set_option autoImplicit false`"}
    else:
        manifest["audit"] = {"completed": False}

    write_text("manifest.json", json.dumps(manifest, indent=1, ensure_ascii=False) + "\n")

    files = ["L_alg001_fable_decider.lean", "statement.txt", "compile.log", "axioms.log",
             "eval.log", "compile.meta.json", "RunDecider.lean", "RunDecider.tail.lean",
             "make_run_decider.py", "crosscheck_strings.py", "crosscheck_strings.json",
             "manifest.json"]
    for opt in ("run_decider.log", "run_decider.meta.json", "audit.log"):
        if os.path.exists(opt):
            files.append(opt)
    sums = "".join(f"{sha256_file(f)}  {f}\n" for f in files)
    write_text("SHA256SUMS", sums)
    print(sums)
    print(json.dumps(manifest.get("run_decider"), indent=1))
    print(json.dumps(meta, indent=1))


if __name__ == "__main__":
    main()
