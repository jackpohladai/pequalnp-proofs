import PEqualNP.Outside.L_alg001_residual

namespace PEqualNP.Outside.L_alg001_fable

open PEqualNP.Search
open PEqualNP.Library.SearchHelpers (restrict)
open PEqualNP.Outside.L_alg001_residual

/-! ## 0. Axiom-free executable building blocks -/

/-- Number of literal occurrences of a formula (the fuel that always suffices). -/
def litCount : CNF → ℕ
  | [] => 0
  | c :: φ => c.length + litCount φ

/-- Boolean test for `(x, v) ∈ c`. -/
def hasLit (x : ℕ) (v : Bool) (c : Clause) : Bool :=
  c.any fun l => l.1 == x && l.2 == v

/-- Axiom-free twin of `restrict`. -/
def restrictX (x : ℕ) (v : Bool) (φ : CNF) : CNF :=
  (φ.filter fun c => !hasLit x v c).map fun c => c.filter fun l => !(l.1 == x)

/-- Axiom-free twin of `combine`. -/
def combineX (a b : Option Bool) : Option Bool :=
  if a == some true || b == some true then some true
  else if a == some false && b == some false then some false else none

/-- Axiom-free twin of `budgetSearch`. -/
def searchX : ℕ → CNF → Option Bool
  | 0, φ =>
    (match φ with
    | [] => some true
    | cl :: _ =>
      (match cl with
      | [] => some false
      | _ :: _ => none))
  | fuel + 1, φ =>
    (match φ with
    | [] => some true
    | cl :: _ =>
      (match cl with
      | [] => some false
      | l :: _ =>
        combineX (searchX fuel (restrictX l.1 false φ)) (searchX fuel (restrictX l.1 true φ))))

#print axioms litCount
#print axioms hasLit
#print axioms restrictX
#print axioms combineX
#print axioms searchX

/-! ## 1. Completeness of the existing search -/

theorem litCount_eq_sum (φ : CNF) : litCount φ = (φ.map List.length).sum := by
  induction φ with
  | nil => rfl
  | cons c φ ih => simp [litCount, ih]

theorem restrict_cons_of_mem {x : ℕ} {b : Bool} {cl : Clause} (φ : CNF) (h : (x, b) ∈ cl) :
    restrict x b (cl :: φ) = restrict x b φ := by
  simp [restrict, h]

theorem restrict_cons_of_not_mem {x : ℕ} {b : Bool} {cl : Clause} (φ : CNF) (h : (x, b) ∉ cl) :
    restrict x b (cl :: φ) = (cl.filter fun l => decide (l.1 ≠ x)) :: restrict x b φ := by
  simp [restrict, h]

theorem litCount_restrict_le (x : ℕ) (b : Bool) (φ : CNF) :
    litCount (restrict x b φ) ≤ litCount φ := by
  induction φ with
  | nil => simp [restrict, litCount]
  | cons cl φ ih =>
    by_cases h : (x, b) ∈ cl
    · rw [restrict_cons_of_mem φ h]
      simp only [litCount]
      omega
    · rw [restrict_cons_of_not_mem φ h]
      simp only [litCount]
      have := List.length_filter_le (fun l : Literal => decide (l.1 ≠ x)) cl
      omega

/-- Key lemma: branching on the head literal's variable strictly decreases the literal count. -/
theorem litCount_restrict_lt (x : ℕ) (v b : Bool) (c : Clause) (φ : CNF) :
    litCount (restrict x b (((x, v) :: c) :: φ)) < litCount (((x, v) :: c) :: φ) := by
  have hle := litCount_restrict_le x b φ
  by_cases h : (x, b) ∈ (x, v) :: c
  · rw [restrict_cons_of_mem φ h]
    simp only [litCount, List.length_cons]
    omega
  · rw [restrict_cons_of_not_mem φ h]
    have hf : ((x, v) :: c).filter (fun l : Literal => decide (l.1 ≠ x)) =
        c.filter (fun l : Literal => decide (l.1 ≠ x)) := by
      apply List.filter_cons_of_neg
      simp
    rw [hf]
    simp only [litCount, List.length_cons]
    have := List.length_filter_le (fun l : Literal => decide (l.1 ≠ x)) c
    omega

theorem combine_isSome {a b : Option Bool} (ha : a.isSome) (hb : b.isSome) :
    (combine a b).isSome := by
  cases a with
  | none => simp at ha
  | some a =>
    cases b with
    | none => simp at hb
    | some b => cases a <;> cases b <;> rfl

/-- Target 1: with fuel at least the literal count the search always returns a definite answer. -/
theorem budgetSearch_isSome (φ : CNF) (fuel : ℕ) (h : litCount φ ≤ fuel) :
    (budgetSearch fuel φ).isSome := by
  induction fuel generalizing φ with
  | zero =>
    cases φ with
    | nil => rfl
    | cons c φ =>
      cases c with
      | nil => rfl
      | cons l c => simp [litCount] at h
  | succ fuel ih =>
    cases φ with
    | nil => rfl
    | cons c φ =>
      cases c with
      | nil => rfl
      | cons l c =>
        obtain ⟨x, v⟩ := l
        simp only [budgetSearch]
        apply combine_isSome
        · apply ih
          have := litCount_restrict_lt x v false c φ
          omega
        · apply ih
          have := litCount_restrict_lt x v true c φ
          omega

/-! ## 2. The CNF-level decider -/

theorem hasLit_eq (x : ℕ) (v : Bool) (c : Clause) : hasLit x v c = decide ((x, v) ∈ c) := by
  apply Bool.eq_iff_iff.mpr
  simp only [hasLit, List.any_eq_true, Bool.and_eq_true, beq_iff_eq, decide_eq_true_eq]
  constructor
  · rintro ⟨⟨y, w⟩, hl, h1, h2⟩
    simp only at h1 h2
    subst h1 h2
    exact hl
  · intro h
    exact ⟨(x, v), h, rfl, rfl⟩

theorem restrictX_eq (x : ℕ) (v : Bool) (φ : CNF) : restrictX x v φ = restrict x v φ := by
  have h1 : (fun c : Clause => !hasLit x v c) = (fun c : Clause => decide ((x, v) ∉ c)) := by
    funext c
    rw [hasLit_eq]
    simp
  have h2 : (fun l : Literal => !(l.1 == x)) = (fun l : Literal => decide (l.1 ≠ x)) := by
    funext l
    by_cases hx : l.1 = x <;> simp [hx]
  simp only [restrictX, restrict, h1, h2]

theorem combineX_eq (a b : Option Bool) : combineX a b = combine a b := by
  cases a with
  | none =>
    cases b with
    | none => rfl
    | some b => cases b <;> rfl
  | some a =>
    cases b with
    | none => cases a <;> rfl
    | some b => cases a <;> cases b <;> rfl

theorem searchX_eq (fuel : ℕ) (φ : CNF) : searchX fuel φ = budgetSearch fuel φ := by
  induction fuel generalizing φ with
  | zero =>
    cases φ with
    | nil => rfl
    | cons c φ => cases c <;> rfl
  | succ fuel ih =>
    cases φ with
    | nil => rfl
    | cons c φ =>
      cases c with
      | nil => rfl
      | cons l c =>
        obtain ⟨x, v⟩ := l
        simp only [searchX, budgetSearch, ih, restrictX_eq, combineX_eq]

/-- Target 2: the explicit CNF-level decider (axiom-free twin of
`budgetSearch (litCount φ) φ == some true`, see `decideSat_eq_budgetSearch`). -/
def decideSat (φ : CNF) : Bool := searchX (litCount φ) φ == some true

#print axioms decideSat

theorem decideSat_eq_budgetSearch (φ : CNF) :
    decideSat φ = (budgetSearch (litCount φ) φ == some true) := by
  simp only [decideSat, searchX_eq]

theorem decideSat_correct (φ : CNF) : Satisfiable φ ↔ decideSat φ = true := by
  rw [decideSat_eq_budgetSearch]
  have hsome := budgetSearch_isSome φ (litCount φ) le_rfl
  have hc := budgetSearch_correct (litCount φ) φ
  cases hres : budgetSearch (litCount φ) φ with
  | none => rw [hres] at hsome; simp at hsome
  | some b =>
    rw [hres] at hc
    simp only [AnswerCorrect] at hc
    rw [hc]
    cases b <;> simp

#print axioms budgetSearch_isSome
#print axioms decideSat_eq_budgetSearch
#print axioms decideSat_correct

/-! ## 3. Decoder for the project's binary encoding -/

/-- Value of a list of binary digits, least significant first. -/
def ofBits : List Bool → ℕ
  | [] => 0
  | b :: bs => Nat.bit b (ofBits bs)

theorem ofBits_bits (n : ℕ) : ofBits (Nat.bits n) = n := by
  induction n using Nat.binaryRec' with
  | zero => simp [ofBits]
  | bit b n h ih => rw [Nat.bits_append_bit n b h, ofBits, ih]

/-- The decoder loop. The input is read in pairs of bits. State: `none` between literals,
`some (p, ds)` inside a literal with polarity `p` whose variable digits read so far are `ds`
(least significant first); `cl` is the list of literals of the current clause read so far.
`[true, d]` is a digit, `[false, true]` ends a literal, `[false, false]` ends a clause. -/
def decodeGo : List Bool → Option (Bool × List Bool) → Clause → Option CNF
  | [], st, cl =>
    (match st with
    | none =>
      (match cl with
      | [] => some []
      | _ :: _ => none)
    | some _ => none)
  | [_], _, _ => none
  | b :: d :: rest, st, cl =>
    (match b with
    | true =>
      (match st with
      | none => decodeGo rest (some (d, [])) cl
      | some pd => decodeGo rest (some (pd.1, pd.2 ++ [d])) cl)
    | false =>
      (match d with
      | true =>
        (match st with
        | none => none
        | some pd => decodeGo rest none (cl ++ [(ofBits pd.2, pd.1)]))
      | false =>
        (match st with
        | none => (decodeGo rest none []).map (fun φ => cl :: φ)
        | some _ => none)))

/-- Target 3: the decoder. Total on all bit strings; `none` on malformed input. -/
def decodeCNF (x : List Bool) : Option CNF := decodeGo x none []

#print axioms ofBits
#print axioms decodeGo
#print axioms decodeCNF

theorem decodeGo_digit_none (d : Bool) (rest : List Bool) (cl : Clause) :
    decodeGo (true :: d :: rest) none cl = decodeGo rest (some (d, [])) cl := rfl

theorem decodeGo_digit_some (d p : Bool) (ds rest : List Bool) (cl : Clause) :
    decodeGo (true :: d :: rest) (some (p, ds)) cl = decodeGo rest (some (p, ds ++ [d])) cl := rfl

theorem decodeGo_endLit (p : Bool) (ds rest : List Bool) (cl : Clause) :
    decodeGo (false :: true :: rest) (some (p, ds)) cl =
      decodeGo rest none (cl ++ [(ofBits ds, p)]) := rfl

theorem decodeGo_endClause (rest : List Bool) (cl : Clause) :
    decodeGo (false :: false :: rest) none cl =
      (decodeGo rest none []).map (fun φ => cl :: φ) := rfl

theorem decodeGo_digits (ds' : List Bool) (p : Bool) (ds rest : List Bool) (cl : Clause) :
    decodeGo ((ds'.flatMap fun d => [true, d]) ++ rest) (some (p, ds)) cl =
      decodeGo rest (some (p, ds ++ ds')) cl := by
  induction ds' generalizing ds with
  | nil => simp
  | cons d ds' ih =>
    rw [List.flatMap_cons]
    show decodeGo (true :: d :: ((ds'.flatMap fun d => [true, d]) ++ rest)) (some (p, ds)) cl = _
    rw [decodeGo_digit_some, ih]
    simp

theorem decodeGo_literal (l : Literal) (rest : List Bool) (cl : Clause) :
    decodeGo (encodeLiteral l ++ rest) none cl = decodeGo rest none (cl ++ [l]) := by
  obtain ⟨i, p⟩ := l
  show decodeGo (true :: p :: (((Nat.bits i).flatMap fun d => [true, d]) ++ [false, true]) ++ rest)
    none cl = _
  rw [List.cons_append, List.cons_append, List.append_assoc, decodeGo_digit_none, decodeGo_digits]
  show decodeGo (false :: true :: rest) (some (p, [] ++ Nat.bits i)) cl = _
  rw [decodeGo_endLit, List.nil_append, ofBits_bits]

theorem decodeGo_literals (c : Clause) (rest : List Bool) (cl : Clause) :
    decodeGo (c.flatMap encodeLiteral ++ rest) none cl = decodeGo rest none (cl ++ c) := by
  induction c generalizing cl with
  | nil => simp
  | cons l c ih =>
    rw [List.flatMap_cons, List.append_assoc, decodeGo_literal, ih]
    simp

theorem decodeGo_clause (c : Clause) (rest : List Bool) :
    decodeGo (encodeClause c ++ rest) none [] =
      (decodeGo rest none []).map (fun φ => c :: φ) := by
  rw [encodeClause, List.append_assoc, decodeGo_literals]
  show decodeGo (false :: false :: rest) none ([] ++ c) = _
  rw [decodeGo_endClause, List.nil_append]

/-- Target 3: the decoder inverts the project's encoder. -/
theorem decodeCNF_encodeCNF (φ : CNF) : decodeCNF (encodeCNF φ) = some φ := by
  unfold decodeCNF
  induction φ with
  | nil => rfl
  | cons c φ ih =>
    have h : encodeCNF (c :: φ) = encodeClause c ++ encodeCNF φ := by
      simp [encodeCNF]
    rw [h, decodeGo_clause, ih]
    rfl

#print axioms decodeCNF_encodeCNF

/-! ## 4. The total decider on bit strings -/

/-- Binary digits of `n`, least significant first, by explicit fuel (axiom-free twin of
`Nat.bits`, see `bitsX_eq`). -/
def bitsAux : ℕ → ℕ → List Bool
  | 0, _ => []
  | fuel + 1, n => if n = 0 then [] else (n % 2 == 1) :: bitsAux fuel (n / 2)

def bitsX (n : ℕ) : List Bool := bitsAux n n

/-- Axiom-free twins of `encodeLiteral`, `encodeClause`, `encodeCNF`. -/
def encodeLiteralX (l : Literal) : List Bool :=
  [true, l.2] ++ ((bitsX l.1).flatMap fun d => [true, d]) ++ [false, true]

def encodeClauseX (c : Clause) : List Bool :=
  c.flatMap encodeLiteralX ++ [false, false]

def encodeCNFX (φ : CNF) : List Bool :=
  φ.flatMap encodeClauseX

theorem bitsAux_eq (fuel n : ℕ) (h : n ≤ fuel) : bitsAux fuel n = Nat.bits n := by
  induction fuel generalizing n with
  | zero =>
    obtain rfl : n = 0 := by omega
    simp [bitsAux]
  | succ fuel ih =>
    by_cases hn : n = 0
    · subst hn
      simp [bitsAux]
    · have h2 : n / 2 ≤ fuel := by omega
      have hbit : Nat.bit (n % 2 == 1) (n / 2) = n := by
        rcases Nat.mod_two_eq_zero_or_one n with h0 | h1
        · rw [h0]
          show 2 * (n / 2) = n
          omega
        · rw [h1]
          show 2 * (n / 2) + 1 = n
          omega
      have hb : n / 2 = 0 → (n % 2 == 1) = true := by
        intro h0
        have h1 : n % 2 = 1 := by omega
        rw [h1]
        rfl
      show (if n = 0 then [] else (n % 2 == 1) :: bitsAux fuel (n / 2)) = Nat.bits n
      rw [ite_eq_right hn, ih _ h2, ← Nat.bits_append_bit _ _ hb, hbit]

theorem bitsX_eq (n : ℕ) : bitsX n = Nat.bits n := bitsAux_eq n n le_rfl

theorem encodeLiteralX_eq (l : Literal) : encodeLiteralX l = encodeLiteral l := by
  simp only [encodeLiteralX, encodeLiteral, bitsX_eq]

theorem encodeClauseX_eq (c : Clause) : encodeClauseX c = encodeClause c := by
  have h : encodeLiteralX = encodeLiteral := funext encodeLiteralX_eq
  simp only [encodeClauseX, encodeClause, h]

theorem encodeCNFX_eq (φ : CNF) : encodeCNFX φ = encodeCNF φ := by
  have h : encodeClauseX = encodeClause := funext encodeClauseX_eq
  simp only [encodeCNFX, encodeCNF, h]

/-- Target 4: the explicit total decider on bit strings. Decode; reject malformed strings;
re-encode and compare (this rejects every non-canonical string); then decide the formula. -/
def satRun (x : List Bool) : Bool :=
  match decodeCNF x with
  | some φ => (encodeCNFX φ == x) && decideSat φ
  | none => false

#print axioms bitsX
#print axioms encodeCNFX
#print axioms satRun

/-- `satRun` is extensionally the function of the brief, stated with the project's own
`encodeCNF` and `budgetSearch`. -/
theorem satRun_eq_spec (x : List Bool) :
    satRun x =
      (match decodeCNF x with
      | some φ => (encodeCNF φ == x) && (budgetSearch (litCount φ) φ == some true)
      | none => false) := by
  unfold satRun
  cases decodeCNF x with
  | none => rfl
  | some φ => simp only [encodeCNFX_eq, decideSat_eq_budgetSearch]

/-- Target 4: correctness on ALL bit strings, including malformed and non-canonical ones. -/
theorem satRun_correct (x : List Bool) : x ∈ SAT ↔ satRun x = true := by
  constructor
  · rintro ⟨φ, rfl, hsat⟩
    unfold satRun
    rw [decodeCNF_encodeCNF]
    simp [encodeCNFX_eq, (decideSat_correct φ).mp hsat]
  · intro h
    unfold satRun at h
    cases hd : decodeCNF x with
    | none =>
      rw [hd] at h
      simp at h
    | some φ =>
      rw [hd] at h
      simp only [Bool.and_eq_true, beq_iff_eq] at h
      exact ⟨φ, by rw [← encodeCNFX_eq]; exact h.1, (decideSat_correct φ).mpr h.2⟩

/-- Target 4: the candidate interface of the foundation file is inhabited. -/
def satDecider : CorrectBitDecider := ⟨satRun, satRun_correct⟩

theorem satDecider_run : satDecider.run = satRun := rfl

#print axioms satRun_eq_spec
#print axioms satRun_correct
#print axioms satDecider

#eval satRun []
#eval satRun (encodeCNF [[]])
#eval satRun (encodeCNF [[(0, true), (1, true)], [(0, false), (1, false)]])
#eval satRun (encodeCNF [[(0, true), (1, true)], [(0, true), (1, false)], [(0, false), (1, true)], [(0, false), (1, false)]])
#eval satRun [true]
#eval satRun [true, true, true, false, false, true, false, false]
#eval satRun [true, true, false, true, false, false]

/-! ## 5. Honest size statement: the procedure is exponential -/

/-- Number of calls of the search on `(fuel, φ)`, the root call included. It has the recursion
of `budgetSearch`: both branches are always explored. -/
def searchCalls : ℕ → CNF → ℕ
  | _, [] => 1
  | _, [] :: _ => 1
  | 0, (_ :: _) :: _ => 1
  | fuel + 1, ((x, v) :: c) :: φ =>
      1 + searchCalls fuel (restrict x false (((x, v) :: c) :: φ))
        + searchCalls fuel (restrict x true (((x, v) :: c) :: φ))

/-- The search instrumented with a call counter. -/
def budgetSearchCounted : ℕ → CNF → Option Bool × ℕ
  | _, [] => (some true, 1)
  | _, [] :: _ => (some false, 1)
  | 0, (_ :: _) :: _ => (none, 1)
  | fuel + 1, ((x, v) :: c) :: φ =>
      (combine (budgetSearchCounted fuel (restrict x false (((x, v) :: c) :: φ))).1
          (budgetSearchCounted fuel (restrict x true (((x, v) :: c) :: φ))).1,
        1 + (budgetSearchCounted fuel (restrict x false (((x, v) :: c) :: φ))).2
          + (budgetSearchCounted fuel (restrict x true (((x, v) :: c) :: φ))).2)

/-- The instrumented search returns the answer of `budgetSearch` and the count `searchCalls`. -/
theorem budgetSearchCounted_eq (fuel : ℕ) (φ : CNF) :
    budgetSearchCounted fuel φ = (budgetSearch fuel φ, searchCalls fuel φ) := by
  induction fuel generalizing φ with
  | zero =>
    cases φ with
    | nil => rfl
    | cons c φ => cases c <;> rfl
  | succ fuel ih =>
    cases φ with
    | nil => rfl
    | cons c φ =>
      cases c with
      | nil => rfl
      | cons l c =>
        obtain ⟨x, v⟩ := l
        simp only [budgetSearchCounted, budgetSearch, searchCalls, ih]

theorem searchCalls_lt (fuel : ℕ) (φ : CNF) : searchCalls fuel φ < 2 ^ (fuel + 1) := by
  induction fuel generalizing φ with
  | zero =>
    cases φ with
    | nil => simp [searchCalls]
    | cons c φ => cases c <;> simp [searchCalls]
  | succ fuel ih =>
    have hpos : 0 < 2 ^ (fuel + 1) := by positivity
    have hpow : 2 ^ (fuel + 1 + 1) = 2 * 2 ^ (fuel + 1) := by ring
    cases φ with
    | nil =>
      simp only [searchCalls]
      omega
    | cons c φ =>
      cases c with
      | nil =>
        simp only [searchCalls]
        omega
      | cons l c =>
        obtain ⟨x, v⟩ := l
        simp only [searchCalls]
        have h1 := ih (restrict x false (((x, v) :: c) :: φ))
        have h2 := ih (restrict x true (((x, v) :: c) :: φ))
        omega

/-- Target 5 (EXPONENTIAL upper bound, not a polynomial one). -/
theorem searchCalls_le (fuel : ℕ) (φ : CNF) : searchCalls fuel φ ≤ 2 ^ (fuel + 1) :=
  (searchCalls_lt fuel φ).le

/-- The decider's search makes at most `2 ^ (litCount φ + 1)` calls: exponential in the size. -/
theorem searchCalls_decider_le (φ : CNF) :
    searchCalls (litCount φ) φ ≤ 2 ^ (litCount φ + 1) :=
  searchCalls_le _ _

/-- A family of trivially satisfiable formulas: `n` tautological clauses on distinct variables. -/
def tautFamily : ℕ → CNF
  | 0 => []
  | n + 1 => [(n, true), (n, false)] :: tautFamily n

theorem litCount_tautFamily (n : ℕ) : litCount (tautFamily n) = 2 * n := by
  induction n with
  | zero => rfl
  | succ n ih =>
    simp only [tautFamily, litCount, ih, List.length_cons, List.length_nil]
    omega

theorem restrict_tautFamily (n x : ℕ) (b : Bool) (h : n ≤ x) :
    restrict x b (tautFamily n) = tautFamily n := by
  induction n with
  | zero => simp [tautFamily, restrict]
  | succ n ih =>
    have hne : n ≠ x := by omega
    have hmem : (x, b) ∉ [(n, true), (n, false)] := by
      simp only [List.mem_cons, Prod.mk.injEq, List.not_mem_nil, or_false, not_or, not_and]
      exact ⟨fun hx => absurd hx.symm hne, fun hx => absurd hx.symm hne⟩
    have hfil : [(n, true), (n, false)].filter (fun l : Literal => decide (l.1 ≠ x)) =
        [(n, true), (n, false)] := by
      simp [hne]
    show restrict x b ([(n, true), (n, false)] :: tautFamily n) = _
    rw [restrict_cons_of_not_mem _ hmem, hfil, ih (by omega)]
    rfl

/-- EXPONENTIAL lower bound for this procedure: on `n` tautological clauses it makes exactly
`2 ^ (n + 1) - 1` calls (for every fuel that suffices). -/
theorem searchCalls_tautFamily (n fuel : ℕ) (h : n ≤ fuel) :
    searchCalls fuel (tautFamily n) = 2 ^ (n + 1) - 1 := by
  induction n generalizing fuel with
  | zero => cases fuel <;> rfl
  | succ n ih =>
    obtain ⟨fuel, rfl⟩ : ∃ k, fuel = k + 1 := ⟨fuel - 1, by omega⟩
    have hmem : ∀ b : Bool, (n, b) ∈ [(n, true), (n, false)] := by
      intro b
      cases b <;> simp
    have hres : ∀ b : Bool,
        restrict n b ([(n, true), (n, false)] :: tautFamily n) = tautFamily n := by
      intro b
      rw [restrict_cons_of_mem _ (hmem b), restrict_tautFamily n n b le_rfl]
    show searchCalls (fuel + 1) ([(n, true), (n, false)] :: tautFamily n) = _
    simp only [searchCalls, hres, ih fuel (by omega)]
    have hpos : 0 < 2 ^ (n + 1) := by positivity
    have hpow : 2 ^ (n + 1 + 1) = 2 * 2 ^ (n + 1) := by ring
    omega

/-- The decider itself (fuel `litCount`) makes `2 ^ (n + 1) - 1` calls on `tautFamily n`, a
formula with `n` clauses and `2 * n` literal occurrences. -/
theorem searchCalls_decider_tautFamily (n : ℕ) :
    searchCalls (litCount (tautFamily n)) (tautFamily n) = 2 ^ (n + 1) - 1 :=
  searchCalls_tautFamily n _ (by rw [litCount_tautFamily]; omega)

#print axioms searchCalls_le
#print axioms budgetSearchCounted_eq
#print axioms searchCalls_decider_tautFamily

#eval (List.range 8).map fun n => searchCalls (litCount (tautFamily n)) (tautFamily n)
#eval (List.range 8).map fun n => (budgetSearchCounted (litCount (tautFamily n)) (tautFamily n))

/-! ## 6. Definitional glue: the missing lemma as one proposition -/

/-- Target 6. A degree bound for ANY correct bit decider puts SAT in P. This is glue: it does
NOT prove `SAT ∈ P`; no `DegreeBound` is constructed anywhere in this file. -/
theorem sat_mem_P_of_degreeBound (c : CorrectBitDecider) (d : ℕ) (h : DegreeBound c d) :
    SAT ∈ PEqualNP.Library.P := by
  refine ⟨c.run, c.correct, ⟨⟨h.machine.toTM2ComputableAux,
    Polynomial.C h.scale * Polynomial.X ^ d + Polynomial.C h.scale, fun a => ?_⟩⟩⟩
  refine ⟨(h.machine.outputsFun a).toEvalsTo,
    (h.machine.outputsFun a).steps_le_m.trans ((h.bound _).trans ?_)⟩
  simp

/-- The missing lemma, as a single proposition about the explicit decider of this file. -/
theorem sat_mem_P_of_missing_lemma (h : Nonempty (DegreeBound satDecider 3)) :
    SAT ∈ PEqualNP.Library.P :=
  h.elim fun b => sat_mem_P_of_degreeBound satDecider 3 b

theorem poly_eval_le (p : Polynomial ℕ) (n : ℕ) :
    p.eval n ≤ p.eval 1 * n ^ p.natDegree + p.eval 1 := by
  have hpow : ∀ i ∈ Finset.range (p.natDegree + 1), n ^ i ≤ n ^ p.natDegree + 1 := by
    intro i hi
    have hi' : i ≤ p.natDegree := Nat.lt_succ_iff.mp (Finset.mem_range.mp hi)
    rcases Nat.eq_zero_or_pos n with rfl | hn
    · rcases Nat.eq_zero_or_pos i with rfl | hi0
      · simp
      · simp [Nat.pos_iff_ne_zero.mp hi0]
    · exact (Nat.pow_le_pow_right hn hi').trans (Nat.le_succ _)
  calc p.eval n = ∑ i ∈ Finset.range (p.natDegree + 1), p.coeff i * n ^ i :=
        Polynomial.eval_eq_sum_range n
    _ ≤ ∑ i ∈ Finset.range (p.natDegree + 1), p.coeff i * (n ^ p.natDegree + 1) :=
        Finset.sum_le_sum fun i hi => Nat.mul_le_mul_left _ (hpow i hi)
    _ = (∑ i ∈ Finset.range (p.natDegree + 1), p.coeff i) * (n ^ p.natDegree + 1) := by
        rw [Finset.sum_mul]
    _ = p.eval 1 * (n ^ p.natDegree + 1) := by
        rw [Polynomial.eval_eq_sum_range]
        simp
    _ = p.eval 1 * n ^ p.natDegree + p.eval 1 := by ring

/-- Honest scope of the missing lemma: a degree bound for the explicit decider exists for some
degree exactly when `SAT ∈ P`. So the explicit decider adds NO complexity content: the remaining
obligation is equivalent to the open statement itself. -/
theorem sat_mem_P_iff_degreeBound :
    SAT ∈ PEqualNP.Library.P ↔ ∃ d : ℕ, Nonempty (DegreeBound satDecider d) := by
  constructor
  · rintro ⟨f, hf, ⟨m⟩⟩
    have hfe : f = satRun := by
      funext x
      exact Bool.eq_iff_iff.mpr ((hf x).symm.trans (satRun_correct x))
    subst hfe
    exact ⟨m.time.natDegree,
      ⟨⟨m.toTM2ComputableInTime, m.time.eval 1, fun n => poly_eval_le m.time n⟩⟩⟩
  · rintro ⟨d, ⟨h⟩⟩
    exact sat_mem_P_of_degreeBound satDecider d h

#print axioms sat_mem_P_of_degreeBound
#print axioms sat_mem_P_of_missing_lemma
#print axioms sat_mem_P_iff_degreeBound

/-! ## 7. Ingredients of the summary theorem -/

theorem budgetSearch_ne_none (fuel : ℕ) (φ : CNF) (h : (φ.map List.length).sum ≤ fuel) :
    budgetSearch fuel φ ≠ none := by
  intro hnone
  have hsome := budgetSearch_isSome φ fuel (by rw [litCount_eq_sum]; exact h)
  rw [hnone] at hsome
  simp at hsome

theorem satisfiable_iff_budgetSearch (φ : CNF) :
    Satisfiable φ ↔ budgetSearch (φ.map List.length).sum φ = some true := by
  rw [← litCount_eq_sum, decideSat_correct, decideSat_eq_budgetSearch]
  simp

/-- Exact decoder: `some φ` exactly on the canonical encoding of `φ`, `none` on every other
string (malformed or non-canonical). Axiom-free. -/
def decodeExact (x : List Bool) : Option CNF :=
  match decodeCNF x with
  | some φ => if encodeCNFX φ == x then some φ else none
  | none => none

#print axioms decodeExact

theorem decodeExact_eq_some_iff (x : List Bool) (φ : CNF) :
    decodeExact x = some φ ↔ encodeCNF φ = x := by
  constructor
  · intro h
    unfold decodeExact at h
    cases hd : decodeCNF x with
    | none =>
      rw [hd] at h
      simp at h
    | some ψ =>
      rw [hd] at h
      by_cases hx : encodeCNFX ψ = x
      · simp only [hx, beq_self_eq_true, ite_true, Option.some.injEq] at h
        subst h
        rw [← encodeCNFX_eq]
        exact hx
      · simp [hx] at h
  · rintro rfl
    unfold decodeExact
    rw [decodeCNF_encodeCNF]
    simp [encodeCNFX_eq]

theorem mem_SAT_iff_decodeExact (x : List Bool) :
    x ∈ SAT ↔ ∃ φ, decodeExact x = some φ ∧
      budgetSearch (φ.map List.length).sum φ = some true := by
  constructor
  · rintro ⟨φ, rfl, hsat⟩
    exact ⟨φ, (decodeExact_eq_some_iff _ φ).mpr rfl, (satisfiable_iff_budgetSearch φ).mp hsat⟩
  · rintro ⟨φ, hdec, hs⟩
    exact ⟨φ, (decodeExact_eq_some_iff x φ).mp hdec, (satisfiable_iff_budgetSearch φ).mpr hs⟩

/-- `satRun` is the exact decoder followed by the CNF-level decider. -/
theorem satRun_eq_decodeExact (x : List Bool) :
    satRun x = (match decodeExact x with
      | some φ => decideSat φ
      | none => false) := by
  unfold satRun decodeExact
  cases decodeCNF x with
  | none => rfl
  | some φ =>
    by_cases hx : encodeCNFX φ = x
    · simp [hx]
    · simp [hx]

end PEqualNP.Outside.L_alg001_fable

/-- Summary (decidability by an EXPONENTIAL procedure; NOT a complexity result, NOT `SAT ∈ P`).
The search of the foundation statement, with the same recurrence, is total with the explicit
fuel `(φ.map List.length).sum`, hence decides satisfiability of every CNF; and there is an exact
decoder for the binary encoding, so that membership of an arbitrary bit string in `SAT` is
`decode` followed by `search`. -/
theorem PEqualNP.Outside.L_alg001_fable_decider :
    ∃ search : ℕ → PEqualNP.Search.CNF → Option Bool,
      (∀ fuel, search fuel [] = some true) ∧
      (∀ fuel φ, search fuel ([] :: φ) = some false) ∧
      (∀ x v c φ, search 0 (((x, v) :: c) :: φ) = none) ∧
      (∀ fuel x v c φ,
        search (fuel + 1) (((x, v) :: c) :: φ) =
          let left := search fuel
              (((((x, v) :: c) :: φ).filter fun d => decide ((x, false) ∉ d)).map
                fun d => d.filter fun l => decide (l.1 ≠ x))
          let right := search fuel
              (((((x, v) :: c) :: φ).filter fun d => decide ((x, true) ∉ d)).map
                fun d => d.filter fun l => decide (l.1 ≠ x))
          if left = some true ∨ right = some true then some true
          else if left = some false ∧ right = some false then some false else none) ∧
      (∀ fuel φ, search fuel φ = some true → PEqualNP.Search.Satisfiable φ) ∧
      (∀ fuel φ, search fuel φ = some false → ¬ PEqualNP.Search.Satisfiable φ) ∧
      (∀ (fuel : ℕ) (φ : PEqualNP.Search.CNF),
        (φ.map List.length).sum ≤ fuel → search fuel φ ≠ none) ∧
      (∀ φ, ∃ fuel, search fuel φ ≠ none) ∧
      (∀ φ : PEqualNP.Search.CNF,
        PEqualNP.Search.Satisfiable φ ↔ search (φ.map List.length).sum φ = some true) ∧
      ∃ decode : List Bool → Option PEqualNP.Search.CNF,
        (∀ (x : List Bool) (φ : PEqualNP.Search.CNF),
          decode x = some φ ↔ PEqualNP.Search.encodeCNF φ = x) ∧
        (∀ x : List Bool, x ∈ PEqualNP.Search.SAT ↔
          ∃ φ : PEqualNP.Search.CNF,
            decode x = some φ ∧ search (φ.map List.length).sum φ = some true) := by
  refine ⟨PEqualNP.Outside.L_alg001_residual.budgetSearch, ?_, ?_, ?_, ?_,
    PEqualNP.Outside.L_alg001_residual.budgetSearch_true,
    PEqualNP.Outside.L_alg001_residual.budgetSearch_false,
    PEqualNP.Outside.L_alg001_fable.budgetSearch_ne_none, ?_,
    PEqualNP.Outside.L_alg001_fable.satisfiable_iff_budgetSearch,
    PEqualNP.Outside.L_alg001_fable.decodeExact,
    PEqualNP.Outside.L_alg001_fable.decodeExact_eq_some_iff,
    PEqualNP.Outside.L_alg001_fable.mem_SAT_iff_decodeExact⟩
  · intro fuel; cases fuel <;> rfl
  · intro fuel φ; cases fuel <;> rfl
  · intros; rfl
  · intros; exact PEqualNP.Outside.L_alg001_residual.combine_eq _ _
  · intro φ
    exact ⟨(φ.map List.length).sum,
      PEqualNP.Outside.L_alg001_fable.budgetSearch_ne_none _ φ le_rfl⟩

#print axioms PEqualNP.Outside.L_alg001_fable_decider
