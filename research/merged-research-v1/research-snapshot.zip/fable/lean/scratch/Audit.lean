import L_alg001_fable_decider

/-!
Scratch audit of the compiled module (imports only the olean built from
`L_alg001_fable_decider.lean`; not a deliverable proof).
-/

open Lean Elab Command Meta

/-- Transitive constants of `n`, with the axioms met on the way. -/
partial def auditWalk (env : Environment) (n : Name) : StateM (NameSet × Array Name) Unit := do
  if (← get).1.contains n then return
  modify fun s => (s.1.insert n, s.2)
  match env.find? n with
  | none => pure ()
  | some ci =>
    if ci matches .axiomInfo _ then modify fun s => (s.1, s.2.push n)
    for c in ci.getUsedConstantsAsSet do auditWalk env c

run_cmd do
  let env ← getEnv
  let mods := env.header.moduleNames
  let some myIdx := mods.findIdx? (· == `L_alg001_fable_decider) | throwError "module not found"
  let md := env.header.moduleData[myIdx]!
  let foreign := md.constNames.filter fun n =>
    !((`PEqualNP.Outside.L_alg001_fable).isPrefixOf n) &&
      n != `PEqualNP.Outside.L_alg001_fable_decider
  logInfo m!"AUD1 the module declares {md.constNames.size} constants; outside its namespace: {foreign}"
  -- the theorem type: which project constants does it mention, and from which modules
  let some th := env.find? `PEqualNP.Outside.L_alg001_fable_decider | throwError "missing thm"
  let mut proj : Array (Name × Name) := #[]
  let mut bad : Array (Name × Name) := #[]
  for n in th.type.getUsedConstants do
    match env.getModuleIdxFor? n with
    | some idx =>
      let m := mods[idx.toNat]!
      if m.getRoot == `PEqualNP then proj := proj.push (n, m)
      if (m.getRoot == `PEqualNP && !((`PEqualNP.Defs).isPrefixOf m)) ||
          m.getRoot == `L_alg001_fable_decider then bad := bad.push (n, m)
    | none => bad := bad.push (n, `thisFile)
  logInfo m!"AUD2 project constants in the theorem type: {proj}"
  logInfo m!"AUD3 constants of the theorem type outside the pinned library and the definitions root: {bad}"
  -- independent axiom walk (not `#print axioms`) for the executable definitions and the theorems
  for n in [`PEqualNP.Outside.L_alg001_fable.satRun, `PEqualNP.Outside.L_alg001_fable.decideSat,
      `PEqualNP.Outside.L_alg001_fable.decodeCNF, `PEqualNP.Outside.L_alg001_fable.decodeExact,
      `PEqualNP.Outside.L_alg001_fable.encodeCNFX, `PEqualNP.Outside.L_alg001_fable.searchX,
      `PEqualNP.Outside.L_alg001_fable.satRunRef, `PEqualNP.Outside.L_alg001_fable.decideSatRef,
      `PEqualNP.Outside.L_alg001_fable.satRun_correct, `PEqualNP.Outside.L_alg001_fable.satDecider,
      `PEqualNP.Outside.L_alg001_fable_decider] do
    let (_, (seen, axs)) := (auditWalk env n).run ({}, #[])
    logInfo m!"AUD4 {n}: {seen.size} transitive constants, axioms {axs}"
  -- which constants of the module are definitions with executable content, and their safety
  let mut unsafeOrPartial : Array Name := #[]
  let mut opaques : Array Name := #[]
  let mut axiomsHere : Array Name := #[]
  for c in md.constants do
    if c.isUnsafe || c.isPartial then unsafeOrPartial := unsafeOrPartial.push c.name
    if c matches .opaqueInfo _ then opaques := opaques.push c.name
    if c matches .axiomInfo _ then axiomsHere := axiomsHere.push c.name
  logInfo m!"AUD5 unsafe or partial constants in the module: {unsafeOrPartial}; opaque: {opaques}; axioms declared: {axiomsHere}"
  -- implemented_by / extern attributes on the module's constants
  let mut impl : Array Name := #[]
  for n in md.constNames do
    if (Compiler.getImplementedBy? env n).isSome then impl := impl.push n
    if isExtern env n then impl := impl.push n
  logInfo m!"AUD6 constants of the module with implemented_by or extern: {impl}"
