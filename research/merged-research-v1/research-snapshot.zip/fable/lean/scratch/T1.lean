import PEqualNP.Outside.L_alg001_residual
open PEqualNP.Search
open PEqualNP.Outside.L_alg001_residual
set_option pp.explicit true in
#print PEqualNP.Library.SearchHelpers.restrict
#print axioms combine
#print axioms Nat.bits
#print axioms Nat.binaryRec
#print axioms Nat.div
#print axioms Nat.mod
#print axioms Nat.decEq
#print axioms instDecidableEqProd
#print axioms List.instDecidableMemOfLawfulBEq
#print axioms instLawfulBEqOfDecidableEq
#print axioms instBEqOfDecidableEq
#print axioms instDecidableNot
#print axioms List.filter
#print axioms List.map
#print axioms List.any
#print axioms List.all
#print axioms List.flatMap
#print axioms List.sum
#print axioms List.length
#print axioms instBEqProd
#print axioms List.instBEq
#print axioms List.beq
#print axioms instDecidableEqBool
#print axioms Nat.testBit
#print axioms Nat.shiftRight
#print axioms Nat.bit
#print axioms Nat.land
#print axioms Nat.pow
#print axioms Nat.add
#print axioms Nat.mul
#print axioms Nat.beq
#print axioms List.elem
#print axioms List.contains
#print axioms List.append
#print axioms encodeLiteral
#print axioms encodeClause
#print axioms Option.bind
#print axioms instDecidableAnd
#print axioms Bool.decEq
#print axioms instDecidableEqNat
#print axioms List.instLawfulBEq
#print axioms instLawfulBEqProd
example : DecidableEq (ℕ × Bool) := inferInstance
set_option pp.explicit true in
#synth Decidable (((1:ℕ), true) ∈ ([] : List (ℕ × Bool)))
set_option pp.explicit true in
#synth LawfulBEq (ℕ × Bool)
set_option pp.explicit true in
#synth DecidableEq (ℕ × Bool)
