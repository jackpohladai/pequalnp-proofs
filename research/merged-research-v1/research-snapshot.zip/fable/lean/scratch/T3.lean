import PEqualNP.Outside.L_alg001_residual
open PEqualNP.Search
open PEqualNP.Outside.L_alg001_residual
#print combine
#print combine.match_1
#print axioms combine.match_1

namespace Probe

/-- nested-match combine -/
def comb (a b : Option Bool) : Option Bool :=
  match a with
  | some true => some true
  | some false =>
    match b with
    | some true => some true
    | some false => some false
    | none => none
  | none =>
    match b with
    | some true => some true
    | _ => none
#print axioms comb

def comb2 : Option Bool → Option Bool → Option Bool
  | some a, some b => some (a || b)
  | some true, none => some true
  | none, some true => some true
  | _, _ => none
#print axioms comb2

def comb3 (a b : Option Bool) : Option Bool :=
  if a == some true || b == some true then some true
  else if a == some false && b == some false then some false else none
#print axioms comb3

def bitsAux : ℕ → ℕ → List Bool
  | 0, _ => []
  | fuel + 1, n => if n = 0 then [] else (n % 2 == 1) :: bitsAux fuel (n / 2)
#print axioms bitsAux

def bitsAux2 : ℕ → ℕ → List Bool
  | 0, _ => []
  | fuel + 1, n => bif n == 0 then [] else (n % 2 == 1) :: bitsAux2 fuel (n / 2)
#print axioms bitsAux2

def ofBits : List Bool → ℕ
  | [] => 0
  | b :: bs => Nat.bit b (ofBits bs)
#print axioms ofBits

def restrictB (x : ℕ) (v : Bool) (φ : CNF) : CNF :=
  (φ.filter fun c => !(c.any fun l => l.1 == x && l.2 == v)).map
    fun c => c.filter fun l => !(l.1 == x)
#print axioms restrictB
set_option pp.explicit true in
#print restrictB

def searchB : ℕ → CNF → Option Bool
  | _, [] => some true
  | _, [] :: _ => some false
  | 0, (_ :: _) :: _ => none
  | fuel + 1, ((x, v) :: c) :: φ =>
      comb
        (searchB fuel (restrictB x false (((x, v) :: c) :: φ)))
        (searchB fuel (restrictB x true (((x, v) :: c) :: φ)))
#print axioms searchB

def searchC (fuel : ℕ) (φ : CNF) : Option Bool :=
  match φ with
  | [] => some true
  | [] :: _ => some false
  | ((x, v) :: c) :: ψ =>
    match fuel with
    | 0 => none
    | fuel + 1 =>
      comb
        (searchC fuel (restrictB x false (((x, v) :: c) :: ψ)))
        (searchC fuel (restrictB x true (((x, v) :: c) :: ψ)))
#print axioms searchC

def litCount (φ : CNF) : ℕ := (φ.map List.length).sum
#print axioms litCount

def decodeGo : List Bool → Option (Bool × List Bool) → Clause → Option CNF
  | [], st, cl =>
      match st, cl with
      | none, [] => some []
      | _, _ => none
  | [_], _, _ => none
  | b :: d :: rest, st, cl =>
      if b then
        match st with
        | none => decodeGo rest (some (d, [])) cl
        | some (p, ds) => decodeGo rest (some (p, ds ++ [d])) cl
      else if d then
        match st with
        | none => none
        | some (p, ds) => decodeGo rest none (cl ++ [(ofBits ds, p)])
      else
        match st with
        | none => (decodeGo rest none []).map (cl :: ·)
        | some _ => none
#print axioms decodeGo

example : (([true, false] : List Bool) == [true, false]) = true := rfl
set_option pp.explicit true in
#check (([true, false] : List Bool) == [true, false])
def eqBits (a b : List Bool) : Bool := a == b
#print axioms eqBits
end Probe
