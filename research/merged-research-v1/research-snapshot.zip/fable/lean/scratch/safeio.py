"""Robust file writes for an overloaded machine: retry on EPERM, then read back and verify.
Standard library only."""
import hashlib
import os
import time


def write_bytes(path: str, data: bytes, tries: int = 12, delay: float = 0.5) -> str:
    last = None
    for _ in range(tries):
        try:
            with open(path, "wb") as f:
                f.write(data)
            with open(path, "rb") as f:
                back = f.read()
            if back == data:
                return hashlib.sha256(data).hexdigest()
            last = RuntimeError("read-back mismatch")
        except OSError as e:  # includes PermissionError
            last = e
        time.sleep(delay)
    raise RuntimeError(f"could not write {path}: {last!r}")


def write_text(path: str, text: str, **kw) -> str:
    return write_bytes(path, text.encode("utf-8"), **kw)


def sha256_file(path: str) -> str:
    with open(path, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()
