import Mathlib
import PEqualNP.Defs
import L_alg001_fable_decider

/-!
Scratch emulation of step 4 (STATEMENT) of the project checker; not a deliverable proof.
The recorded statement (statement.txt, pasted verbatim below) is elaborated with the whole of
Mathlib and the definitions root imported, and the theorem compiled from
`L_alg001_fable_decider.lean` (which imports far less) must be a proof of it.
-/

open Lean Elab Command Meta

def PEqualNPCheckerEmu.recorded : Prop :=
    ∃ search : ℕ → PEqualNP.Search.CNF → Option Bool,
          (∀ fuel, search fuel [] = some true) ∧
          (∀ fuel φ, search fuel ([] :: φ) = some false) ∧
          (∀ x v c φ, search 0 (((x, v) :: c) :: φ) = none) ∧
          (∀ fuel x v c φ,
            search (fuel + 1) (((x, v) :: c) :: φ) =
              let left := search fuel
                  (((((x, v) :: c) :: φ).filter fun d => decide ((x, false) ∉ d)).map
                    fun d => d.filter fun l => decide (l.1 ≠ x))
              let right := search fuel
                  (((((x, v) :: c) :: φ).filter fun d => decide ((x, true) ∉ d)).map
                    fun d => d.filter fun l => decide (l.1 ≠ x))
              if left = some true ∨ right = some true then some true
              else if left = some false ∧ right = some false then some false else none) ∧
          (∀ fuel φ, search fuel φ = some true → PEqualNP.Search.Satisfiable φ) ∧
          (∀ fuel φ, search fuel φ = some false → ¬ PEqualNP.Search.Satisfiable φ) ∧
          (∀ (fuel : ℕ) (φ : PEqualNP.Search.CNF),
            (φ.map List.length).sum ≤ fuel → search fuel φ ≠ none) ∧
          (∀ φ, ∃ fuel, search fuel φ ≠ none) ∧
          (∀ φ : PEqualNP.Search.CNF,
            PEqualNP.Search.Satisfiable φ ↔ search (φ.map List.length).sum φ = some true) ∧
          ∃ decode : List Bool → Option PEqualNP.Search.CNF,
            (∀ (x : List Bool) (φ : PEqualNP.Search.CNF),
              decode x = some φ ↔ PEqualNP.Search.encodeCNF φ = x) ∧
            (∀ x : List Bool, x ∈ PEqualNP.Search.SAT ↔
              ∃ φ : PEqualNP.Search.CNF,
                decode x = some φ ∧ search (φ.map List.length).sum φ = some true)

theorem PEqualNPCheckerEmu.accepted : PEqualNPCheckerEmu.recorded :=
  PEqualNP.Outside.L_alg001_fable_decider

#print axioms PEqualNPCheckerEmu.accepted

run_cmd do
  let env ← getEnv
  let some ci := env.find? ``PEqualNPCheckerEmu.recorded | throwError "missing recorded"
  let some th := env.find? ``PEqualNP.Outside.L_alg001_fable_decider | throwError "missing thm"
  logInfo m!"recorded statement syntactically equal to the theorem type: {ci.value! == th.type}"
  let names := env.constants.map₂.foldl (fun acc n _ => n :: acc) ([] : List Name)
  logInfo m!"constants declared by this scratch file: {names}"
  let used := ci.value!.getUsedConstants
  let mods := env.header.moduleNames
  let mut bad : Array (Name × Name) := #[]
  for n in used do
    match env.getModuleIdxFor? n with
    | some idx =>
      let m := mods[idx.toNat]!
      if m.getRoot == `PEqualNP && !((`PEqualNP.Defs).isPrefixOf m) then bad := bad.push (n, m)
      if m.getRoot == `L_alg001_fable_decider then bad := bad.push (n, m)
    | none => bad := bad.push (n, `thisFile)
  logInfo m!"statement constants outside the pinned library and the definitions root: {bad}"
  let projUsed := used.filterMap fun n => match env.getModuleIdxFor? n with
    | some idx => let m := mods[idx.toNat]!; if m.getRoot == `PEqualNP then some (n, m) else none
    | none => none
  logInfo m!"project constants used by the statement: {projUsed}"
