import Mathlib
import PEqualNP.Defs
import L_alg001_fable_decider

/-!
Scratch emulation of steps 3 and 4 (AXIOMS, STATEMENT) of the project checker
`lean/CheckLemma.lean`; not a deliverable proof and not a substitute for the checker.
As in the checker, the recorded statement (statement.txt, pasted verbatim) is elaborated as the
type of a theorem, in parentheses, with `autoImplicit false`, here with the whole of Mathlib and
the definitions root imported. Instead of `sorry` the compiled theorem is given as the proof, so
Lean checks that the theorem of `L_alg001_fable_decider.lean` proves the recorded statement.
-/

open Lean Elab Command Meta

set_option autoImplicit false
theorem PEqualNPCheckerEmu.recorded :
(
∃ search : ℕ → PEqualNP.Search.CNF → Option Bool,
      (∀ fuel, search fuel [] = some true) ∧
      (∀ fuel φ, search fuel ([] :: φ) = some false) ∧
      (∀ x v c φ, search 0 (((x, v) :: c) :: φ) = none) ∧
      (∀ fuel x v c φ,
        search (fuel + 1) (((x, v) :: c) :: φ) =
          let left := search fuel
              (((((x, v) :: c) :: φ).filter fun d => decide ((x, false) ∉ d)).map
                fun d => d.filter fun l => decide (l.1 ≠ x))
          let right := search fuel
              (((((x, v) :: c) :: φ).filter fun d => decide ((x, true) ∉ d)).map
                fun d => d.filter fun l => decide (l.1 ≠ x))
          if left = some true ∨ right = some true then some true
          else if left = some false ∧ right = some false then some false else none) ∧
      (∀ fuel φ, search fuel φ = some true → PEqualNP.Search.Satisfiable φ) ∧
      (∀ fuel φ, search fuel φ = some false → ¬ PEqualNP.Search.Satisfiable φ) ∧
      (∀ (fuel : ℕ) (φ : PEqualNP.Search.CNF),
        (φ.map List.length).sum ≤ fuel → search fuel φ ≠ none) ∧
      (∀ φ, ∃ fuel, search fuel φ ≠ none) ∧
      (∀ φ : PEqualNP.Search.CNF,
        PEqualNP.Search.Satisfiable φ ↔ search (φ.map List.length).sum φ = some true) ∧
      ∃ decode : List Bool → Option PEqualNP.Search.CNF,
        (∀ (x : List Bool) (φ : PEqualNP.Search.CNF),
          decode x = some φ ↔ PEqualNP.Search.encodeCNF φ = x) ∧
        (∀ x : List Bool, x ∈ PEqualNP.Search.SAT ↔
          ∃ φ : PEqualNP.Search.CNF,
            decode x = some φ ∧ search (φ.map List.length).sum φ = some true)
) := PEqualNP.Outside.L_alg001_fable_decider

#print axioms PEqualNPCheckerEmu.recorded

run_cmd do
  let env ← getEnv
  let some rec := env.find? ``PEqualNPCheckerEmu.recorded | throwError "missing recorded"
  let some th := env.find? ``PEqualNP.Outside.L_alg001_fable_decider | throwError "missing thm"
  logInfo m!"EMU1 recorded type structurally equal to the theorem type: {rec.type == th.type}"
  let names := env.constants.map₂.foldl (fun acc n _ => n :: acc) ([] : List Name)
  logInfo m!"EMU2 constants declared by this scratch file: {names}"
  let mods := env.header.moduleNames
  let used := rec.type.getUsedConstants
  let mut bad : Array (Name × Name) := #[]
  let mut proj : Array (Name × Name) := #[]
  for n in used do
    match env.getModuleIdxFor? n with
    | some idx =>
      let m := mods[idx.toNat]!
      if m.getRoot == `PEqualNP then proj := proj.push (n, m)
      if m.getRoot == `PEqualNP && !((`PEqualNP.Defs).isPrefixOf m) then bad := bad.push (n, m)
      if m.getRoot == `L_alg001_fable_decider then bad := bad.push (n, m)
    | none => bad := bad.push (n, `thisFile)
  logInfo m!"EMU3 direct constants of the recorded statement outside the pinned library and the definitions root: {bad}"
  logInfo m!"EMU4 project constants used directly by the recorded statement: {proj}"
  let some myIdx := mods.findIdx? (· == `L_alg001_fable_decider) | throwError "module not found"
  let md := env.header.moduleData[myIdx]!
  let foreign := md.constNames.filter fun n =>
    !((`PEqualNP.Outside.L_alg001_fable).isPrefixOf n) && n != `PEqualNP.Outside.L_alg001_fable_decider
  logInfo m!"EMU5 module declares {md.constNames.size} constants; outside its namespace: {foreign}"
