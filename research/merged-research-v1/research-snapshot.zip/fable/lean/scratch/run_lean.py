#!/usr/bin/env python3
"""Driver: run `lake env lean <args>` inside the (read-only) Lean repository and save the
combined compiler output to a log file under fable/lean. Standard library only.

The machine was heavily overloaded during this work and file creation failed intermittently
with EPERM, so the log is written with retries and read-back verification, and the full output
is ALSO printed to stdout between marker lines so that it is never lost.

usage: run_lean.py <log path> [--lean-path-extra DIR] [--timeout SECONDS] -- <lean args...>
"""
import json
import os
import subprocess
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from safeio import write_text  # noqa: E402

ROOT = "/Users/jackpohlad/Documents/Codex/2026-11-25/fetch-and-follow-the-instructions-at"
REPO = ROOT + "/work/pequalnp-sparse/lean"


def main() -> int:
    argv = sys.argv[1:]
    log = argv.pop(0)
    extra = None
    timeout = 900
    while argv and argv[0] != "--":
        flag = argv.pop(0)
        if flag == "--lean-path-extra":
            extra = argv.pop(0)
        elif flag == "--timeout":
            timeout = int(argv.pop(0))
        else:
            raise SystemExit(f"unknown flag {flag}")
    argv.pop(0)
    env = dict(os.environ)
    # same three settings as work/lean-local-env.sh
    env["ELAN_HOME"] = ROOT + "/work/elan"
    env["XDG_CACHE_HOME"] = ROOT + "/work/lean-local-cache"
    env["PATH"] = ROOT + "/work/elan/bin:" + env.get("PATH", "")
    if extra:
        env["LEAN_PATH"] = extra
    cmd = ["lake", "env", "lean"] + argv
    t0 = time.time()
    started = time.strftime("%Y-%m-%dT%H:%M:%S%z")
    try:
        r = subprocess.run(cmd, cwd=REPO, env=env, capture_output=True, text=True, timeout=timeout)
        out, rc = r.stdout + r.stderr, r.returncode
    except subprocess.TimeoutExpired as e:
        out = ""
        for part in (e.stdout, e.stderr):
            if isinstance(part, bytes):
                out += part.decode("utf-8", "replace")
            elif isinstance(part, str):
                out += part
        rc = -999
    dt = time.time() - t0
    meta = {"cmd": cmd, "cwd": REPO, "lean_path_extra": extra, "exit_code": rc,
            "seconds": round(dt, 1), "started": started, "output_lines": out.count("\n")}
    print("=====BEGIN LEAN OUTPUT=====")
    sys.stdout.write(out if out.endswith("\n") or not out else out + "\n")
    print("=====END LEAN OUTPUT=====")
    print("META " + json.dumps(meta))
    sys.stdout.flush()
    try:
        write_text(log, out, tries=40, delay=1.0)
        write_text(log + ".meta.json", json.dumps(meta, indent=1) + "\n", tries=40, delay=1.0)
        print(f"log written: {log}")
    except Exception as e:  # keep going: the output is on stdout
        print(f"LOG WRITE FAILED: {e!r}")
    return 0 if rc == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
