import PEqualNP.Outside.L_alg001_residual

namespace PEqualNP.Outside.L_alg001_fable

open PEqualNP.Search
open PEqualNP.Library.SearchHelpers (restrict)
open PEqualNP.Outside.L_alg001_residual

/-! ## 0. Axiom-free executable building blocks -/

/-- Number of literal occurrences of a formula (the fuel that always suffices). -/
def litCount : CNF → ℕ
  | [] => 0
  | c :: φ => c.length + litCount φ

/-- Boolean test for `(x, v) ∈ c`. -/
def hasLit (x : ℕ) (v : Bool) (c : Clause) : Bool :=
  c.any fun l => l.1 == x && l.2 == v

/-- Axiom-free twin of `restrict`. -/
def restrictX (x : ℕ) (v : Bool) (φ : CNF) : CNF :=
  (φ.filter fun c => !hasLit x v c).map fun c => c.filter fun l => !(l.1 == x)

/-- Axiom-free twin of `combine`. -/
def combineX (a b : Option Bool) : Option Bool :=
  if a == some true || b == some true then some true
  else if a == some false && b == some false then some false else none

/-- Axiom-free twin of `budgetSearch`. -/
def searchX : ℕ → CNF → Option Bool
  | 0, φ =>
    (match φ with
    | [] => some true
    | cl :: _ =>
      (match cl with
      | [] => some false
      | _ :: _ => none))
  | fuel + 1, φ =>
    (match φ with
    | [] => some true
    | cl :: _ =>
      (match cl with
      | [] => some false
      | l :: _ =>
        combineX (searchX fuel (restrictX l.1 false φ)) (searchX fuel (restrictX l.1 true φ))))

#print axioms litCount
#print axioms hasLit
#print axioms restrictX
#print axioms combineX
#print axioms searchX

/-! ## 1. Completeness of the existing search -/

theorem litCount_eq_sum (φ : CNF) : litCount φ = (φ.map List.length).sum := by
  induction φ with
  | nil => rfl
  | cons c φ ih => simp [litCount, ih]

theorem restrict_cons_of_mem {x : ℕ} {b : Bool} {cl : Clause} (φ : CNF) (h : (x, b) ∈ cl) :
    restrict x b (cl :: φ) = restrict x b φ := by
  simp [restrict, h]

theorem restrict_cons_of_not_mem {x : ℕ} {b : Bool} {cl : Clause} (φ : CNF) (h : (x, b) ∉ cl) :
    restrict x b (cl :: φ) = (cl.filter fun l => decide (l.1 ≠ x)) :: restrict x b φ := by
  simp [restrict, h]

theorem litCount_restrict_le (x : ℕ) (b : Bool) (φ : CNF) :
    litCount (restrict x b φ) ≤ litCount φ := by
  induction φ with
  | nil => simp [restrict, litCount]
  | cons cl φ ih =>
    by_cases h : (x, b) ∈ cl
    · rw [restrict_cons_of_mem φ h]
      simp only [litCount]
      omega
    · rw [restrict_cons_of_not_mem φ h]
      simp only [litCount]
      have := List.length_filter_le (fun l : Literal => decide (l.1 ≠ x)) cl
      omega

/-- Key lemma: branching on the head literal's variable strictly decreases the literal count. -/
theorem litCount_restrict_lt (x : ℕ) (v b : Bool) (c : Clause) (φ : CNF) :
    litCount (restrict x b (((x, v) :: c) :: φ)) < litCount (((x, v) :: c) :: φ) := by
  have hle := litCount_restrict_le x b φ
  by_cases h : (x, b) ∈ (x, v) :: c
  · rw [restrict_cons_of_mem φ h]
    simp only [litCount, List.length_cons]
    omega
  · rw [restrict_cons_of_not_mem φ h]
    have hf : ((x, v) :: c).filter (fun l : Literal => decide (l.1 ≠ x)) =
        c.filter (fun l : Literal => decide (l.1 ≠ x)) := by
      apply List.filter_cons_of_neg
      simp
    rw [hf]
    simp only [litCount, List.length_cons]
    have := List.length_filter_le (fun l : Literal => decide (l.1 ≠ x)) c
    omega

theorem combine_isSome {a b : Option Bool} (ha : a.isSome) (hb : b.isSome) :
    (combine a b).isSome := by
  cases a with
  | none => simp at ha
  | some a =>
    cases b with
    | none => simp at hb
    | some b => cases a <;> cases b <;> rfl

/-- Target 1: with fuel at least the literal count the search always returns a definite answer. -/
theorem budgetSearch_isSome (φ : CNF) (fuel : ℕ) (h : litCount φ ≤ fuel) :
    (budgetSearch fuel φ).isSome := by
  induction fuel generalizing φ with
  | zero =>
    cases φ with
    | nil => rfl
    | cons c φ =>
      cases c with
      | nil => rfl
      | cons l c => simp [litCount] at h
  | succ fuel ih =>
    cases φ with
    | nil => rfl
    | cons c φ =>
      cases c with
      | nil => rfl
      | cons l c =>
        obtain ⟨x, v⟩ := l
        simp only [budgetSearch]
        apply combine_isSome
        · apply ih
          have := litCount_restrict_lt x v false c φ
          omega
        · apply ih
          have := litCount_restrict_lt x v true c φ
          omega

/-! ## 2. The CNF-level decider -/

theorem hasLit_eq (x : ℕ) (v : Bool) (c : Clause) : hasLit x v c = decide ((x, v) ∈ c) := by
  apply Bool.eq_iff_iff.mpr
  simp only [hasLit, List.any_eq_true, Bool.and_eq_true, beq_iff_eq, decide_eq_true_eq]
  constructor
  · rintro ⟨⟨y, w⟩, hl, h1, h2⟩
    simp only at h1 h2
    subst h1 h2
    exact hl
  · intro h
    exact ⟨(x, v), h, rfl, rfl⟩

theorem restrictX_eq (x : ℕ) (v : Bool) (φ : CNF) : restrictX x v φ = restrict x v φ := by
  have h1 : (fun c : Clause => !hasLit x v c) = (fun c : Clause => decide ((x, v) ∉ c)) := by
    funext c
    rw [hasLit_eq]
    simp
  have h2 : (fun l : Literal => !(l.1 == x)) = (fun l : Literal => decide (l.1 ≠ x)) := by
    funext l
    simp
  simp only [restrictX, restrict, h1, h2]

theorem combineX_eq (a b : Option Bool) : combineX a b = combine a b := by
  cases a with
  | none =>
    cases b with
    | none => rfl
    | some b => cases b <;> rfl
  | some a =>
    cases b with
    | none => cases a <;> rfl
    | some b => cases a <;> cases b <;> rfl

theorem searchX_eq (fuel : ℕ) (φ : CNF) : searchX fuel φ = budgetSearch fuel φ := by
  induction fuel generalizing φ with
  | zero =>
    cases φ with
    | nil => rfl
    | cons c φ => cases c <;> rfl
  | succ fuel ih =>
    cases φ with
    | nil => rfl
    | cons c φ =>
      cases c with
      | nil => rfl
      | cons l c =>
        obtain ⟨x, v⟩ := l
        simp only [searchX, budgetSearch, ih, restrictX_eq, combineX_eq]

/-- Target 2: the explicit CNF-level decider (axiom-free twin of
`budgetSearch (litCount φ) φ == some true`, see `decideSat_eq_budgetSearch`). -/
def decideSat (φ : CNF) : Bool := searchX (litCount φ) φ == some true

#print axioms decideSat

theorem decideSat_eq_budgetSearch (φ : CNF) :
    decideSat φ = (budgetSearch (litCount φ) φ == some true) := by
  simp only [decideSat, searchX_eq]

theorem decideSat_correct (φ : CNF) : Satisfiable φ ↔ decideSat φ = true := by
  rw [decideSat_eq_budgetSearch]
  have hsome := budgetSearch_isSome φ (litCount φ) le_rfl
  have hc := budgetSearch_correct (litCount φ) φ
  cases hres : budgetSearch (litCount φ) φ with
  | none => rw [hres] at hsome; simp at hsome
  | some b =>
    rw [hres] at hc
    simp only [AnswerCorrect] at hc
    rw [hc]
    cases b <;> simp

#print axioms budgetSearch_isSome
#print axioms decideSat_eq_budgetSearch
#print axioms decideSat_correct

end PEqualNP.Outside.L_alg001_fable
