import PEqualNP.Outside.L_alg001_residual
open PEqualNP.Search
open PEqualNP.Outside.L_alg001_residual
set_option linter.auxLemma false
#print axioms PEqualNP.Library.SearchHelpers.restrict._proof_1
#check @PEqualNP.Library.SearchHelpers.restrict._proof_1
#print axioms instLawfulBCmpCompare_mathlib
#print axioms Bool.linearOrder
#print axioms Std.LawfulBCmp.toLawfulBEqCmp
#print axioms Std.instLawfulBEqOrdOfLawfulOrderOrdOfLawfulOrderBEq
#print axioms Nat.instLawfulOrderOrd
#print axioms Prod.instLawfulBEq
#print axioms Option.filter
#check @Option.filter_eq_some_iff
#check @Nat.size_eq_bits_len
#check @Nat.size_le
#check @Nat.lt_two_pow_self
#check @List.length_flatMap
#check @ite_true
#check @ite_eq_right
#check @Polynomial.eval_eq_sum_range
