import Mathlib.Combinatorics.SimpleGraph.Tutte

/-!
Fable (local research, L-alg-001): mathematical soundness of the UNSAT certificate used by the
read-twice cardinality island (`layers.py`, Theorem M (d) in `theory/theory.md`).

`layers.verify_barrier` counts the odd components left after deleting a vertex set `u` and
reports "no perfect matching" only if that count exceeds `|u|`. Mathlib calls such a set a
Tutte violator. The first theorem is the soundness of the certificate; the second records that
the certificate is also complete (Tutte's theorem), i.e. a barrier always exists when there is
no perfect matching. Neither is a statement about the Python code, the reduction of a CNF to
a matching problem, or running time.
-/

namespace PEqualNP.Outside.L_alg001_fable_matching

open SimpleGraph

/-- A Tutte violator excludes every perfect matching (soundness of the certificate). -/
theorem no_perfectMatching_of_barrier {V : Type*} [Finite V] (G : SimpleGraph V) (u : Set V)
    (h : G.IsTutteViolator u) : ¬ ∃ M : G.Subgraph, M.IsPerfectMatching := by
  rintro ⟨M, hM⟩
  exact not_isTutteViolator_of_isPerfectMatching hM u h

/-- Conversely a graph without a perfect matching has a Tutte violator (completeness). -/
theorem barrier_of_no_perfectMatching {V : Type*} [Finite V] (G : SimpleGraph V)
    (h : ¬ ∃ M : G.Subgraph, M.IsPerfectMatching) : ∃ u : Set V, G.IsTutteViolator u := by
  by_contra hne
  exact h (tutte.mpr fun u hu => hne ⟨u, hu⟩)

end PEqualNP.Outside.L_alg001_fable_matching

/-- The Tutte–Berge certificate is sound and complete for "no perfect matching". -/
theorem PEqualNP.Outside.L_alg001_fable_matching :
    ∀ (V : Type) [Finite V] (G : SimpleGraph V),
      (¬ ∃ M : G.Subgraph, M.IsPerfectMatching) ↔
        ∃ u : Set V,
          u.ncard < ((⊤ : G.Subgraph).deleteVerts u).coe.oddComponents.ncard := by
  intro V _ G
  constructor
  · intro h
    exact PEqualNP.Outside.L_alg001_fable_matching.barrier_of_no_perfectMatching G h
  · rintro ⟨u, hu⟩
    exact PEqualNP.Outside.L_alg001_fable_matching.no_perfectMatching_of_barrier G u hu

#print axioms PEqualNP.Outside.L_alg001_fable_matching
