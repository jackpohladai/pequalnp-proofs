
/-! # Test harness

Everything above this line is a verbatim copy of `L_alg001_fable_decider.lean`. The harness below
executes the decider (compiled/interpreted code, not kernel reduction):

* on every bit string of length at most `maxLen` (default 14), tallying how many strings decode,
  how many are canonical encodings, how many are accepted, and whether `satRun` and the literal
  reference `satRunRef` ever differ;
* on the adversarial corpus (`corpus.jsonl`, read-only), comparing `decideSat`, `decideSatRef`
  and `satRun ∘ encodeCNF` with the status recorded by the independent exhaustive oracle.

Correctness is proved above; this is a sanity check of the executed code and of the corpus.
-/

namespace PEqualNP.Outside.L_alg001_fable_run

open PEqualNP.Search PEqualNP.Outside.L_alg001_fable

/-- All bit strings of a given length, in lexicographic order (`false < true`). -/
def allStrings : Nat → List (List Bool)
  | 0 => [[]]
  | n + 1 => (allStrings n).map (fun x => false :: x) ++ (allStrings n).map (fun x => true :: x)

structure Tally where
  total : Nat := 0
  decodable : Nat := 0
  canonical : Nat := 0
  sat : Nat := 0
  refMismatch : Nat := 0
  hash : Nat := 0

def tallyStep (t : Tally) (x : List Bool) : Tally :=
  let dec := (decodeCNF x).isSome
  let can := (decodeExact x).isSome
  let s := satRun x
  let r := satRunRef x
  { total := t.total + 1
    decodable := t.decodable + (if dec then 1 else 0)
    canonical := t.canonical + (if can then 1 else 0)
    sat := t.sat + (if s then 1 else 0)
    refMismatch := t.refMismatch + (if s == r then 0 else 1)
    hash := (t.hash * 31 + (if s then 2 else 1) + (if can then 4 else 0)) % 1000000007 }

def runStrings (maxLen : Nat) : IO Nat := do
  let mut total := 0
  let mut decodable := 0
  let mut canonical := 0
  let mut sat := 0
  let mut mismatch := 0
  for len in [0:maxLen + 1] do
    let t := (allStrings len).foldl tallyStep {}
    IO.println s!"STRINGS len={len} total={t.total} decodable={t.decodable} canonical={t.canonical} sat={t.sat} ref_mismatch={t.refMismatch} hash={t.hash}"
    total := total + t.total
    decodable := decodable + t.decodable
    canonical := canonical + t.canonical
    sat := sat + t.sat
    mismatch := mismatch + t.refMismatch
  IO.println s!"STRINGS_TOTAL max_len={maxLen} total={total} decodable={decodable} canonical={canonical} sat={sat} unsat_canonical={canonical - sat} ref_mismatch={mismatch}"
  return mismatch

/-- One corpus line: identifier, oracle status (`true` for SAT), formula. A signed non-zero
integer `k` becomes the literal `(|k|, 0 < k)`. -/
def parseCase (line : String) : Except String (String × Bool × CNF) := do
  let j ← Lean.Json.parse line
  let id ← j.getObjValAs? String "id"
  let oracle ← j.getObjVal? "oracle"
  let status ← oracle.getObjValAs? String "status"
  let clausesJ ← j.getObjVal? "clauses"
  let clauses ← clausesJ.getArr?
  let mut φ : CNF := []
  for cj in clauses do
    let lits ← cj.getArr?
    let mut c : Clause := []
    for lj in lits do
      let k ← lj.getInt?
      if k == 0 then throw "zero literal"
      c := c ++ [(k.natAbs, decide (0 < k))]
    φ := φ ++ [c]
  if status == "SAT" then return (id, true, φ)
  else if status == "UNSAT" then return (id, false, φ)
  else throw s!"unexpected oracle status {status}"

def runCorpus (path : System.FilePath) : IO Nat := do
  let text ← IO.FS.readFile path
  let lines := (text.splitOn "\n").filter (fun l => l != "")
  let mut agree := 0
  let mut disagree := 0
  let mut sat := 0
  let mut unsat := 0
  let mut bad := 0
  let mut maxCalls := 0
  let mut maxLits := 0
  let mut maxBits := 0
  for line in lines do
    match parseCase line with
    | .error e =>
      bad := bad + 1
      IO.println s!"CORPUS_PARSE_ERROR {e}"
    | .ok (id, expected, φ) =>
      let x := encodeCNF φ
      let a := decideSat φ
      let b := satRun x
      let c := decideSatRef φ
      if a == expected && b == expected && c == expected then
        agree := agree + 1
      else
        disagree := disagree + 1
        IO.println s!"CORPUS_DISAGREE id={id} oracle={expected} decideSat={a} satRun={b} decideSatRef={c}"
      if expected then sat := sat + 1 else unsat := unsat + 1
      maxCalls := max maxCalls (budgetSearchCounted (litCount φ) φ).2
      maxLits := max maxLits (litCount φ)
      maxBits := max maxBits x.length
  IO.println s!"CORPUS cases={lines.length} parse_errors={bad} agree={agree} disagree={disagree} oracle_sat={sat} oracle_unsat={unsat} max_literal_occurrences={maxLits} max_input_bits={maxBits} max_search_calls={maxCalls}"
  return disagree + bad

end PEqualNP.Outside.L_alg001_fable_run

/-- usage: `lake env lean --run RunDecider.lean <corpus.jsonl> [maxLen]` -/
def main (args : List String) : IO UInt32 := do
  let maxLen := (args.getD 1 "14").toNat!
  let m ← PEqualNP.Outside.L_alg001_fable_run.runStrings maxLen
  let d ← match args.head? with
    | some path => PEqualNP.Outside.L_alg001_fable_run.runCorpus path
    | none => do
      IO.println "CORPUS skipped (no path given)"
      pure 0
  if m == 0 && d == 0 then
    IO.println "RUN_DECIDER_RESULT PASS"
    return 0
  else
    IO.println "RUN_DECIDER_RESULT FAIL"
    return 1
