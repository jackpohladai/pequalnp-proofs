import sys, random, math
from h_probe import run, xor_clauses
def xorsys(n, m, k, rng):
    sol = [rng.randrange(2) for _ in range(n + 1)]
    eqs = []
    for _ in range(m):
        vs = rng.sample(range(1, n + 1), k)
        eqs.append((vs, sum(sol[v] for v in vs) % 2))
    cl = []
    for vs, r in eqs: cl += xor_clauses(vs, r)
    return eqs, cl
def rank(rows):
    rows = list(rows); r = 0
    basis = {}
    for x in rows:
        while x:
            h = x.bit_length() - 1
            if h in basis: x ^= basis[h]
            else: basis[h] = x; r += 1; break
    return r
def state_profile(eqs, n, order):
    """Trellis-style connectivity of the full row space along the order:
    s_t = dim W - dim W(first t coords) - dim W(last n-t coords), W = rowspace."""
    pos = {v: i for i, v in enumerate(order)}
    rows = [sum(1 << pos[v] for v in vs) for vs, _ in eqs]
    dimW = rank(rows); best = 0
    for t in range(1, n):
        lowmask = (1 << t) - 1
        # dim of subcode supported on first t coords = dimW - rank(rows projected on last n-t coords)
        past = dimW - rank([x >> t for x in rows])
        fut = dimW - rank([x & lowmask for x in rows])
        best = max(best, dimW - past - fut)
    return best
rng = random.Random(11)
for dens in (0.5, 0.7, 0.85, 1.0):
    for n in (16, 24, 32, 40, 48):
        m = round(dens * n)
        eqs, cl = xorsys(n, m, 3, rng)
        order = list(range(1, n + 1))
        r = run(n, cl, order, cap=300000, tcap=12)
        print(f'dens={dens} n={n} m={m} natural: {r} trellis_state_max={state_profile(eqs, n, order)}', flush=True)
