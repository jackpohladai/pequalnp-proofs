import random
from h_probe import run, xor_clauses
def rand_k(n, m, k, rng):
    return [[v * rng.choice((-1, 1)) for v in rng.sample(range(1, n + 1), k)] for _ in range(m)]
def mindeg_order(n, clauses):
    adj = {v: set() for v in range(1, n + 1)}
    for c in clauses:
        vs = {abs(l) for l in c}
        for a in vs: adj[a] |= vs - {a}
    order = []; alive = set(adj)
    while alive:
        v = min(alive, key=lambda x: (len(adj[x]), x))
        nb = adj[v]
        for a in nb:
            adj[a] |= nb - {a}; adj[a].discard(v)
        alive.discard(v); order.append(v); del adj[v]
    return order
rng = random.Random(5)
print('== random 2-CNF (satisfiable regime, density 0.9) ==')
for n in (20, 40, 60, 80, 120, 160):
    cl = rand_k(n, round(0.9 * n), 2, rng)
    print(n, 'natural', run(n, cl, list(range(1, n + 1)), tcap=10), 'mindeg', run(n, cl, mindeg_order(n, cl), tcap=10), flush=True)
print('== random 3-CNF density 3.0 ==')
for n in (16, 20, 24, 28, 32, 36, 40):
    cl = rand_k(n, 3 * n, 3, rng)
    print(n, 'natural', run(n, cl, list(range(1, n + 1)), tcap=10), 'mindeg', run(n, cl, mindeg_order(n, cl), tcap=10), flush=True)
print('== 3-XOR m=n planted, larger n ==')
for n in (40, 56, 72, 88):
    sol = [rng.randrange(2) for _ in range(n + 1)]; cl = []
    for _ in range(n):
        vs = rng.sample(range(1, n + 1), 3); cl += xor_clauses(vs, sum(sol[v] for v in vs) % 2)
    print(n, 'natural', run(n, cl, list(range(1, n + 1)), tcap=10), 'mindeg', run(n, cl, mindeg_order(n, cl), tcap=10), flush=True)
