"""Quick hypothesis probes for residual_dag (read-only import)."""
import sys, random, time, itertools, math, resource
sys.path.insert(0, '../../native-search')
sys.setrecursionlimit(100000)
from residual_dag import DAG

def run(n, clauses, order, cap=400000, tcap=20.0):
    d = DAG(); root = d.cnf(clauses); t0 = time.time(); peak = 0
    for v in order:
        root = d.forget(root, v)
        if len(d.nodes) > cap or time.time() - t0 > tcap:
            return dict(res='CAP', alloc=len(d.nodes), sec=round(time.time()-t0, 2))
    assert root in (0, 1)
    return dict(res='SAT' if root == 1 else 'UNSAT', alloc=len(d.nodes), sec=round(time.time()-t0, 2))

def xor_clauses(vs, rhs):
    out = []
    for bits in itertools.product((0, 1), repeat=len(vs)):
        if sum(bits) % 2 != rhs:      # forbid assignments with wrong parity
            out.append([v if b == 0 else -v for v, b in zip(vs, bits)])
    return out

def random_regular(nv, deg, rng):
    while True:
        stubs = list(range(nv)) * deg; rng.shuffle(stubs)
        edges = [tuple(sorted(stubs[i:i+2])) for i in range(0, len(stubs), 2)]
        if any(a == b for a, b in edges) or len(set(edges)) != len(edges): continue
        return edges

def tseitin(nv, rng, sat=False):
    edges = random_regular(nv, 3, rng)
    inc = {v: [] for v in range(nv)}
    for i, (a, b) in enumerate(edges, 1): inc[a].append(i); inc[b].append(i)
    charge = [0] * nv
    if not sat: charge[0] = 1
    cl = []
    for v in range(nv): cl += xor_clauses(inc[v], charge[v])
    return len(edges), cl

def xor3(n, m, rng, planted=True):
    """m random 3-variable parity equations over n vars, each var in ~3m/n equations."""
    sol = [rng.randrange(2) for _ in range(n + 1)]
    cl = []
    for _ in range(m):
        vs = rng.sample(range(1, n + 1), 3)
        rhs = (sol[vs[0]] + sol[vs[1]] + sol[vs[2]]) % 2 if planted else rng.randrange(2)
        cl += xor_clauses(vs, rhs)
    return n, cl

def php(p, h):
    var = lambda i, k: i * h + k + 1
    cl = [[var(i, k) for k in range(h)] for i in range(p)]
    for k in range(h):
        for i in range(p):
            for j in range(i + 1, p): cl.append([-var(i, k), -var(j, k)])
    return p * h, cl, var

if __name__ == '__main__':
    rng = random.Random(7)
    print('== H2 Tseitin random cubic, UNSAT, three orders ==')
    for nv in (16, 32, 64, 128, 256):
        n, cl = tseitin(nv, rng)
        row = []
        for name in ('natural', 'reverse', 'shuffle'):
            order = list(range(1, n + 1))
            if name == 'reverse': order.reverse()
            if name == 'shuffle': random.Random(nv).shuffle(order)
            row.append((name, run(n, cl, order)))
        print(nv, n, row, flush=True)
    print('== H3 random 3-XOR, m = n (planted SAT), three orders ==')
    for n in (10, 14, 18, 22, 26, 30):
        _, cl = xor3(n, n, rng)
        row = []
        for name in ('natural', 'shuffle'):
            order = list(range(1, n + 1))
            if name == 'shuffle': random.Random(n).shuffle(order)
            row.append((name, run(n, cl, order)))
        print(n, row, flush=True)
    print('== H4 PHP hole-wise vs pigeon-wise ==')
    for h in (3, 4, 5, 6, 7, 8):
        n, cl, var = php(h + 1, h)
        holewise = [var(i, k) for k in range(h) for i in range(h + 1)]
        pigeonwise = [var(i, k) for i in range(h + 1) for k in range(h)]
        pred = sum(math.comb(h + 1, j) for j in range(0, h + 1))
        print(h, 'hole', run(n, cl, holewise), 'pigeon', run(n, cl, pigeonwise), 'sumC', pred, flush=True)
