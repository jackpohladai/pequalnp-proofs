# Reproducing the Fable results (work/alg001/fable)

All commands are run from `work/alg001/fable/` unless stated otherwise. Python 3.12, standard
library only. Every script is deterministic (fixed seeds) and every single run stays below
30 s on an unloaded machine; the time-boxed fuzzers print how many cases they covered.

## 1. Theorem A: exponential behaviour of the unchanged residual DAG at induced width 2
    cd theory
    python3 width2_counterexample.py         # allocated = 2^(k+1)+7k+7 for k = 1..14, width 2
    python3 verify_theoremA_invariant.py     # the induction invariant as child-id set equality

## 2. Repairs of the syntactic DAG (R1, R1b) and the Tseitin fragility test
    cd repairs
    python3 miniscope_dag.py                 # R1 exactness (29,184 checks)
    python3 miniscope_dag_b.py               # R1b exactness (26,976 checks)
    python3 compare_r0_r1.py                 # R0 vs R1 on W_k, G_k, PHP, Tseitin, 3-CNF, 3-XOR
    python3 ../theory/tseitin_fragility.py   # R1 regression on Tseitin + redundant clauses
    python3 compare_three.py                 # R0 / R1 / R1b side by side

## 3. Polynomial islands (layers.py)
    cd tests
    python3 test_layers.py                   # blossom + barrier vs brute force, layers vs brute
                                             # force, structured families (PHP, Hall, K_m, boards,
                                             # Tseitin, mixed parity/matching)
    python3 test_island_stage.py             # island_stage vs brute force

## 4. The candidate (islands + CFPE engine)
    cd ../adversarial                        # i.e. work/alg001/adversarial
    python3 run_candidate.py --candidate <abs path>/fable/candidate.py --keep-going \
            --output <abs path>/fable/experiments/corpus-report.json
    cd <abs path>/fable/tests && python3 test_candidate.py
    cd <abs path>/fable/review_lead && python3 fuzz_integrated.py .. 25 1
    python3 islands_vs_engine.py .. ../experiments/islands_vs_engine.json

## 5. Lean (Lean 4.36.0 + pinned Mathlib; never `lake build`)
    source work/lean-local-env.sh
    cd work/pequalnp-sparse/lean
    lake env lean <abs path>/fable/lean/L_alg001_fable_engine.lean
    lake env lean <abs path>/fable/lean/L_alg001_fable_matching.lean
    lake env lean <abs path>/fable/lean/L_alg001_fable_decider.lean

## 6. Review of the other workers' candidates (read-only imports)
    cd review_lead
    python3 fuzz_others.py                   # 10,000 differential cases each
    python3 scale_others.py                  # W_k, PHP, Tseitin, 3-XOR, random 3-CNF
    python3 scale_others_hard.py             # structured families with known answers

## 7. Decisive tests of the unchanged residual DAG under many orders
    cd dag_analysis && python3 run_experiments.py E1   # ... E8, see dag_analysis/REPORT.md
