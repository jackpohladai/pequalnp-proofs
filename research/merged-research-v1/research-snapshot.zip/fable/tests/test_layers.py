"""Independent tests for fable/layers.py (brute force oracles only).
Run: python3 test_layers.py            (each block is time-boxed well under 30 s)"""
import sys, random, itertools, time, json
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import layers as L

def brute_sat(clauses):
    vs = sorted({abs(l) for c in clauses for l in c})
    for bits in itertools.product((False, True), repeat=len(vs)):
        a = dict(zip(vs, bits))
        if all(any(a[abs(l)] == (l > 0) for l in c) for c in clauses): return True
    return False

def xor_clauses(vs, rhs):
    return [[v if b == 0 else -v for v, b in zip(vs, bits)]
            for bits in itertools.product((0, 1), repeat=len(vs)) if sum(bits) % 2 != rhs]

def model_ok(clauses, model):
    return all(any(model[abs(l)] == (l > 0) for l in c) for c in clauses)

def brute_max_matching(n, edges):
    best = 0
    def rec(i, used, size):
        nonlocal best
        best = max(best, size)
        for j in range(i, len(edges)):
            a, b = edges[j]
            if not (used >> a) & 1 and not (used >> b) & 1:
                rec(j + 1, used | (1 << a) | (1 << b), size + 1)
    rec(0, 0, 0); return best

def test_matching(seconds=8, seed=1):
    rng = random.Random(seed); t0 = time.time(); cases = barriers = 0
    while time.time() - t0 < seconds:
        n = rng.randrange(1, 10); p = rng.choice((0.15, 0.3, 0.5, 0.8))
        edges = [(a, b) for a in range(n) for b in range(a + 1, n) if rng.random() < p]
        adj = [[] for _ in range(n)]
        for a, b in edges: adj[a].append(b); adj[b].append(a)
        m = L.max_matching(n, adj)
        size = sum(1 for v in range(n) if m[v] != -1) // 2
        assert all(m[m[v]] == v and m[v] in adj[v] for v in range(n) if m[v] != -1)
        assert size == brute_max_matching(n, edges), (n, edges, size)
        slow = L.tutte_berge_barrier(n, adj, list(m), slow=True)
        barrier = L.tutte_berge_barrier(n, adj, m)
        assert barrier is not None and barrier == slow, ('fast and slow Gallai-Edmonds sets differ', n, edges)
        seen = [v in barrier for v in range(n)]; odd = 0
        for s in range(n):
            if seen[s]: continue
            seen[s] = True; st = [s]; sz = 0
            while st:
                v = st.pop(); sz += 1
                for u in adj[v]:
                    if not seen[u]: seen[u] = True; st.append(u)
            odd += sz & 1
        assert odd - len(barrier) == n - 2 * size, ('Tutte-Berge equality failed', n, edges)   # barrier is tight
        ok, _ = L.verify_barrier(n, adj, barrier)
        assert ok == (n - 2 * size > 0)
        cases += 1; barriers += ok
    return dict(graphs=cases, graphs_with_deficiency=barriers)

def random_group_formula(rng):
    """Random read-twice cardinality system, then renamed and polarity-flipped."""
    ngroups = rng.randrange(1, 6); nvars = rng.randrange(1, 11)
    members = [[] for _ in range(ngroups)]
    for v in range(1, nvars + 1):
        for g in rng.sample(range(ngroups), min(ngroups, rng.choice((1, 2, 2, 2)))):
            members[g].append(v)
    clauses = []
    for g in members:
        if not g: continue
        t = rng.choice('LUXP')
        if t == 'P':
            if 2 <= len(g) <= 5:
                clauses += xor_clauses(g, rng.randrange(2)); continue
            t = 'X'
        if t in 'LX' and len(g) >= 2: clauses.append(list(g))
        if t in 'LX' and len(g) == 1 and rng.random() < 0.3: clauses.append(list(g))
        if t in 'UX':
            clauses += [[-a, -b] for a, b in itertools.combinations(g, 2)]
    used = sorted({abs(l) for c in clauses for l in c})
    if not used: return None
    perm = dict(zip(used, rng.sample(range(1, len(used) + 1), len(used))))
    flip = {v: rng.choice((1, -1)) for v in used}
    clauses = [tuple(perm[abs(l)] * (1 if l > 0 else -1) * flip[abs(l)] for l in c) for c in clauses]
    rng.shuffle(clauses)
    return list(dict.fromkeys(clauses))

def random_tight_groups(rng):
    """Like random_group_formula but biased to UNSAT: few variables, mostly exactly-one groups."""
    ngroups = rng.randrange(2, 7); nvars = rng.randrange(1, 8)
    members = [[] for _ in range(ngroups)]
    for v in range(1, nvars + 1):
        for g in rng.sample(range(ngroups), 2 if rng.random() < 0.85 else 1):
            members[g].append(v)
    clauses = []
    for g in members:
        t = rng.choice('XXXLU')
        if not g:
            continue
        if t in 'LX': clauses.append(list(g))
        if t in 'UX': clauses += [[-a, -b] for a, b in itertools.combinations(g, 2)]
    if any(len(c) == 1 for c in clauses) and rng.random() < 0.7:
        clauses = [c for c in clauses if len(c) != 1]
    used = sorted({abs(l) for c in clauses for l in c})
    if not used: return None
    perm = dict(zip(used, rng.sample(range(1, len(used) + 1), len(used))))
    flip = {v: rng.choice((1, -1)) for v in used}
    clauses = [tuple(perm[abs(l)] * (1 if l > 0 else -1) * flip[abs(l)] for l in c) for c in clauses]
    rng.shuffle(clauses)
    return list(dict.fromkeys(clauses))

def random_graph_factor(rng):
    """Degree constraints on a random small graph (edges = variables): each vertex gets
    exactly-one / at-least-one / at-most-one over its incident edges. About half are UNSAT."""
    nv = rng.randrange(3, 8); p = rng.choice((0.4, 0.6, 0.9))
    edges = [(a, b) for a in range(nv) for b in range(a + 1, nv) if rng.random() < p]
    inc = {v: [i + 1 for i, e in enumerate(edges) if v in e] for v in range(nv)}
    if len(edges) > 11 or any(len(inc[v]) == 1 for v in inc): return None
    clauses = []
    for v in range(nv):
        if not inc[v]: continue
        t = rng.choice('XXXXLUPPP')
        if t == 'P':
            if len(inc[v]) > 5: t = 'X'
            else:
                clauses += xor_clauses(inc[v], rng.randrange(2)); continue
        if t in 'LX': clauses.append(list(inc[v]))
        if t in 'UX': clauses += [[-a, -b] for a, b in itertools.combinations(inc[v], 2)]
    used = sorted({abs(l) for c in clauses for l in c})
    if not used: return None
    perm = dict(zip(used, rng.sample(range(1, len(used) + 1), len(used))))
    flip = {v: rng.choice((1, -1)) for v in used}
    clauses = [tuple(perm[abs(l)] * (1 if l > 0 else -1) * flip[abs(l)] for l in c) for c in clauses]
    rng.shuffle(clauses)
    return list(dict.fromkeys(clauses))

def random_cnf(rng):
    n = rng.randrange(1, 9); out = []
    for _ in range(rng.randrange(1, 3 * n + 2)):
        w = rng.randrange(1, min(4, n) + 1)
        out.append(tuple(v * rng.choice((-1, 1)) for v in rng.sample(range(1, n + 1), w)))
    return list(dict.fromkeys(out))

def random_horn(rng):
    n = rng.randrange(1, 9); out = []
    for _ in range(rng.randrange(1, 3 * n + 2)):
        vs = rng.sample(range(1, n + 1), rng.randrange(1, min(4, n) + 1))
        c = [-v for v in vs]
        if rng.random() < 0.7: c[0] = -c[0]
        out.append(tuple(c))
    if rng.random() < 0.5: out = [tuple(-l for l in c) for c in out]
    return list(dict.fromkeys(out))

def test_layers(seconds=18, seed=2):
    rng = random.Random(seed); t0 = time.time()
    stats = {k: dict(tried=0, answered=0, SAT=0, UNSAT=0) for k in ('horn', 'twosat', 'cardinality')}
    while time.time() - t0 < seconds:
        gen = rng.choice((random_group_formula, random_tight_groups, random_graph_factor, random_graph_factor, random_cnf, random_horn))
        f = gen(rng)
        if not f: continue
        for comp in L.split_components(f):
            truth = brute_sat(comp)
            for name, layer in L.LAYERS:
                if name == 'cardinality' and any(len(c) == 1 for c in comp):
                    continue                      # layer contract: units are removed by the caller
                stats[name]['tried'] += 1
                r = layer(comp)
                if r is None: continue
                stats[name]['answered'] += 1; stats[name][r[0]] += 1
                assert (r[0] == 'SAT') == truth, (name, comp, r)
                if r[0] == 'SAT':
                    assert model_ok(comp, r[1]), (name, comp, r)
    return stats

def test_families():
    sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'review_lead'))
    from hard_families import php, hidden_hall, perfect_matching_clique, mutilated_chessboard
    rows = []
    def go(name, n, cl, exp):
        cl = [tuple(c) for c in cl]; t0 = time.time(); ticks = [0]
        def tick(cat, amount=1): ticks[0] += amount
        answers = []
        for comp in L.split_components(cl):
            r = L.cardinality_layer(comp, tick)
            assert r is not None, (name, 'layer not applicable')
            if r[0] == 'SAT': assert model_ok(comp, r[1])
            answers.append(r[0])
        got = 'UNSAT' if 'UNSAT' in answers else 'SAT'
        assert got == exp, (name, got, exp)
        rows.append(dict(family=name, nvars=n, clauses=len(cl), answer=got, ticks=ticks[0], seconds=round(time.time() - t0, 2)))
        print(rows[-1], flush=True)
    for h in (4, 8, 12, 16, 20):
        n, cl, exp = php(h + 1, h); go(f'php_{h+1}_{h}', n, cl, exp)
        rng = random.Random(h); perm = list(range(1, n + 1)); rng.shuffle(perm); flip = [rng.choice((1, -1)) for _ in range(n + 1)]
        cl2 = [[perm[abs(l) - 1] * (1 if l > 0 else -1) * flip[perm[abs(l) - 1]] for l in c] for c in cl]; rng.shuffle(cl2)
        go(f'php_{h+1}_{h}_renamed_polarity_flipped', n, cl2, exp)
    n, cl, exp = php(12, 12); go('php_12_12_SATcontrol', n, cl, exp)
    for args in ((30, 36, 8, 4, 3), (40, 48, 10, 4, 4), (80, 96, 12, 4, 5), (160, 190, 16, 5, 6)):
        n, cl, exp = hidden_hall(*args); go('hidden_hall_P%d_H%d_k%d_d%d' % args[:4], n, cl, exp)
    for m in (7, 9, 11, 12, 13, 15, 17, 18, 21):
        n, cl, exp = perfect_matching_clique(m); go(f'perfect_matching_K{m}', n, cl, exp)
    for s in (4, 6, 8, 10, 12, 16):
        n, cl, exp = mutilated_chessboard(s); go(f'mutilated_chessboard_{s}x{s}', n, cl, exp)
    n, cl, exp = mutilated_chessboard(10, mutilated=False); go('chessboard_10x10_SATcontrol', n, cl, exp)
    # Tseitin on random cubic graphs (answer = parity of the total charge; connected graphs)
    sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scratch'))
    from h_probe import random_regular
    def connected(nv, edges):
        seen = {0}; grow = True
        while grow:
            grow = False
            for a, b in edges:
                if (a in seen) != (b in seen): seen |= {a, b}; grow = True
        return len(seen) == nv
    for nv in (16, 64, 128, 256):
        rng = random.Random(900 + nv)
        while True:
            edges = random_regular(nv, 3, rng)
            if connected(nv, edges): break
        inc = {v: [] for v in range(nv)}
        for i, (a, b) in enumerate(edges, 1): inc[a].append(i); inc[b].append(i)
        for odd in (1, 0):
            cl = []
            for v in range(nv): cl += xor_clauses(inc[v], 1 if (v == 0 and odd) else 0)
            go(f'tseitin_cubic_{nv}v_' + ('odd_charge' if odd else 'even_charge'), len(edges), cl, 'UNSAT' if odd else 'SAT')
    # mixed: perfect matching on K_m where every third vertex only asks for ODD degree;
    # an odd-degree spanning subgraph exists iff m is even (handshake), so m odd is UNSAT and
    # m even is SAT (take a perfect matching)
    for m in (9, 10, 13, 14, 17):
        ids = {}
        var = lambda a, b: ids.setdefault((min(a, b), max(a, b)), len(ids) + 1)
        cl = []
        for v in range(m):
            inc_v = [var(v, u) for u in range(m) if u != v]
            if v % 3 == 0 and len(inc_v) <= 5:
                cl += xor_clauses(inc_v, 1)
            elif v % 3 == 0:
                # degree too large for a clause-encoded XOR: thin this vertex to 5 incident edges
                keep = inc_v[:5]
                cl += xor_clauses(keep, 1)
                cl += [[-e] for e in inc_v[5:]]
            else:
                cl.append(inc_v); cl += [[-a, -b] for a, b in itertools.combinations(inc_v, 2)]
        # the layer contract excludes units: propagate the negative units by deleting edges
        dead = {-c[0] for c in cl if len(c) == 1}
        cl = [[l for l in c if l not in dead] for c in cl if len(c) > 1 and not any((-l) in dead for l in c if l < 0)]
        if any(len(c) < 2 for c in cl): continue
        go(f'mixed_parity_matching_K{m}', len(ids), cl, 'UNSAT' if m % 2 else 'SAT')
    return rows

if __name__ == '__main__':
    out = {}
    out['matching_vs_bruteforce'] = test_matching(); print('matching:', out['matching_vs_bruteforce'], flush=True)
    out['layers_vs_bruteforce'] = test_layers(); print('layers:', out['layers_vs_bruteforce'], flush=True)
    out['families'] = test_families()
    json.dump(out, open(Path(__file__).resolve().parents[1] / 'experiments_lead_layers.json', 'w'), indent=1)
    print('ALL LAYER TESTS PASSED')
