#!/usr/bin/env python3
"""Run the whole CFPE test suite as bounded subprocesses and aggregate the counts.

  python3 tests/run_tests.py                 # fixed cases + 24000 fuzz + 800 mid-size
  python3 tests/run_tests.py --shards 4      # quick smoke run (first 4 fuzz shards)

Every subprocess is one shard of tests/test_candidate.py with a 30 s wall-clock limit
(the machine may be heavily loaded: a shard that hits the limit is retried, and if it
still does not finish it is reported as NOT RUN -- never as passed).
Writes tests/fuzz-report.json.
"""
import argparse
import concurrent.futures
import hashlib
import json
import os
import subprocess
import sys
import tempfile
import time

HERE = os.path.dirname(os.path.abspath(__file__))
TEST = os.path.join(HERE, "test_candidate.py")
DEFAULT_CANDIDATE = os.path.join(os.path.dirname(HERE), "candidate.py")


def run_one(cmd, timeout, retries=2):
    last = None
    for attempt in range(retries + 1):
        fd, path = tempfile.mkstemp(suffix=".json", prefix="cfpe_test_")
        os.close(fd)
        try:
            env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
            proc = subprocess.run(cmd + ["--output", path], stdout=subprocess.PIPE,
                                  stderr=subprocess.PIPE, timeout=timeout, env=env)
            with open(path) as fh:
                report = json.load(fh)
            report["exit"] = proc.returncode
            first = proc.stdout.decode(errors="replace").splitlines()[:1]
            if proc.returncode != 0:
                report["first_line"] = first[0][:4000] if first else ""
                report["stderr"] = proc.stderr.decode(errors="replace")[-2000:]
            return report
        except subprocess.TimeoutExpired:
            last = {"passed": None, "timeout": True, "attempts": attempt + 1}
        except (OSError, ValueError) as exc:
            return {"passed": False, "error": repr(exc)}
        finally:
            try:
                os.unlink(path)
            except OSError:
                pass
    return last


def merge(total, stats):
    for k, v in stats.items():
        if isinstance(v, dict):
            d = total.setdefault(k, {})
            for kk, vv in v.items():
                d[kk] = d.get(kk, 0) + vv
        else:
            total[k] = total.get(k, 0) + v


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--candidate", default=DEFAULT_CANDIDATE)
    ap.add_argument("--total", type=int, default=24000)
    ap.add_argument("--fuzz-shards", type=int, default=96)
    ap.add_argument("--mid-total", type=int, default=800)
    ap.add_argument("--mid-shards", type=int, default=32)
    ap.add_argument("--shards", type=int, default=None, help="only run the first K fuzz shards")
    ap.add_argument("--skip-fixed", action="store_true")
    ap.add_argument("--skip-mid", action="store_true")
    ap.add_argument("--jobs", type=int, default=6)
    ap.add_argument("--timeout", type=float, default=30.0)
    ap.add_argument("--stop-on-failure", action="store_true")
    ap.add_argument("--output", default=os.path.join(HERE, "fuzz-report.json"))
    args = ap.parse_args()

    base = [sys.executable, TEST, "--candidate", args.candidate]
    jobs = []
    if not args.skip_fixed:
        jobs.append(("fixed", base + ["--fixed"]))
    nshards = args.fuzz_shards if args.shards is None else min(args.shards, args.fuzz_shards)
    for i in range(nshards):
        jobs.append(("fuzz", base + ["--shard", str(i), "--shards", str(args.fuzz_shards),
                                     "--total", str(args.total)]))
    if not args.skip_mid:
        for i in range(args.mid_shards):
            jobs.append(("mid", base + ["--mid", "--shard", str(i), "--shards", str(args.mid_shards),
                                        "--total", str(args.mid_total)]))
    start = time.monotonic()
    totals = {"fixed": {}, "fuzz": {}, "mid": {}}
    failures = []
    not_run = []
    done = {"fixed": 0, "fuzz": 0, "mid": 0}
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.jobs) as pool:
        futs = {pool.submit(run_one, cmd, args.timeout): (kind, cmd) for kind, cmd in jobs}
        for fut in concurrent.futures.as_completed(futs):
            kind, cmd = futs[fut]
            rep = fut.result()
            if rep.get("passed") is None:
                not_run.append({"kind": kind, "cmd": cmd[2:]})
                continue
            done[kind] += 1
            if kind == "fixed":
                totals["fixed"] = {"cases": rep.get("cases", 0)}
            else:
                merge(totals[kind], rep.get("stats", {}))
            if not rep["passed"]:
                failures.append({"kind": kind, "cmd": cmd[2:], "report": {
                    k: rep.get(k) for k in ("failed", "first_line", "stderr", "error", "exit")}})
                if args.stop_on_failure:
                    for f in futs:
                        f.cancel()
                    break
    with open(args.candidate, "rb") as fh:
        sha = hashlib.sha256(fh.read()).hexdigest()
    report = {
        "candidate": os.path.abspath(args.candidate), "candidate_sha256": sha,
        "passed": not failures and not not_run,
        "shards_run": done, "shards_planned": {"fixed": 0 if args.skip_fixed else 1, "fuzz": nshards,
                                               "mid": 0 if args.skip_mid else args.mid_shards},
        "shards_not_run_timeout": not_run, "failures": failures,
        "fixed": totals["fixed"], "fuzz": totals["fuzz"], "mid": totals["mid"],
        "wall_seconds": round(time.monotonic() - start, 1),
    }
    text = json.dumps(report, indent=1, sort_keys=True) + "\n"
    for attempt in range(40):      # the workspace sandbox sometimes refuses a write
        try:
            with open(args.output, "w") as fh:
                fh.write(text)
            break
        except OSError:
            time.sleep(1.5)
    short = {k: report[k] for k in ("passed", "shards_run", "shards_planned", "wall_seconds")}
    short["fuzz_instances"] = totals["fuzz"].get("instances", 0)
    short["mid_instances"] = totals["mid"].get("instances", 0)
    short["failures"] = len(failures)
    short["not_run"] = len(not_run)
    print(json.dumps(short, indent=1, sort_keys=True))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    sys.exit(main())
