"""Raw-misuse fuzz for fable/layers.py.

Every layer, `try_layers` and `island_stage` are called on ARBITRARY clause lists, including
inputs outside the layers' stated contract: empty clauses, repeated literals, tautologies,
duplicate clauses, unit clauses and several components at once. A layer may decline (None),
but any definite answer must be correct and no exception may escape.

(Added after the independent reviewer showed that `cardinality_layer` answered SAT when it was
handed an input containing the empty clause; all layers now return UNSAT for that.)

Usage: python3 test_layers_raw_misuse.py [seed] [seconds]
"""
import collections
import itertools
import json
import random
import sys
import time
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))
import layers as L
import test_layers as T


def brute(cl):
    vs = sorted({abs(l) for c in cl for l in c})
    for bits in itertools.product((False, True), repeat=len(vs)):
        a = dict(zip(vs, bits))
        if all(any(a[abs(l)] == (l > 0) for l in c) for c in cl):
            return True
    return False


def raw(rng):
    k = rng.randrange(6)
    if k == 0:
        n = rng.randrange(1, 8)
        f = [[rng.randrange(1, n + 1) * rng.choice((-1, 1)) for _ in range(rng.randrange(0, 5))]
             for _ in range(rng.randrange(0, 12))]
    else:
        g = {1: T.random_group_formula, 2: T.random_graph_factor, 3: T.random_tight_groups,
             4: T.random_horn, 5: T.random_cnf}[k](rng) or []
        f = [list(c) for c in g]
        for _ in range(rng.randrange(0, 4)):            # damage it
            m = rng.randrange(6)
            if m == 0:
                f.append([])
            elif m == 1 and f:
                c = rng.choice(f)
                if c:
                    c.append(rng.choice(c))
            elif m == 2 and f:
                c = rng.choice(f)
                if c:
                    c.append(-rng.choice(c))
            elif m == 3 and f:
                f.append(list(rng.choice(f)))
            elif m == 4:
                f.append([rng.randrange(1, 9) * rng.choice((-1, 1))])
            elif m == 5 and f:
                f.append([l + 20 * (1 if l > 0 else -1) for l in rng.choice(f)])
    rng.shuffle(f)
    return [tuple(c) for c in f]


def run(seed=1, seconds=22.0):
    rng = random.Random(seed)
    t0 = time.time()
    st = collections.Counter()
    bad = []
    callers = list(L.LAYERS) + [("try_layers", lambda c: (lambda r: None if r is None else r[1])(L.try_layers(c)))]
    while time.time() - t0 < seconds:
        f = raw(rng)
        if len({abs(l) for c in f for l in c}) > 13:
            continue
        truth = brute(f)
        st["cases"] += 1
        for name, layer in callers:
            try:
                r = layer(f)
            except Exception as e:                       # noqa: BLE001 - reported, not hidden
                st[name + ":exception"] += 1
                bad.append((name, "exception", repr(e)[:120], f))
                continue
            if r is None:
                st[name + ":none"] += 1
                continue
            st[name + ":" + r[0]] += 1
            ok = ((r[0] == "SAT" and truth
                   and all(any(r[1].get(abs(l)) == (l > 0) for l in c) for c in f))
                  or (r[0] == "UNSAT" and not truth))
            if not ok:
                st[name + ":WRONG"] += 1
                bad.append((name, r[0], truth, f))
        try:
            v, res, vals, log = L.island_stage(max([abs(l) for c in f for l in c], default=0), f)
            ok = (not truth) if v == "UNSAT" else (brute(res) == truth)
            st["island_stage:" + str(v)] += 1
            if not ok:
                st["island_stage:WRONG"] += 1
                bad.append(("island_stage", v, truth, f))
        except Exception as e:                           # noqa: BLE001
            st["island_stage:exception"] += 1
            bad.append(("island_stage", "exception", repr(e)[:120], f))
    return dict(st), bad


if __name__ == "__main__":
    seed = int(sys.argv[1]) if len(sys.argv) > 1 else 1
    seconds = float(sys.argv[2]) if len(sys.argv) > 2 else 22.0
    stats, bad = run(seed, seconds)
    print(json.dumps(stats, sort_keys=True))
    print("PROBLEMS:", len(bad))
    for b in bad[:6]:
        print("  ", json.dumps(b)[:400])
    sys.exit(1 if bad else 0)
