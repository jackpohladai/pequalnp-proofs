"""Brute-force tests of layers.island_stage (the candidate's front end)."""
import sys, random, itertools, time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import layers as L
import test_layers as T

def models(n, clauses):
    for bits in itertools.product((False, True), repeat=n):
        if all(any(bits[abs(l) - 1] == (l > 0) for l in c) for c in clauses):
            yield bits

def gen(rng):
    kind = rng.randrange(5)
    if kind == 0: f = T.random_cnf(rng)
    elif kind == 1: f = T.random_horn(rng)
    elif kind == 2: f = T.random_group_formula(rng)
    elif kind == 3: f = T.random_graph_factor(rng)
    else: f = T.random_tight_groups(rng)
    f = [list(c) for c in (f or [])]
    # glue an independent second part and some noise (units, duplicates, tautologies, empties)
    if rng.random() < 0.5:
        g = T.random_cnf(rng); shift = max([abs(l) for c in f for l in c], default=0)
        f += [[l + shift if l > 0 else l - shift for l in c] for c in g]
    n = max([abs(l) for c in f for l in c], default=0) + rng.randrange(0, 2)
    if n and rng.random() < 0.3: f.append([rng.randrange(1, n + 1) * rng.choice((-1, 1))])
    if f and rng.random() < 0.2: f.append(list(f[0]) + [f[0][0]])
    if n and rng.random() < 0.1: v = rng.randrange(1, n + 1); f.append([v, -v])
    if rng.random() < 0.02: f.append([])
    rng.shuffle(f)
    return n, f

def run(seconds=20, seed=5, max_n=13):
    rng = random.Random(seed); t0 = time.time()
    st = dict(cases=0, unsat_by_stage=0, fully_decided_sat=0, residual_left=0, island_hits={})
    while time.time() - t0 < seconds:
        n, f = gen(rng)
        if n > max_n: continue
        truth = next(models(n, f), None) is not None
        verdict, residual, values, log = L.island_stage(n, f)
        st['cases'] += 1
        if verdict == 'UNSAT':
            assert not truth, (n, f, log); st['unsat_by_stage'] += 1; continue
        rvars = {abs(l) for c in residual for l in c}
        assert not (rvars & set(values)), 'residual shares a variable with fixed values'
        rsat = None
        for bits in itertools.product((False, True), repeat=len(rvars)):
            a = dict(zip(sorted(rvars), bits))
            if all(any(a[abs(l)] == (l > 0) for l in c) for c in residual):
                rsat = a; break
        assert (rsat is not None) == truth, ('equisatisfiability broken', n, f, residual, values)
        if rsat is not None:
            full = [False] * n
            for v, b in {**values, **rsat}.items(): full[v - 1] = b
            assert all(any(full[abs(l) - 1] == (l > 0) for l in c) for c in f), ('merged model wrong', n, f)
        if residual: st['residual_left'] += 1
        else: st['fully_decided_sat'] += 1
        for k, v in log['islands'].items(): st['island_hits'][k] = st['island_hits'].get(k, 0) + v
    return st

if __name__ == '__main__':
    print(run()); print('ISLAND STAGE TESTS PASSED')
