#!/usr/bin/env python3
"""Differential fuzz and invariant tests for the CFPE candidate.

Independent of candidate internals: only the public ``solve`` / ``solve_capped`` /
``encoded_bit_length`` entry points and the documented ``debug_hook`` events are used.
The oracle is this file's own exhaustive truth-table enumeration.

  python3 tests/test_candidate.py --shard 0 --shards 8      # one fuzz shard (< 30 s)
  python3 tests/test_candidate.py --fixed                    # deterministic unit cases
  python3 tests/test_candidate.py --mid --shard 0 --shards 8 --total 800   # 11 <= n <= 16
  python3 tests/test_candidate.py --candidate /path/to/mutant.py --shard 0 --shards 8

Exit status 0 = every check passed; 1 = a check failed (the instance is printed).

Checks per fuzz instance
  D1  status is SAT or UNSAT (unlimited budget) and equals the exhaustive oracle;
  D2  SAT comes with a length-nvars 0/1 assignment satisfying every ORIGINAL clause (I4);
  D3  UNSAT names one of the four refutation rules of (I3);
  D4  the external budget saw exactly the ticks the solver reports, category by category;
  D5  same answer / same ticks after shuffling clauses and literals (canonical run);
  D6  under a random finite budget the answer is either UNKNOWN or correct and within
      budget (never a guess); solve_capped agrees with its own bound;
  D7  every explicit strategy and tiny node caps: UNKNOWN or correct, never wrong;
  I1  (n <= 8, hook) preprocessing is an exact projection and every residual model
      translates back to a model of the original for arbitrary values of free variables;
  I2  (n <= 8, hook) after every elimination, AND(factors)(a) = 1 iff a extends to a model.
"""
import argparse
import importlib.util
import itertools
import json
import os
import random
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_CANDIDATE = os.path.join(os.path.dirname(HERE), "candidate.py")

UNSAT_RULES = {"empty_clause", "unit_conflict", "affine_inconsistent",
               "empty_clause_after_substitution", "bdd_false"}
STRATEGIES = ["wide+mindeg", "wide+cross", "wide+minfac", "bfs+mindeg", "bfs+cross",
              "force+minfac", "index+level", "wide+revlevel", "bfs+level", "force+mindeg",
              "index+minfac", "force+cross", "index+cross"]


def load_candidate(path):
    spec = importlib.util.spec_from_file_location("cfpe_under_test", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


class TestBudget:
    """Mirror of adversarial/meter.py::Budget, owned by the test."""

    class Exceeded(RuntimeError):
        pass

    def __init__(self, maximum=None):
        self.maximum = maximum
        self.total = 0
        self.categories = {}

    def tick(self, category="step", amount=1):
        if type(amount) is not int or amount < 0:
            raise ValueError("operation charge must be a nonnegative integer")
        self.total += amount
        self.categories[str(category)] = self.categories.get(str(category), 0) + amount
        if self.maximum is not None and self.total > self.maximum:
            raise BudgetExceeded("operation budget %d exceeded" % self.maximum)


class BudgetExceeded(RuntimeError):
    pass


# ----------------------------------------------------------------------------- oracle

def truth_table(nvars, clauses):
    """Bitset over all 2^nvars assignments (bit x set iff assignment x is a model;
    variable i is bit i-1 of x)."""
    size = 1 << nvars
    full = (1 << size) - 1
    lit = []
    for i in range(nvars):
        block = (1 << (1 << i)) - 1                  # 2^i ones
        period = 1 << (i + 1)
        m = 0
        for start in range(1 << i, size, period):
            m |= block << start
        lit.append(m)
    value = full
    for c in clauses:
        part = 0
        for l in c:
            part |= lit[l - 1] if l > 0 else full ^ lit[-l - 1]
        value &= part
        if not value:
            break
    return value


def satisfies(nvars, clauses, assignment):
    if not isinstance(assignment, list) or len(assignment) != nvars:
        return False
    if any(type(b) not in (bool, int) or b not in (0, 1) for b in assignment):
        return False
    return all(any(bool(assignment[abs(l) - 1]) == (l > 0) for l in c) for c in clauses)


def bit_length_N(clauses):
    return sum(4 + 2 * abs(l).bit_length() for c in clauses for l in c) + 2 * len(clauses)


# ----------------------------------------------------------------------------- generators

def xor_clauses(vs, parity, rng=None):
    out = []
    for bits in itertools.product((0, 1), repeat=len(vs)):
        if sum(bits) % 2 != parity:
            out.append(tuple(-v if b else v for v, b in zip(vs, bits)))
    return out


def gen_mixed(rng):
    n = rng.randrange(0, 11)
    live = rng.randrange(0, n + 1) if rng.random() < 0.3 else n
    clauses = []
    if live == 0:
        for _ in range(rng.randrange(0, 3)):
            if rng.random() < 0.3:
                clauses.append(())
        return n, clauses
    m = rng.randrange(0, 4 * live + 4)
    wmax = rng.choice([1, 2, 3, 3, 3, 4, 5])
    for _ in range(m):
        r = rng.random()
        if r < 0.015:
            clauses.append(())
            continue
        w = rng.randrange(1, wmax + 1)
        c = [rng.randrange(1, live + 1) * rng.choice((1, -1)) for _ in range(w)]
        if rng.random() < 0.05 and c:
            c.append(c[0])                                   # duplicate literal
        if rng.random() < 0.03 and c:
            c.append(-c[0])                                  # tautology
        clauses.append(tuple(c))
        if rng.random() < 0.05:
            clauses.append(tuple(c))                         # duplicate clause
    return n, clauses


def gen_kcnf(rng):
    n = rng.randrange(3, 11)
    k = rng.choice([2, 3, 3, 3, 4])
    k = min(k, n)
    ratio = {2: rng.uniform(0.5, 2.0), 3: rng.uniform(2.5, 6.0), 4: rng.uniform(6.0, 12.0)}[k]
    m = max(1, int(ratio * n))
    clauses = []
    for _ in range(m):
        vs = rng.sample(range(1, n + 1), k)
        clauses.append(tuple(v * rng.choice((1, -1)) for v in vs))
    return n, clauses


def gen_xor_mix(rng):
    n = rng.randrange(2, 11)
    clauses = []
    for _ in range(rng.randrange(1, 6)):
        k = rng.randrange(2, min(n, 7) + 1) if rng.random() < 0.15 else rng.randrange(2, min(n, 4) + 1)
        vs = rng.sample(range(1, n + 1), k)
        cl = xor_clauses(vs, rng.randrange(2))
        r = rng.random()
        if r < 0.12 and len(cl) > 1:
            cl.pop(rng.randrange(len(cl)))                   # almost an XOR
        elif r < 0.18:
            cl += xor_clauses(vs, rng.randrange(2))          # maybe both parities
        elif r < 0.25:
            extra = tuple(v * rng.choice((1, -1)) for v in vs)
            cl.append(extra)                                 # XOR plus one more clause
        clauses += cl
    for _ in range(rng.randrange(0, 2 * n)):
        w = rng.randrange(1, min(n, 4) + 1)
        vs = rng.sample(range(1, n + 1), w)
        clauses.append(tuple(v * rng.choice((1, -1)) for v in vs))
    rng.shuffle(clauses)
    return n, clauses


def gen_equiv_mix(rng):
    n = rng.randrange(2, 11)
    clauses = []
    for _ in range(rng.randrange(1, n + 1)):
        a, b = rng.sample(range(1, n + 1), 2)
        if rng.random() < 0.5:
            clauses += [(a, -b), (-a, b)]                    # a == b
        else:
            clauses += [(a, b), (-a, -b)]                    # a == not b
    for _ in range(rng.randrange(0, 3 * n)):
        w = rng.randrange(1, min(n, 4) + 1)
        vs = rng.sample(range(1, n + 1), w)
        clauses.append(tuple(v * rng.choice((1, -1)) for v in vs))
    for _ in range(rng.randrange(0, 3)):
        k = rng.randrange(2, min(n, 5) + 1)
        clauses += xor_clauses(rng.sample(range(1, n + 1), k), rng.randrange(2))
    rng.shuffle(clauses)
    return n, clauses


def gen_pure_xor(rng):
    n = rng.randrange(1, 11)
    clauses = []
    for _ in range(rng.randrange(1, n + 3)):
        k = rng.randrange(1, min(n, 5) + 1)
        clauses += xor_clauses(rng.sample(range(1, n + 1), k), rng.randrange(2))
    if rng.random() < 0.3:
        for _ in range(rng.randrange(1, 4)):
            w = rng.randrange(2, min(n, 3) + 1) if n >= 2 else 1
            vs = rng.sample(range(1, n + 1), w)
            clauses.append(tuple(v * rng.choice((1, -1)) for v in vs))
    return n, clauses


def gen_structured(rng):
    r = rng.randrange(6)
    if r == 0:                                               # pigeonhole p pigeons, h holes
        h = rng.randrange(1, 4)
        p = rng.randrange(1, 5)
        while p * h > 10:
            p -= 1
        var = lambda i, k: i * h + k + 1
        clauses = [tuple(var(i, k) for k in range(h)) for i in range(p)]
        for k in range(h):
            for i in range(p):
                for j in range(i + 1, p):
                    clauses.append((-var(i, k), -var(j, k)))
        n = p * h
    elif r == 1:                                             # Tseitin on a random multigraph-free graph
        nv = rng.randrange(2, 6)
        edges = [e for e in itertools.combinations(range(nv), 2) if rng.random() < 0.6][:10]
        n = len(edges)
        clauses = []
        for v in range(nv):
            inc = [i + 1 for i, e in enumerate(edges) if v in e]
            if inc:
                clauses += xor_clauses(inc, rng.randrange(2))
            elif rng.random() < 0.2:
                clauses.append(())                           # isolated vertex with odd charge
    elif r == 2:                                             # implication chain with units
        n = rng.randrange(2, 11)
        clauses = [(-i, i + 1) for i in range(1, n)]
        clauses.append((1,))
        if rng.random() < 0.5:
            clauses.append((-rng.randrange(1, n + 1),))
    elif r == 3:                                             # selector family
        k = rng.randrange(1, 4)
        clauses = []
        for i in range(1, k + 1):
            clauses += [(i, k + i), (-i, 2 * k + i)]
        n = 3 * k
        for _ in range(rng.randrange(0, 4)):
            vs = rng.sample(range(1, n + 1), min(n, 2))
            clauses.append(tuple(v * rng.choice((1, -1)) for v in vs))
    elif r == 4:                                             # Horn
        n = rng.randrange(2, 11)
        clauses = []
        for _ in range(rng.randrange(1, 3 * n)):
            w = rng.randrange(1, min(n, 4) + 1)
            vs = rng.sample(range(1, n + 1), w)
            c = [-v for v in vs]
            if rng.random() < 0.6:
                c[0] = -c[0]
            clauses.append(tuple(c))
    else:                                                    # XOR-substituted clauses
        k = rng.randrange(1, 6)
        n = 2 * k
        clauses = []
        for _ in range(rng.randrange(1, 5)):
            w = rng.randrange(1, min(k, 3) + 1)
            xs = rng.sample(range(1, k + 1), w)
            signs = [rng.choice((0, 1)) for _ in xs]
            # literal on x_i (sign s) is false iff (a_i xor b_i) == s
            for bits in itertools.product((0, 1), repeat=w):
                c = []
                for x, s, b in zip(xs, signs, bits):
                    a_val, b_val = b, b ^ s
                    c += [-(2 * x - 1) if a_val else (2 * x - 1), -(2 * x) if b_val else (2 * x)]
                clauses.append(tuple(c))
    return n, clauses


def gen_dense(rng):
    """No unit clauses, widths 2..5, tuned so that most instances reach the BDD phase
    and a good share of them is unsatisfiable."""
    n = rng.randrange(3, 11)
    wmax = min(n, rng.choice([2, 3, 3, 4, 5]))
    per_var = {2: rng.uniform(0.8, 2.2), 3: rng.uniform(3.0, 6.5), 4: rng.uniform(7.0, 13.0),
               5: rng.uniform(14.0, 24.0)}[wmax]
    clauses = []
    for _ in range(max(1, int(per_var * n))):
        w = rng.randrange(2, wmax + 1) if rng.random() < 0.3 else wmax
        vs = rng.sample(range(1, n + 1), w)
        clauses.append(tuple(v * rng.choice((1, -1)) for v in vs))
    if rng.random() < 0.3:
        k = rng.randrange(2, min(n, 4) + 1)
        clauses += xor_clauses(rng.sample(range(1, n + 1), k), rng.randrange(2))
    return n, clauses


GENERATORS = [(gen_mixed, 22), (gen_kcnf, 16), (gen_dense, 18), (gen_xor_mix, 16),
              (gen_equiv_mix, 11), (gen_pure_xor, 6), (gen_structured, 11)]


def draw(rng):
    r = rng.randrange(sum(w for _, w in GENERATORS))
    for g, w in GENERATORS:
        if r < w:
            n, cl = g(rng)
            return g.__name__, n, [tuple(c) for c in cl]
        r -= w
    raise AssertionError


# ----------------------------------------------------------------------------- checks

class Failure(Exception):
    pass


def expect(cond, msg):
    if not cond:
        raise Failure(msg)


def projection_set(nvars, table, retained):
    """Set of assignments of ``retained`` (as tuples of bools) that extend to a model."""
    out = set()
    x = 0
    t = table
    while t:
        low = t & -t
        x = low.bit_length() - 1
        out.add(tuple(bool(x >> (v - 1) & 1) for v in retained))
        t ^= low
    return out


def check_hook_events(nvars, clauses, table, events, rng):
    counts = {"i1_assignments": 0, "i2_assignments": 0, "i2_stages": 0, "i1_models": 0}
    allvars = list(range(1, nvars + 1))
    for ev in events:
        stage = ev["stage"]
        retained = list(ev["retained"])
        expect(len(set(retained)) == len(retained) and all(1 <= v <= nvars for v in retained),
               "hook: bad retained list")
        good = projection_set(nvars, table, retained)
        if stage == "preprocessed":
            rset = set(retained)
            for c in ev["clauses"]:
                expect(all(abs(l) in rset for l in c) and len(c) >= 2,
                       "I1: residual clause mentions a non-retained variable or is short")
            for vs, p in ev["xors"]:
                expect(all(v in rset for v in vs), "I1: residual row mentions a non-retained variable")
            defined = [v for v, t, p in ev["trail"]] + [pv for pv, rest, p in ev["dropped_rows"]]
            expect(len(set(defined)) == len(defined), "I1: a variable is defined twice")
            expect(not (set(defined) & rset), "I1: a defined variable is still retained")
            for values in itertools.product((False, True), repeat=len(retained)):
                a = dict(zip(retained, values))
                ok = all(any(a[abs(l)] == (l > 0) for l in c) for c in ev["clauses"]) and \
                    all(sum(a[v] for v in vs) % 2 == p for vs, p in ev["xors"])
                counts["i1_assignments"] += 1
                expect(ok == (values in good),
                       "I1: residual is not the exact projection at %r" % (a,))
                if not ok:
                    continue
                # translate back, with arbitrary values for free variables
                full = dict(a)
                for pv, rest, p in reversed(ev["dropped_rows"]):
                    b = p
                    for u in rest:
                        if u not in full:
                            expect(u not in defined, "I1: row reads a not-yet-defined variable")
                            full[u] = rng.random() < 0.5
                        b ^= full[u]
                    expect(pv not in full, "I1: pivot defined twice")
                    full[pv] = bool(b)
                for v, t, p in reversed(ev["trail"]):
                    expect(v not in full, "I1: trail variable defined twice")
                    if t == 0:
                        full[v] = bool(p)
                    else:
                        if t not in full:
                            expect(t not in defined, "I1: trail reads a not-yet-defined variable")
                            full[t] = rng.random() < 0.5
                        full[v] = full[t] != bool(p)
                for v in allvars:
                    if v not in full:
                        full[v] = rng.random() < 0.5
                counts["i1_models"] += 1
                expect(all(any(full[abs(l)] == (l > 0) for l in c) for c in clauses),
                       "I1: translated residual model violates the original formula")
        else:
            expect(stage in ("bdd_start", "bdd_step", "bdd_false"), "hook: unknown stage %r" % stage)
            factors = ev["factors"]
            evaluate = ev["evaluate"]
            counts["i2_stages"] += 1
            for values in itertools.product((False, True), repeat=len(retained)):
                a = dict(zip(retained, values))
                got = all(evaluate(f, a) for f in factors)
                counts["i2_assignments"] += 1
                expect(got == (values in good),
                       "I2: factors are not the exact projection at stage %s, a=%r" % (stage, a))
    return counts


def shuffled(rng, clauses):
    cl = [tuple(rng.sample(list(c), len(c))) for c in clauses]
    rng.shuffle(cl)
    return cl


def check_instance(mod, nvars, clauses, rng, deep, stats):
    table = truth_table(nvars, clauses)
    expected = "SAT" if table else "UNSAT"
    budget = TestBudget()
    res = mod.solve(nvars, tuple(clauses), budget)
    status = res.get("status")
    expect(status in ("SAT", "UNSAT"), "D1: status %r with an unlimited budget (%r)" % (status, res.get("reason")))
    expect(status == expected, "D1: claimed %s, oracle says %s" % (status, expected))
    ops = res.get("operations")
    expect(isinstance(ops, dict), "operations missing")
    if status == "SAT":
        expect(satisfies(nvars, clauses, res.get("assignment")), "D2: SAT without a valid witness")
        stats["sat"] += 1
    else:
        expect("assignment" not in res or res["assignment"] is None, "UNSAT with an assignment")
        expect(ops.get("decided_by") in UNSAT_RULES, "D3: UNSAT by unknown rule %r" % ops.get("decided_by"))
        stats["unsat"] += 1
    stats["by_rule"][ops.get("decided_by")] = stats["by_rule"].get(ops.get("decided_by"), 0) + 1
    expect(ops.get("total_ticks") == budget.total, "D4: reported ticks differ from the budget's total")
    expect(ops.get("categories") == budget.categories, "D4: reported categories differ from the budget's")
    for key in ("bdd_nodes_total", "bdd_nodes_peak", "bit_cost_upper", "encoded_bits_N"):
        expect(type(ops.get(key)) is int, "operations lacks integer %r" % key)
    expect(ops["encoded_bits_N"] == bit_length_N(clauses), "N differs from the encodeCNF length")
    nodes = max(2, ops["bdd_nodes_total"])
    expect(ops["bit_cost_upper"] == ops["total_ticks"] * max(1, (nodes - 1).bit_length()),
           "bit_cost_upper does not follow the stated formula")

    # D5 canonical: clause / literal order must not matter
    res2 = mod.solve(nvars, tuple(shuffled(rng, clauses)), TestBudget())
    expect(res2["status"] == status, "D5: status changed under shuffling")
    expect(res2.get("assignment") == res.get("assignment"), "D5: witness changed under shuffling")
    expect(res2["operations"]["total_ticks"] == ops["total_ticks"], "D5: ticks changed under shuffling")

    # D6 finite budgets
    if rng.random() < 0.5:
        maximum = rng.randrange(0, max(2, 2 * budget.total))
        b = TestBudget(maximum)
        try:
            r3 = mod.solve(nvars, tuple(clauses), b)
        except BudgetExceeded:
            r3 = {"status": "UNKNOWN"}
            stats["budget_propagated"] += 1
        if r3["status"] in ("SAT", "UNSAT"):
            expect(r3["status"] == expected, "D6: wrong answer under a finite budget")
            expect(b.total <= maximum, "D6: decided although the budget was exceeded")
            if r3["status"] == "SAT":
                expect(satisfies(nvars, clauses, r3.get("assignment")), "D6: bad witness under budget")
            expect(maximum >= budget.total or b.total <= maximum, "D6")
            stats["budget_decided"] += 1
        else:
            expect(r3["status"] == "UNKNOWN", "D6: status %r under a finite budget" % r3["status"])
            expect(maximum < budget.total, "D6: UNKNOWN although the budget sufficed")
            stats["budget_unknown"] += 1
    if rng.random() < 0.15:
        rc = mod.solve_capped(nvars, tuple(clauses), C=rng.choice([1, 1, 5]), d=rng.choice([2, 3]))
        expect(rc["N"] == bit_length_N(clauses), "solve_capped: wrong N")
        if rc["status"] in ("SAT", "UNSAT"):
            expect(rc["status"] == expected and rc["budget_total"] <= rc["budget_maximum"],
                   "solve_capped: wrong or over budget")
            stats["capped_decided"] += 1
        else:
            expect(rc["status"] == "UNKNOWN", "solve_capped: status %r" % rc["status"])
            stats["capped_unknown"] += 1

    # D7 explicit strategies and small node caps
    if rng.random() < 0.35:
        strat = rng.choice(STRATEGIES)
        cap = rng.choice([4, 8, 16, 32, 64, 256, 100000])
        r4 = mod.solve(nvars, tuple(clauses), TestBudget(), strategy=strat, node_cap=cap)
        if r4["status"] in ("SAT", "UNSAT"):
            expect(r4["status"] == expected, "D7: wrong answer with %s cap %d" % (strat, cap))
            if r4["status"] == "SAT":
                expect(satisfies(nvars, clauses, r4.get("assignment")), "D7: bad witness (%s)" % strat)
            stats["strategy_decided"] += 1
        else:
            expect(r4["status"] == "UNKNOWN" and r4.get("reason") == "node_cap",
                   "D7: status %r reason %r with %s cap %d" % (r4["status"], r4.get("reason"), strat, cap))
            stats["strategy_cap"] += 1
    if rng.random() < 0.1:
        cap = rng.choice([70, 200, 600, 3000])
        r5 = mod.solve(nvars, tuple(clauses), TestBudget(), node_cap=cap)   # portfolio, small cap
        if r5["status"] in ("SAT", "UNSAT"):
            expect(r5["status"] == expected, "D7: wrong portfolio answer with cap %d" % cap)
            if r5["status"] == "SAT":
                expect(satisfies(nvars, clauses, r5.get("assignment")), "D7: bad portfolio witness")
        else:
            expect(r5["status"] == "UNKNOWN", "D7: portfolio status %r" % r5["status"])
            stats["portfolio_cap"] += 1

    # D8 maximal preemption: tiny race slices and a kernel check at every cache miss
    # must not change any answer, and (I1)/(I2) must hold in every interleaved attempt
    if rng.random() < 0.25:
        saved = (mod.RACE_SLICE, mod.KERNEL_CHECK_MASK)
        mod.RACE_SLICE, mod.KERNEL_CHECK_MASK = 0, 0
        events = []
        try:
            r7 = mod.solve(nvars, tuple(clauses), TestBudget(),
                           debug_hook=events.append if (deep and nvars <= 8) else None)
        finally:
            mod.RACE_SLICE, mod.KERNEL_CHECK_MASK = saved
        expect(r7["status"] == expected, "D8: answer changed under maximal preemption")
        if expected == "SAT":
            expect(satisfies(nvars, clauses, r7.get("assignment")), "D8: bad witness under preemption")
        if events:
            c = check_hook_events(nvars, clauses, table, events, rng)
            for k, v in c.items():
                stats[k] += v
            stats["preempt_hook_runs"] += 1
        stats["preempt_runs"] += 1

    # I1 / I2 through the debug hook
    if deep and nvars <= 8:
        events = []
        strat = rng.choice([None] + STRATEGIES)
        r6 = mod.solve(nvars, tuple(clauses), TestBudget(), debug_hook=events.append, strategy=strat)
        expect(r6["status"] == expected, "hook run changed the answer")
        if strat is None:
            expect(r6["operations"]["total_ticks"] == ops["total_ticks"], "the hook changed the tick count")
        c = check_hook_events(nvars, clauses, table, events, rng)
        for k, v in c.items():
            stats[k] += v
        stats["hook_instances"] += 1
        if any(e["stage"] != "preprocessed" for e in events):
            stats["hook_instances_with_bdd"] += 1
        if any(e["stage"] == "bdd_false" for e in events):
            stats["hook_instances_bdd_false"] += 1
    stats["instances"] += 1


def new_stats():
    keys = ["instances", "sat", "unsat", "budget_decided", "budget_unknown", "budget_propagated",
            "capped_decided", "capped_unknown", "strategy_decided", "strategy_cap", "portfolio_cap",
            "hook_instances", "hook_instances_with_bdd", "hook_instances_bdd_false", "preempt_runs",
            "preempt_hook_runs",
            "i1_assignments", "i1_models", "i2_assignments", "i2_stages"]
    st = {k: 0 for k in keys}
    st["by_rule"] = {}
    st["by_generator"] = {}
    return st


def run_shard(mod, shard, shards, total, seed, deep_share):
    rng = random.Random(seed * 100003 + shard)
    stats = new_stats()
    count = total // shards + (1 if shard < total % shards else 0)
    for i in range(count):
        name, n, clauses = draw(rng)
        stats["by_generator"][name] = stats["by_generator"].get(name, 0) + 1
        deep = rng.random() < deep_share
        try:
            check_instance(mod, n, clauses, rng, deep, stats)
        except Failure as exc:
            print(json.dumps({"failed": str(exc), "shard": shard, "index": i, "generator": name,
                              "nvars": n, "clauses": clauses}))
            return stats, False
    return stats, True


# ----------------------------------------------------------------------------- fixed cases

def fixed_cases(mod):
    done = 0

    def run(nvars, clauses, expected, **kw):
        nonlocal done
        res = mod.solve(nvars, tuple(tuple(c) for c in clauses), TestBudget(), **kw)
        expect(res["status"] == expected, "fixed: got %s expected %s (%s)" % (res["status"], expected, res.get("reason")))
        if expected == "SAT":
            expect(satisfies(nvars, clauses, res["assignment"]), "fixed: bad witness")
        done += 1
        return res

    run(0, [], "SAT")
    run(0, [()], "UNSAT")
    run(8, [], "SAT")
    run(12, [(1,)], "SAT")
    run(12, [(1,), (-1,)], "UNSAT")
    run(16, [(16,), (-1, 16)], "SAT")
    run(16, [(16,), (-16,)], "UNSAT")
    run(3, [(1, -1)], "SAT")
    run(3, [(2, 2, 2), (-2,)], "UNSAT")
    run(4, [(1, 2), (1, 2), (-1,), (-2,)], "UNSAT")
    run(8, [(1, -2, 3), (-3, 4), (4,)], "SAT")
    run(5, [(1, -1), ()], "UNSAT")
    # invalid literals must be rejected, not guessed
    for bad in ([(0,)], [(4,)], [(1, -9)]):
        try:
            mod.solve(3, tuple(bad), TestBudget())
            raise Failure("fixed: invalid literal accepted: %r" % (bad,))
        except ValueError:
            done += 1
    # deep / wide structures: no recursion limits anywhere
    n = 6000
    run(n, [tuple(range(1, n + 1))], "SAT")                                   # one wide clause
    run(n, [tuple(range(1, n + 1))] + [(-i,) for i in range(1, n + 1)], "UNSAT")
    run(n, [(-i, i + 1) for i in range(1, n)] + [(1,)], "SAT")               # unit chain
    run(n, [(-i, i + 1) for i in range(1, n)] + [(1,), (-n,)], "UNSAT")
    chain = [(-i, i + 1) for i in range(1, n)] + [(-n, 1)]                    # equivalence cycle
    run(n, chain + [(1, 2)], "SAT")
    run(n, chain + [(1, n), (-2, -3)], "UNSAT")
    # deep BDDs: a long implication ladder that is not an equivalence chain
    n = 3000
    ladder = [(-i, i + 1, i + 2) for i in range(1, n - 1)]
    run(n, ladder + [(1, 2), (-n, -(n - 1))], "SAT", strategy="index+level")
    run(n, ladder + [(1, 2), (-n, -(n - 1))], "SAT", strategy="bfs+revlevel")
    run(n, ladder + [(1, 2), (-n, -(n - 1))], "SAT")
    # one wide clause conjoined with an at-most-one ladder: BDD depth 600
    n = 600
    wide = [tuple(range(1, n + 1))] + [(-i, -(i + 1)) for i in range(1, n)] + [(-1, 3, 5)]
    run(n, wide, "SAT")
    # pigeonhole by construction
    def php(p, h):
        var = lambda i, k: i * h + k + 1
        cl = [tuple(var(i, k) for k in range(h)) for i in range(p)]
        for k in range(h):
            for i in range(p):
                for j in range(i + 1, p):
                    cl.append((-var(i, k), -var(j, k)))
        return p * h, cl
    for h in (2, 3, 4, 5, 6):
        run(*php(h + 1, h), "UNSAT")
        run(*php(h, h), "SAT")
    # Tseitin on a cycle and on K5: parity of total charge decides
    for nv in (3, 7, 40):
        edges = [(i, (i + 1) % nv) for i in range(nv)]
        for odd in (0, 1):
            cl = []
            for v in range(nv):
                inc = [i + 1 for i, e in enumerate(edges) if v in e]
                cl += xor_clauses(inc, 1 if (odd and v == 0) else 0)
            run(len(edges), cl, "UNSAT" if odd else "SAT")
    edges = list(itertools.combinations(range(5), 2))
    for charges in ([1, 0, 0, 0, 0], [1, 1, 0, 0, 0], [1, 1, 1, 0, 1]):
        cl = []
        for v in range(5):
            cl += xor_clauses([i + 1 for i, e in enumerate(edges) if v in e], charges[v])
        run(len(edges), cl, "UNSAT" if sum(charges) % 2 else "SAT")
    # a width-7 parity (not detected by the affine layer) against its negation
    vs = list(range(1, 8))
    run(7, xor_clauses(vs, 0), "SAT")
    run(7, xor_clauses(vs, 0) + xor_clauses(vs, 1), "UNSAT")
    # budget exhaustion is UNKNOWN, never a guess
    nv, cl = php(6, 5)
    b = TestBudget(50)
    try:
        r = mod.solve(nv, tuple(cl), b)
        expect(r["status"] == "UNKNOWN", "fixed: tiny budget must give UNKNOWN, got %s" % r["status"])
    except BudgetExceeded:
        pass
    done += 1
    r = mod.solve(nv, tuple(cl), TestBudget(), node_cap=40)
    expect(r["status"] == "UNKNOWN" and r.get("reason") == "node_cap", "fixed: node cap must give UNKNOWN")
    done += 1
    r = mod.solve(nv, tuple(cl), TestBudget(), time_limit=0.0)
    expect(r["status"] in ("UNKNOWN", "UNSAT"), "fixed: zero time limit")
    done += 1
    # solve_capped
    r = mod.solve_capped(nv, tuple(cl), C=1, d=3)
    expect(r["status"] == "UNSAT" and r["N"] == bit_length_N(cl) and r["within_budget"], "fixed: solve_capped")
    done += 1
    return done


def run_mid(mod, shard, shards, total, seed):
    """Differential check on larger instances (11 <= n <= 16) against the truth table."""
    rng = random.Random(seed * 7001 + shard)
    stats = {"instances": 0, "sat": 0, "unsat": 0, "by_rule": {}}
    count = total // shards + (1 if shard < total % shards else 0)
    for i in range(count):
        n = rng.randrange(11, 17)
        kind = rng.randrange(4)
        if kind == 0:
            k = 3
            m = int(rng.uniform(3.6, 5.2) * n)
            clauses = [tuple(v * rng.choice((1, -1)) for v in rng.sample(range(1, n + 1), k))
                       for _ in range(m)]
        elif kind == 1:
            clauses = [tuple(v * rng.choice((1, -1)) for v in rng.sample(range(1, n + 1), 2))
                       for _ in range(int(rng.uniform(0.8, 1.6) * n))]
            clauses += [tuple(v * rng.choice((1, -1)) for v in rng.sample(range(1, n + 1), 3))
                        for _ in range(int(rng.uniform(0.5, 3.0) * n))]
        elif kind == 2:
            clauses = []
            for _ in range(rng.randrange(3, n)):
                k = rng.randrange(2, 5)
                clauses += xor_clauses(rng.sample(range(1, n + 1), k), rng.randrange(2))
            clauses += [tuple(v * rng.choice((1, -1)) for v in rng.sample(range(1, n + 1), 3))
                        for _ in range(int(rng.uniform(0.5, 3.5) * n))]
        else:
            h = rng.choice([3, 4])
            p = rng.choice([h, h + 1]) if (h + 1) * h <= 16 else h
            var = lambda a, b: a * h + b + 1
            clauses = [tuple(var(a, b) for b in range(h)) for a in range(p)]
            for b in range(h):
                for a in range(p):
                    for a2 in range(a + 1, p):
                        clauses.append((-var(a, b), -var(a2, b)))
            n = p * h
            perm = list(range(1, n + 1))
            rng.shuffle(perm)
            clauses = [tuple((perm[abs(l) - 1] if l > 0 else -perm[abs(l) - 1]) for l in c) for c in clauses]
            for _ in range(rng.randrange(0, 3)):
                clauses.append(tuple(v * rng.choice((1, -1)) for v in rng.sample(range(1, n + 1), 3)))
        table = truth_table(n, clauses)
        expected = "SAT" if table else "UNSAT"
        strat = rng.choice([None, None] + STRATEGIES)
        preempt = rng.random() < 0.3
        saved = (mod.RACE_SLICE, mod.KERNEL_CHECK_MASK)
        if preempt:
            mod.RACE_SLICE, mod.KERNEL_CHECK_MASK = 0, 0
        try:
            res = mod.solve(n, tuple(clauses), TestBudget(), strategy=strat)
        finally:
            mod.RACE_SLICE, mod.KERNEL_CHECK_MASK = saved
        try:
            expect(res["status"] == expected, "mid: claimed %s, oracle %s (strategy %s)" % (res["status"], expected, strat))
            if expected == "SAT":
                expect(satisfies(n, clauses, res.get("assignment")), "mid: bad witness")
        except Failure as exc:
            print(json.dumps({"failed": str(exc), "shard": shard, "index": i, "nvars": n, "clauses": clauses}))
            return stats, False
        stats["instances"] += 1
        stats["sat" if expected == "SAT" else "unsat"] += 1
        rule = res["operations"].get("decided_by")
        stats["by_rule"][rule] = stats["by_rule"].get(rule, 0) + 1
    return stats, True


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--candidate", default=DEFAULT_CANDIDATE)
    ap.add_argument("--shard", type=int, default=0)
    ap.add_argument("--shards", type=int, default=8)
    ap.add_argument("--total", type=int, default=24000)
    ap.add_argument("--seed", type=int, default=20261125)
    ap.add_argument("--deep-share", type=float, default=0.3)
    ap.add_argument("--fixed", action="store_true")
    ap.add_argument("--mid", action="store_true", help="larger instances, 11 <= n <= 16")
    ap.add_argument("--output")
    args = ap.parse_args()
    mod = load_candidate(args.candidate)
    start = time.monotonic()
    if args.fixed:
        try:
            n = fixed_cases(mod)
            report = {"mode": "fixed", "cases": n, "passed": True}
        except Failure as exc:
            report = {"mode": "fixed", "passed": False, "failed": str(exc)}
    elif args.mid:
        stats, ok = run_mid(mod, args.shard, args.shards, args.total, args.seed)
        report = {"mode": "mid", "shard": args.shard, "shards": args.shards, "seed": args.seed,
                  "total": args.total, "passed": ok, "stats": stats}
    else:
        stats, ok = run_shard(mod, args.shard, args.shards, args.total, args.seed, args.deep_share)
        report = {"mode": "fuzz", "shard": args.shard, "shards": args.shards, "seed": args.seed,
                  "total": args.total, "passed": ok, "stats": stats}
    report["seconds"] = round(time.monotonic() - start, 3)
    report["candidate"] = os.path.abspath(args.candidate)
    text = json.dumps(report, indent=1, sort_keys=True)
    if args.output:
        with open(args.output, "w") as fh:
            fh.write(text + "\n")
    print(text)
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    sys.exit(main())
