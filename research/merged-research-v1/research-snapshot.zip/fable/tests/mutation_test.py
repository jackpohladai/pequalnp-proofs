#!/usr/bin/env python3
"""Mutation sanity check (T3): the test suite must FAIL on deliberately broken copies
of candidate.py.  The original file is never modified (mutants are written to
tests/mutants/ and its SHA256 is compared before and after).

  python3 tests/mutation_test.py            # all mutants
  python3 tests/mutation_test.py --only xor_parity_flip

A mutant is KILLED if any of the first ``--shards`` fuzz shards (or the mid-size shard)
exits non-zero.  Writes tests/mutation-report.json.
"""
import argparse
import concurrent.futures
import hashlib
import json
import os
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
CANDIDATE = os.path.join(os.path.dirname(HERE), "candidate.py")
TEST = os.path.join(HERE, "test_candidate.py")
MUTANTS = os.path.join(HERE, "mutants")

# name -> (description, old text, new text[, old2, new2, ...]); every old text must occur
# exactly once in candidate.py.
MUTATIONS = {
    "xor_parity_flip": (
        "XOR detection: a complete odd-forbidden class is recorded as XOR(S)=1 instead of 0",
        "                rows.append((mask, 0))\n                remove.update(odd)",
        "                rows.append((mask, 1))\n                remove.update(odd)"),
    "xor_incomplete_class": (
        "XOR detection: accept an odd-forbidden class when one clause is missing",
        "        if len(odd) == need or len(d) - len(odd) == need:\n            mask = _mask_of(vs)",
        "        if len(odd) >= need - 1 or len(d) - len(odd) == need:\n            mask = _mask_of(vs)",
        "            if len(odd) == need:\n                # every odd-parity",
        "            if len(odd) >= need - 1:\n                # every odd-parity"),
    "keep_tautologies": (
        "normalisation: tautological clauses are not dropped",
        "        if taut:\n            continue\n        if not s:\n            empty = True",
        "        if not s:\n            empty = True"),
    "exists_as_forall": (
        "projection: EXISTS implemented with AND (universal quantification)",
        "                    r = self.bor(lo[x], hi[x])",
        "                    r = self.band(lo[x], hi[x])"),
    "bcp_conflict_ignored": (
        "unit propagation: neither a falsified clause nor a contradicting unit is reported "
        "(the two checks are mutually redundant, so both are removed)",
        "            nfree[i] -= 1\n            if nfree[i] == 0:\n                tick(\"clause_literal_scan\", steps)\n                raise _Unsat(\"unit_conflict\")",
        "            nfree[i] -= 1\n            if nfree[i] == 0:\n                continue",
        "            if old != b:\n                tick(\"clause_literal_scan\", steps)\n                raise _Unsat(\"unit_conflict\")\n            continue",
        "            continue"),
    "bcp_one_conflict_check_removed": (
        "(equivalent mutant) only the falsified-clause check of unit propagation is removed; "
        "the contradicting-unit check still reports every conflict",
        "            nfree[i] -= 1\n            if nfree[i] == 0:\n                tick(\"clause_literal_scan\", steps)\n                raise _Unsat(\"unit_conflict\")",
        "            nfree[i] -= 1\n            if nfree[i] == 0:\n                continue"),
    "equivalence_sign_flip": (
        "substitution of x = y xor p uses the wrong sign",
        "                nl = t if (l > 0) != bool(p) else -t",
        "                nl = t if (l > 0) == bool(p) else -t"),
    "gf2_inconsistency_ignored": (
        "Gaussian elimination: a 0 = 1 row is treated as redundant",
        "        if not mask:\n            return 2 if parity else 0",
        "        if not mask:\n            return 0"),
    "parity_bdd_swapped": (
        "parity factor built for the opposite parity",
        "        return self.mk(top, o, e) if parity else self.mk(top, e, o)",
        "        return self.mk(top, e, o) if parity else self.mk(top, o, e)"),
    "project_shared_variables": (
        "affine projection also eliminates variables that still occur in clauses",
        "    umask = wmask & ~cmask",
        "    umask = wmask"),
    "apply_cache_collision": (
        "apply cache key is not injective",
        "                k = (f << sh) | g\n                r = cache.get(k)",
        "                k = f + g\n                r = cache.get(k)"),
    "and_terminal_wrong": (
        "AND with the constant TRUE returns FALSE",
        "                    if f < 2:\n                        push(g if f else 0)\n                        continue",
        "                    if f < 2:\n                        push(0)\n                        continue"),
    "clause_bdd_polarity": (
        "clause factor: literal polarities swapped",
        "            r = self.mk(level, r, 1) if pos else self.mk(level, 1, r)",
        "            r = self.mk(level, 1, r) if pos else self.mk(level, r, 1)"),
    "bucket_skips_a_factor": (
        "bucket conjunction leaves out its largest factor",
        "            for f in fs[1:]:\n                tick(\"bucket_and\", 1)",
        "            for f in fs[1:-1] if len(fs) > 2 else fs[1:]:\n                tick(\"bucket_and\", 1)"),
    "witness_wrong_value": (
        "witness reconstruction always sets an eliminated variable to True",
        "        val[L] = False\n        ok, s = bdd.evaluate(B, val)\n        steps += s\n        if not ok:",
        "        val[L] = True\n        ok, s = bdd.evaluate(B, val)\n        steps += s\n        if False:"),
    "pivot_pivot_parity_dropped": (
        "equivalence of two pivots with equal rest: parity of the second row ignored",
        "                out.append((pv, first, parity ^ rows[first][1]))",
        "                out.append((pv, first, parity))"),
    "trail_not_reversed": (
        "witness: the substitution trail is replayed in creation order",
        "    for v, t, p in reversed(pre.trail):\n        bit = 1 << v",
        "    for v, t, p in pre.trail:\n        bit = 1 << v"),
    "xor_parity_flip_unverified": (
        "XOR parity flip AND the final witness verification is switched off (no safety net)",
        "                rows.append((mask, 0))\n                remove.update(odd)",
        "                rows.append((mask, 1))\n                remove.update(odd)",
        "                if not sat:\n                    ok = False\n            meter.tick(\"verify_literal_scan\", nlit)",
        "            meter.tick(\"verify_literal_scan\", nlit)"),
    "clause_polarity_unverified": (
        "clause factor polarity swapped AND no final verification (no safety net)",
        "            r = self.mk(level, r, 1) if pos else self.mk(level, 1, r)",
        "            r = self.mk(level, 1, r) if pos else self.mk(level, r, 1)",
        "                if not sat:\n                    ok = False\n            meter.tick(\"verify_literal_scan\", nlit)",
        "            meter.tick(\"verify_literal_scan\", nlit)"),
    "exists_as_forall_unchecked": (
        "EXISTS implemented with AND, and the internal 'projection is FALSE' check removed",
        "                    r = self.bor(lo[x], hi[x])",
        "                    r = self.band(lo[x], hi[x])",
        "            if new == 0:\n                raise _Internal(\"projection of a satisfiable bucket is FALSE\")\n",
        ""),
    "preempt_loses_exists_cache": (
        "(liveness, not soundness) a restarted EXISTS forgets its partial results",
        "                    new = bdd.exists(acc, L, ecache)",
        "                    new = bdd.exists(acc, L, None)"),
}
# The last mutant is expected to SURVIVE: it only wastes work.  It documents that the
# suite checks answers, not speed.
EXPECTED_SURVIVORS = {"preempt_loses_exists_cache", "bcp_one_conflict_check_removed"}


def write_retry(path, text):
    """The workspace sandbox sometimes refuses a write for a few seconds: retry."""
    for attempt in range(40):
        try:
            with open(path, "w") as fh:
                fh.write(text)
            return
        except OSError:
            time.sleep(1.5)
    raise OSError("could not write %s" % path)


def sha256(path):
    with open(path, "rb") as fh:
        return hashlib.sha256(fh.read()).hexdigest()


def run(cmd, timeout):
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
    try:
        proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout, env=env)
    except subprocess.TimeoutExpired:
        return None, "timeout"
    out = proc.stdout.decode(errors="replace")
    first = out.splitlines()[0] if out else ""
    detail = ""
    if proc.returncode != 0:
        try:
            detail = json.loads(first).get("failed", "")
        except ValueError:
            detail = (proc.stderr.decode(errors="replace").strip().splitlines() or [""])[-1]
    return proc.returncode, detail[:300]


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--only", action="append")
    ap.add_argument("--shards", type=int, default=6, help="fuzz shards (of 96) tried per mutant")
    ap.add_argument("--jobs", type=int, default=6)
    ap.add_argument("--timeout", type=float, default=30.0)
    ap.add_argument("--output", default=os.path.join(HERE, "mutation-report.json"))
    args = ap.parse_args()
    os.makedirs(MUTANTS, exist_ok=True)
    before = sha256(CANDIDATE)
    with open(CANDIDATE) as fh:
        source = fh.read()
    names = args.only or list(MUTATIONS)
    results = []
    start = time.monotonic()
    for name in names:
        desc = MUTATIONS[name][0]
        pairs = MUTATIONS[name][1:]
        mutated = source
        bad = None
        for old, new in zip(pairs[0::2], pairs[1::2]):
            if source.count(old) != 1:
                bad = "pattern occurs %d times: %r" % (source.count(old), old[:60])
                break
            mutated = mutated.replace(old, new)
        if bad is not None or mutated == source:
            results.append({"mutation": name, "description": desc, "outcome": "NOT_APPLIED",
                            "reason": bad or "no change"})
            print(json.dumps(results[-1]), flush=True)
            continue
        path = os.path.join(MUTANTS, "mutant_%s.py" % name)
        write_retry(path, mutated)
        cmds = [[sys.executable, TEST, "--candidate", path, "--shard", str(i), "--shards", "96"]
                for i in range(args.shards)]
        cmds.append([sys.executable, TEST, "--candidate", path, "--mid", "--shard", "0",
                     "--shards", "32", "--total", "800"])
        killed_by = []
        timeouts = 0
        with concurrent.futures.ThreadPoolExecutor(max_workers=args.jobs) as pool:
            for cmd, (code, detail) in zip(cmds, pool.map(lambda c: run(c, args.timeout), cmds)):
                if code is None:
                    timeouts += 1
                elif code != 0:
                    killed_by.append({"test": " ".join(cmd[4:]), "detail": detail})
        outcome = "KILLED" if killed_by else ("TIMEOUT_ONLY" if timeouts == len(cmds) else "SURVIVED")
        results.append({"mutation": name, "description": desc, "outcome": outcome,
                        "failing_runs": len(killed_by), "timeouts": timeouts, "runs": len(cmds),
                        "first_failure": killed_by[0] if killed_by else None,
                        "expected": "SURVIVE" if name in EXPECTED_SURVIVORS else "KILL"})
        print(json.dumps(results[-1]), flush=True)
    after = sha256(CANDIDATE)
    killed = [r["mutation"] for r in results if r["outcome"] == "KILLED"]
    unexpected = [r["mutation"] for r in results
                  if (r["outcome"] == "KILLED") != (r["mutation"] not in EXPECTED_SURVIVORS)]
    report = {"candidate_sha256_before": before, "candidate_sha256_after": after,
              "candidate_untouched": before == after, "mutants": len(results),
              "killed": killed, "survived": [r["mutation"] for r in results if r["outcome"] == "SURVIVED"],
              "other": [r["mutation"] for r in results if r["outcome"] not in ("KILLED", "SURVIVED")],
              "unexpected": unexpected, "results": results,
              "wall_seconds": round(time.monotonic() - start, 1)}
    write_retry(args.output, json.dumps(report, indent=1, sort_keys=True) + "\n")
    print(json.dumps({k: report[k] for k in ("candidate_untouched", "mutants", "killed", "survived",
                                              "other", "unexpected", "wall_seconds")}, indent=1))
    return 0 if (before == after and not unexpected) else 1


if __name__ == "__main__":
    sys.exit(main())
