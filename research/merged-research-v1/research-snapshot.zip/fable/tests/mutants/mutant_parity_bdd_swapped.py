#!/usr/bin/env python3
"""CFPE -- canonical-factor projective elimination (candidate for project L-alg-001).

A complete, deterministic SAT decision procedure.  NO polynomial worst-case bound is
claimed or expected: the procedure is exact existential projection (bucket elimination)
whose factors are stored in a semantic canonical form (reduced ordered BDDs), preceded
by an algebraic GF(2) layer that removes affine structure before any BDD is built.
Standard library only, no recursion, no randomness, no wall-clock dependence unless a
``time_limit`` is given.

Pipeline of ``solve(nvars, clauses, budget)``
---------------------------------------------
0. Normalise: validate literals (ValueError otherwise), dedupe literals, drop
   tautological clauses, dedupe clauses, rename the mentioned variables densely
   (order-isomorphic), sort clauses canonically -- the run depends on the clause *set*
   only, not on clause or literal order.  Empty clause -> UNSAT.
1. Unit propagation to fixpoint (conflict -> UNSAT).  Every forced literal is also a
   width-1 row of the linear system.
2. Affine layer.
   a. XOR detection: clauses are grouped by variable set S, 2 <= |S| <= 6.  A clause
      forbids exactly one assignment of S (positive literal -> 0, negative -> 1).
      "XOR(S) = p" is present iff all 2^(|S|-1) clauses forbidding the assignments of
      parity 1-p are present; those clauses are then *replaced* by the row.
   b. Gaussian elimination over GF(2); rows are Python-int bitmasks.  A row 0 = 1 ->
      UNSAT (every row is a GF(2) combination of rows implied by input clauses).
   c. In the fully reduced basis: a row of width 1 is a forced value, a row of width 2
      is a literal equivalence, and two pivot rows with identical non-pivot parts are
      an equivalence of their pivots (these are exactly the weight <= 2 vectors of the
      row space).  They are substituted into all clauses and rows and recorded on a
      trail; steps 1-2 repeat to a fixpoint.
   d. Exact projection of XOR-only variables.  U := variables that occur in rows but
      in no remaining clause.  The detected rows (with all substitutions applied) are
      brought into echelon form with pivots restricted to U.  A row with a pivot in U
      is dropped and recorded for witness reconstruction: its pivot occurs in no
      clause and in no surviving row, so the row is satisfied by choosing the pivot.
      The rows that end up U-free span exactly {w in rowspace : w_U = 0}, i.e. the
      exact projection EXISTS U; a minimum-total-width independent subset of them
      survives as parity factors.  If no clause remains the instance is decided here in
      polynomial time with a witness read off the echelon form.
      (Documented deviation from the lead brief: the surviving rows are NOT read off
      the fully reduced Gauss-Jordan form, because that densifies rows that never
      touch U; the row space, hence the constraint, is the same.)
3. Factors: one ROBDD per remaining clause and per surviving parity row (a parity BDD
   of width k has 2k-1 internal nodes), one unique table, one global variable order.
4. Bucket elimination: pick a variable v by the elimination rule, B_v := AND of all
   factors mentioning v (smallest first; FALSE -> UNSAT), new factor := EXISTS v. B_v
   (dropped if TRUE), B_v is remembered.  No variable left -> SAT.
5. Witness: eliminated variables in reverse order, each gets a value making its B_v
   true under the values already chosen (must exist, otherwise internal error ->
   status ERROR, never SAT); then step 2 is undone (dropped rows, then the trail in
   reverse); free and unused variables are False.  The assignment is VERIFIED against
   the ORIGINAL clauses; a failed verification returns status ERROR.
6. Ordering rules.  All are computed from the constraint hypergraph of the residual;
   variable indices are used only to break exact ties.
     BDD order   'wide'  : widest-constraint-first placement.  Constraints are taken
                           by (width desc, #already placed variables desc, canonical
                           index); the unplaced variables of the chosen constraint are
                           appended and form a *block*.
                 'bfs'   : hypergraph breadth-first order from a least-occurring variable.
                 'force' : FORCE centre-of-gravity iterations started from 'wide'.
                 'index' : dense variable index (NOT structural; baseline only).
     Elimination 'mindeg': dynamic min-degree on the current factor scopes, key
                           (degree, #factors in bucket, BDD level).
                 'cross' : static.  Breadth-first search over the graph that links two
                           variables iff they share a constraint AND lie in different
                           blocks of the 'wide' placement; components are started at
                           their top-most variable, new variables are queued by level.
                           I.e. eliminate *across* the blocks of the BDD order.
                 'minfac': dynamic, key (#factors in bucket, 0 if v is in the scope of
                           the factor created by the previous step else 1, degree, level).
                 'level' / 'revlevel' : top-down / bottom-up in BDD order (classic).
   The SHIPPED ``solve`` (strategy=None) races the two strategies of PORTFOLIO =
   (wide+mindeg, wide+cross) deterministically: both start from the same preprocessed
   residual with their own unique table (node_cap // 2 nodes each), the attempt that
   has consumed fewer ticks is advanced, and an attempt is preempted (inside the BDD
   kernels as well) as soon as it leads by RACE_SLICE + 16*(residual variables) + 16
   ticks.  A preempted kernel call is restarted and finds its finished sub-results in
   the operation caches.  The first attempt that finishes decides; all work of all
   attempts is metered.  Total cost <= 2 * (cost of the better strategy) + one slice.
7. Metering: ``budget.tick(category, amount)`` is called for every primitive.
     clause_scan, clause_literal_scan : clauses / literals read (normalise, unit
                                         propagation, substitution, XOR grouping,
                                         factor construction)
     verify_literal_scan               : literals read by the final witness check
     sort_step                         : k*bitlen(k) per sort of k items
     gf2_step, gf2_words               : row operations and the 64-bit words they touch
     order_step                        : ordering heuristics (heap operations, scope
                                         unions in words, placement / search steps)
     bdd_unique_insert                 : unique-table insertions (= BDD nodes created)
     bdd_and_miss, bdd_or_miss, bdd_exists_miss : apply / exists cache misses
     bdd_visit                         : nodes visited by support/size traversals
     bucket_and                        : top-level conjunctions in buckets
     witness_step                      : BDD edges followed / words touched during
                                         witness reconstruction
   Inside the BDD kernels the counters are flushed every KERNEL_CHECK_MASK+1 cache
   misses and at the end of each call; totals are exact and a budget overrun is noticed
   within one batch.  One tick stands for O(1) word-RAM operations on indices of
   O(log(nodes + N)) bits with *expected* O(1) hashing; big-int row operations are
   charged per 64-bit word.  Allocating the length-``nvars`` output list is not metered
   (``nvars`` is not part of the Lean encoding); all work on mentioned variables is.
   An exception whose class is named ``BudgetExceeded`` (raised by ``budget.tick``) is
   caught and turned into ``{"status": "UNKNOWN", ...}``; nothing is ever guessed.

``operations`` in the result: every category total (also under "categories"),
"total_ticks", "bdd_nodes_total" (unique-table insertions over all attempts; there is
no garbage collection, so "bdd_nodes_peak" -- nodes stored simultaneously -- is the
same number), "bdd_largest_bucket" / "bdd_largest_factor" (internal nodes of the
largest single B_v / factor), "bit_cost_upper" = total_ticks * ceil(log2(max(2,
nodes))) as specified by the brief, "bit_cost_upper_wordsize" = total_ticks * max(64,
bit lengths of nodes, nvars, #clauses) (the more conservative reading), the encoded
length "encoded_bits_N", "decided_by", the winning "strategy" and per-attempt data.

Invariants (asserted by tests/test_candidate.py through ``debug_hook``)
-----------------------------------------------------------------------
 (I1) Preprocessing preserves satisfiability and models translate back exactly: for
      every assignment a of the residual variables, [residual clauses and rows hold
      on a] iff a extends to a model of the original formula, and the dropped rows
      plus the trail turn every residual model into a model of the original, for
      arbitrary values of the free variables.
 (I2) At every stage of the BDD phase, for every assignment a of the retained
      variables, AND(factors)(a) = 1 iff a extends to a model of the original formula
      (exact projection).
 (I3) UNSAT is returned only on: an empty clause (in the input, or after substituting
      implied units/equivalences), a unit-propagation conflict, a 0 = 1 row, or a
      FALSE BDD.
 (I4) SAT is returned only with a witness verified against the original clauses.

Status values: SAT, UNSAT, UNKNOWN (budget / node cap / deadline; never a refutation),
ERROR (an internal consistency check failed; never converted into SAT or UNSAT).

``debug_hook(event)`` (tests only; no effect on the run): one event
{"stage": "preprocessed", "retained", "clauses", "xors", "dropped_rows", "trail"} in
original variable names (dropped rows are valid in reverse list order, then the trail
in reverse), and per attempt {"stage": "bdd_start" | "bdd_step" | "bdd_false",
"strategy", "retained", "eliminated", "factors", "evaluate(factor, {var: bool})"}.
"""

from heapq import heapify, heappop, heappush
import time

__all__ = ["solve", "solve_capped", "encoded_bit_length", "Budget", "BudgetExceeded",
           "PORTFOLIO", "DEFAULT_NODE_CAP"]

DEFAULT_NODE_CAP = 1_500_000

# Shipped portfolio: (BDD order rule, elimination rule).  The attempts are raced
# deterministically (see ``solve``); each gets node_cap // len(PORTFOLIO) BDD nodes.
PORTFOLIO = (("wide", "mindeg"), ("wide", "cross"))
# An attempt is preempted once it is RACE_SLICE + 16*(residual variables) + 16 ticks
# ahead of the slowest other attempt.  A preempted kernel call is simply restarted; its
# finished sub-results are in the operation caches.  A restart re-expands at most
# 2*depth unfinished calls and leaves at most 2*depth unfinished, and a slice contains
# at least slice/2 cache misses, so every slice makes permanent progress.
RACE_SLICE = 20000
# The BDD kernels flush their tick counters and test deadline / slice every
# KERNEL_CHECK_MASK + 1 cache misses (must be 2^k - 1).  Tests set both to 0.
KERNEL_CHECK_MASK = 4095

XOR_MAX_WIDTH = 6


class BudgetExceeded(RuntimeError):
    """Raised by Budget.tick when the declared operation budget is exceeded."""


class Budget:
    """Cooperative operation counter; same contract as adversarial/meter.py."""

    def __init__(self, maximum=None):
        if maximum is not None and (type(maximum) is not int or maximum < 0):
            raise ValueError("maximum operations must be a nonnegative integer")
        self.maximum = maximum
        self.total = 0
        self.categories = {}

    def tick(self, category="step", amount=1):
        if type(amount) is not int or amount < 0:
            raise ValueError("operation charge must be a nonnegative integer")
        self.total += amount
        self.categories[category] = self.categories.get(category, 0) + amount
        if self.maximum is not None and self.total > self.maximum:
            raise BudgetExceeded("operation budget %d exceeded" % self.maximum)

    def snapshot(self):
        return {"total": self.total, "categories": dict(self.categories),
                "maximum": self.maximum, "accounting": "cooperative explicit ticks"}


class _Abort(Exception):
    """Resource stop (node cap or deadline): the answer is UNKNOWN."""

    def __init__(self, reason):
        Exception.__init__(self, reason)
        self.reason = reason


class _Unsat(Exception):
    """A sound refutation was found; ``reason`` names the rule of (I3)."""

    def __init__(self, reason):
        Exception.__init__(self, reason)
        self.reason = reason


class _Internal(Exception):
    """An internal invariant failed: status ERROR, never SAT/UNSAT."""


class _Preempt(Exception):
    """The running portfolio attempt used up its time slice (see ``solve``)."""


class _Meter:
    __slots__ = ("budget", "cats", "total", "deadline", "slice_end")

    def __init__(self, budget, deadline):
        self.budget = budget
        self.cats = {}
        self.total = 0
        self.deadline = deadline
        self.slice_end = None

    def tick(self, cat, amount=1):
        if amount:
            self.cats[cat] = self.cats.get(cat, 0) + amount
            self.total += amount
            if self.budget is not None:
                self.budget.tick(cat, amount)

    def check(self):
        """Deadline check (anywhere)."""
        if self.deadline is not None and time.monotonic() > self.deadline:
            raise _Abort("deadline")

    def check_kernel(self):
        """Deadline and time-slice check; only called from restartable BDD kernels."""
        if self.deadline is not None and time.monotonic() > self.deadline:
            raise _Abort("deadline")
        if self.slice_end is not None and self.total >= self.slice_end:
            raise _Preempt()


def encoded_bit_length(clauses):
    """Length of the Lean ``encodeCNF`` string with 1-based variable indices:
    4 + 2*bitlen(var) bits per literal plus 2 bits per clause."""
    n = 0
    for c in clauses:
        n += 2
        for l in c:
            n += 4 + 2 * abs(l).bit_length()
    return n


def _bits(mask):
    """Indices of the set bits of ``mask`` in increasing order."""
    out = []
    while mask:
        low = mask & -mask
        out.append(low.bit_length() - 1)
        mask ^= low
    return out


def _mask_of(indices):
    """Bitmask with the given bit indices set, built in O(#indices + size) time."""
    top = -1
    for i in indices:
        if i > top:
            top = i
    if top < 0:
        return 0
    buf = bytearray((top >> 3) + 1)
    for i in indices:
        buf[i >> 3] |= 1 << (i & 7)
    return int.from_bytes(buf, "little")


def _words(x):
    """Number of 64-bit words of the bitmask x (at least 1)."""
    return (x.bit_length() + 63) >> 6 or 1


def _ckey(c):
    return (len(c), [abs(l) for l in c], c)


def _sort_cost(k):
    return k * max(1, k.bit_length())


# --------------------------------------------------------------------------------------
# Steps 1-2: unit propagation and the GF(2) layer
# --------------------------------------------------------------------------------------

def _bcp(C, meter):
    """Unit propagation to fixpoint on a list of normalised clauses.

    Returns (clauses, forced_literals); raises _Unsat on a conflict.  Remaining clauses
    have no assigned variable and at least two literals.
    """
    tick = meter.tick
    tick("clause_scan", len(C))
    queue = [c[0] for c in C if len(c) == 1]
    if not queue:
        return C, []
    occ = {}
    nlit = 0
    for i, c in enumerate(C):
        nlit += len(c)
        for l in c:
            lst = occ.get(l)
            if lst is None:
                occ[l] = [i]
            else:
                lst.append(i)
    tick("clause_literal_scan", nlit)
    nfree = [len(c) for c in C]
    dead = [False] * len(C)
    val = {}
    forced = []
    qi = 0
    steps = 0
    while qi < len(queue):
        l = queue[qi]
        qi += 1
        v = l if l > 0 else -l
        b = l > 0
        old = val.get(v)
        if old is not None:
            if old != b:
                tick("clause_literal_scan", steps)
                raise _Unsat("unit_conflict")
            continue
        val[v] = b
        forced.append(l)
        for i in occ.get(l, ()):
            dead[i] = True
            steps += 1
        for i in occ.get(-l, ()):
            steps += 1
            if dead[i]:
                continue
            nfree[i] -= 1
            if nfree[i] == 0:
                tick("clause_literal_scan", steps)
                raise _Unsat("unit_conflict")
            if nfree[i] == 1:
                for m in C[i]:
                    steps += 1
                    if (m if m > 0 else -m) not in val:
                        queue.append(m)
                        break
                else:
                    raise _Internal("bcp: unit clause without a free literal")
    tick("clause_literal_scan", steps)
    out = []
    seen = set()
    nlit = 0
    for i, c in enumerate(C):
        if dead[i]:
            continue
        nlit += len(c)
        t = tuple([l for l in c if (l if l > 0 else -l) not in val])
        if len(t) < 2:
            raise _Internal("bcp: short clause survived propagation")
        if t not in seen:
            seen.add(t)
            out.append(t)
    tick("clause_literal_scan", nlit)
    return out, forced


def _detect_xors(C, meter):
    """Find complete parity classes.  Returns (remaining clauses, rows)."""
    groups = {}
    nlit = 0
    for i, c in enumerate(C):
        k = len(c)
        if 2 <= k <= XOR_MAX_WIDTH:
            nlit += k
            vs = []
            neg = 0
            bit = 1
            for l in c:
                if l < 0:
                    vs.append(-l)
                    neg |= bit
                else:
                    vs.append(l)
                bit <<= 1
            vs = tuple(vs)
            d = groups.get(vs)
            if d is None:
                groups[vs] = {neg: i}
            else:
                d[neg] = i
    meter.tick("clause_literal_scan", nlit)
    meter.tick("clause_scan", len(C))
    rows = []
    remove = set()
    for vs, d in groups.items():
        need = 1 << (len(vs) - 1)
        if len(d) < need:
            continue
        odd = [i for neg, i in d.items() if neg.bit_count() & 1]
        if len(odd) == need or len(d) - len(odd) == need:
            mask = 0
            for v in vs:
                mask |= 1 << v
            if len(odd) == need:
                # every odd-parity assignment of S is forbidden: XOR(S) = 0
                rows.append((mask, 0))
                remove.update(odd)
            if len(d) - len(odd) == need:
                # every even-parity assignment of S is forbidden: XOR(S) = 1
                rows.append((mask, 1))
                remove.update(i for neg, i in d.items() if not neg.bit_count() & 1)
    if not rows:
        return C, rows
    return [c for i, c in enumerate(C) if i not in remove], rows


class _GF2:
    """Echelon basis over GF(2).  Rows are (mask, parity): XOR of the variables in
    ``mask`` equals ``parity``.  The pivot of a stored row is its lowest *allowed* bit.
    With ``allowed`` given, rows without an allowed bit after reduction are kept in
    ``survivors`` (they span the projection onto the non-allowed variables)."""

    def __init__(self, meter, allowed=None):
        self.rows = {}
        self.pivmask = 0
        self.allowed = allowed
        self.survivors = []
        self.meter = meter

    def insert(self, mask, parity):
        """0 dependent, 1 new pivot row, 2 inconsistent (0 = 1), 3 survivor."""
        rows = self.rows
        pm = self.pivmask
        allowed = self.allowed
        words = 0
        steps = 1
        while True:
            cand = mask if allowed is None else (mask & allowed)
            if not cand:
                break
            low = cand & -cand
            if not (low & pm):
                break
            r = rows[low.bit_length() - 1]
            a = mask.bit_length()
            b = r[0].bit_length()
            # one XOR plus the mask / lowest-bit / pivot tests of this iteration
            words += 4 * (((a if a > b else b) + 63) >> 6)
            steps += 1
            mask ^= r[0]
            parity ^= r[1]
        self.meter.tick("gf2_step", steps)
        self.meter.tick("gf2_words", words + 3 * _words(mask))
        if not mask:
            return 2 if parity else 0
        if not cand:
            self.survivors.append((mask, parity))
            return 3
        rows[low.bit_length() - 1] = (mask, parity)
        self.pivmask = pm | low
        return 1

    def reduce_all(self):
        """Back-substitution: afterwards no row contains another row's pivot."""
        rows = self.rows
        pm = self.pivmask
        words = 0
        steps = 0
        order = sorted(rows, reverse=True)
        self.meter.tick("sort_step", _sort_cost(len(order)))
        for pv in order:
            mask, parity = rows[pv]
            common = (mask & pm) ^ (1 << pv)
            steps += 1
            words += 3 * _words(mask)
            if not common:
                continue
            while common:
                low = common & -common
                r = rows[low.bit_length() - 1]
                a = mask.bit_length()
                b = r[0].bit_length()
                words += 4 * (((a if a > b else b) + 63) >> 6)
                steps += 1
                mask ^= r[0]
                parity ^= r[1]
                common ^= low
            rows[pv] = (mask, parity)
        self.meter.tick("gf2_step", steps)
        self.meter.tick("gf2_words", words)

    def extract(self):
        """After reduce_all: remove and return every unit and equivalence of the row
        space as (var, target, parity) meaning var = value(target) XOR parity, with
        target 0 for a constant."""
        rows = self.rows
        out = []
        by_rest = {}
        order = sorted(rows)
        self.meter.tick("sort_step", _sort_cost(len(order)))
        self.meter.tick("gf2_step", len(order))
        self.meter.tick("gf2_words", 4 * sum(_words(rows[pv][0]) for pv in order))
        for pv in order:
            mask, parity = rows[pv]
            rest = mask ^ (1 << pv)
            if rest == 0:
                out.append((pv, 0, parity))
            elif rest & (rest - 1) == 0:
                out.append((pv, rest.bit_length() - 1, parity))
            else:
                first = by_rest.get(rest)
                if first is None:
                    by_rest[rest] = pv
                    continue
                out.append((pv, first, parity ^ rows[first][1]))
            del rows[pv]
            self.pivmask ^= 1 << pv
        return out


def _substitute(C, sub, meter):
    """Apply var -> (target, parity) / (0, constant) to every clause and renormalise."""
    out = []
    seen = set()
    nlit = 0
    for c in C:
        nlit += len(c)
        touched = False
        for l in c:
            if (l if l > 0 else -l) in sub:
                touched = True
                break
        if not touched:
            if c not in seen:
                seen.add(c)
                out.append(c)
            continue
        nlit += len(c)
        lits = set()
        sat = False
        for l in c:
            s = sub.get(l if l > 0 else -l)
            if s is None:
                nl = l
            else:
                t, p = s
                if t == 0:
                    if (l > 0) == bool(p):
                        sat = True
                        break
                    continue
                nl = t if (l > 0) != bool(p) else -t
            if -nl in lits:
                sat = True
                break
            lits.add(nl)
        if sat:
            continue
        if not lits:
            meter.tick("clause_literal_scan", nlit)
            raise _Unsat("empty_clause_after_substitution")
        t = tuple(sorted(lits, key=abs))
        if t not in seen:
            seen.add(t)
            out.append(t)
    meter.tick("clause_literal_scan", nlit)
    meter.tick("clause_scan", len(C))
    return out


class _Pre:
    __slots__ = ("orig", "clauses", "xrows", "rowrecs", "trail", "rounds")


def _preprocess(nvars, clauses, meter):
    """Steps 0-2.  Returns a _Pre; raises _Unsat."""
    tick = meter.tick
    raw = []
    used = set()
    empty = False
    for c in clauses:
        s = set()
        taut = False
        n = 0
        for l in c:
            n += 1
            if type(l) is not int or l == 0 or l > nvars or l < -nvars:
                raise ValueError("invalid literal %r for nvars=%r" % (l, nvars))
            if -l in s:
                taut = True
            s.add(l)
        tick("clause_scan", 1)
        tick("clause_literal_scan", n)
        if taut:
            continue
        if not s:
            empty = True
            continue
        raw.append(s)
        for l in s:
            used.add(l if l > 0 else -l)
    if empty:
        # reported only after the whole input was read and validated, so that the run
        # does not depend on where the empty clause sits
        raise _Unsat("empty_clause")
    orig = sorted(used)
    tick("sort_step", _sort_cost(len(orig)))
    dense = {v: i + 1 for i, v in enumerate(orig)}
    cset = set()
    for s in raw:
        t = sorted([(dense[l] if l > 0 else -dense[-l]) for l in s], key=abs)
        tick("sort_step", _sort_cost(len(t)))
        cset.add(tuple(t))
    C = sorted(cset, key=_ckey)
    tick("sort_step", _sort_cost(len(C)))

    basis = _GF2(meter)
    W = []
    trail = []
    rounds = 0
    while True:
        meter.check()
        rounds += 1
        progress = False
        C, forced = _bcp(C, meter)
        for l in forced:
            if basis.insert(1 << (l if l > 0 else -l), 1 if l > 0 else 0) == 2:
                raise _Unsat("affine_inconsistent")
            progress = True
        C, newrows = _detect_xors(C, meter)
        for m, p in newrows:
            if basis.insert(m, p) == 2:
                raise _Unsat("affine_inconsistent")
            W.append((m, p))
            progress = True
        if not progress:
            break
        basis.reduce_all()
        ext = basis.extract()
        if not ext:
            continue
        trail.extend(ext)
        sub = {}
        for v, t, p in ext:
            sub[v] = (t, p)
        extmask = _mask_of([v for v, t, p in ext])
        newW = []
        steps = 0
        words = 0
        for m, p in W:
            hit = m & extmask
            steps += 1
            w = _words(m)
            words += w
            while hit:
                low = hit & -hit
                t, q = sub[low.bit_length() - 1]
                m ^= low
                p ^= q
                if t:
                    m ^= 1 << t
                hit ^= low
                steps += 1
                words += 4 * w
            if m:
                newW.append((m, p))
            elif p:
                raise _Internal("substituted row became 0 = 1 after a consistent basis")
        tick("gf2_step", steps)
        tick("gf2_words", words)
        W = newW
        C = _substitute(C, sub, meter)

    C = sorted(set(C), key=_ckey)
    tick("sort_step", _sort_cost(len(C)))
    pre = _Pre()
    pre.orig = orig
    pre.clauses = C
    pre.trail = trail
    pre.rounds = rounds
    if not C:
        # purely affine remainder: every basis row is dropped, pivot = lowest bit
        pre.rowrecs = dict(basis.rows)
        pre.xrows = []
        return pre
    cvars = set()
    for c in C:
        for l in c:
            cvars.add(l if l > 0 else -l)
    cmask = _mask_of(cvars)
    tick("clause_literal_scan", sum(len(c) for c in C))
    wmask = 0
    for m, p in W:
        wmask |= m
    tick("gf2_words", sum(_words(m) for m, p in W))
    umask = wmask & ~cmask
    if umask:
        ub = _GF2(meter, allowed=umask)
        for m, p in W:
            if ub.insert(m, p) == 2:
                raise _Internal("projection met 0 = 1 after a consistent basis")
        pre.rowrecs = dict(ub.rows)
        surv = ub.survivors
    else:
        pre.rowrecs = {}
        surv = W
    surv = sorted(set(surv), key=lambda r: (r[0].bit_count(), r[0], r[1]))
    tick("sort_step", _sort_cost(len(surv)))
    ind = _GF2(meter)
    xrows = []
    for m, p in surv:
        res = ind.insert(m, p)
        if res == 1:
            xrows.append((m, p))
        elif res == 2:
            raise _Internal("surviving rows are inconsistent after a consistent basis")
    pre.xrows = xrows
    return pre


def _reconstruct(pre, values, meter):
    """Undo step 2.  ``values`` maps residual dense variables to bool.  Returns the
    bitmask of all mentioned dense variables that are True; every variable that is
    neither residual nor defined by a dropped row / the trail is free and stays False."""
    valmask = _mask_of([d for d, b in values.items() if b])
    rowrecs = pre.rowrecs
    # variables that still have to receive a value from a dropped row or the trail
    pending = _mask_of(list(rowrecs) + [v for v, t, p in pre.trail])
    if pending & _mask_of(list(values)):
        raise _Internal("reconstruction: a defined variable is also residual")
    words = 0
    order = sorted(rowrecs, reverse=True)
    for pv in order:
        mask, parity = rowrecs[pv]
        bit = 1 << pv
        rest = mask ^ bit
        if not (mask & bit) or not (pending & bit):
            raise _Internal("reconstruction: pivot is not pending")
        if rest & pending:
            raise _Internal("reconstruction: row reads a variable that is not yet defined")
        if (parity ^ (rest & valmask).bit_count()) & 1:
            valmask |= bit
        pending ^= bit
        words += 6 * _words(mask)
    for v, t, p in reversed(pre.trail):
        bit = 1 << v
        if not (pending & bit):
            raise _Internal("reconstruction: trail variable is not pending")
        b = p
        if t:
            if (pending >> t) & 1:
                raise _Internal("reconstruction: equivalence target is not yet defined")
            b ^= (valmask >> t) & 1
        if b:
            valmask |= bit
        pending ^= bit
        words += 4 * _words(valmask)
    if pending:
        raise _Internal("reconstruction: a defined variable received no value")
    meter.tick("witness_step", words + len(order) + len(pre.trail))
    meter.tick("sort_step", _sort_cost(len(order)))
    return valmask


# --------------------------------------------------------------------------------------
# Step 3: the BDD kernel (iterative, no recursion)
# --------------------------------------------------------------------------------------

class _BDD:
    """Reduced ordered BDDs without complement edges.  Node 0 = FALSE, 1 = TRUE.
    ``lv[x]`` is the level of node x (0 = top; terminals have level n)."""

    def __init__(self, nlevels, meter, cap):
        self.n = nlevels
        self.lv = [nlevels, nlevels]
        self.lo = [0, 1]
        self.hi = [0, 1]
        self.uniq = [dict() for _ in range(nlevels)]
        self.cap = max(2, cap)
        self.sh = max(self.cap.bit_length() + 1, 8)
        self.andc = {}
        self.orc = {}
        self.and_limit = max(1 << 12, self.cap // 2)
        self.or_limit = max(1 << 12, self.cap // 4)
        self.meter = meter

    def nodes(self):
        return len(self.lv)

    def mk(self, level, l, h):
        if l == h:
            return l
        d = self.uniq[level]
        k = (l << self.sh) | h
        r = d.get(k)
        if r is None:
            r = len(self.lv)
            if r >= self.cap:
                raise _Abort("node_cap")
            self.lv.append(level)
            self.lo.append(l)
            self.hi.append(h)
            d[k] = r
            self.meter.tick("bdd_unique_insert", 1)
        return r

    def clause(self, lits):
        """BDD of a clause given as [(level, positive)]."""
        r = 0
        self.meter.tick("sort_step", _sort_cost(len(lits)))
        for level, pos in sorted(lits, reverse=True):
            r = self.mk(level, r, 1) if pos else self.mk(level, 1, r)
        return r

    def parity(self, levels, parity):
        """BDD of XOR(levels) == parity."""
        levels = sorted(levels, reverse=True)
        self.meter.tick("sort_step", _sort_cost(len(levels)))
        if not levels:
            return 0 if parity else 1
        e, o = 1, 0
        for level in levels[:-1]:
            e, o = self.mk(level, e, o), self.mk(level, o, e)
        top = levels[-1]
        return self.mk(top, e, o) if parity else self.mk(top, o, e)

    def _apply(self, f, g, is_and):
        lv = self.lv
        lo = self.lo
        hi = self.hi
        uniq = self.uniq
        sh = self.sh
        cap = self.cap
        cache = self.andc if is_and else self.orc
        todo = [f, g]
        out = []
        pop = todo.pop
        push = out.append
        opop = out.pop
        miss = 0
        ins = 0
        meter = self.meter
        cat = "bdd_and_miss" if is_and else "bdd_or_miss"
        mask = KERNEL_CHECK_MASK
        try:
            while todo:
                g = pop()
                f = pop()
                if f < 0:
                    h1 = opop()
                    h0 = opop()
                    if h0 == h1:
                        r = h0
                    else:
                        d = uniq[-1 - f]
                        k = (h0 << sh) | h1
                        r = d.get(k)
                        if r is None:
                            r = len(lv)
                            if r >= cap:
                                raise _Abort("node_cap")
                            lv.append(-1 - f)
                            lo.append(h0)
                            hi.append(h1)
                            d[k] = r
                            ins += 1
                    cache[g] = r
                    push(r)
                    continue
                if f == g:
                    push(f)
                    continue
                if is_and:
                    if f < 2:
                        push(g if f else 0)
                        continue
                    if g < 2:
                        push(f if g else 0)
                        continue
                else:
                    if f < 2:
                        push(1 if f else g)
                        continue
                    if g < 2:
                        push(1 if g else f)
                        continue
                if f > g:
                    f, g = g, f
                k = (f << sh) | g
                r = cache.get(k)
                if r is not None:
                    push(r)
                    continue
                miss += 1
                if not miss & mask:
                    meter.tick(cat, mask + 1)
                    meter.tick("bdd_unique_insert", ins)
                    ins = 0
                    meter.check_kernel()
                a = lv[f]
                b = lv[g]
                if a == b:
                    todo += (-1 - a, k, hi[f], hi[g], lo[f], lo[g])
                elif a < b:
                    todo += (-1 - a, k, hi[f], g, lo[f], g)
                else:
                    todo += (-1 - b, k, f, hi[g], f, lo[g])
        finally:
            meter.tick(cat, miss & mask)
            meter.tick("bdd_unique_insert", ins)
        return out[0]

    def band(self, f, g):
        if f == g:
            return f
        if f < 2:
            return g if f else 0
        if g < 2:
            return f if g else 0
        return self._apply(f, g, True)

    def bor(self, f, g):
        if f == g:
            return f
        if f < 2:
            return 1 if f else g
        if g < 2:
            return 1 if g else f
        return self._apply(f, g, False)

    def trim(self):
        """Bound the operation caches (called between elimination steps only, so a
        preempted and restarted kernel call never loses its own partial results)."""
        if len(self.andc) > self.and_limit:
            self.andc.clear()
        if len(self.orc) > self.or_limit:
            self.orc.clear()

    def exists(self, f, L, cache=None):
        """EXISTS (variable at level L) . f.  ``cache`` (node -> result for this L)
        may be supplied by the caller so that a restarted call resumes its work."""
        lv = self.lv
        if f < 2 or lv[f] > L:
            return f
        lo = self.lo
        hi = self.hi
        uniq = self.uniq
        sh = self.sh
        cap = self.cap
        if cache is None:
            cache = {}
        todo = [f]
        out = []
        miss = 0
        ins = 0
        meter = self.meter
        mask = KERNEL_CHECK_MASK
        try:
            while todo:
                x = todo.pop()
                if x < 0:
                    n = -1 - x
                    h1 = out.pop()
                    h0 = out.pop()
                    if h0 == h1:
                        r = h0
                    else:
                        a = lv[n]
                        d = uniq[a]
                        k = (h0 << sh) | h1
                        r = d.get(k)
                        if r is None:
                            r = len(lv)
                            if r >= cap:
                                raise _Abort("node_cap")
                            lv.append(a)
                            lo.append(h0)
                            hi.append(h1)
                            d[k] = r
                            ins += 1
                    cache[n] = r
                    out.append(r)
                    continue
                if x < 2:
                    out.append(x)
                    continue
                a = lv[x]
                if a > L:
                    out.append(x)
                    continue
                r = cache.get(x)
                if r is not None:
                    out.append(r)
                    continue
                miss += 1
                if not miss & mask:
                    meter.tick("bdd_exists_miss", mask + 1)
                    meter.tick("bdd_unique_insert", ins)
                    ins = 0
                    meter.check_kernel()
                if a == L:
                    r = self.bor(lo[x], hi[x])
                    cache[x] = r
                    out.append(r)
                    continue
                todo.append(-1 - x)
                todo.append(hi[x])
                todo.append(lo[x])
        finally:
            meter.tick("bdd_exists_miss", miss & mask)
            meter.tick("bdd_unique_insert", ins)
        return out[0]

    def support(self, f):
        """(sorted levels in the support, number of internal nodes) of f."""
        lv = self.lv
        lo = self.lo
        hi = self.hi
        seen = set()
        levels = set()
        stack = [f]
        while stack:
            x = stack.pop()
            if x < 2 or x in seen:
                continue
            seen.add(x)
            levels.add(lv[x])
            stack.append(lo[x])
            stack.append(hi[x])
        self.meter.tick("bdd_visit", len(seen))
        return sorted(levels), len(seen)

    def evaluate(self, f, val):
        """Value of f under ``val`` (list indexed by level); also the path length."""
        lv = self.lv
        lo = self.lo
        hi = self.hi
        steps = 0
        while f > 1:
            b = val[lv[f]]
            if b is None:
                raise _Internal("witness: BDD path reads an unassigned variable")
            f = hi[f] if b else lo[f]
            steps += 1
        return f == 1, steps


# --------------------------------------------------------------------------------------
# Step 6: structural BDD orders
# --------------------------------------------------------------------------------------

def _occurrences(n, scopes):
    occ = [[] for _ in range(n)]
    for j, s in enumerate(scopes):
        for v in s:
            occ[v].append(j)
    return occ


def _order_wide(n, scopes, meter, blocks=None):
    """Widest-constraint-first placement.  If ``blocks`` is a list of length n it
    receives, for every variable, the index of the constraint that placed it."""
    occ = _occurrences(n, scopes)
    heap = [(-len(s), 0, j) for j, s in enumerate(scopes)]
    heapify(heap)
    overlap = [0] * len(scopes)
    done = [False] * len(scopes)
    placed = [False] * n
    order = []
    steps = len(heap)
    while heap:
        w, ov, j = heappop(heap)
        steps += 1
        if done[j] or -ov != overlap[j]:
            continue
        done[j] = True
        for v in scopes[j]:
            steps += 1
            if placed[v]:
                continue
            placed[v] = True
            order.append(v)
            if blocks is not None:
                blocks[v] = j
            for i in occ[v]:
                steps += 1
                if not done[i]:
                    overlap[i] += 1
                    heappush(heap, (-len(scopes[i]), -overlap[i], i))
    meter.tick("order_step", steps * max(1, len(scopes).bit_length()))
    for v in range(n):
        if not placed[v]:
            order.append(v)
            if blocks is not None:
                blocks[v] = len(scopes) + v
    return order


def _elim_cross(n, scopes, level, blocks, meter):
    """Static elimination order 'cross': breadth-first search over the graph that
    links two variables iff they share a constraint and lie in different blocks of the
    widest-first placement.  Components are started at their top-most variable and
    newly reached variables are queued by BDD level.  Every constraint is expanded
    at most twice (from two different blocks), so the cost is linear in the size."""
    occ = _occurrences(n, scopes)
    seen = [False] * n
    first = [-1] * len(scopes)       # block from which the constraint was first expanded
    closed = [False] * len(scopes)
    order = []
    steps = _sort_cost(n)
    for s in sorted(range(n), key=lambda v: level[v]):
        if seen[s]:
            continue
        seen[s] = True
        queue = [s]
        qi = 0
        while qi < len(queue):
            v = queue[qi]
            qi += 1
            order.append(v)
            b = blocks[v]
            new = []
            for j in occ[v]:
                steps += 1
                if closed[j] or first[j] == b:
                    continue
                if first[j] == -1:
                    first[j] = b
                else:
                    closed[j] = True
                for u in scopes[j]:
                    steps += 1
                    if not seen[u] and blocks[u] != b:
                        seen[u] = True
                        new.append(u)
            if new:
                new.sort(key=lambda u: level[u])
                steps += _sort_cost(len(new))
                queue.extend(new)
    meter.tick("order_step", steps)
    return order


def _order_bfs(n, scopes, meter):
    occ = _occurrences(n, scopes)
    starts = sorted(range(n), key=lambda v: (len(occ[v]), v))
    seen = [False] * n
    used = [False] * len(scopes)
    order = []
    steps = _sort_cost(n)
    for s in starts:
        if seen[s]:
            continue
        seen[s] = True
        queue = [s]
        qi = 0
        while qi < len(queue):
            v = queue[qi]
            qi += 1
            order.append(v)
            for j in occ[v]:
                steps += 1
                if used[j]:
                    continue
                used[j] = True
                for u in scopes[j]:
                    steps += 1
                    if not seen[u]:
                        seen[u] = True
                        queue.append(u)
    meter.tick("order_step", steps)
    return order


def _order_force(n, scopes, meter):
    order = _order_wide(n, scopes, meter)
    if n < 3 or not scopes:
        return order
    occ = _occurrences(n, scopes)
    pos = [0] * n
    for i, v in enumerate(order):
        pos[v] = i

    def span():
        return sum(max(pos[v] for v in s) - min(pos[v] for v in s) for s in scopes if s)

    size = sum(len(s) for s in scopes)
    best = list(order)
    best_span = span()
    stale = 0
    for _ in range(4 * max(1, n.bit_length())):
        meter.check()
        cog = [(sum(pos[v] for v in s) / len(s)) if s else 0.0 for s in scopes]
        key = []
        for v in range(n):
            js = occ[v]
            key.append(((sum(cog[j] for j in js) / len(js)) if js else float(pos[v]),
                        pos[v], v))
        key.sort()
        for i, (_, _, v) in enumerate(key):
            pos[v] = i
        meter.tick("order_step", 3 * size + _sort_cost(n))
        sp = span()
        if sp < best_span:
            best_span = sp
            best = [v for _, _, v in key]
            stale = 0
        else:
            stale += 1
            if stale >= 3:
                break
    return best


def _compute_order(rule, n, scopes, meter):
    if rule == "wide":
        order = _order_wide(n, scopes, meter)
    elif rule == "bfs":
        order = _order_bfs(n, scopes, meter)
    elif rule == "force":
        order = _order_force(n, scopes, meter)
    elif rule == "index":
        order = list(range(n))
    elif isinstance(rule, (list, tuple)) and len(rule) == 2 and rule[0] == "static":
        order = list(rule[1])
    else:
        raise ValueError("unknown BDD order rule %r" % (rule,))
    if sorted(order) != list(range(n)):
        raise _Internal("order rule did not return a permutation")
    return order


# --------------------------------------------------------------------------------------
# Steps 4-5: bucket elimination and witness
# --------------------------------------------------------------------------------------

def _bdd_stage(pre, strategy, meter, cap, hook, stats):
    """Decide the residual (clauses + parity rows).  This is a generator: it yields
    after every elimination step (so that a portfolio can interleave attempts) and
    finally returns {dense var: bool} for the residual variables.  Raises _Unsat on a
    refutation and _Abort on the node cap / deadline."""
    tick = meter.tick
    order_rule, elim_rule = strategy
    rset = set()
    for c in pre.clauses:
        for l in c:
            rset.add(l if l > 0 else -l)
    xvars = [_bits(m) for m, p in pre.xrows]
    for vs in xvars:
        rset.update(vs)
    rvars = sorted(rset)
    tick("sort_step", _sort_cost(len(rvars)))
    nr = len(rvars)
    local = {v: i for i, v in enumerate(rvars)}
    cscopes = [tuple([local[l if l > 0 else -l] for l in c]) for c in pre.clauses]
    xscopes = [tuple([local[v] for v in vs]) for vs in xvars]
    tick("gf2_words", sum(len(vs) * _words(m) for vs, (m, p) in zip(xvars, pre.xrows)))
    scopes = cscopes + xscopes
    nlit = sum(len(s) for s in scopes)
    tick("clause_literal_scan", nlit)

    dense_of = {o: i + 1 for i, o in enumerate(pre.orig)}

    def to_local(seq):
        """Original variable ids -> local residual indices (unknown ids are skipped,
        missing residual variables are appended in index order)."""
        out = []
        seen = set()
        for o in seq:
            i = local.get(dense_of.get(o))
            if i is not None and i not in seen:
                seen.add(i)
                out.append(i)
        out += [i for i in range(nr) if i not in seen]
        return out

    if isinstance(order_rule, (list, tuple)) and order_rule[0] == "static":
        order = _compute_order(("static", to_local(order_rule[1])), nr, scopes, meter)
    else:
        order = _compute_order(order_rule, nr, scopes, meter)
    level = [0] * nr
    for L, i in enumerate(order):
        level[i] = L

    bdd = _BDD(nr, meter, cap)
    stats["bdd"] = bdd
    lv = bdd.lv

    fnode = {}
    fscope = {}
    fvars = {}
    fsize = {}
    node2fid = {}
    occ = [set() for _ in range(nr)]
    counter = [0]
    words = (nr + 63) >> 6 or 1

    def add(node):
        if node == 1:
            return None
        if node == 0:
            raise _Unsat("bdd_false")
        fid = node2fid.get(node)
        if fid is not None:
            return fid
        levels, size = bdd.support(node)
        fid = counter[0]
        counter[0] = fid + 1
        for L in levels:
            occ[L].add(fid)
        fnode[fid] = node
        fscope[fid] = _mask_of(levels)
        fvars[fid] = levels
        fsize[fid] = size
        node2fid[node] = fid
        if size > stats["largest_factor"]:
            stats["largest_factor"] = size
        tick("order_step", len(levels))
        return fid

    for c, s in zip(pre.clauses, cscopes):
        add(bdd.clause([(level[i], l > 0) for l, i in zip(c, s)]))
    for (m, p), s in zip(pre.xrows, xscopes):
        add(bdd.parity([level[i] for i in s], p))
    tick("clause_literal_scan", nlit)

    orig = pre.orig

    def emit(stage, eliminated):
        if hook is None:
            return
        gone = set(L for L, B in records)
        retained = [orig[rvars[order[L]] - 1] for L in range(nr) if L not in gone]
        var_level = {orig[rvars[order[L]] - 1]: L for L in range(nr)}

        def evaluate(node, assignment):
            x = node
            while x > 1:
                x = bdd.hi[x] if assignment[orig[rvars[order[lv[x]]] - 1]] else bdd.lo[x]
            return x == 1

        hook({"stage": stage, "strategy": strategy, "retained": retained,
              "eliminated": None if eliminated is None else orig[rvars[order[eliminated]] - 1],
              "factors": list(fnode.values()), "evaluate": evaluate,
              "var_level": var_level, "nodes": bdd.nodes()})

    records = []
    emit("bdd_start", None)

    static = None
    dynamic = elim_rule in ("mindeg", "minfac", "level", "revlevel")
    if not dynamic:
        if elim_rule == "cross":
            blocks = [0] * nr
            _order_wide(nr, scopes, meter, blocks)
            static = [level[i] for i in _elim_cross(nr, scopes, level, blocks, meter)]
        elif isinstance(elim_rule, (list, tuple)) and len(elim_rule) == 2 and elim_rule[0] == "static":
            static = [level[i] for i in to_local(elim_rule[1])]
        else:
            raise ValueError("unknown elimination rule %r" % (elim_rule,))
    recent = [0, ()]
    cur = [None] * nr
    heap = []

    def key_of(u):
        fs = occ[u]
        if elim_rule == "level":
            return (u,)
        if elim_rule == "revlevel":
            return (-u,)
        tot = 0
        for f in fs:
            tot += len(fvars[f])
        if tot <= len(fs) * words:
            # few small scopes: union as a set of levels
            u_set = set()
            for f in fs:
                u_set.update(fvars[f])
            tick("order_step", tot + len(fs) + 1)
            deg = len(u_set) - 1
        else:
            m = 0
            for f in fs:
                m |= fscope[f]
            tick("order_step", len(fs) * (words + 1) + 1)
            deg = m.bit_count() - 1
        if elim_rule == "mindeg":
            return (deg, len(fs), u)
        return (len(fs), 0 if (recent[0] >> u) & 1 else 1, deg, u)

    if dynamic:
        for u in range(nr):
            if occ[u]:
                k = key_of(u)
                cur[u] = k
                heap.append((k, u))
        heapify(heap)
        tick("order_step", len(heap))
    si = 0
    try:
        while True:
            meter.check()
            L = None
            if dynamic:
                while heap:
                    k, u = heappop(heap)
                    tick("order_step", 1)
                    if cur[u] == k and occ[u]:
                        L = u
                        break
            else:
                while si < len(static):
                    u = static[si]
                    si += 1
                    tick("order_step", 1)
                    if occ[u]:
                        L = u
                        break
            if L is None:
                break
            fs = sorted(occ[L], key=lambda f: (fsize[f], f))
            tick("sort_step", _sort_cost(len(fs)))
            bdd.trim()
            acc = fnode[fs[0]]
            for f in fs[1:]:
                tick("bucket_and", 1)
                while True:
                    try:
                        acc = bdd.band(acc, fnode[f])
                        break
                    except _Preempt:
                        yield None      # resumed later; finished sub-results are cached
                if acc == 0:
                    records.append((L, 0))
                    raise _Unsat("bdd_false")
            single = fsize[fs[0]] if len(fs) == 1 else None
            touched = set()
            nt = 0
            for f in fs:
                vs = fvars[f]
                nt += len(vs)
                for u in vs:
                    occ[u].discard(f)
                    touched.add(u)
                del node2fid[fnode[f]]
                del fnode[f], fscope[f], fvars[f], fsize[f]
            tick("order_step", nt)
            touched.discard(L)
            cur[L] = None
            records.append((L, acc))
            bsize = single if single is not None else bdd.support(acc)[1]
            if bsize > stats["largest_bucket"]:
                stats["largest_bucket"] = bsize
            ecache = {}
            while True:
                try:
                    new = bdd.exists(acc, L, ecache)
                    break
                except _Preempt:
                    yield None
            ecache = None
            if new == 0:
                raise _Internal("projection of a satisfiable bucket is FALSE")
            fid = add(new)
            stats["eliminations"] += 1
            if dynamic:
                if elim_rule == "minfac":
                    old = recent[1]
                    if fid is not None:
                        recent[0] = fscope[fid]
                        recent[1] = fvars[fid]
                    else:
                        recent[0] = 0
                        recent[1] = ()
                    touched.update(old)
                    touched.discard(L)
                for u in touched:
                    if occ[u]:
                        k = key_of(u)
                        if k != cur[u]:
                            cur[u] = k
                            heappush(heap, (k, u))
                            tick("order_step", 1)
                    else:
                        cur[u] = None
            emit("bdd_step", L)
            yield None
    except _Unsat:
        if hook is not None:
            fnode.clear()
            fnode[-1] = 0
            emit("bdd_false", None)
        raise
    if fnode:
        raise _Internal("factors remain after all variables were eliminated")

    # witness: never-eliminated variables are free (False); the others go backwards
    val = [False] * nr
    for L, B in records:
        val[L] = None
    steps = 0
    for L, B in reversed(records):
        val[L] = False
        ok, s = bdd.evaluate(B, val)
        steps += s
        if not ok:
            val[L] = True
            ok, s = bdd.evaluate(B, val)
            steps += s
            if not ok:
                raise _Internal("witness: bucket has no satisfying value")
    tick("witness_step", steps)
    return {rvars[order[L]]: val[L] for L in range(nr)}


# --------------------------------------------------------------------------------------
# Public entry points
# --------------------------------------------------------------------------------------

def _strategy_name(s):
    def one(x):
        return x if isinstance(x, str) else "static"
    return one(s[0]) + "+" + one(s[1])


def _parse_strategy(strategy):
    if strategy is None:
        return None
    if isinstance(strategy, str):
        a, b = strategy.split("+")
        return (a, b)
    return (strategy[0], strategy[1])


def solve(nvars, clauses, budget=None, *, node_cap=DEFAULT_NODE_CAP, time_limit=None,
          strategy=None, debug_hook=None):
    """Decide the CNF.  Returns a dict with ``status`` in {SAT, UNSAT, UNKNOWN, ERROR},
    ``assignment`` (list[bool] of length nvars) for SAT, and ``operations``.

    strategy=None runs the shipped portfolio; otherwise a pair / "order+elim" string
    selects one (BDD order rule, elimination rule) with the whole node cap.  Static
    orders are given as ("static", [original variable ids])."""
    if type(nvars) is not int or nvars < 0:
        raise ValueError("nvars must be a nonnegative integer")
    deadline = None if time_limit is None else time.monotonic() + time_limit
    meter = _Meter(budget, deadline)
    start = time.monotonic()
    info = {"decided_by": None, "strategy": None, "attempts": [], "preprocess_rounds": 0,
            "residual_vars": 0, "residual_clauses": 0, "residual_xor_rows": 0}
    nodes_total = 0
    nodes_peak = 0
    largest_bucket = 0
    largest_factor = 0
    status = "UNKNOWN"
    reason = None
    assignment = None
    try:
        try:
            pre = _preprocess(nvars, clauses, meter)
            info["preprocess_rounds"] = pre.rounds
            info["residual_clauses"] = len(pre.clauses)
            info["residual_xor_rows"] = len(pre.xrows)
            orig = pre.orig
            if debug_hook is not None:
                rs = sorted(set(abs(l) for c in pre.clauses for l in c))
                debug_hook({
                    "stage": "preprocessed",
                    "retained": [orig[d - 1] for d in rs],
                    "clauses": [tuple((orig[abs(l) - 1] if l > 0 else -orig[abs(l) - 1])
                                      for l in c) for c in pre.clauses],
                    "xors": [(tuple(orig[d - 1] for d in _bits(m)), p) for m, p in pre.xrows],
                    "dropped_rows": [(orig[pv - 1], tuple(orig[d - 1] for d in _bits(m ^ (1 << pv))), p)
                                     for pv, (m, p) in sorted(pre.rowrecs.items())],
                    "trail": [(orig[v - 1], orig[t - 1] if t else 0, p) for v, t, p in pre.trail],
                })
            values = None
            if not pre.clauses:
                values = {}
                info["decided_by"] = "affine_sat"
            else:
                info["residual_vars"] = len(set(abs(l) for c in pre.clauses for l in c))
                chosen = _parse_strategy(strategy)
                strategies = [chosen] if chosen is not None else list(PORTFOLIO)
                cap = max(4, node_cap // len(strategies))
                runs = []
                for idx, strat in enumerate(strategies):
                    stats = {"bdd": None, "largest_bucket": 0, "largest_factor": 0,
                             "eliminations": 0}
                    att = {"strategy": _strategy_name(strat), "node_cap": cap,
                           "result": "abandoned", "ticks": 0}
                    runs.append([0, idx, _bdd_stage(pre, strat, meter, cap, debug_hook, stats),
                                 stats, att])
                # Race: always advance the attempt that has consumed the fewest ticks
                # (ties: portfolio order).  Deterministic; total work <= #strategies *
                # (work of the first strategy to finish) + one elimination step each.
                active = list(runs)
                last_abort = None
                try:
                    while active and values is None:
                        run = min(active, key=lambda r: (r[0], r[1]))
                        before = meter.total
                        if len(active) > 1:
                            lead = min(r[0] for r in active if r is not run) - run[0]
                            meter.slice_end = (before + lead + RACE_SLICE
                                               + 16 * info["residual_vars"] + 16)
                        else:
                            meter.slice_end = None
                        try:
                            next(run[2])
                        except StopIteration as stop:
                            values = stop.value
                            run[4]["result"] = "SAT"
                            info["strategy"] = run[4]["strategy"]
                        except _Abort as exc:
                            run[4]["result"] = exc.reason
                            active.remove(run)
                            last_abort = exc
                            if exc.reason == "deadline":
                                break
                        except _Unsat:
                            run[4]["result"] = "UNSAT"
                            info["strategy"] = run[4]["strategy"]
                            raise
                        finally:
                            run[0] += meter.total - before
                finally:
                    meter.slice_end = None
                    for ticks, idx, gen, stats, att in runs:
                        gen.close()
                        made = stats["bdd"].nodes() - 2 if stats["bdd"] is not None else 0
                        att["ticks"] = ticks
                        att["nodes"] = made
                        att["largest_bucket"] = stats["largest_bucket"]
                        att["largest_factor"] = stats["largest_factor"]
                        att["eliminations"] = stats["eliminations"]
                        info["attempts"].append(att)
                        nodes_total += made
                        nodes_peak += made
                        largest_bucket = max(largest_bucket, stats["largest_bucket"])
                        largest_factor = max(largest_factor, stats["largest_factor"])
                        stats["bdd"] = None
                if values is None:
                    raise last_abort if last_abort is not None else _Abort("no_strategy")
                info["decided_by"] = "bdd_sat"
            valmask = _reconstruct(pre, values, meter)
            assignment = [False] * nvars
            raw = valmask.to_bytes((valmask.bit_length() >> 3) + 1, "little")
            for d in range(1, len(orig) + 1):
                if (d >> 3) < len(raw) and raw[d >> 3] >> (d & 7) & 1:
                    assignment[orig[d - 1] - 1] = True
            meter.tick("witness_step", len(orig))
            # (I4) full scan of the ORIGINAL clauses (no early exit, so that the
            # charge does not depend on literal order)
            nlit = 0
            ok = True
            for c in clauses:
                sat = False
                for l in c:
                    nlit += 1
                    if assignment[abs(l) - 1] == (l > 0):
                        sat = True
                if not sat:
                    ok = False
            meter.tick("verify_literal_scan", nlit)
            if ok:
                status = "SAT"
            else:
                status = "ERROR"
                reason = "internal: reconstructed assignment violates an original clause"
                assignment = None
        except _Unsat as exc:
            status = "UNSAT"
            info["decided_by"] = exc.reason
        except _Abort as exc:
            status = "UNKNOWN"
            reason = exc.reason
            assignment = None
        except _Internal as exc:
            status = "ERROR"
            reason = "internal: %s" % exc
            assignment = None
    except Exception as exc:  # the cooperative budget of the caller
        if type(exc).__name__ != "BudgetExceeded":
            raise
        status = "UNKNOWN"
        reason = "budget_exceeded: %s" % exc
        assignment = None
    nodes = max(2, nodes_total)
    log_nodes = (nodes - 1).bit_length()
    word = max(64, log_nodes, max(1, nvars).bit_length(), max(1, len(clauses)).bit_length())
    ops = dict(meter.cats)
    ops.update({
        "total_ticks": meter.total,
        "categories": dict(meter.cats),
        "bdd_nodes_total": nodes_total,
        "bdd_nodes_peak": nodes_peak,
        "bdd_largest_bucket": largest_bucket,
        "bdd_largest_factor": largest_factor,
        "bit_cost_upper": meter.total * max(1, log_nodes),
        "bit_cost_upper_wordsize": meter.total * word,
        "encoded_bits_N": encoded_bit_length(clauses),
        "seconds": round(time.monotonic() - start, 6),
    })
    ops.update(info)
    result = {"status": status, "operations": ops}
    if status == "SAT":
        result["assignment"] = assignment
    if reason is not None:
        result["reason"] = reason
    return result


def solve_capped(nvars, clauses, C=1, d=3, **kwargs):
    """``solve`` under its own Budget of C * N**d ticks, N = encoded_bit_length."""
    n = encoded_bit_length(clauses)
    maximum = int(C * n ** d)
    budget = Budget(maximum)
    result = solve(nvars, clauses, budget, **kwargs)
    result["N"] = n
    result["budget_maximum"] = maximum
    result["budget_total"] = budget.total
    result["within_budget"] = budget.total <= maximum
    return result


def _parse_dimacs(text):
    nvars = None
    toks = []
    for line in text.splitlines():
        line = line.strip()
        if not line or line[0] in "c%":
            continue
        if line[0] == "p":
            nvars = int(line.split()[2])
            continue
        toks.extend(int(t) for t in line.split())
    clauses = []
    cur = []
    for t in toks:
        if t == 0:
            clauses.append(tuple(cur))
            cur = []
        else:
            cur.append(t)
    if cur:
        raise ValueError("unterminated clause")
    if nvars is None:
        nvars = max((abs(l) for c in clauses for l in c), default=0)
    return nvars, clauses


def _main(argv):
    import argparse
    import json
    ap = argparse.ArgumentParser(description="CFPE SAT decider (research candidate)")
    ap.add_argument("cnf", help="DIMACS file")
    ap.add_argument("--strategy", default=None, help="e.g. wide+minfac (default: portfolio)")
    ap.add_argument("--node-cap", type=int, default=DEFAULT_NODE_CAP)
    ap.add_argument("--time-limit", type=float, default=None)
    ap.add_argument("--model", action="store_true", help="print the assignment")
    args = ap.parse_args(argv)
    with open(args.cnf) as fh:
        nvars, clauses = _parse_dimacs(fh.read())
    res = solve(nvars, clauses, None, node_cap=args.node_cap, time_limit=args.time_limit,
                strategy=args.strategy)
    if not args.model:
        res.pop("assignment", None)
    print(json.dumps(res, indent=1, sort_keys=True))
    return 0 if res["status"] in ("SAT", "UNSAT") else 2


if __name__ == "__main__":
    import sys
    sys.exit(_main(sys.argv[1:]))
