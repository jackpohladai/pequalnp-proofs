"""Machine check of the induction invariant used in the proof of Theorem A (theory.md).

Claim(j), 0 <= j <= k-1: after forgetting v, p_1..p_j the root of the UNCHANGED residual_dag
is an OR node whose children are exactly  lit(a)  and the 2^j AND nodes
    A_T = and( {lit(b)} u {or(a,q_i) : i in T} u {or(a,p_i,q_i) : j < i <= k} ),  T subset of [j],
which are pairwise distinct. We rebuild each predicted node through the public API of the same
DAG object (hash-consing makes node identity = structural identity) and compare id sets.
"""
import sys, itertools, json
sys.path.insert(0, '../../native-search')
from residual_dag import DAG

def check(k):
    v, a, b = 1, 2, 3
    p = lambda i: 3 + i
    q = lambda i: 3 + k + i
    clauses = [(-v, a), (v, b)] + [(a, p(i), q(i)) for i in range(1, k + 1)]
    d = DAG(); root = d.cnf(clauses)
    root = d.forget(root, v)
    widths = []
    for j in range(0, k):                       # j eliminated p's so far
        kind, data = d.nodes[root]
        assert kind == 'or', (k, j, kind)
        predicted = {d.literal(a)}
        for r in range(j + 1):
            for T in itertools.combinations(range(1, j + 1), r):
                kids = [d.literal(b)]
                kids += [d.junction('or', [d.literal(a), d.literal(q(i))]) for i in T]
                kids += [d.junction('or', [d.literal(a), d.literal(p(i)), d.literal(q(i))])
                         for i in range(j + 1, k + 1)]
                predicted.add(d.junction('and', kids))
        assert len(predicted) == 2 ** j + 1, (k, j, len(predicted))
        assert set(data) == predicted, (k, j)
        widths.append(len(data))
        root = d.forget(root, p(j + 1))
    return widths

out = {}
for k in range(1, 13):
    out[k] = check(k)
    print(k, 'root OR arity after v,p_1..p_j for j=0..k-1:', out[k], flush=True)
json.dump(out, open('verify_theoremA_invariant.json', 'w'))
print('Claim(j) verified structurally for all 0 <= j <= k-1, k = 1..12')
