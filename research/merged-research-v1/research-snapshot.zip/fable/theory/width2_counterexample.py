"""W_k: a treewidth-2 CNF and an elimination order of induced width 2 on which the
unchanged residual_dag allocates exponentially many nodes.

Variables: v=1, a=2, b=3, p_i=3+i, q_i=3+k+i  (i=1..k)
Clauses:   (-v v a), (v v b), (a v p_i v q_i) for i=1..k
Order:     v, p_1..p_k, q_1..q_k, a, b
Bucket elimination along this order never creates a function on more than 2 variables.
"""
import sys, itertools, json
sys.path.insert(0, '../../native-search')
sys.setrecursionlimit(100000)
from residual_dag import DAG

def W(k):
    v, a, b = 1, 2, 3
    p = lambda i: 3 + i
    q = lambda i: 3 + k + i
    clauses = [(-v, a), (v, b)] + [(a, p(i), q(i)) for i in range(1, k + 1)]
    order = [v] + [p(i) for i in range(1, k + 1)] + [q(i) for i in range(1, k + 1)] + [a, b]
    good = [p(i) for i in range(1, k + 1)] + [q(i) for i in range(1, k + 1)] + [v, a, b]
    return 3 + 2 * k, clauses, order, good

def induced_width(n, clauses, order):
    adj = {x: set() for x in range(1, n + 1)}
    for c in clauses:
        vs = {abs(l) for l in c}
        for x in vs: adj[x] |= vs - {x}
    w = 0
    for x in order:
        nb = adj.pop(x)
        w = max(w, len(nb))
        for y in nb:
            adj[y] |= nb - {y}; adj[y].discard(x)
    return w

def run(n, clauses, order, trace=False):
    d = DAG(); root = d.cnf(clauses); arities = []
    for x in order:
        root = d.forget(root, x)
        kind, data = d.nodes[root]
        top = max((len(d.nodes[c][1]) for c in ([root] + list(data) if kind in ('and', 'or') else [root])
                   if d.nodes[c][0] == 'or'), default=0)
        arities.append(top)
    return root, len(d.nodes), max(arities)

rows = []
for k in range(1, 15):
    n, clauses, bad, good = W(k)
    r1, alloc_bad, widest_or = run(n, clauses, bad)
    r2, alloc_good, _ = run(n, clauses, good)
    assert r1 == 1 and r2 == 1          # satisfiable (e.g. a = b = True)
    rows.append(dict(k=k, n=n, induced_width_bad_order=induced_width(n, clauses, bad),
                     alloc_bad_order=alloc_bad, widest_or_arity=widest_or,
                     pow2k_plus1=2 ** k + 1, alloc_good_order=alloc_good))
    print(rows[-1], flush=True)
json.dump(rows, open('width2_counterexample.json', 'w'), indent=1)
