"""Is the polynomial behaviour of residual_dag on Tseitin formulas robust?
We add REDUNDANT clauses (each is an existing clause weakened by one extra literal of a
non-incident edge, hence subsumed: the Boolean function is unchanged) and re-measure.
Runs are capped (20 s / 400k nodes); CAP is a censored observation, not a lower bound."""
import sys, random, time, json
sys.path.insert(0, '../../native-search'); sys.path.insert(0, '../scratch'); sys.path.insert(0, '../repairs')
sys.setrecursionlimit(1000000)
from residual_dag import DAG
from miniscope_dag import MiniDAG
from h_probe import xor_clauses, random_regular

def tseitin_edges(nv, rng):
    edges = random_regular(nv, 3, rng)
    inc = {v: [] for v in range(nv)}
    for i, (a, b) in enumerate(edges, 1): inc[a].append(i); inc[b].append(i)
    return edges, inc

def build(nv, seed, extra_per_vertex):
    rng = random.Random(seed)
    edges, inc = tseitin_edges(nv, rng)
    n = len(edges); cl = []
    for v in range(nv):
        base = xor_clauses(inc[v], 1 if v == 0 else 0)
        cl += base
        for _ in range(extra_per_vertex):
            c = list(rng.choice(base))
            others = [e for e in range(1, n + 1) if e not in inc[v]]
            c.append(rng.choice(others) * rng.choice((-1, 1)))
            cl.append(c)                      # subsumed by an existing clause
    return n, cl

def run(cls, n, cl, order, cap=400000, tcap=20.0):
    d = cls(); root = d.cnf(cl); t0 = time.time()
    for v in order:
        root = d.forget(root, v)
        if len(d.nodes) > cap or time.time() - t0 > tcap: return 'CAP', len(d.nodes)
    return ('SAT' if root == 1 else 'UNSAT'), len(d.nodes)

if __name__ == '__main__':
    rows = []
    for nv in (8, 12, 16, 20, 24, 28, 32):
        for extra in (0, 1):
            n, cl = build(nv, 1000 + nv, extra)
            order = list(range(1, n + 1)); random.Random(nv).shuffle(order)
            r0 = run(DAG, n, cl, order); r1 = run(MiniDAG, n, cl, order)
            rows.append(dict(vertices=nv, edges=n, redundant_per_vertex=extra, R0=r0, R1=r1))
            print(rows[-1], flush=True)
    json.dump(rows, open('tseitin_fragility.json', 'w'), indent=1)
