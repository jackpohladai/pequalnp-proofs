# L-alg-001 / Fable: theory notes (paper proofs + machine checks)

Status legend used throughout
- [PROVED-PAPER]  complete proof written here; not Lean-checked.
- [CHECKED-FINITE] verified by an exact computation for the stated finite range only.
- [EMPIRICAL]     measured growth; says nothing about asymptotics.
- [LEAN]          checked by Lean 4.36 + pinned Mathlib (see ../lean/).
- [LITERATURE]    recalled from the literature, NOT verified in this session, context only;
                  no claim below depends on it.

Nothing in this file proves SAT in P, P = NP, or any polynomial bound for a complete SAT
algorithm.

--------------------------------------------------------------------------------------------
## 0. Exact model of `native-search/residual_dag.py`

Nodes: `const 0/1`, `lit(l)`, `and(S)`, `or(S)` (S a finite set of node ids; hash-consed on
`(op, sorted S)`). For op in {and, or} let dual(op) be the other one, identity = 1/0 and
absorbing = 0/1 respectively. `junction(op, C)` is, in this order:

- J1 flatten: return absorbing if an absorbing constant is in C; drop identity constants;
     replace every child of kind `op` by its children. Empty result -> identity.
- J2 complementary literals among the children -> absorbing.
- J3 absorption: delete every child c of kind dual(op) with children(c) ∩ flat ≠ ∅
     (A ∧ (A ∨ B) = A and its dual), tested against the set before deletion.
- J4 one child left -> return it.
- J5 (op = or only) with fs(c) = children(c) for and-children and {c} otherwise, let
     K = ∩ fs(c). If K ≠ ∅ return junction(and, K ∪ { junction(or, { junction(and, fs(c) \ K) }) }).
- J6 intern `(op, sorted flat)`.

`cofactor(u, x, b)`: substitute x := b in the literals, rebuild every and/or node with
`junction` (memoised on (u, x, b)). `forget(u, x) = junction(or, {cofactor(u,x,0), cofactor(u,x,1)})`.
Run: `root = cnf(F)`; for x in order: `root = forget(root, x)`; answer `root == 1`.

Three elementary facts (each by inspection of the code, used below):

- F1 `junction(op, C)` depends only on `op` and the SET C.
- F2 (idempotence) every interned node (op, S) satisfies: no child of kind op, no constant
  child, no complementary literal pair, no J3-absorbable child, |S| ≥ 2, and for op = or
  K = ∅. Hence `junction(op, S)` returns that same node.
- F3 `cofactor(u, x, b) = u` whenever x does not occur below u (induction, using F2).

Semantics [LEAN, other worker: `formal/L_alg001_projection.lean`]: after forgetting a set E
the root computes ∃E. F. The Lean file proves the abstract operations, not the Python.

Structural reading (informal, explains everything below). If the root is `and(S)` and x is
forgotten, the children not mentioning x survive J5 as the common factor K and the children
mentioning x are merged into ONE new node `or(and(S_x|0), and(S_x|1))`. So the candidate is
*bucket elimination*; a bucket function is stored as a nested Shannon expansion over the
variables eliminated inside it, and two such expansions are identified only when they are
syntactically equal as sets of sets. J3 can fire in one branch and not in the other, which
is what makes the stored scopes larger than the bucket-elimination scopes (Section 1).

--------------------------------------------------------------------------------------------
## 1. Theorem A: exponential allocation at induced width 2   [PROVED-PAPER + CHECKED-FINITE]

For k ≥ 1 let W_k be the CNF over v, a, b, p_1..p_k, q_1..q_k with the k + 2 clauses

    c1 = (¬v ∨ a),   c2 = (v ∨ b),   d_i = (a ∨ p_i ∨ q_i)   (1 ≤ i ≤ k),

and let π = (v, p_1, …, p_k, q_1, …, q_k, a, b).

**Theorem A.**
(i) W_k is satisfiable, its primal graph has treewidth 2, and the induced width of π is 2
    (so bucket elimination along π only ever builds functions of ≤ 2 variables: O(k) work).
(ii) Run the unchanged `residual_dag` along π. For every 0 ≤ j ≤ k−1, after forgetting
    v, p_1, …, p_j the root is an or-node with exactly 2^j + 1 children:

        lit(a)   and   A^j_T = and( {lit(b)} ∪ {e_i : i ∈ T} ∪ {d_i : j < i ≤ k} ),  T ⊆ [j],

    where e_i = or(lit a, lit q_i); these 2^j and-nodes are pairwise distinct.
(iii) Consequently at least 2^k − 1 distinct nodes are allocated, i.e. 2^{Ω(N / log N)} for
    encoded input length N = Θ(k log k).

*Proof.* (i) a = b = 1 satisfies W_k. The primal graph is the path b–v–a with k triangles
{a, p_i, q_i} glued at a: treewidth 2. Along π: v has neighbours {a, b} (fill edge ab),
p_i has neighbours {a, q_i}, then q_i has neighbour {a}, then a has {b}. Width 2.

(ii) `cnf` gives root_0 = and(c1, c2, d_1..d_k) (no J3: all children are or-nodes whose
children are literals). Forget v. Branch v=0: c1 ↦ 1 (dropped), c2 ↦ lit b, d_i unchanged (F3);
J3 does not fire because lit b is not a child of any d_i; result A^0_∅ = and(b, d_1..d_k).
Branch v=1: c1 ↦ lit a, c2 ↦ 1; now every d_i has the child lit a, so J3 deletes all of them
and J4 returns lit a. The top-level `junction(or, {A^0_∅, lit a})`: J3 does not fire (lit a is
not a child of A^0_∅), K = fs(A^0_∅) ∩ {lit a} = ∅, so R_0 = or(A^0_∅, lit a): Claim(0).

Step j → j+1 ≤ k−1. By F3, cofactoring by p_{j+1} changes only d_{j+1}:
d_{j+1}|0 = e_{j+1} and d_{j+1}|1 = 1. Hence, with no J3 (the only literal child is lit b, which
is not a child of any e_i or d_i) and at least two children (j+1 ≤ k−1 keeps d_k):

    cofactor(A^j_T, p_{j+1}, 0) = A^{j+1}_{T ∪ {j+1}},     cofactor(A^j_T, p_{j+1}, 1) = A^{j+1}_T.

Each cofactor of the root is `junction(or, {lit a} ∪ {and-nodes})`: J3 does not fire (lit a is
not a child of any and-node, no and-node is a child of another), and K ⊆ {lit a} ∩ fs(A) = ∅.
The final `junction(or, {O_0, O_1})` flattens both or-nodes (J1) into
{lit a} ∪ {A^{j+1}_{T'} : T' ⊆ [j+1]}; J3 and J5 are inert for the same reasons. The e_i are
distinct nodes for distinct i, so distinct T' give distinct child sets, hence distinct nodes:
Claim(j+1).

(iii) A^{j+1}_{T'} contains d_{j+2..k} but not d_{j+1}, so nodes of different levels differ:
Σ_{j=0}^{k-1} 2^j = 2^k − 1 distinct and-nodes are allocated. ∎

Machine checks.
- `verify_theoremA_invariant.py`: Claim(j) checked as an equality of child-id SETS against
  independently rebuilt predicted nodes, for all 0 ≤ j ≤ k−1, k = 1..12.  [CHECKED-FINITE]
- `width2_counterexample.py`: total allocated nodes = 2^(k+1) + 7k + 7 exactly for k = 1..14
  along π (32873 at k = 14) versus 6k + 10 along (p_1..p_k, q_1..q_k, v, a, b).  [CHECKED-FINITE]

**Corollary A.** No bound of the form poly(N) · 2^{O(w(π))} holds for the candidate, where
w(π) is the induced width of the order actually used: order-for-order it can be exponentially
slower than textbook bucket elimination. (This does not say every order is bad on W_k.)

Why it happens. After the first split the root is `or(and(b, d_1..d_k), a)`; the clauses d_i
are *inside* an or-alternative although bucket elimination would leave them alone (J3 fired
only in the branch v = 1). Each later p_i is "pure in context", but J1 flattens the two
cofactor or-nodes into one and J5 only extracts factors common to ALL alternatives, so
`or(and(X), and(X ∪ Y))` is never collapsed and the alternatives double.

--------------------------------------------------------------------------------------------
## 2. Repair R1 (miniscoping) and what it does not repair

`../repairs/miniscope_dag.py` (a subclass; original untouched) replaces `forget` by the exact
identities ∃x.(A ∨ B) = ∃x.A ∨ ∃x.B, ∃x.(A ∧ B) = A ∧ ∃x.B (x not in A), ∃x.lit(x) = 1, and
uses Shannon expansion only for the conjuncts that mention x.
- Exactness: 29,184 stage-by-stage assignment checks on 400 random CNFs (n ≤ 7) pass. [CHECKED-FINITE]
- W_k along π: 4k + 10 nodes (66 at k = 14, down from 32873); G_k: 6k + 6.          [CHECKED-FINITE]
- PHP (both grid orders), random 3-CNF at 4.26, 3-XOR with m = n: allocation changes by small
  constant factors only; the growth ratios are unchanged (`../repairs/compare_r0_r1.json`). [EMPIRICAL]
- A regression introduced by R1 (`../theory/tseitin_fragility.py`): add to a Tseitin formula on a
  random cubic graph one REDUNDANT clause per vertex (an existing clause weakened by a far
  literal, so the Boolean function is unchanged). R0 is unaffected (1366 vs 1252 nodes at 48
  edges) because it cofactors the whole conjunction and the weakened clause collapses back to
  an existing set element; R1 isolates the dependent conjuncts, loses that coincidence and
  with it the parity collapse of Section 3: 17,428 nodes at 48 edges, 12,251 at 60.   [EMPIRICAL]
- Repair R1b (`../repairs/miniscope_dag_b.py`, 26,976 exactness checks pass): distribute ∃ over
  or, recurse when exactly ONE conjunct mentions x, otherwise do exactly what R0 does.
  W_k: 80 nodes at k = 14; G_k: 90; redundant Tseitin: identical to R0 (1366 at 48 edges,
  2325 at 60); PHP and random 3-CNF: same growth as R0 (`../repairs/compare_three.json`). [CHECKED-FINITE/EMPIRICAL]

So Theorem A exposes a repairable normal-form defect (R1b is the repair we recommend if the
syntactic candidate is kept), while the PHP / 3-CNF / XOR growth has a different cause:
syntactic identity does not see semantic equality of bucket functions. The R1 regression is
a warning about the whole approach: each syntactic rewrite helps one family and can destroy
an accidental collapse in another, which is the practical argument for a SEMANTIC canonical
form (Section 5).

--------------------------------------------------------------------------------------------
## 3. Tseitin formulas: why the candidate looked so good on parity      [EMPIRICAL + mechanism]

Observation: on Tseitin formulas (variables = edges of a graph G, one parity constraint per
vertex) the unchanged candidate allocates a polynomial-looking number of nodes under every
order tried, including random cubic expanders, on which resolution-based solvers need
exponential size [LITERATURE: Urquhart 1987]. Numbers: see `../dag_analysis/REPORT.md` (E1).

Mechanism (not a proof for the actual normaliser). For a vertex with remaining edge set S the
clause set of "⊕S = c" restricted by x := 1 equals the clause set of "⊕(S∖x) = c+1" and by
x := 0 that of "⊕(S∖x) = c": a vertex's residual depends only on (assigned edges, parity).
When an edge e = {s,t} is forgotten the two endpoint components A ∋ s, B ∋ t merge into
or( and(K_A|e=0, K_B|e=0), and(K_A|e=1, K_B|e=1) ). Because or-children are a SET (F1), the
branch pair {(p_A, p_B), (p_A+1, p_B+1)} depends only on p_A + p_B: by induction a cofactor of
a merged component depends only on (component, set of assigned boundary edges, TOTAL parity).
Assigned sets form a chain in elimination order, so O(n) cofactors per historical component
and O(n^2) merge nodes overall (times 2^d for the clause sets of degree-d vertices).
What is missing for a proof: J3 lets a unit literal produced by one component delete clauses
of another, so node identities are not purely local; the argument above must be redone with
that extra state. We therefore label the polynomial behaviour EMPIRICAL.

The mechanism needs every variable to occur in exactly two parity constraints. With three or
more occurrences a merged bucket function is an affine space of codimension > 1 whose cofactors
are distinct cosets, and the same candidate grows exponentially (E2 in the report).

--------------------------------------------------------------------------------------------
## 4. The paradigm's missing lemma is equivalent to the target        [PROVED-PAPER]

Fix the generic scheme: a *normaliser* is a map 𝒩 on and/or-DAGs over literals with 𝒩(D) ≡ D.
ELIM_𝒩(F): D_0 = 𝒩(dag(F)); D_i = 𝒩( or(D_{i−1}|x_i=0, D_{i−1}|x_i=1) ) for i = 1..n; accept iff
the variable-free D_n evaluates to 1. (`residual_dag` is ELIM with the syntactic 𝒩 of
Section 0; CFPE in Section 5 is ELIM with 𝒩 = reduced ordered BDD plus a different schedule.)

**Normalisation Lemma NL(𝒩, p):** 𝒩 is computable in time p(|D|), and for every CNF F of
encoded length N and every i, |D_i| ≤ p(N).

**Proposition 4.1.** (∃ 𝒩 ∃ polynomial p: NL(𝒩, p))  ⟺  SAT ∈ P.

*Proof.* (⇒) D_i ≡ ∃x_1..x_i F by induction (exactness of cofactor/or; Lean-checked
semantically in `formal/L_alg001_projection.lean`). There are n ≤ N rounds; a round forms a
DAG of size ≤ 2p(N) + 1 in linear time and normalises it in time p(2p(N) + 1).

(⇐) Assume a machine M decides SAT in time q. Then P = NP, hence Σ₂ᵖ = P.
*Size.* g_i(y) := (∃x_1..x_i F)(y) holds iff the CNF F ∧ ⋀_{j>i} (x_j = y_j) is satisfiable. The
encoding of that CNF has a fixed length N' = O(N) and depends on y only through n − i polarity
bits, so g_i(y) = M(enc_y) has a Boolean circuit of size polynomial in q(N') (tableau
simulation of the machine), and pushing negations to the inputs (dual rail) gives an
and/or-DAG over literals of at most twice that size.
So min-size(g_i) ≤ s(N) for a fixed polynomial s.
*Normaliser.* Let 𝒩(D) be the lexicographically first minimum-size and/or-DAG equivalent to D.
The language {(D, t, w) : some DAG C with |C| ≤ t whose encoding extends w satisfies ∀a C(a)=D(a)}
is in Σ₂ᵖ = P, so 𝒩 is computable in polynomial time by binary search on t and prefix extension.
With this 𝒩, |D_i| ≤ s(N) for all i and every normaliser input has size ≤ 2s(N) + 1. ∎

Reading. The residual-DAG paradigm is *complete* (if P = NP it works with an ideal normaliser)
and *vacuous as a reduction*: every bit of difficulty sits in NL, which is the target itself.

For concrete normalisers NL (as stated, with the index order) is false:
- syntactic 𝒩 of Section 0: Theorem A with the variables of W_k numbered along π gives
  |D_i| ≥ 2^{k−1} + 1.                                                        [PROVED-PAPER]
- 𝒩 = reduced ordered BDD in index order, monolithic schedule: for
  E_k = ⋀_{i≤k} (¬x_i ∨ y_i)(x_i ∨ ¬y_i) with order x_1..x_k, y_1..y_k the 2^k assignments of
  x give pairwise different subfunctions of y, so |D_0| ≥ 2^k.                 [PROVED-PAPER, standard]
Both refutations depend on the order/schedule. Whether a polynomial-time ORDER-CHOOSING rule
rescues either normaliser is not settled by a proof here: for the syntactic 𝒩 every order tried
is exponential on PHP, random 3-CNF and 3-XOR [EMPIRICAL, ../dag_analysis]; for BDD-based
elimination with reordering exponential lower bounds are reported in the literature
[LITERATURE: Itsykson–Knop–Romashchenko–Sokolov 2017; Segerlind 2008; unverified here].

--------------------------------------------------------------------------------------------
## 5. The candidate: islands + CFPE (canonical-factor projective elimination)

Code: `../candidate.py` (engine, written by a subagent to the lead's specification, reviewed and
integrated by the lead), `../layers.py` (islands). Numbers: `../experiments/`.

Pipeline of `solve(nvars, clauses, budget)`:
 A. Island stage (`layers.island_stage`): normalise, unit propagation, connected components;
    a component that is Horn / dual-Horn, 2-CNF, or a read-twice cardinality system
    (Section 6) is decided exactly; UNSAT of any component ends the run.
 B. Affine stage on the remaining clauses: detection of complete XOR clause groups (width ≤ 6),
    Gaussian elimination over GF(2); 0 = 1 → UNSAT; rows of weight ≤ 2 are substituted
    (forced values, literal equivalences); variables occurring only in XOR rows are projected
    out exactly by dropping the echelon rows that have them as pivots.
 C. BDD stage: one reduced ordered BDD per remaining clause and parity row; bucket
    elimination B_v = ∧{factors mentioning v}, new factor = ∃v.B_v; a FALSE BDD → UNSAT.
 D. Witness: reverse elimination order through the stored B_v, undo stage B, add stage A
    values; the assignment is VERIFIED against the original clauses, otherwise status ERROR.
 Budget: every primitive calls `budget.tick`; exhaustion returns UNKNOWN, never a guess.

**Invariant (exact projection).** After stage A the input is satisfiable iff the residual is,
and models translate back. During B and C, for every assignment a of the retained variables,
[all current rows and factors hold at a] iff a extends to a model of the residual. Each step is
one of the identities of `../lean/L_alg001_fable_engine.lean` [LEAN, semantic level]:
`forget_and_of_independent` (bucket step), `forget_defined` (unit / equivalence substitution),
`forget_definition` (dropping an echelon row whose pivot occurs nowhere else), and the engine
theorem (any exact representation with any semantics-preserving normaliser decides SAT). The
BDD operations themselves (apply, exists, canonicity) are standard and are tested, not proved.

**Correctness of the answers.**
- SAT is returned only with an assignment that satisfies every input clause (checked at the end).
- UNSAT is returned only on: an empty clause; a unit-propagation conflict; an island certificate
  (Horn forward chaining, 2-SAT SCC, verified Tutte–Berge barrier); a row 0 = 1 (every row is a
  GF(2) combination of constraints implied by the input); or a FALSE BDD (by the invariant).
- Completeness: with unlimited budget stage C always terminates with a constant.
These are argued on paper and tested; the Python is not formally verified.     [PROVED-PAPER + CHECKED-FINITE]

**Proved polynomial classes (restricted results).** Let N be the encoded input length.
 (0) Stage A overhead on any input: O(N log N) ticks (one sort; propagation with counters).
 (1) Horn and dual-Horn components: O(N) ticks.  (2) 2-CNF components: O(N) ticks.
 (3) Read-twice cardinality components: O(N³) ticks (Theorem M).
 (4) Formulas whose clauses are complete XOR groups of width ≤ 6: Gaussian elimination,
     O(N²) row operations on rows of N bits, i.e. O(N³) bit operations.
 (5) Bounded width: if the elimination order used in stage C has induced width w on the factor
     scopes, every BDD has support ≤ w + 1 and hence at most 2^{w+1} + 1 nodes; each apply or
     exists costs at most (2^{w+1} + 1)² cache misses and there are at most m + 2n of them, so
     stage C costs O((m + n) · 4^{w}) ticks: polynomial whenever w = O(log N).
     The shipped min-degree rule attains w ≤ 2 whenever the primal graph H of the factor scopes
     ENTERING stage C has treewidth ≤ 2: such a graph has a vertex v of degree ≤ 2, the new
     factor's support lies in N_H(v), so the next graph is a subgraph of a minor of H and again
     has treewidth ≤ 2. (Stage B can identify variables, so this is a statement about the
     residual, not about the input.) For larger treewidth no guarantee on the order is claimed.
     (The bound assumes the node cap is not reached; the cap is a constant of the shipped code.)
None of (1)–(5) is new mathematics; they are the classical tractable islands, each wired in as an
exact layer with its own cost bound.

**No general bound.** Outside these classes nothing polynomial is proved, and Section 4 explains
why nothing short of the target itself could be: the number of BDD nodes is a function of the
projected Boolean functions and the orders. Measured growth and the most damaging family are in
`../experiments/CANDIDATE_REPORT.md` and summarised in `../findings.txt`.              [EMPIRICAL]

**Cost model.** A tick is O(1) word-RAM operations on indices of O(log(nodes + N)) bits (unique
table and operation caches are hash tables: expected O(1), not worst case); GF(2) row
operations are charged per 64-bit word. `operations.bit_cost_upper` = ticks × ⌈log₂ nodes⌉.
A Turing-machine bound would add the usual polynomial overhead for random access; none is
claimed.

--------------------------------------------------------------------------------------------
## 6. A polynomial island with checkable certificates: read-twice degree systems  [PROVED-PAPER + LEAN(d) + CHECKED-FINITE]

(Runs as part of stage A, before the engine of Section 5. Code: `../layers.py`, tests:
`../tests/test_layers.py`, `../tests/test_island_stage.py`.)

Definition. A CNF component F is a *read-twice degree system* if for some choice of a "normal"
literal λ(x) ∈ {x, ¬x} per variable there is a family of variable sets (groups), each of type
L, U, X or P, such that every variable lies in one or two groups and, writing clauses in
normal literals, the clause set of F is exactly the union of
    L, X :  the clause ⋁_{x∈g} λ(x)                         ("at least one")
    U, X :  the pairs (¬λ(x) ∨ ¬λ(y)), x ≠ y ∈ g            ("at most one")
    P    :  the 2^{|g|−1} clauses over g expressing ⊕_{x∈g} λ(x) = t_g   (|g| ≥ 3)
So X = "exactly one" and P = "odd / even number". Pigeonhole (pigeons L, holes U), functional
pigeonhole, bipartite "pigeon i may use hole j" systems, perfect matching on a graph and domino
tilings (vertices X, edges = variables), Tseitin formulas (vertices P), and arbitrary mixtures
of these are of this form, under any renaming of variables and any flipping of polarities.

Recognition (sound, not complete). Complete parity clause groups of width ≥ 3 become P groups.
Among the other clauses, wide clauses fix λ and binary clauses propagate it (both literals
normal or both anti-normal); a positive clause whose variables are pairwise in conflict is an
X group, any other positive clause an L group; the remaining conflict pairs must split into
cliques (U groups). The layer then REGENERATES the clause set from the groups and continues
only if it equals the input clause set, so a wrong recognition cannot produce an answer.

**Theorem M.** Let H be the multigraph whose vertices are the groups plus one private vertex
per variable lying in a single group, and whose edges are the variables.
(a) F is satisfiable iff H has an edge set T (the variables whose normal literal is true) with
    deg_T(g) ≥ 1 for L and X, deg_T(g) ≤ 1 for U and X, and deg_T(g) ≡ t_g (mod 2) for P.
(b) Build the simple graph G: one vertex per U or X group (*required* iff X); for an L group g
    one required *copy* (g, x) per member and |g| − 1 optional *dummies* adjacent to all copies
    of g; for a P group g one required copy per member, all copies pairwise adjacent, plus one
    required *helper* adjacent to all copies iff |g| − t_g is odd; one optional vertex per
    private vertex; each variable becomes an edge between the representatives of its two
    endpoints (the copy (g, x) at an L or P group; parallel edges between two capacity-one
    vertices are merged). Then T as in (a) exists iff G has a matching covering all required
    vertices.
(c) Let G² be two disjoint copies of G plus an edge o–o′ for every optional vertex o. G has a
    matching covering the required vertices iff G² has a perfect matching.
(d) If some A ⊆ V(G²) leaves more than |A| odd components in G² − A, then G² has no perfect
    matching, hence F is unsatisfiable. [LEAN: `../lean/L_alg001_fable_matching.lean`, from
    Mathlib's `SimpleGraph.tutte`, together with the converse that such an A always exists.
    The Lean file says nothing about the Python code or about (a)–(c).]
(e) |V(G²)| ≤ 2(#groups + 5n) for n variables; Edmonds' algorithm and the barrier computation
    use O(|V(G²)|³) = O(N³) elementary steps on O(log N)-bit integers. (Parity groups have
    |g| ≤ log₂ N + 1 because their clause encoding has 2^{|g|−1} clauses, so their cliques add
    O(N log N) edges.)

*Proof.* (a) Unfold the definition.
(b) (⇒) Use the edges of T: a capacity-one vertex meets ≤ 1 of them, a copy only its own
variable, parallel variables cannot both be in T. An L group with j ≥ 1 edges of T has
|g| − j ≤ |g| − 1 free copies: match them to distinct dummies. In a P group the number r of
free copies satisfies r ≡ |g| − t_g (mod 2); if a helper exists r is odd, so match the helper
to one free copy; the remaining free copies are even in number and pairwise adjacent. X
vertices have degree 1. So every required vertex is covered. (⇐) Let T be the variables whose
edge is in the matching. Capacity-one vertices give deg ≤ 1; an X vertex is covered and all
its edges are variables; the |g| copies of an L group are all covered but only |g| − 1 dummies
exist, so some copy is matched through its variable. In a P group every copy and the helper
(if any) are covered; those not matched through a variable are matched among themselves, so
their number |g| − deg_T(g) + [helper] is even, i.e. deg_T(g) ≡ |g| − [helper] ≡ t_g.
(c) (⇒) Use the matching in both copies; the uncovered vertices are optional and the same in
both copies: join each to its twin. (⇐) Required vertices have no twin edge, so a perfect
matching restricted to the first copy covers every required vertex.
(d) Each odd component of G² − A has a vertex matched outside it, necessarily into A, and
distinct components use distinct vertices of A.
(e) Copies and dummies of L groups number at most 2·Σ|g| ≤ 4n, copies and helpers of P groups at
most 2n + #groups, private vertices at most n. ∎

What is trusted where. A SAT answer is checked against the clauses. An UNSAT answer is issued
only if a barrier A passes `verify_barrier`, a 15-line component count that does not use the
matching code. A is found in three attempts: the empty set (an odd component — for a Tseitin
formula this is literally the parity argument), then the Gallai–Edmonds set computed from the
failed alternating searches of the exposed vertices, then the same set computed by deleting
each vertex in turn; if none verifies the layer declines to answer. So UNSAT rests on (a)–(d),
on the regeneration check and on that count — not on the blossom implementation.

Checks [CHECKED-FINITE]: maximum matching size, equality of the fast and slow Gallai–Edmonds
sets and the Tutte–Berge equality against brute force on 43,882 random graphs (≤ 9 vertices);
the layers of the FINAL code against brute-force satisfiability in one campaign of four seeds
(the degree layer answered 25,041 components, 1,692 of them UNSAT; the Horn layer 25,874; the
2-SAT layer 19,866), all correct with verified models; `island_stage` against brute force on
35,276 formulas (11,885 refuted by the stage, the rest equisatisfiable with their residual and
the merged model correct). Earlier versions of the layer passed about 40,000 further cases.
Structured instances (`../experiments_lead_layers_families.json`), ticks: PHP(h+1,h) 1.4e3,
1.0e4, 3.7e4, 9.4e4, 2.0e5 for h = 4, 8, 12, 16, 20 (about N^1.0); hidden Hall violator with 800
variables 8.8e4; perfect matching on K21 2.6e4; mutilated 16×16 board 1.7e4; Tseitin on a
random cubic graph with 256 vertices 1.9e4; "matching with every third vertex only odd" on K17
6.0e3. The whole suite runs in 3 s. Growth figures are [EMPIRICAL]; the proved bound is O(N³).

Comparison [EMPIRICAL, 30 s limit, `../review_lead/scale_others_hard.json`]: the three other
candidates in the workspace (hydrogen, neon, native hybrid) give no wrong answer on these
families, and all three return UNKNOWN on perfect matching in K13 (78 variables); two of three
return UNKNOWN on the mutilated 8×8 board and on hidden Hall violators with 120 variables.

Scope. This is a known tractable class — degree-constrained subgraphs with degree sets without
gaps of length two [LITERATURE: Edmonds 1965; Tutte 1947; Lovász 1972; Cornuéjols 1988] —
wired in as one exact layer. It unifies the textbook hard examples for resolution-like search
(pigeonhole, Tseitin, matching principles), which is why it is useful as a layer, and it says
nothing about formulas outside the class: it is not progress on SAT in general.

--------------------------------------------------------------------------------------------
## 7. What is Lean-checked                                                        [LEAN]

All files are in `../lean/`, compile with `lake env lean <file>` in the pinned repository
(Lean 4.36.0 + Mathlib), contain no `sorry`, no new axiom, no `native_decide`, no `unsafe`, and
their theorems depend only on `propext`, `Classical.choice`, `Quot.sound` (the functions named
"axiom-free" below depend on none).

`L_alg001_fable_decider.lean` (subagent C to the lead's specification; namespace
`PEqualNP.Outside.L_alg001_fable`):
- `budgetSearch_isSome`: the foundation's fuel-bounded search answers whenever
  fuel ≥ total number of literal occurrences; `decideSat_correct : Satisfiable φ ↔ decideSat φ = true`.
- `decodeCNF_encodeCNF : decodeCNF (encodeCNF φ) = some φ` for the project's binary encoding.
- `satRun : List Bool → Bool`, an explicit program (`#print axioms satRun`: none), with
  `satRun_correct : x ∈ SAT ↔ satRun x = true` for EVERY bit string, malformed and non-canonical
  ones included; `satDecider : CorrectBitDecider`. This inhabits an interface the formal track
  had listed as open. It is decidability by exhaustive search, not a complexity result.
- `run_eq_satRun`: every correct bit decider is this same function, so a "degree bound for the
  candidate" is a statement about the function, not about any particular algorithm.
- `searchCalls_le : searchCalls fuel φ ≤ 2^(fuel+1)` and `exponential_family`: on an explicit
  satisfiable family of at most n(4n+10) input bits this procedure makes exactly 2^(n+1) − 1
  calls. (A lower bound for THIS procedure only.)
- `sat_mem_P_of_degreeBound` and
  `sat_mem_P_iff_degreeBound : SAT ∈ P ↔ ∃ d, Nonempty (DegreeBound satDecider d)`:
  the missing lemma, in the project's own definitions of P and of Turing-machine time, is
  equivalent to SAT ∈ P. Nothing here constructs a `DegreeBound`.

`L_alg001_fable_engine.lean` (lead): for ANY representation type with a denotation, an exact
compile, an exact forget and an arbitrary semantics-preserving normaliser, forgetting all
occurring variables decides SAT; plus `forget_or`, `forget_and_of_independent`,
`forget_defined`, `forget_definition`. This is the semantic half of Proposition 4.1 (⇒) and of
the invariant of Section 5; it contains no size or time statement.

`L_alg001_fable_matching.lean` (lead): a vertex set whose removal leaves more odd components
than its size excludes a perfect matching, and conversely such a set exists whenever there is
no perfect matching (from Mathlib's `SimpleGraph.tutte`). This is Theorem M (d).

Not Lean-checked: Theorem A, Proposition 4.1 (⇐) and the complexity half of (⇒), Theorem M
(a)–(c) and (e), every statement about Python code, and every running-time statement.
