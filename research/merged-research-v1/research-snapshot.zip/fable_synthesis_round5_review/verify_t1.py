import itertools,json,time
from pathlib import Path

def value(cols,a):
 result=0
 for i,col in enumerate(cols):
  if (a>>i)&1: result ^= col
 return result

def span(cols): return {value(cols,a) for a in range(1<<len(cols))}

def rank(cols): return len(span(cols)).bit_length()-1

started=time.time();checks=0;matrices=0
for m,n in [(1,1),(1,2),(1,3),(1,4),(2,1),(2,2),(2,3),(2,4),(3,1),(3,2),(3,3)]:
 for cols in itertools.product(range(1<<m),repeat=n):
  matrices+=1;fullspan=span(cols);rA=rank(cols)
  for cut in range(1<<n):
   B=[cols[i] for i in range(n) if (cut>>i)&1]
   R=[cols[i] for i in range(n) if not ((cut>>i)&1)]
   rB,rR=rank(B),rank(R)
   for b in fullspan:
    nonempty=[]
    for a in range(1<<len(B)):
     residual=tuple(y for y in range(1<<len(R)) if value(R,y)==(b^value(B,a)))
     if residual:nonempty.append(residual)
    expected_feasible=1<<(len(B)-rA+rR)
    expected_distinct=1<<(rB+rR-rA)
    assert len(nonempty)==expected_feasible,(m,n,cols,cut,b)
    assert len(set(nonempty))==expected_distinct,(m,n,cols,cut,b)
    checks+=1
out={'scope':'Finite exhaustive corroboration, not a proof of the general T1 theorem','matrices':matrices,'matrix_cut_consistent_rhs_checks':checks,'mismatches':0,'shapes':'all 1<=m<=3,1<=n<=3 plus (1,4),(2,4)','elapsed_seconds':time.time()-started}
Path(__file__).with_name('t1-finite-receipt.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
