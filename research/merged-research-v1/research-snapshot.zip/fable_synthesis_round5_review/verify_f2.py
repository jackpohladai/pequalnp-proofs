import itertools,json
from pathlib import Path
bits=lambda n:list(itertools.product((0,1),repeat=n))
def f2(a):
 x1,x2,y1,y2=a
 return (x1 or y1 or not y2) and (not x1 or not y1 or y2) and (x2 or y2 or not y1) and (not x2 or not y2 or y1)
models=[a for a in bits(4) if f2(a)]
affine=[]
for c in bits(5):
 if all((c[0]+sum(x*y for x,y in zip(c[1:],a)))%2==0 for a in models):affine.append(c)
residual={''.join(map(str,a)):[y for y in bits(2) if f2(a+y)] for a in bits(2)}
assert len(models)==10
assert affine==[(0,0,0,0,0)]
assert len({tuple(v) for v in residual.values()})==3
assert all(residual.values())
out={'source':'fable_synthesis_round5/proposal.txt section6','models':models,'model_count':len(models),'all_32_affine_equations_tested':True,'only_vanishing_affine_coefficient_vector':affine,'residual_solution_sets':residual,'distinct_residual_model_sets':3,'all_four_prefixes_satisfiable':True,'important_scope':'Three different residual functions before 2SAT terminal dispatch, not three memoized full K1 solver states or a runtime lower bound.'}
Path(__file__).with_name('f2-receipt.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
