import Init
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace FableRound5Audit

def F2 (x1 x2 y1 y2 : Bool) : Bool :=
  (x1 || y1 || !y2) && (!x1 || !y1 || y2) &&
  (x2 || y2 || !y1) && (!x2 || !y2 || y1)

theorem F2_no_affine : ∀ c0 c1 c2 c3 c4 : Bool,
    (∀ x1 x2 y1 y2 : Bool, F2 x1 x2 y1 y2 = true →
      xor c0 (xor (c1 && x1) (xor (c2 && x2)
        (xor (c3 && y1) (c4 && y2)))) = false) →
    c0 = false ∧ c1 = false ∧ c2 = false ∧ c3 = false ∧ c4 = false := by
  decide

theorem F2_prefix00_eq_prefix11 : ∀ y1 y2 : Bool,
    F2 false false y1 y2 = F2 true true y1 y2 := by decide

theorem F2_prefix00_ne_prefix01 :
    (fun y1 y2 => F2 false false y1 y2) ≠
    (fun y1 y2 => F2 false true y1 y2) := by
  intro h
  have h' := congrFun (congrFun h true) false
  cases h'

theorem F2_prefix00_ne_prefix10 :
    (fun y1 y2 => F2 false false y1 y2) ≠
    (fun y1 y2 => F2 true false y1 y2) := by
  intro h
  have h' := congrFun (congrFun h false) true
  cases h'

theorem F2_prefix01_ne_prefix10 :
    (fun y1 y2 => F2 false true y1 y2) ≠
    (fun y1 y2 => F2 true false y1 y2) := by
  intro h
  have h' := congrFun (congrFun h true) false
  cases h'

theorem F2_every_prefix_satisfiable : ∀ x1 x2 : Bool,
    ∃ y1 y2 : Bool, F2 x1 x2 y1 y2 = true := by decide

#print axioms F2_no_affine
#print axioms F2_prefix00_eq_prefix11
#print axioms F2_prefix00_ne_prefix01
#print axioms F2_prefix00_ne_prefix10
#print axioms F2_prefix01_ne_prefix10
#print axioms F2_every_prefix_satisfiable
end FableRound5Audit
