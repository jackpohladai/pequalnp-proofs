"""Independent executable mirror and exhaustive oracle; imports no candidate code.

Lean's actual executable function is separately exercised in AlgorithmExamples.lean.
This mirror is tested against independent exhaustive SAT enumeration.
"""
import hashlib
import itertools
import json
from pathlib import Path


def clause_value(clause, assignment):
    return any(bool((assignment >> (abs(lit) - 1)) & 1) == (lit > 0)
               for lit in clause)


def formula_value(formula, assignment):
    return all(clause_value(c, assignment) for c in formula)


def solve(n, formula):
    true_set = set(range(n))
    trace = [tuple(sorted(true_set))]
    for fuel in range(n, -1, -1):
        assignment = sum(1 << x for x in true_set)
        if fuel == 0:
            return (assignment if formula_value(formula, assignment) else None), trace
        bad = next((c for c in formula if not clause_value(c, assignment)), None)
        if bad is None:
            return assignment, trace
        negative = next((lit for lit in bad if lit < 0), None)
        if negative is None:
            return None, trace
        var = -negative - 1
        assert var in true_set
        true_set.remove(var)
        trace.append(tuple(sorted(true_set)))
    raise AssertionError('unreachable')


def clauses(n):
    return [tuple(sign * (i + 1) for i, sign in enumerate(signs) if sign)
            for signs in itertools.product((0, 1, -1), repeat=n)
            if sum(sign == -1 for sign in signs) <= 1]


def solve_sparse(formula):
    support = {abs(lit) - 1 for clause in formula for lit in clause}
    true_set = set(support)
    flips = 0
    for fuel in range(len(support), -1, -1):
        bad = next((clause for clause in formula if not any(
            ((abs(lit) - 1) in true_set) == (lit > 0) for lit in clause)), None)
        if bad is None:
            return true_set, support, flips
        if fuel == 0:
            return None, support, flips
        negative = next((lit for lit in bad if lit < 0), None)
        if negative is None:
            return None, support, flips
        var = -negative - 1
        assert var in true_set
        true_set.remove(var)
        flips += 1
    raise AssertionError('unreachable')


def verify(n, formula):
    models = [a for a in range(1 << n) if formula_value(formula, a)]
    result, trace = solve(n, formula)
    sparse, support, sparse_flips = solve_sparse(formula)
    expanded = None if sparse is None else sum(
        1 << x for x in range(n) if x in sparse or x not in support)
    assert expanded == result
    assert sparse_flips <= len(support)
    assert (result is not None) == bool(models)
    if models:
        assert result in models
        assert all((a & result) == a for a in models)
    assert len(trace) - 1 <= n
    for index, state in enumerate(trace):
        mask = sum(1 << x for x in state)
        assert all((a & mask) == a for a in models)
        assert len(state) == n - index
    return bool(models), len(trace) - 1, len(trace) * len(models)


def main():
    formulas = satisfiable = flips = invariant_checks = 0
    max_flips = 0
    for n in range(4):
        options = clauses(n)
        sizes = range(len(options) + 1) if n <= 2 else range(5)
        for size in sizes:
            for formula in itertools.combinations(options, size):
                sat, count, checks = verify(n, formula)
                formulas += 1
                satisfiable += sat
                flips += count
                invariant_checks += checks
                max_flips = max(max_flips, count)
    # Explicit ordering, repetition, tautology, and sparse-identifier cases.
    edge_cases = [
        (3, ((-1,), (1, -2), (2, -3))),
        (3, ((-1,), (1, -2), (2, -3), (3,))),
        (3, ((1, 1, -2), (-1,), (2, -3))),
        (3, ((1, -1), (-2,), (2, 3, 3))),
        (6, ((-6,), (6, 1))),
        (0, ((),)),
        (0, ()),
    ]
    for n, formula in edge_cases:
        verify(n, formula)
    # The syntax premise is essential: outside dual-Horn, this solver can fail.
    nondual = ((-1, -2), (1,))
    assert solve(2, nondual)[0] is None
    assert formula_value(nondual, 1)
    sparse, support, count = solve_sparse(((-1000000001,), (1000000001, 8)))
    assert sparse == {7} and support == {7, 1000000000} and count == 1
    print(json.dumps({
        'status': 'passed', 'verifier_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'dual_horn_formulas': formulas, 'satisfiable_formulas': satisfiable,
        'total_flip_steps': flips, 'max_flip_steps_on_three_variables': max_flips,
        'model_domination_checks_along_traces': invariant_checks,
        'additional_edge_cases': len(edge_cases), 'nondual_failure_checked': True,
        'sparse_and_range_solvers_agree_on_all_formulas': True,
        'billion_index_sparse_case_passed': True,
        'scope': 'Python mirror versus exhaustive oracle; Lean execution examples separately compiled',
        'candidate_executed': False, 'bit_runtime_proved': False, 'general_sat_claim': False
    }))


if __name__ == '__main__':
    main()
