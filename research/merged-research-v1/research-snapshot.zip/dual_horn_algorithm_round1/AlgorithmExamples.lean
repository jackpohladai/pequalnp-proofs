import DualHornAlgorithm

namespace PEqualNP.Outside.DualHornAlgorithm

-- These examples reduce the actual executable Lean function, not a model proxy.
example : solve 0 [] = some ∅ := by decide
example : solve 0 [[]] = none := by decide
example : solve 3 [[(0,false)],[(0,true),(1,false)],[(1,true),(2,false)]] =
    some ∅ := by decide
example : solve 3 [[(0,false)],[(0,true),(1,false)],[(1,true),(2,false)],
    [(2,true)]] = none := by decide
example : solve 3 [[(0,false)],[(1,true),(2,true)]] = some {1,2} := by decide
example : solve 6 [[(5,false)],[(5,true),(0,true)]] = some {0,1,2,3,4} := by decide

#eval (solve 3 [[(0,false)],[(0,true),(1,false)],[(1,true),(2,false)]]).map Finset.card
#eval (solve 3 [[(0,false)],[(0,true),(1,false)],[(1,true),(2,false)],[(2,true)]]).map Finset.card
#eval (solve 3 [[(0,false)],[(1,true),(2,true)]]).map Finset.card
end PEqualNP.Outside.DualHornAlgorithm
