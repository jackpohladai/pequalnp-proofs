import pathlib,sys,json,subprocess,time,datetime,os,signal
base=pathlib.Path.cwd();folder=base/'work/alg001/fable_synthesis_round3';sys.path.insert(0,str(base/'work/alg001/shared_workspace'));import claude_backup,board
hub=pathlib.Path('/Users/jackpohlad/Desktop/AI Math/P vs NP Research Hub');start=time.monotonic();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
cmd=[str(pathlib.Path.home()/'.local/bin/claude'),'-p','--model','claude-fable-5-2','--effort','max','--settings',str(folder/'settings.json'),'--strict-mcp-config','--mcp-config',str(folder/'empty-mcp.json'),'--safe-mode','--no-chrome','--no-session-persistence','--tools','','--output-format','json','--system-prompt','Generate rigorous mathematical research proposals from the supplied brief. Treat unproved claims as conjectures. You have no tools.']
env=claude_backup.sanitized_environment(claude_backup.SUBSCRIPTION);env.update(CLAUDE_CODE_MAX_OUTPUT_TOKENS='32768',CLAUDE_CODE_MAX_RETRIES='0')
board.upsert_job(hub,{'id':'targeted-fable-synthesis-round3','status':'running','started_at':now()})
proc=subprocess.Popen(cmd,cwd=folder,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,start_new_session=True)
(folder/'process.json').write_text(json.dumps({'pid':proc.pid,'started_at':now(),'command_without_prompt':cmd,'timeout_seconds':600,'subscription_only':True},indent=2))
try:out,err=proc.communicate((folder/'task.txt').read_text(),timeout=600);code=proc.returncode
except subprocess.TimeoutExpired:
 os.killpg(proc.pid,signal.SIGTERM)
 try:out,err=proc.communicate(timeout=3)
 except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);out,err=proc.communicate()
 code=124
redact=claude_backup.redactor();out=redact(out.encode()).decode();err=redact(err.encode()).decode();(folder/'response.json').write_text(out);(folder/'stderr.txt').write_text(err)
try:native=json.loads(out)
except ValueError:native={}
success=code==0 and native.get('is_error') is False and bool(native.get('result'))
receipt={'finished_at':now(),'exit_code':code,'success':success,'seconds':time.monotonic()-start,'model_usage':native.get('modelUsage',{}),'usage':native.get('usage',{}),'subtype':native.get('subtype'),'is_error':native.get('is_error'),'fast_mode_state':native.get('fast_mode_state'),'subscription_only':True,'error_summary':str(native.get('result','') if not success else '')[:1200]}
(folder/'receipt.json').write_text(json.dumps(receipt,indent=2))
if success:(folder/'proposal.txt').write_text(native['result'])
board.upsert_job(hub,{'id':'targeted-fable-synthesis-round3','status':'research_draft' if success else 'error','ended_at':now(),'summary':'Fable maximum-effort targeted proposal saved; unreviewed conjectures, not a proof.' if success else 'Targeted Fable assignment could not complete; see local receipt.','metadata_json':{'kind':'research_generation','effort':'max','receipt':str(folder/'receipt.json'),'success':success,'proof_checked':False}})
print(json.dumps(receipt),flush=True)
