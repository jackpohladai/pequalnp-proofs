# Checked component library v2

This is an offline integration of the eight component families recorded in the research checkpoint. It retains 12 importable modules, including the existing `CheckedComposition` bridge to `PEqualNP.Search.CNF.eval` and the checked sparse dual-Horn solver.

## Use the saved library

From the workspace root, load the recorded search path and run the import smoke check.

```sh
checked_lean="$HOME/.elan/toolchains/leanprover--lean4---v4.36.0/bin/lean"
export LEAN_PATH="$(python3 -S -c 'import json; from pathlib import Path; print(json.loads(Path("work/alg001/checked_components_v2/build-receipt.json").read_text())["lean_path"])')"
"$checked_lean" -j 1 -DElab.async=false work/alg001/checked_components_v2/LibrarySmoke.lean
```

Modules are saved under `build/lib/lean`. A consumer can import the required module by name, such as `import CheckedDualHorn` or `import CheckedComposition`. The installed project and pinned package libraries on the recorded `LEAN_PATH` remain dependencies.

`LibrarySmoke.lean` imports all 12 modules, checks representative declarations, and applies `checkedSolve_result_correct` at its actual project CNF and sparse-model types. The outer `none` result means unsupported syntax. `some none` is checked UNSAT within the supported fragment, and `some (some T)` returns a greatest model represented by `T`. The smoke check uses the existing theorems as written. A general SAT decision procedure and a global bit-time bound require separate results.

## Rebuild

```sh
PYTHONDONTWRITEBYTECODE=1 python3 -S work/alg001/checked_components_v2/build.py
```

The builder records the checkpoint and receipt digests, checks each source against its recorded pins, and proceeds in import order. It reuses a v1 binary only when its source, artifact, and local dependency digests agree with the verified v1 manifest and receipt. Other modules are freshly compiled in a temporary directory and copied to the durable build, where the smoke check runs. Pass `--fresh` to recompile all modules. The build uses existing Lean and Mathlib installations.

- [Source manifest](source-manifest.json)
- [Artifact manifest](artifact-manifest.json)
- [Build commands and axiom receipt](build-receipt.json)
