import ParityExtraction
import StalledParity
import RankObstruction
import GuardedHall
import PairedUnion
import GreatestGuard
import DualHorn
import DualHornGreatestGuard
import DualHornAlgorithm
import SparseDualHornAlgorithm
import CheckedDualHorn
import CheckedComposition

open PEqualNP.Search
open PEqualNP.Outside.SparseDualHornAlgorithm

#check ParityExtraction.replace_parity_subcollection
#check PEqualNP.Outside.StalledParity.padded_satisfiable_iff
#check PEqualNP.Outside.RankObstruction.factorization_width_bound
#check PEqualNP.Outside.GuardedHall.guarded_hall_projection
#check PEqualNP.Outside.PairedUnion.certificate_branch
#check PEqualNP.Outside.GreatestGuard.greatest_matching_iff_feasible_extension
#check PEqualNP.Outside.DualHorn.exists_greatest_model
#check PEqualNP.Outside.DualHornGreatestGuard.restricted_extension_iff_matching
#check PEqualNP.Outside.DualHornAlgorithm.solve_correct
#check solveSparse_correct
#check checkedSolve_result_correct
#check PEqualNP.Outside.CheckedComposition.project_parity_replacement

example (formula : CNF) (result : Option (Finset Nat))
    (accepted : checkedSolve formula = some result) :
    PEqualNP.Outside.DualHorn.IsDualHorn formula ∧ Correct (support formula) formula result :=
  checkedSolve_result_correct formula result accepted

#print axioms checkedSolve_result_correct
#print axioms PEqualNP.Outside.CheckedComposition.project_parity_replacement
