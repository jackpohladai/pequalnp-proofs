"""Assemble the checkpoint's hash-verified local modules with pinned, installed Lean."""

import argparse
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import tempfile
import time


HERE = Path(__file__).resolve().parent
ALG = HERE.parent
WORK = ALG.parent
PREVIOUS = ALG / "checked_components"
CHECKPOINT = WORK / "session-checkpoint.json"
LEAN = Path.home() / ".elan/toolchains/leanprover--lean4---v4.36.0/bin/lean"
PROJECT = WORK / "pequalnp-sparse/lean"
VERSION = "version 4.36.0,"
COMMIT = "commit 611c117bfaf7b7ae1cfcf246ce6fba31e8f509e9,"
FAMILIES = (
    "parity_extraction_round1", "stalled_parity_round1", "rank_obstruction_round1",
    "hall_projection_round1", "paired_union_round1", "greatest_guard_round1",
    "dual_horn_round1", "dual_horn_algorithm_round1",
)
MODULES = (
    "ParityExtraction", "StalledParity", "RankObstruction", "GuardedHall", "PairedUnion",
    "GreatestGuard", "DualHorn", "DualHornGreatestGuard", "DualHornAlgorithm",
    "SparseDualHornAlgorithm", "CheckedDualHorn", "CheckedComposition",
)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def write_json(path, record):
    temporary = path.with_suffix(".json.tmp")
    temporary.write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
    temporary.replace(path)


def valid_version(version):
    return isinstance(version, str) and VERSION in version and COMMIT in version


def module_receipt_hash(path, content, name, prior_manifest):
    if path.suffix == ".txt":
        receipt = content.decode("utf-8")
        fingerprint = re.search(rf"^([a-f0-9]{{64}})  {name}\.lean$", receipt, re.MULTILINE)
        if fingerprint and "Lean exit status 0." in receipt and COMMIT in receipt:
            return fingerprint[1]
        raise ValueError(f"Invalid text receipt for {name}")
    receipt = json.loads(content)
    version = receipt.get("lean_version")
    if not valid_version(version) and version != "4.36.0":
        raise ValueError(f"Invalid compiler version for {name}")
    if name == "CheckedComposition":
        if receipt.get("verified") is True and receipt["modules"][name]["exit_code"] == 0:
            return prior_manifest["composition_source_sha256"]
    elif receipt.get("exit_code") == 0:
        if Path(receipt.get("source", "")).name == name + ".lean":
            return receipt["source_sha256"]
        for check in receipt.get("checks", []):
            if check.get("exit_code") != 0:
                continue
            if Path(check.get("source", "")).name == name + ".lean":
                return check["source_sha256"]
            if check.get("module") == name:
                return receipt["sources"][name]["source_sha256"]
    raise ValueError(f"No successful compile in {path} for {name}")


def checkpoint_sources(prior_manifest):
    checkpoint_bytes = CHECKPOINT.read_bytes()
    checkpoint = json.loads(checkpoint_bytes)
    components = {entry["id"]: entry for entry in checkpoint["new_local_lean_components"]}
    pins = {}
    for family in FAMILIES:
        entry = components[family]
        receipt = Path(entry["receipt"]).resolve()
        extra = entry.get("additional_sources", [])
        extra = list(extra.values()) if isinstance(extra, dict) else extra
        for row in [entry, *extra]:
            source = Path(row["source"]).resolve()
            fingerprint = row.get("source_sha256") or row["sha256"]
            if source.stem in pins and pins[source.stem][1] != fingerprint:
                raise ValueError(f"Conflicting checkpoint digests for {source.stem}")
            pins.setdefault(source.stem, (source, fingerprint, receipt))
    bridge_source = PREVIOUS / "CheckedComposition.lean"
    bridge_hash = prior_manifest["composition_source_sha256"]
    bridge = checkpoint.get("checked_component_library", {})
    if bridge.get("source") == str(bridge_source) and bridge.get("source_sha256") != bridge_hash:
        raise ValueError("Checkpoint digest differs for the previous composition bridge")
    pins["CheckedComposition"] = (bridge_source, bridge_hash, PREVIOUS / "build-receipt.json")
    sources, entries = {}, {}
    for name in MODULES:
        source, expected, receipt = pins[name]
        if name == "DualHornAlgorithm":
            receipt = source.with_name("compile-receipt.json")
        content = source.read_bytes()
        receipt_content = receipt.read_bytes()
        if digest(content) != expected or module_receipt_hash(receipt, receipt_content, name, prior_manifest) != expected:
            raise ValueError(f"Checkpoint and compiler receipt must match the bytes of {name}")
        sources[name] = content
        imports = re.findall(rb"^import ([A-Za-z][A-Za-z0-9_.]*)", content, re.MULTILINE)
        entries[name] = {
            "source": str(source.relative_to(ALG)),
            "source_sha256": expected,
            "compiler_receipt": str(receipt.relative_to(ALG)),
            "compiler_receipt_sha256": digest(receipt_content),
            "local_imports": [module.decode() for module in imports if module.decode() in MODULES],
        }
    return sources, entries, digest(checkpoint_bytes)


def project_paths(project, prior_manifest):
    manifest_bytes = (project / "lake-manifest.json").read_bytes()
    manifest = json.loads(manifest_bytes)
    built = project / ".lake/build/lib/lean"
    paths = [built]
    for package in manifest["packages"]:
        library = (project / manifest["packagesDir"] / package["name"] / (package.get("subDir") or "")
                   / ".lake/build/lib/lean")
        if library.is_dir():
            paths.append(library)
    fingerprints = {
        "lake_manifest_sha256": digest(manifest_bytes),
        "project_search_source_sha256": digest((project / "PEqualNP/Defs/Search.lean").read_bytes()),
        "project_search_olean_sha256": digest((built / "PEqualNP/Defs/Search.olean").read_bytes()),
    }
    for key, value in fingerprints.items():
        if prior_manifest["project"].get(key) != value:
            raise ValueError(f"Installed project differs from the checkpoint library at {key}")
    return paths, fingerprints


def lean_run(command, cwd, environment):
    start = time.monotonic()
    try:
        result = subprocess.run(command, cwd=cwd, env=environment, text=True,
                                stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=180)
        exit_code, output = result.returncode, result.stdout
    except subprocess.TimeoutExpired as error:
        exit_code, output = 124, (error.stdout or b"").decode("utf-8", errors="replace")
    return {
        "command": command, "cwd": str(cwd), "exit_code": exit_code, "output": output,
        "elapsed_seconds": round(time.monotonic() - start, 3),
        "verified": exit_code == 0 and "sorryAx" not in output,
    }


def compile_module(name, lean, stages, library, environment):
    artifact = library / (name + ".olean")
    result = lean_run([lean, "-j", "1", "-DElab.async=false", "-R", str(stages),
                       "-o", str(artifact), str(stages / (name + ".lean"))], stages, environment)
    result["verified"] = result["verified"] and artifact.is_file()
    result["mode"] = "fresh_compile"
    if result["verified"]:
        result["artifact_sha256"] = digest(artifact.read_bytes())
    print(f"{name} compiled with exit {result['exit_code']} in {result['elapsed_seconds']}s", flush=True)
    return result


def reuse_module(name, entry, checks, library, prior_receipt, prior_manifest):
    record = prior_receipt["modules"].get(name)
    source = prior_manifest["components"].get(name, {})
    expected_source = (prior_manifest["composition_source_sha256"] if name == "CheckedComposition"
                       else source.get("source_sha256"))
    if (not record or record.get("verified") is not True or record.get("exit_code") != 0
            or "sorryAx" in record["output"] or expected_source != entry["source_sha256"]):
        return None
    if any(checks[dep]["artifact_sha256"] != prior_receipt["modules"][dep]["artifact_sha256"]
           for dep in entry["local_imports"]):
        return None
    artifact = PREVIOUS / "build/lib/lean" / (name + ".olean")
    try:
        content = artifact.read_bytes()
    except OSError:
        return None
    if digest(content) != record["artifact_sha256"]:
        return None
    (library / artifact.name).write_bytes(content)
    print(f"{name} reused from its verified v1 export", flush=True)
    return {
        "mode": "verified_reuse", "verified": True, "artifact_sha256": record["artifact_sha256"],
        "original_command": record["command"], "original_output": record["output"],
        "original_artifact": str(artifact), "original_receipt": str(PREVIOUS / "build-receipt.json"),
    }


def assemble(lean, project, workers, fresh, build_root, scratch):
    version = subprocess.check_output([lean, "--version"], text=True, timeout=15).strip()
    if not valid_version(version):
        raise ValueError(f"Unexpected compiler: {version}")
    prior_receipt_bytes = (PREVIOUS / "build-receipt.json").read_bytes()
    prior_manifest_bytes = (PREVIOUS / "source-manifest.json").read_bytes()
    prior_receipt, prior_manifest = json.loads(prior_receipt_bytes), json.loads(prior_manifest_bytes)
    sources, entries, checkpoint_sha = checkpoint_sources(prior_manifest)
    dependencies, project_evidence = project_paths(project, prior_manifest)
    stages, library = scratch / "source", scratch / "lib"
    stages.mkdir()
    library.mkdir()
    for name, content in sources.items():
        (stages / (name + ".lean")).write_bytes(content)
    smoke = HERE / "LibrarySmoke.lean"
    write_json(HERE / "source-manifest.json", {
        "checkpoint": str(CHECKPOINT), "checkpoint_sha256": checkpoint_sha,
        "checkpoint_families": list(FAMILIES), "modules": entries, "project": project_evidence,
        "previous_manifest_sha256": digest(prior_manifest_bytes),
        "previous_build_receipt_sha256": digest(prior_receipt_bytes),
        "smoke_source_sha256": digest(smoke.read_bytes()),
    })
    env = dict(os.environ, LEAN_PATH=os.pathsep.join(map(str, [library, *dependencies])))
    checks = {}
    pending = dict(entries)
    reuse = not fresh and prior_receipt.get("verified") is True and valid_version(prior_receipt["lean_version"])
    with ThreadPoolExecutor(max_workers=workers) as executor:
        while pending:
            ready = [name for name, fields in pending.items()
                     if all(checks.get(dep, {}).get("verified") for dep in fields["local_imports"])]
            if not ready:
                break
            futures = {}
            for name in ready:
                del pending[name]
                record = reuse_module(name, entries[name], checks, library, prior_receipt, prior_manifest) if reuse else None
                if record is None:
                    futures[name] = executor.submit(compile_module, name, lean, stages, library, env)
                else:
                    checks[name] = record
            checks.update({name: future.result() for name, future in futures.items()})

    retained_lib = build_root / "lib/lean"
    persistent_env = dict(os.environ, LEAN_PATH=os.pathsep.join(map(str, [retained_lib, *dependencies])))
    artifacts = {}
    smoke_result = None
    if len(checks) == len(entries) and all(result["verified"] for result in checks.values()):
        retained_sources = build_root / "source"
        retained_sources.mkdir(exist_ok=True)
        retained_lib.mkdir(parents=True, exist_ok=True)
        for name in MODULES:
            (retained_sources / (name + ".lean")).write_bytes(sources[name])
            file = retained_lib / (name + ".olean")
            file.write_bytes((library / file.name).read_bytes())
            fingerprint = digest(file.read_bytes())
            if fingerprint != checks[name]["artifact_sha256"]:
                raise ValueError(f"Copied artifact differs for {name}")
            artifacts[name] = {"path": str(file.relative_to(HERE)), "sha256": fingerprint,
                               "source_sha256": entries[name]["source_sha256"], "mode": checks[name]["mode"]}
        smoke_result = lean_run([lean, "-j", "1", "-DElab.async=false", str(smoke)], HERE, persistent_env)
    write_json(HERE / "artifact-manifest.json", {"lean_version": version, "modules": artifacts})
    passed = bool(smoke_result and smoke_result["verified"])
    write_json(HERE / "build-receipt.json", {
        "checked_at_utc": datetime.now(timezone.utc).isoformat(), "lean_version": version,
        "compile_lean_path": env["LEAN_PATH"], "lean_path": persistent_env["LEAN_PATH"],
        "modules": checks, "skipped_modules": list(pending),
        "smoke": smoke_result, "verified": passed,
    })
    print(f"Durable library import {'passed' if passed else 'failed'}", flush=True)
    return 0 if passed else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lean", type=Path, default=LEAN)
    parser.add_argument("--project", type=Path, default=PROJECT)
    parser.add_argument("--workers", type=int, choices=(1, 2, 3), default=3)
    parser.add_argument("--fresh", action="store_true", help="Recompile the prior library modules too")
    args = parser.parse_args()
    build_root = HERE / "build"
    build_root.mkdir(mode=0o700, exist_ok=True)
    info = build_root.lstat()
    if not stat.S_ISDIR(info.st_mode) or info.st_uid != os.getuid() or info.st_mode & 0o077:
        raise ValueError("Expected a private, owner-controlled build directory")
    with (build_root / ".lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        with tempfile.TemporaryDirectory(prefix="pnp-checked-components-v2-") as scratch:
            return assemble(str(args.lean.resolve()), args.project.resolve(), args.workers, args.fresh,
                            build_root, Path(scratch).resolve())


if __name__ == "__main__":
    raise SystemExit(main())
