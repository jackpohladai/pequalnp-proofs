import CertifiedConstructorSolver

namespace PEqualNP.Outside.CertifiedConstructorSolver
open PEqualNP.Search
open PEqualNP.Outside.GuardedCNFEncoding

def label : Result → String
  | .unsupported => "unsupported"
  | .invalidCertificate => "invalid certificate"
  | .unsat => "UNSAT"
  | .sat _ => "SAT"

def returnedValues (result : Result) (ids : List Nat) : List Bool :=
  match result with
  | .sat assignment => ids.map assignment
  | _ => []

def returnedModelCheck (result : Result) (formula : CNF) : Bool :=
  match result with
  | .sat assignment => CNF.eval assignment formula
  | _ => false

private def fullTwo : Fin 2 → Finset (Fin 2) := fun _ => Finset.univ
private def noGuards : Fin 2 → Clause := fun _ => []
private def matchingSAT : Result := certify 0 [] fullTwo noGuards (.success (fun i => some i))
private def matchingUNSAT : Result := certify 0 []
  (fun _ : Fin 2 => ({0} : Finset (Fin 1))) noGuards (.failure Finset.univ)
private def invalidSuccess : Result := certify 0 [] fullTwo noGuards (.success (fun _ => some 0))
private def invalidFailure : Result := certify 0 [] fullTwo noGuards (.failure Finset.univ)
private def unsupportedSyntax : Result := certify 2 [[(0,false),(1,false)]]
  (fun _ : Fin 0 => (∅ : Finset (Fin 0))) (fun _ => []) (.success (fun _ => none))
private def retainedUNSAT : Result := certify 0 [[]]
  (fun _ : Fin 0 => (∅ : Finset (Fin 0))) (fun _ => []) (.success (fun _ => none))
private def negativeGuard : Result := certify 1 []
  (fun _ : Fin 1 => (∅ : Finset (Fin 0))) (fun _ => [(0,false)]) (.success (fun _ => none))
private def badOffset : Result := certify 2 [[(2,true)]]
  (fun _ : Fin 0 => (∅ : Finset (Fin 0))) (fun _ => []) (.success (fun _ => none))
private def allInactive : Result := certify 1 []
  (fun _ : Fin 2 => (∅ : Finset (Fin 0))) (fun _ => [(0,true)]) (.success (fun _ => none))

private def propagatedF : CNF := [[(0,false)]]
private def propagatedN : Fin 1 → Finset (Fin 1) := fun _ => {0}
private def propagatedGuards : Fin 1 → Clause := fun _ => [(0,true)]
private def propagatedSAT : Result := certify 1 propagatedF propagatedN propagatedGuards
  (.success (fun _ => some 0))

example : label matchingSAT = "SAT" := by decide
example : label matchingUNSAT = "UNSAT" := by decide
example : label retainedUNSAT = "UNSAT" := by decide
example : label invalidSuccess = "invalid certificate" := by decide
example : label invalidFailure = "invalid certificate" := by decide
example : label unsupportedSyntax = "unsupported" := by decide
example : label negativeGuard = "unsupported" := by decide
example : label badOffset = "unsupported" := by decide
example : label allInactive = "SAT" := by decide
example : returnedValues propagatedSAT [0,1] = [false,true] := by decide
example : returnedModelCheck propagatedSAT
    (encode propagatedF propagatedN propagatedGuards (freshEdge 1)) = true := by decide

#eval [matchingSAT, matchingUNSAT, retainedUNSAT, invalidSuccess, invalidFailure,
  unsupportedSyntax, negativeGuard, badOffset, allInactive].map label
#eval returnedModelCheck matchingSAT (encode [] fullTwo noGuards (freshEdge 0))
#eval returnedValues propagatedSAT [0,1]
#eval returnedModelCheck propagatedSAT (encode propagatedF propagatedN propagatedGuards (freshEdge 1))
end PEqualNP.Outside.CertifiedConstructorSolver
