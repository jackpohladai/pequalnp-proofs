import PreparedComponents

namespace PEqualNP.Outside.PreparedComponentOracle

open PEqualNP.Search
open PEqualNP.Outside.ConstructorBoundary

private def evalMask (mask : Nat) (F : CNF) : Bool :=
  F.all fun C => C.any fun (identifier, positive) =>
    mask.testBit identifier == positive

private def referenceSAT (variableCount : Nat) (F : CNF) : Bool :=
  (List.range (2 ^ variableCount)).any fun mask => evalMask mask F

private def wordsOfLength (alphabet : List α) : Nat → List (List α)
  | 0 => [[]]
  | n + 1 => alphabet.flatMap fun x => (wordsOfLength alphabet n).map (x :: ·)

private def wordsThrough (alphabet : List α) (maxLength : Nat) : List (List α) :=
  (List.range (maxLength + 1)).flatMap (wordsOfLength alphabet)

private def literalAlphabet : List Literal := [(0, false), (0, true), (1, false), (1, true)]

private def distinctLiteralClauses : List Clause :=
  (List.range 16).map fun mask =>
    (literalAlphabet.zipIdx.filter fun (_, index) => mask.testBit index).map Prod.fst

private def exhaustiveDistinct : List CNF := wordsThrough distinctLiteralClauses 3

private def exhaustiveRepeated : List CNF :=
  wordsThrough (wordsThrough literalAlphabet 2) 2

private def prngStep (s : Nat) : Nat := (48271 * s) % 2147483647

private def draws (state : Nat) : Nat → List Nat
  | 0 => []
  | count + 1 =>
    let next := prngStep state
    next :: draws next count

private def randomCase (seed : Nat) : CNF :=
  let values := draws seed 49
  let rows := values.headD 0 % 9
  (List.range rows).map fun row =>
    let begin := 1 + 6 * row
    let width := values[begin]! % 6
    (List.range width).map fun col =>
      let sample := values[begin + col + 1]! % 10
      (sample / 2, sample % 2 == 1)

private def randomCorpus : List CNF :=
  (draws 719371 400).map randomCase

private def raiseIndices (F : CNF) : CNF :=
  F.map fun C => C.map fun (identifier, positive) => (2 ^ 80 + 19 * identifier, positive)

structure Stats where
  cases : Nat := 0
  sat : Nat := 0
  unsat : Nat := 0
  disagreements : Nat := 0
  inconclusive : Nat := 0
  invalidPartitions : Nat := 0
  splitFormulas : Nat := 0
  deriving Repr, BEq

private def testCases (k : Nat) (corpus : List CNF) (encode : CNF → CNF) : Stats :=
  corpus.foldl (fun old F =>
    let expected := referenceSAT k F
    let encoded := encode F
    let prepared := UnitPreparedDecision.prepare encoded
    let parts := ComponentExtraction.extract prepared
    let accepted := ComponentSplit.check prepared parts
    let actual := PreparedComponents.solveCNF encoded
    { cases := old.cases + 1
      sat := old.sat + (if expected then 1 else 0)
      unsat := old.unsat + (if expected then 0 else 1)
      disagreements := old.disagreements + (if actual == some expected then 0 else 1)
      inconclusive := old.inconclusive + (if actual.isNone then 1 else 0)
      invalidPartitions := old.invalidPartitions + (if accepted then 0 else 1)
      splitFormulas := old.splitFormulas + (if parts.length > 1 then 1 else 0) }) {}

private def shift (n : Nat) (F : CNF) : CNF :=
  F.map fun C => C.map fun (identifier, positive) => (identifier+n, positive)

-- Separate-variable products. Expected truth is computed by direct full masks,
-- not by the implementation's partition or its leaf solver.
private def disconnected : List CNF :=
  (List.range 80).map fun i =>
    randomCase (17*i+11) ++ shift 5 (randomCase (29*i+31))

private def boundaryCases : List CNF :=
  [[], [[]], [[],[]], [[(0,true)],[(0,false)]],
   [[(0,true)],[(1,false)]], [[(0,true),(0,false)]],
   [[(0,true),(0,true)],[(0,false),(1,true)],[(1,false)]],
   [[(0,true),(1,true)],[(0,false),(1,false)]],
   [[(0,true),(1,true)],[(1,false),(2,true)],[(2,false),(3,true)],[(3,false)]],
   [[(0,true),(1,true)],[(2,false),(3,true)],[(1,false),(2,true)]],
   [[(0,true),(1,false)],[(0,true),(1,false)],[(2,false)],[(3,true)]],
   [[],[(0,true),(1,false)],[(2,false)],[(3,true)]]]

private def stats : List Stats :=
  [testCases 2 exhaustiveDistinct id,
   testCases 2 exhaustiveRepeated id,
   testCases 5 randomCorpus id,
   testCases 5 (randomCorpus.take 40) raiseIndices,
   testCases 10 disconnected id,
   testCases 4 boundaryCases id,
   testCases 4 boundaryCases raiseIndices]

#eval stats
#guard (stats.take 4).map (fun row => (row.cases, row.sat, row.unsat)) ==
  [(4369, 3396, 973), (463, 405, 58), (400, 200, 200), (40, 26, 14)]
#guard stats.all fun record => record.disagreements == 0 && record.inconclusive == 0 && record.invalidPartitions == 0
#print axioms stats

end PEqualNP.Outside.PreparedComponentOracle
