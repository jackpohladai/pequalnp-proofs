"""Bounded independent experiment for Fable auto00010 BLQ predictions.

This is NOT the proposed polynomial atom-descent implementation. For n<=12 it
enumerates small vector spaces and tries a greedy compatible basis. SKIP is
allowed. Every accepted block rewrite is exhaustively checked, as are all
original assignments. No production solver or general runtime claim changes.
"""
import datetime as dt
import itertools as it
import json
from pathlib import Path
import random
import sys
import time

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / 'ialh_counting'))
from solver import run_counting, variables
from check_scc_and_growth import canon, two_sat


def parity(x):
    return bin(x).count('1') % 2


def basis(vectors):
    rows = {}
    for v in vectors:
        while v:
            pivot = v.bit_length() - 1
            if pivot in rows:
                v ^= rows[pivot]
            else:
                rows[pivot] = v
                break
    return tuple(rows[k] for k in sorted(rows, reverse=True))


def span(vectors):
    result = {0}
    for v in basis(vectors):
        result |= {x ^ v for x in result}
    return result


def points(support):
    return [sum(bit << (v - 1) for v, bit in zip(support, bits))
            for bits in it.product((0, 1), repeat=len(support))]


def holds(formula, assignment):
    return all(any(bool(assignment & (1 << (abs(l) - 1))) == (l > 0) for l in c) for c in formula)


def experiment(formula):
    start = time.monotonic()
    assert all(type(l) is int and 1 <= abs(l) <= 12 for c in formula for l in c)
    f = canon(formula)
    if f is None or not f:
        return {'status': 'already_decided', 'sat': f is not None}
    blocks = {}
    for clause in f:
        support = tuple(sorted(map(abs, clause)))
        z = sum(1 << (abs(l) - 1) for l in clause if l < 0)
        blocks.setdefault(support, set()).add(z)
    data = []
    for support, z in sorted(blocks.items()):
        z0 = min(z)
        w = {a ^ z0 for a in z if {b ^ a ^ z0 for b in z} == z}
        assert span(w) == w
        wb = basis(w)
        annihilator = {a for a in points(support) if all(parity(a & d) == 0 for d in wb)}
        assert span(annihilator) == annihilator
        data.append(dict(support=support, forbidden=z, stabilizer=w, forms=annihilator))
    candidates = set().union(*(d['forms'] for d in data)) - {0}
    candidates = sorted(candidates, key=lambda v: (-sum(v in d['forms'] for d in data), bin(v).count('1'), v))
    chosen, chosen_span = [], {0}
    for v in candidates:
        if v not in chosen_span:
            chosen.append(v)
            chosen_span |= {a ^ v for a in chosen_span}
    assert len(basis(chosen)) == len(chosen)
    if any(span(v for v in chosen if v in d['forms']) != d['forms'] for d in data):
        return dict(status='skip_incompatible_greedy_basis', source_variables=len(variables(formula)), seconds=time.monotonic()-start)
    rewritten, summaries, block_checks = [], [], 0
    for d in data:
        indices = [i for i, v in enumerate(chosen) if v in d['forms']]
        forbidden = {tuple(parity(z & chosen[i]) for i in indices) for z in d['forbidden']}
        assert len(forbidden) * len(d['stabilizer']) == len(d['forbidden'])
        clauses = [tuple(-(i + 1) if bit else i + 1 for i, bit in zip(indices, t)) for t in sorted(forbidden)]
        for x in points(d['support']):
            y = sum(parity(x & v) << i for i, v in enumerate(chosen))
            assert holds(clauses, y) == (x not in d['forbidden'])
            block_checks += 1
        rewritten.extend(clauses)
        summaries.append(dict(support=d['support'], forbidden_points=len(d['forbidden']),
                              stabilizer_size=len(d['stabilizer']), form_rank=len(basis(d['forms'])),
                              quotient_clauses=len(clauses)))
    n = max(variables(formula), default=0)
    image, sat_before, sat_after, assignment_checks = set(), False, False, 0
    for x in range(2 ** n):
        y = sum(parity(x & v) << i for i, v in enumerate(chosen))
        before, after = holds(formula, x), holds(rewritten, y)
        assert before == after, (formula, rewritten, chosen, x)
        sat_before |= before
        sat_after |= after
        image.add(y)
        assignment_checks += 1
    assert len(image) == 2 ** len(chosen), 'The quotient map must be onto'
    assert sat_before == sat_after
    result = run_counting(rewritten, variables(rewritten))
    assert result['sat'] == sat_before
    if all(len(c) <= 2 for c in rewritten):
        assert two_sat(rewritten) == sat_before
    return dict(status='accepted_finite_quotient', source_variables=len(variables(formula)), source_clauses=len(formula),
                quotient_variables=len(chosen), quotient_clauses=len(rewritten), quotient=rewritten,
                basis_forms=chosen, blocks=summaries, block_assignment_checks=block_checks,
                full_assignment_checks=assignment_checks, oracle_sat=sat_before,
                quotient_solver_sat=result['sat'], quotient_solver_peak=result['peak'],
                max_quotient_width=max(map(len, rewritten), default=0), seconds=time.monotonic()-start)


def lift(base, groups):
    output = []
    for clause in base:
        support = sorted({v for l in clause for v in groups[abs(l) - 1]})
        for x in points(support):
            if any(parity(sum(1 << (v - 1) for v in groups[abs(l) - 1]) & x) == (l > 0) for l in clause):
                continue
            output.append(tuple(-v if x & (1 << (v - 1)) else v for v in support))
    return output


def main():
    start = time.monotonic()
    results = []
    for name in ['neon_worstcase_auto_00006', 'neon_worstcase_auto_00007']:
        p = HERE.parent / name
        candidate = json.loads((p / 'structured-output.json').read_text())
        prior = json.loads((p / 'test-receipt.json').read_text())
        result = experiment(candidate['formula'])
        assert result['status'] == 'accepted_finite_quotient'
        assert result['quotient_solver_peak'] == 0 and result['oracle_sat'] is False
        assert result['max_quotient_width'] == 2
        result.update(source=name, deployed_peak=prior['observed']['peak'])
        results.append(result)
    rng = random.Random(261126)
    random_results = []
    # Positive and negative controls prevent vacuous all-UNSAT agreement.
    for _ in range(80):
        logical = rng.randint(2, 4)
        groups = [list(range(2*i + 1, 2*i + 3)) for i in range(logical)]
        base = [tuple(rng.choice((-1, 1)) * v for v in rng.sample(list(range(1, logical + 1)), rng.randint(1, min(3, logical))))
                for _ in range(rng.randint(1, 10))]
        random_results.append(experiment(lift(base, groups)))
    accepted = [r for r in random_results if r['status'] == 'accepted_finite_quotient']
    assert any(r['oracle_sat'] for r in accepted) and any(not r['oracle_sat'] for r in accepted)
    receipt = dict(at=dt.datetime.now(dt.timezone.utc).isoformat(), source_proposal='fable_worstcase_auto_00010',
                   method='Bounded exhaustive block spaces, greedy certified basis; NOT Fable atom descent.',
                   fixtures=results, random_controls=dict(total=len(random_results),
                       accepted=len(accepted), sat=sum(r['oracle_sat'] for r in accepted),
                       unsat=sum(not r['oracle_sat'] for r in accepted),
                       skipped=sum(r['status']=='skip_incompatible_greedy_basis' for r in random_results),
                       block_assignment_checks=sum(r.get('block_assignment_checks', 0) for r in random_results),
                       full_assignment_checks=sum(r.get('full_assignment_checks', 0) for r in random_results), failures=0),
                   seconds=time.monotonic()-start, deployment_changed=False, lean_verified=False,
                   general_polynomial_sat_proof=False,
                   scope='Checks exact quotient predictions on finite inputs and controls. No proof of polynomial discovery, encoding robustness or general growth.')
    (HERE / 'test-receipt.json').write_text(json.dumps(receipt, indent=2))
    print(json.dumps({**{k:v for k,v in receipt.items() if k!='fixtures'}, 'fixtures':[
        {k:r[k] for k in ['source','source_variables','source_clauses','quotient_variables','quotient_clauses','deployed_peak','quotient_solver_peak','seconds','full_assignment_checks']} for r in results]}), flush=True)


if __name__ == '__main__':
    main()
