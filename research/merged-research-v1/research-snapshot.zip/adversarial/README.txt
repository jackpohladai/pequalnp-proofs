Independent adversarial SAT harness for proposed L-alg-001 algorithms

Scope
The oracle enumerates all assignments; it is separate from candidate code and
from the CNF witness evaluator. The default corpus has 594 deterministic cases
(155 SAT, 439 UNSAT), verified across 168,892 assignments. No external packages
are required. Run commands below from this directory with Python 3.

Files
  cnf.py: immutable signed-literal tuple interface, strict DIMACS I/O, metrics.
  oracle.py: exact status, model count and first witness, at most 20 variables.
  families.py: deterministic challenge generators and a small scaling API.
  corpus/corpus.jsonl: formulas, independently enumerated answers and metadata.
  corpus/manifest.json: compact counts, checks, source hashes and corpus SHA256.
  run_candidate.py: subprocess isolation, response/witness checking, time budget.
  candidate_bridge.py + meter.py: Python interface with cooperative operation counts.
  reference_candidate.py: exponential reference implementation for harness validation.
  batch_reviewed.py: explicit reviewed-source selection, hash checks and run deadlines.
  residual_dag_wrapper.py: adapter for the separately audited native DAG prototype.

Verified corpus coverage
  512: all subsets of the nine canonical non-tautological clauses on 2 variables.
   15: Tseitin parity CNFs on K4, K3,3, cube, cycle and disconnected graphs.
   14: ordinary/functional pigeonhole formulas, including satisfiable controls.
   36: seeded random 3-CNFs on 3..8 variables at clause ratios 1, 4 and 6.
    6: planted satisfiable 3-CNFs with verified planted assignments.
   11: empty/false formulas, tautologies, duplicate literals/clauses, isolated
       variables and sparse high-index variables (maximum 16 variables).
Disconnected parity cases catch the error of checking only the global charge.
Every formula, including planted instances, has exhaustive ground truth.

Build and verify
  python3 -m unittest -v test_harness.py
  python3 build_corpus.py
  python3 run_candidate.py --candidate reference_candidate.py --output reference-report.json

Python candidate interface
In a separate file implement:

  def solve(nvars, clauses, budget):
      # clauses is tuple[tuple[int,...],...]; literals use signed 1-based indices.
      # Variables may be declared but absent; clauses/formulas may be empty.
      budget.tick('literal_test')   # charge every primitive of the proposed model
      return {'status': 'SAT', 'assignment': [True, False, ...]}
      # or {'status': 'UNSAT'}
      # or {'status': 'UNKNOWN', 'reason': 'explicit limitation'}

Run:
  python3 run_candidate.py --candidate /absolute/path/candidate.py --output report.json
  python3 run_candidate.py --candidate /absolute/path/candidate.py --family tseitin --keep-going
  python3 run_candidate.py --candidate /absolute/path/candidate.py --case php-4-3-ordinary

A SAT decision without an assignment can be checked against the exact oracle.
If an assignment is provided it must contain nvars Boolean/0/1 values and really
satisfy every clause. Invalid assignments are failures even if the SAT label is
correct. Default behavior stops at the first wrong/incomplete/error/timeout case;
--keep-going checks the entire selection. Wall timeout defaults to 5 seconds per
case and includes worker initialization on the first case. Diagnostics go to
stderr, not the protocol channel. Reports retain a complete first counterexample.
Exit codes: 0 all selected cases correct; 1 wrong decision/witness; 2 incomplete,
timeout, protocol error, or operation-bound failure. This is not a security sandbox.

Standalone candidate interface (any language)
  python3 run_candidate.py --command 'python3 /absolute/path/solver.py' --output report.json
Keep the process alive. Read one JSON request and write one JSON response per line.
Request example:
  {"id":"probe","nvars":2,"clauses":[[1,-2],[2]],
   "metrics":{"dimacs_bytes":24},"budget":{"max_operations":1000}}
Response example:
  {"id":"probe","status":"SAT","assignment":[true,true],
   "operations":{"literal_tests":4}}
The exact id must be echoed. Oracle answers and generation metadata are never
sent to candidates. Standalone operation counts are only self-reported; the
runner cannot enforce them. Worker process groups are terminated on timeout.

Testing a concrete operation bound
  python3 run_candidate.py --candidate candidate.py --bound-degree 2 --bound-constant 10 --bound-size dimacs_bytes
  python3 run_candidate.py --candidate candidate.py --bound-degree 3 --bound-constant 1 --bound-size literal_occurrences
  python3 run_candidate.py --candidate reference_candidate.py --case sparse-high-index-conflict --max-operations 100 --output budget-report.json
The bridge enforces cooperative ticks and records categories. A candidate must
instrument all operations needed by its stated model; treating an exponential
subroutine as one tick invalidates that accounting. Counts do not measure Python
instructions or the bit cost of unbounded integers. Choose and state the input
size and cost model before interpreting growth. Exceeding a specific C*N^k budget
refutes that concrete bound on that case, not all O(N^k) bounds with other constants.
Passing a finite corpus proves neither correctness on arbitrary inputs nor an
asymptotic running time. Timeouts/UNKNOWN are not proofs of impossibility.

Restricted batch evaluation for reviewed proposals
  python3 batch_reviewed.py reviewed-selection.example.json
  python3 batch_reviewed.py reviewed-selection.example.json --execute --candidate-timeout 30 --case-timeout 2
Without --execute this validates the explicit selection and hashes only. The
manifest must list reviewed=true, the candidate Python path, and a sources map
of reviewed paths to their SHA256 hashes, including the candidate file itself.
List nonstandard imported dependencies too; imports are not automatically
audited. Paths are relative to the selection file. No generated proposal is
discovered or imported automatically. The included example lists only the
manually reviewed reference and residual-DAG adapter/dependency. Each candidate
gets a total deadline, per-case deadline and cooperative tick budget. Reports
state selected/tested counts; unfinished runs are never labeled complete.
This allowlist is not an OS sandbox: only run code after reviewing it.

Saved adversarial regressions and independent audits
  residual-dag-audit.json: 4,182 full projection-stage truth tables passed on the
    frozen native DAG source; see residual-dag-review.txt for proof boundaries.
  threshold-repair-audit.json: 1,536 guarded-row cases / 6,144 retained assignments
    passed; raw recognizer assumes valid nonzero integer literals.
  neon-audit/candidate-4c1128604842.py: frozen, known-incorrect candidate snapshot.
  neon-audit/minimized-counterexample.cnf: 9 variables / 12 clauses, 20 models,
    but frozen Neon reports UNSAT. Only x7 and x9 need be true for a witness.
  neon-audit/minimized-counterexample.json: replacing only the hull helper with
    independent exact enumeration changes that answer to a verified SAT witness.
  neon-audit/regression-corpus/: 20 isomorphic versions of this counterexample;
    all have 20 models; the frozen solver gives false UNSAT on seven of them.
  audit_neon_linear.py: explicitly selected reviewed-source helper regression;
    40,534 insertion orders / 282,836 prefixes plus 4,096 equation sequences;
    all affine-hull pairs in dimensions 2 and 3 (2,722 pairs).
The known-incorrect Neon snapshot is deliberately absent from the reviewed batch
example. To test a reviewed repair, pass the alternate corpus explicitly:
  python3 run_candidate.py --candidate repaired_wrapper.py --corpus neon-audit/regression-corpus/corpus.jsonl --keep-going
The batch command accepts the same --corpus option. Do not infer that passing
the original 594 cases establishes correctness: the frozen buggy solver passed
all of those before this targeted regression exposed its unsound deduction.

DIMACS and generic tuple use
  python3 corpus_tool.py --export tseitin-K4-0 > example.cnf
  python3 corpus_tool.py --oracle example.cnf
Python: CNF.from_tuples(nvars, clauses); parse_dimacs(text); cnf.dimacs().
The parser supports multiline clauses, multiple clauses per line, comments,
zero-variable headers and empty clauses; it rejects missing/wrong counts,
out-of-range/zero literals in the tuple API and unterminated DIMACS clauses.

Later hypothesis-specific scaling
families.scaled_family('php', h) makes h+1 pigeons in h holes.
families.scaled_family('random3'|'planted3'|'isolated', n, seed) is deterministic.
Large cases must not be labeled by the exhaustive oracle beyond its explicit
limit. Start with a proposed mechanism and a targeted family, rather than an
unbounded random campaign. No candidate here claims a P=NP result.
