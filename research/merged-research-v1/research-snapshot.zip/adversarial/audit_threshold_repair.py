"""Independent full-relation audit of the reviewed guarded-row recognizer."""
import hashlib
import importlib.util
import itertools
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
SOURCE = HERE.parent / 'native-search' / 'threshold_repair.py'
sys.path.insert(0, str(SOURCE.parent))
spec = importlib.util.spec_from_file_location('reviewed_threshold_repair', SOURCE)
candidate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(candidate)


def direct_cnf(clauses, bits):
    return all(any(bool((bits >> (abs(lit)-1)) & 1) == (lit > 0) for lit in c)
               for c in clauses)


def eval_dag(dag, root, bits):
    values = []
    for i, (kind, data) in enumerate(dag.nodes):
        if kind == 'const':
            value = data
        elif kind == 'lit':
            value = bool((bits >> (abs(data)-1)) & 1) == (data > 0)
        else:
            assert kind in ('and', 'or') and all(0 <= child < i for child in data)
            value = all(values[c] for c in data) if kind == 'and' else any(values[c] for c in data)
        values.append(value)
    return values[root]


def truth_cnf(truth, first):
    return [tuple(-(first+i) if (bits >> i) & 1 else first+i for i in range(2))
            for bits in range(4) if not (truth >> bits) & 1]


def run():
    checks, cases, refused = 0, 0, 0
    for rows, holes in [(1, 2), (2, 2), (2, 3)]:
        hidden = rows * holes
        for signed in (False, True):
            grid = [[(i*holes+j+1) * (-1 if signed and (i+j)%2 else 1)
                     for j in range(holes)] for i in range(rows)]
            for left, right in itertools.product(range(16), repeat=2):
                guards = [truth_cnf(left, hidden+1), truth_cnf(right, hidden+1)]
                if holes == 3:
                    guards.append(truth_cnf(6, hidden+1))  # correlated XOR guard
                # Context deliberately shares the same retained variables.
                context = truth_cnf((left ^ right) | 1, hidden+1)
                original = [list(row) for row in grid] + context
                for j in range(holes):
                    for a, b in itertools.combinations(range(rows), 2):
                        original.append([-grid[a][j], -grid[b][j]])
                    for row in grid:
                        for guard in guards[j]:
                            original.append([-row[j], *guard])
                result = candidate.compress(original, grid)
                assert result is not None
                dag, root, match, count = result
                assert count <= 2*rows*holes
                for remaining in range(4):
                    prefix = remaining << hidden
                    expected = any(direct_cnf(original, prefix | assignment)
                                   for assignment in range(1 << hidden))
                    assert eval_dag(dag, root, prefix) == expected
                    checks += 1
                cases += 1
                # Every additional unclassified positive hidden occurrence must
                # be rejected unless tautological or already a structural clause.
                if rows == 2 and holes == 2:
                    assert candidate.recognize(original + [[grid[0][0], grid[1][1]]], grid) is None
                    refused += 1
    grid = [[1, 2], [3, 4]]
    structural = [[1,2],[3,4],[-1,-3],[-2,-4]]
    malformed_zero_accepted = candidate.recognize(structural + [[0]], grid) is not None
    return {'source': str(SOURCE), 'sha256': hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
            'cases_checked': cases, 'retained_assignments_checked': checks,
            'invalid_hidden_occurrence_rejections': refused, 'all_valid_input_checks_passed': True,
            'malformed_zero_literal_accepted': malformed_zero_accepted,
            'scope': 'Finite full existential-relation checks; valid signed integer literal contract only.'}


if __name__ == '__main__':
    result = run()
    (HERE/'threshold-repair-audit.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result, indent=2))
