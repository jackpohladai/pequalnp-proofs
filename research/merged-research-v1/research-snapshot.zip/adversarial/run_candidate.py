"""Check a Python candidate or JSONL subprocess against the verified corpus."""
import argparse
from collections import Counter
from decimal import Decimal
import hashlib
import json
import os
from pathlib import Path
import selectors
import shlex
import signal
import subprocess
import sys
import tempfile
import time
from cnf import CNF


class ProtocolError(RuntimeError):
    pass


class Worker:
    def __init__(self, command, stderr):
        self.process = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                        stderr=stderr, start_new_session=True, bufsize=0)
        self.selector = selectors.DefaultSelector()
        self.selector.register(self.process.stdout, selectors.EVENT_READ)
        self.pending = b""

    def request(self, payload, timeout):
        try:
            self.process.stdin.write((json.dumps(payload) + "\n").encode())
        except BrokenPipeError as exc:
            raise ProtocolError("candidate exited before accepting request") from exc
        deadline = time.monotonic() + timeout
        while b"\n" not in self.pending:
            remaining = deadline - time.monotonic()
            if remaining <= 0 or not self.selector.select(remaining):
                raise TimeoutError("candidate exceeded the per-case wall-clock limit")
            chunk = os.read(self.process.stdout.fileno(), 65536)
            if not chunk:
                raise ProtocolError("candidate exited without a complete JSON response")
            self.pending += chunk
            if len(self.pending) > 1024 * 1024:
                raise ProtocolError("candidate response exceeded 1 MiB")
        line, self.pending = self.pending.split(b"\n", 1)
        try:
            response = json.loads(line)
        except (json.JSONDecodeError, UnicodeDecodeError) as exc:
            raise ProtocolError("candidate response was not a JSON object") from exc
        if not isinstance(response, dict) or response.get("id") != payload["id"]:
            raise ProtocolError("candidate response must echo the request id")
        return response

    def close(self):
        self.selector.close()
        # Kill descendants too, including after the protocol worker exits first.
        try:
            os.killpg(self.process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        self.process.wait()
        self.process.stdin.close()
        self.process.stdout.close()


def judge(cnf, expected, response):
    status = response.get("status")
    if status == "UNKNOWN":
        return "incomplete", response.get("reason", "candidate did not decide")
    if status == "ERROR":
        return "error", response.get("reason", "candidate error")
    if status not in ("SAT", "UNSAT"):
        return "error", "status must be SAT, UNSAT, or UNKNOWN"
    if status != expected:
        return "incorrect", f"claimed {status}, exhaustive oracle proves {expected}"
    if response.get("assignment") is not None:
        if status != "SAT" or not cnf.satisfied_by(response["assignment"]):
            return "incorrect", "reported assignment is invalid or does not satisfy the formula"
    return "correct", "decision agrees with exhaustive oracle"


def main():
    here = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--candidate", help="Python file with solve(nvars, clauses, budget)")
    mode.add_argument("--command", help="JSONL subprocess command; shlex parsed, never a shell")
    parser.add_argument("--corpus", default=str(here / "corpus" / "corpus.jsonl"))
    parser.add_argument("--family", action="append", help="repeat to select families")
    parser.add_argument("--case", action="append", help="repeat to select exact case IDs")
    parser.add_argument("--limit", type=int)
    parser.add_argument("--timeout", type=float, default=5.0)
    parser.add_argument("--total-timeout", type=float, help="wall-clock limit for the whole candidate run")
    parser.add_argument("--max-operations", type=int)
    parser.add_argument("--bound-degree", type=int, choices=(2, 3))
    parser.add_argument("--bound-constant", type=Decimal, default=Decimal(1))
    parser.add_argument("--bound-size", choices=("nvars", "clauses", "literal_occurrences",
                                                   "structural_size", "dimacs_bytes"),
                        default="dimacs_bytes")
    parser.add_argument("--keep-going", action="store_true")
    parser.add_argument("--output", help="write complete JSON report here")
    args = parser.parse_args()
    if args.timeout <= 0 or args.bound_constant < 0 or (args.limit is not None and args.limit < 1):
        parser.error("timeout and limit must be positive; bound constant nonnegative")
    if args.total_timeout is not None and args.total_timeout <= 0:
        parser.error("total timeout must be positive")
    if args.max_operations is not None and args.max_operations < 0:
        parser.error("max operations must be nonnegative")
    corpus_path = Path(args.corpus)
    encoded = corpus_path.read_bytes()
    manifest = json.loads(corpus_path.with_name("manifest.json").read_text())
    if hashlib.sha256(encoded).hexdigest() != manifest["sha256"]:
        parser.error("corpus SHA256 differs from manifest")
    rows = [json.loads(line) for line in encoded.splitlines()]
    rows = [r for r in rows if (not args.family or r["family"] in args.family)
            and (not args.case or r["id"] in args.case)]
    if args.limit:
        rows = rows[:args.limit]
    if not rows:
        parser.error("selection contains no cases")
    command = ([sys.executable, str(here / "candidate_bridge.py"),
                str(Path(args.candidate).resolve())] if args.candidate else shlex.split(args.command))
    if not command:
        parser.error("empty command")
    results, first_failure, counts = [], None, Counter()
    start = time.monotonic()
    total_timeout_reached = False
    def terminate_request(_signum, _frame):
        # A supervising batch runner can terminate us while still letting finally
        # kill the candidate's separate process group.
        raise KeyboardInterrupt("candidate run terminated by supervisor")
    signal.signal(signal.SIGTERM, terminate_request)
    with tempfile.TemporaryFile() as stderr:
        worker = None
        try:
            for row in rows:
                remaining = (args.total_timeout - (time.monotonic() - start)
                             if args.total_timeout is not None else args.timeout)
                if remaining <= 0:
                    total_timeout_reached = True
                    break
                cnf = CNF.from_tuples(row["nvars"], row["clauses"])
                assert hashlib.sha256(cnf.dimacs().encode()).hexdigest() == row["cnf_sha256"]
                maximum = args.max_operations
                if args.bound_degree:
                    bound = int(args.bound_constant * row["metrics"][args.bound_size] ** args.bound_degree)
                    maximum = min(maximum, bound) if maximum is not None else bound
                # Do not send oracle answers, planted assignments, or metadata to a candidate.
                payload = {"id": row["id"], "nvars": cnf.nvars, "clauses": cnf.clauses,
                           "metrics": row["metrics"], "budget": {"max_operations": maximum}}
                case_start = time.monotonic()
                try:
                    if worker is None:
                        worker = Worker(command, stderr)
                    response = worker.request(payload, min(args.timeout, remaining))
                    verdict, reason = judge(cnf, row["oracle"]["status"], response)
                except (TimeoutError, ProtocolError) as exc:
                    verdict = "timeout" if isinstance(exc, TimeoutError) else "error"
                    reason, response = str(exc), {}
                    if worker:
                        worker.close()
                    worker = None
                result = {"id": row["id"], "family": row["family"], "verdict": verdict,
                          "reason": reason, "expected": row["oracle"]["status"],
                          "metrics": row["metrics"], "max_operations": maximum,
                          "wall_seconds": time.monotonic() - case_start, "response": response}
                meter = response.get("_harness", {}).get("meter", {}) if args.candidate else {}
                ticks = meter.get("total")
                result["operation_bound_check"] = (
                    "no bound requested" if maximum is None else
                    "unmeasured" if type(ticks) is not int else
                    "exceeded" if ticks > maximum else "within cooperative tick budget")
                if verdict == "correct" and maximum is not None and type(ticks) is int and ticks > maximum:
                    verdict = "bound_exceeded"
                    result.update(verdict=verdict, reason="decision correct, but declared operation budget exceeded")
                results.append(result)
                counts[verdict] += 1
                if verdict != "correct":
                    if first_failure is None:
                        first_failure = {"case": row, "result": result}
                    if not args.keep_going:
                        break
        finally:
            if worker:
                worker.close()
        stderr.seek(0)
        diagnostic = stderr.read(65536).decode(errors="replace")
    report = {"format": "sat-candidate-report-v1", "command": command,
              "corpus_sha256": manifest["sha256"], "selected_cases": len(rows),
              "tested_cases": len(results), "counts": dict(counts),
              "complete_and_correct": counts["correct"] == len(rows),
              "elapsed_seconds": time.monotonic() - start, "first_failure": first_failure,
              "total_timeout_seconds": args.total_timeout,
              "total_timeout_reached": total_timeout_reached,
              "operation_accounting": ("cooperative budget.tick calls; not enforced instruction counts"
                                       if args.candidate else "candidate-reported; not independently measured"),
              "bound": {"degree": args.bound_degree, "constant": str(args.bound_constant),
                        "size": args.bound_size},
              "warning": "A finite pass is not a polynomial-time proof. A timeout is not an impossibility result.",
              "stderr_prefix": diagnostic, "results": results}
    if args.output:
        Path(args.output).write_text(json.dumps(report, indent=2) + "\n")
        print(json.dumps({k: v for k, v in report.items()
                          if k not in ("results", "first_failure", "stderr_prefix")}, indent=2))
    else:
        print(json.dumps(report, indent=2))
    return 0 if report["complete_and_correct"] else 1 if counts["incorrect"] else 2


if __name__ == "__main__":
    sys.exit(main())
