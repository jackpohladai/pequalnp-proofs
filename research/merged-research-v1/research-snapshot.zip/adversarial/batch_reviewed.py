"""Evaluate only explicit, reviewed, hash-pinned candidate selections.

Dry-run by default. This is an execution allowlist, not an OS security sandbox.
It does not discover/import/execute proposals found in other directories.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import uuid


def review_entries(path):
    manifest = json.loads(path.read_text())
    entries, ids = [], set()
    if manifest.get("format") != "reviewed-sat-candidates-v1":
        raise ValueError("unsupported selection-manifest format")
    for entry in manifest.get("candidates", []):
        identifier = entry.get("id", "")
        if not re.fullmatch(r"[A-Za-z0-9_.-]+", identifier) or identifier in ids:
            raise ValueError("candidate IDs must be unique safe filenames")
        ids.add(identifier)
        if entry.get("reviewed") is not True:
            raise ValueError(f"{identifier}: explicit reviewed=true is required")
        candidate = (path.parent / entry["candidate"]).resolve()
        sources = {}
        for filename, expected in entry.get("sources", {}).items():
            source = (path.parent / filename).resolve()
            actual = hashlib.sha256(source.read_bytes()).hexdigest()
            if expected != actual:
                raise ValueError(f"{identifier}: reviewed source hash changed: {source}")
            sources[str(source)] = actual
        if str(candidate) not in sources or candidate.suffix != ".py":
            raise ValueError(f"{identifier}: candidate Python file must be included in reviewed sources")
        entries.append({"id": identifier, "candidate": str(candidate), "sources": sources,
                        "review_note": entry.get("review_note", "")})
    if not entries:
        raise ValueError("selection has no candidates")
    return entries


def main():
    here = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("selection", help="explicit JSON manifest; no directory discovery")
    parser.add_argument("--execute", action="store_true", help="otherwise verify hashes and print only")
    parser.add_argument("--candidate-timeout", type=float, default=30)
    parser.add_argument("--case-timeout", type=float, default=2)
    parser.add_argument("--max-operations", type=int, default=1000000)
    parser.add_argument("--family", action="append")
    parser.add_argument("--corpus", help="explicit alternate verified JSONL corpus with adjacent manifest")
    parser.add_argument("--output-dir", default=str(here / "batch-results"))
    args = parser.parse_args()
    if min(args.candidate_timeout, args.case_timeout) <= 0 or args.max_operations < 0:
        parser.error("timeouts must be positive and operation budget nonnegative")
    selected_path = Path(args.selection).resolve()
    try:
        entries = review_entries(selected_path)
    except (ValueError, KeyError, OSError) as exc:
        parser.error(str(exc))
    if not args.execute:
        print(json.dumps({"execution": False, "reviewed_candidates": entries,
                          "next_step": "Run the same selection with --execute after reviewing it."}, indent=2))
        return 0
    run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "-" + uuid.uuid4().hex[:6]
    destination = Path(args.output_dir) / run_id
    destination.mkdir(parents=True, exist_ok=False)
    results = []
    for entry in entries:
        # Recheck approved hashes immediately before executing each candidate.
        for filename, expected in entry["sources"].items():
            if hashlib.sha256(Path(filename).read_bytes()).hexdigest() != expected:
                raise RuntimeError(f"source changed since selection validation: {filename}")
        output = destination / (entry["id"] + ".json")
        command = [sys.executable, str(here / "run_candidate.py"), "--candidate", entry["candidate"],
                   "--output", str(output), "--timeout", str(args.case_timeout),
                   "--total-timeout", str(args.candidate_timeout),
                   "--max-operations", str(args.max_operations)]
        for family in args.family or []:
            command.extend(["--family", family])
        if args.corpus:
            command.extend(["--corpus", str(Path(args.corpus).resolve())])
        process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                   start_new_session=True)
        supervisor_timeout = False
        try:
            stdout, stderr = process.communicate(timeout=args.candidate_timeout + 3)
        except subprocess.TimeoutExpired:
            supervisor_timeout = True
            os.killpg(process.pid, signal.SIGTERM)
            try:
                stdout, stderr = process.communicate(timeout=2)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                stdout, stderr = process.communicate()
        result = {"id": entry["id"], "reviewed_sources": entry["sources"],
                  "returncode": process.returncode, "supervisor_timeout": supervisor_timeout,
                  "report": str(output) if output.exists() else None,
                  "stdout": stdout.decode(errors="replace")[:4000],
                  "stderr": stderr.decode(errors="replace")[:4000]}
        if output.exists():
            report = json.loads(output.read_text())
            for key in ["selected_cases", "tested_cases", "counts", "complete_and_correct"]:
                result[key] = report[key]
        else:
            result["complete_and_correct"] = False
        results.append(result)
        print(json.dumps({k:v for k,v in result.items()
                          if k not in ("stdout", "stderr", "reviewed_sources")}), flush=True)
    summary = {"selection": str(selected_path), "results": results,
               "scope": "Explicit reviewed sources only; no code discovery. Finite correctness checks, no complexity theorem."}
    (destination / "summary.json").write_text(json.dumps(summary, indent=2)+"\n")
    print(f"Summary: {destination / 'summary.json'}")
    return 0 if all(r["complete_and_correct"] for r in results) else 1


if __name__ == "__main__":
    raise SystemExit(main())
