"""Exact factored Shannon AND/OR DAG solver with existential projection.

Implements exact SAT/UNSAT decision via:
  1. Exact preprocessing (empty clause detection, literal deduplication,
     tautological clause elimination, clause deduplication).
  2. Factored conjunction F = {u_1, ..., u_k} of reduced ordered Shannon
     ITE DAGs (nodes representing (v & hi) | (~v & lo), with FALSE=0, TRUE=1).
  3. Exact forced-literal propagation (from root-forced ITE nodes lo==0 or hi==0)
     and single-factor existential projection (|B_x| == 1).
  4. Exact multi-factor existential projection:
         exists x. AND_{u in B_x} u  ==  (AND_{u in B_x} u|_{x=1})
                                     |  (AND_{u in B_x} u|_{x=0}),
     keeping results factored whenever one branch collapses to FALSE or common
     factors factor out, and detecting UNSAT immediately if any factor becomes 0.
  5. Exact witness reconstruction backwards along the elimination stack, plus
     full O(N) clause verification before returning SAT.
  6. Strict resource budgeting: returns status="UNKNOWN" if any budget is hit,
     never treating failure to find a witness or budget exhaustion as UNSAT.
"""

from __future__ import annotations

from collections import deque
from typing import Any


class BudgetExhausted(Exception):
    """Raised when an explicit operation, node, or bit-op budget is exceeded."""


class ShannonDAGManager:
    """Reduced ordered Shannon ITE DAG manager with hash-consing and budgeting."""

    FALSE = 0
    TRUE = 1

    def __init__(
        self,
        nvars: int,
        var_order: list[int],
        max_ops: int,
        max_nodes: int,
        max_bit_ops: int,
    ) -> None:
        self.nvars = nvars
        # var_order[r] = 1-based variable at rank r (0 <= r < nvars)
        self.var_order = var_order
        self.rank_of: dict[int, int] = {v: r for r, v in enumerate(var_order)}
        self.inf_rank = nvars + 1

        # Node storage: parallel arrays for low memory overhead
        # Node 0 = FALSE, Node 1 = TRUE
        self.node_rank: list[int] = [self.inf_rank, self.inf_rank]
        self.node_hi: list[int] = [0, 1]
        self.node_lo: list[int] = [0, 1]
        self.node_size_cache: dict[int, int] = {0: 1, 1: 1}

        # Unique table: (rank, hi, lo) -> node_id
        self.unique: dict[tuple[int, int, int], int] = {}

        # Operation memo tables
        self.and_cache: dict[tuple[int, int], int] = {}
        self.or_cache: dict[tuple[int, int], int] = {}
        self.restrict_cache: dict[tuple[int, int, bool], int] = {}

        # Budgets
        self.max_ops = max_ops
        self.max_nodes = max_nodes
        self.max_bit_ops = max_bit_ops

        # Instrumentation
        self.ops = {
            "ite_nodes_created": 0,
            "ite_unique_hits": 0,
            "apply_calls": 0,
            "apply_cache_hits": 0,
            "restrict_calls": 0,
            "restrict_cache_hits": 0,
            "projections": 0,
            "single_factor_projections": 0,
            "forced_propagations": 0,
            "short_circuit_true": 0,
            "short_circuit_unsat": 0,
            "witness_evals": 0,
            "bit_ops_estimate": 0,
            "max_nodes_live": 2,
            "max_factor_dag_size": 1,
            "max_active_factors": 0,
            "budget_exhausted": False,
        }

    def _charge(self, op_cost: int = 1) -> None:
        self.ops["apply_calls"] += 0  # kept as explicit counter
        total_ops = (
            self.ops["apply_calls"]
            + self.ops["restrict_calls"]
            + self.ops["ite_nodes_created"]
            + self.ops["witness_evals"]
        )
        # Bit-cost per DAG step: O(log(nvars + num_nodes)) bits for node IDs / table lookup
        width = max(1, (self.nvars + len(self.node_rank)).bit_length())
        self.ops["bit_ops_estimate"] += op_cost * width
        if total_ops > self.max_ops:
            self.ops["budget_exhausted"] = True
            raise BudgetExhausted("max_ops exceeded")
        if self.ops["bit_ops_estimate"] > self.max_bit_ops:
            self.ops["budget_exhausted"] = True
            raise BudgetExhausted("max_bit_ops exceeded")

    def mk_ite(self, rank: int, hi: int, lo: int) -> int:
        if hi == lo:
            return hi
        key = (rank, hi, lo)
        existing = self.unique.get(key)
        if existing is not None:
            self.ops["ite_unique_hits"] += 1
            return existing
        if len(self.node_rank) >= self.max_nodes:
            self.ops["budget_exhausted"] = True
            raise BudgetExhausted("max_nodes exceeded")
        nid = len(self.node_rank)
        self.node_rank.append(rank)
        self.node_hi.append(hi)
        self.node_lo.append(lo)
        self.unique[key] = nid
        self.ops["ite_nodes_created"] += 1
        if len(self.node_rank) > self.ops["max_nodes_live"]:
            self.ops["max_nodes_live"] = len(self.node_rank)
        self._charge(1)
        return nid

    def from_clause(self, lits: list[int]) -> int:
        """Build exact Shannon ITE DAG for a non-tautological clause."""
        if not lits:
            return self.FALSE
        # Sort descending by rank so we build bottom-up from largest rank to smallest
        ranked = sorted(((self.rank_of[abs(lit)], lit > 0) for lit in lits), reverse=True)
        cur = self.FALSE
        for r, is_pos in ranked:
            if is_pos:
                cur = self.mk_ite(r, self.TRUE, cur)
            else:
                cur = self.mk_ite(r, cur, self.TRUE)
        return cur

    def apply_and(self, u: int, v: int) -> int:
        self.ops["apply_calls"] += 1
        self._charge(1)
        if u == 0 or v == 0:
            return 0
        if u == 1:
            return v
        if v == 1:
            return u
        if u == v:
            return u
        if u > v:
            u, v = v, u
        key = (u, v)
        cached = self.and_cache.get(key)
        if cached is not None:
            self.ops["apply_cache_hits"] += 1
            return cached

        ru = self.node_rank[u]
        rv = self.node_rank[v]
        r = ru if ru < rv else rv
        u_hi, u_lo = (self.node_hi[u], self.node_lo[u]) if ru == r else (u, u)
        v_hi, v_lo = (self.node_hi[v], self.node_lo[v]) if rv == r else (v, v)
        hi = self.apply_and(u_hi, v_hi)
        lo = self.apply_and(u_lo, v_lo)
        res = self.mk_ite(r, hi, lo)
        self.and_cache[key] = res
        return res

    def apply_or(self, u: int, v: int) -> int:
        self.ops["apply_calls"] += 1
        self._charge(1)
        if u == 1 or v == 1:
            return 1
        if u == 0:
            return v
        if v == 0:
            return u
        if u == v:
            return u
        if u > v:
            u, v = v, u
        key = (u, v)
        cached = self.or_cache.get(key)
        if cached is not None:
            self.ops["apply_cache_hits"] += 1
            return cached

        ru = self.node_rank[u]
        rv = self.node_rank[v]
        r = ru if ru < rv else rv
        u_hi, u_lo = (self.node_hi[u], self.node_lo[u]) if ru == r else (u, u)
        v_hi, v_lo = (self.node_hi[v], self.node_lo[v]) if rv == r else (v, v)
        hi = self.apply_or(u_hi, v_hi)
        lo = self.apply_or(u_lo, v_lo)
        res = self.mk_ite(r, hi, lo)
        self.or_cache[key] = res
        return res

    def restrict(self, u: int, target_rank: int, val: bool) -> int:
        self.ops["restrict_calls"] += 1
        self._charge(1)
        ru = self.node_rank[u]
        if ru > target_rank:
            return u
        if ru == target_rank:
            return self.node_hi[u] if val else self.node_lo[u]
        key = (u, target_rank, val)
        cached = self.restrict_cache.get(key)
        if cached is not None:
            self.ops["restrict_cache_hits"] += 1
            return cached
        hi = self.restrict(self.node_hi[u], target_rank, val)
        lo = self.restrict(self.node_lo[u], target_rank, val)
        res = self.mk_ite(ru, hi, lo)
        self.restrict_cache[key] = res
        return res

    def support_vars(self, u: int) -> set[int]:
        """Exact variable support (1-based variable indices) of DAG rooted at u."""
        if u <= 1:
            return set()
        seen: set[int] = set()
        vars_out: set[int] = set()
        stack = [u]
        while stack:
            cur = stack.pop()
            if cur <= 1 or cur in seen:
                continue
            seen.add(cur)
            r = self.node_rank[cur]
            vars_out.add(self.var_order[r])
            stack.append(self.node_hi[cur])
            stack.append(self.node_lo[cur])
        if len(seen) > self.ops["max_factor_dag_size"]:
            self.ops["max_factor_dag_size"] = len(seen)
        return vars_out

    def dag_size(self, u: int) -> int:
        if u <= 1:
            return 1
        seen: set[int] = set()
        stack = [u]
        while stack:
            cur = stack.pop()
            if cur <= 1 or cur in seen:
                continue
            seen.add(cur)
            stack.append(self.node_hi[cur])
            stack.append(self.node_lo[cur])
        return len(seen)

    def eval_total(self, u: int, assign: dict[int, bool]) -> bool:
        """Evaluate DAG u under an assignment covering all variables in u."""
        cur = u
        while cur > 1:
            self.ops["witness_evals"] += 1
            v = self.var_order[self.node_rank[cur]]
            cur = self.node_hi[cur] if assign[v] else self.node_lo[cur]
        return cur == 1


def _preprocess_clauses(nvars: int, clauses: list[list[int]]) -> tuple[bool, list[list[int]]]:
    """Normalize clauses: handle empty clause, repeated literals, tautologies, duplicates.

    Returns (is_trivially_unsat, normalized_unique_clauses).
    """
    seen_clauses: set[tuple[int, ...]] = set()
    cleaned: list[list[int]] = []
    for cl in clauses:
        if len(cl) == 0:
            return True, []
        lit_set: set[int] = set()
        taut = False
        for lit in cl:
            if not isinstance(lit, int) or isinstance(lit, bool) or lit == 0 or abs(lit) > nvars:
                raise ValueError(f"Invalid literal {lit!r} for nvars={nvars}")
            if -lit in lit_set:
                taut = True
                break
            lit_set.add(lit)
        if taut:
            continue
        canon = tuple(sorted(lit_set, key=lambda x: (abs(x), x)))
        if canon not in seen_clauses:
            seen_clauses.add(canon)
            cleaned.append(list(canon))
    return False, cleaned


def _compute_var_order(nvars: int, clauses: list[list[int]], strategy: str = "rcm") -> list[int]:
    """Compute a global variable order (1-based variable IDs)."""
    if nvars == 0:
        return []
    if strategy == "natural":
        return list(range(1, nvars + 1))

    adj: list[set[int]] = [set() for _ in range(nvars + 1)]
    for cl in clauses:
        vs = [abs(l) for l in cl]
        for i in range(len(vs)):
            vi = vs[i]
            for j in range(i + 1, len(vs)):
                vj = vs[j]
                if vi != vj:
                    adj[vi].add(vj)
                    adj[vj].add(vi)

    # Reverse Cuthill-McKee across connected components
    visited = [False] * (nvars + 1)
    order: list[int] = []
    nodes_by_deg = sorted(range(1, nvars + 1), key=lambda v: (len(adj[v]), v))
    for start in nodes_by_deg:
        if visited[start]:
            continue
        comp_order: list[int] = []
        q = deque([start])
        visited[start] = True
        while q:
            u = q.popleft()
            comp_order.append(u)
            nbrs = sorted((w for w in adj[u] if not visited[w]), key=lambda w: (len(adj[w]), w))
            for w in nbrs:
                visited[w] = True
                q.append(w)
        comp_order.reverse()
        order.extend(comp_order)
    return order


def _verify_assignment(clauses: list[list[int]], assignment: list[bool]) -> bool:
    for cl in clauses:
        sat = False
        for lit in cl:
            val = assignment[abs(lit) - 1]
            if (lit > 0 and val) or (lit < 0 and not val):
                sat = True
                break
        if not sat:
            return False
    return True


def solve(
    nvars: int,
    clauses: list[list[int]],
    budget: dict[str, Any] | int | None = None,
) -> dict[str, Any]:
    """Decide SAT/UNSAT/UNKNOWN using exact factored Shannon AND/OR DAGs with existential projection."""
    if not isinstance(nvars, int) or isinstance(nvars, bool) or nvars < 0:
        raise ValueError(f"Invalid nvars={nvars!r}")

    if isinstance(budget, int):
        max_ops = budget
        max_nodes = max(1000, budget)
        max_bit_ops = max(10_000, budget * 64)
        order_strategy = "rcm"
        elim_strategy = "min_bucket"
    elif isinstance(budget, dict):
        max_ops = int(budget.get("max_ops", 2_000_000))
        max_nodes = int(budget.get("max_nodes", 500_000))
        max_bit_ops = int(budget.get("max_bit_ops", 100_000_000))
        order_strategy = str(budget.get("order_strategy", "rcm"))
        elim_strategy = str(budget.get("elim_strategy", "min_bucket"))
    elif budget is None:
        max_ops = 2_000_000
        max_nodes = 500_000
        max_bit_ops = 100_000_000
        order_strategy = "rcm"
        elim_strategy = "min_bucket"
    else:
        raise ValueError(f"Unsupported budget type: {type(budget)}")

    triv_unsat, norm_clauses = _preprocess_clauses(nvars, clauses)
    if triv_unsat:
        return {
            "status": "UNSAT",
            "assignment": None,
            "operations": {
                "ite_nodes_created": 0,
                "ite_unique_hits": 0,
                "apply_calls": 0,
                "apply_cache_hits": 0,
                "restrict_calls": 0,
                "restrict_cache_hits": 0,
                "projections": 0,
                "single_factor_projections": 0,
                "forced_propagations": 0,
                "short_circuit_true": 0,
                "short_circuit_unsat": 1,
                "witness_evals": 0,
                "bit_ops_estimate": 1,
                "max_nodes_live": 2,
                "max_factor_dag_size": 1,
                "max_active_factors": 0,
                "budget_exhausted": False,
            },
        }

    if not norm_clauses:
        return {
            "status": "SAT",
            "assignment": [False] * nvars,
            "operations": {
                "ite_nodes_created": 0,
                "ite_unique_hits": 0,
                "apply_calls": 0,
                "apply_cache_hits": 0,
                "restrict_calls": 0,
                "restrict_cache_hits": 0,
                "projections": 0,
                "single_factor_projections": 0,
                "forced_propagations": 0,
                "short_circuit_true": 1,
                "short_circuit_unsat": 0,
                "witness_evals": 0,
                "bit_ops_estimate": max(1, nvars),
                "max_nodes_live": 2,
                "max_factor_dag_size": 1,
                "max_active_factors": 0,
                "budget_exhausted": False,
            },
        }

    var_order = _compute_var_order(nvars, norm_clauses, strategy=order_strategy)
    mgr = ShannonDAGManager(
        nvars=nvars,
        var_order=var_order,
        max_ops=max_ops,
        max_nodes=max_nodes,
        max_bit_ops=max_bit_ops,
    )

    # Active factors: factor_id -> (node_id, support_vars_set, dag_size)
    factors: dict[int, tuple[int, set[int], int]] = {}
    var_to_factors: dict[int, set[int]] = {v: set() for v in range(1, nvars + 1)}
    next_fid = 0

    def add_factor(nid: int) -> bool:
        """Add DAG node as an active factor. Returns False iff nid == FALSE (UNSAT)."""
        nonlocal next_fid
        if nid == mgr.FALSE:
            mgr.ops["short_circuit_unsat"] += 1
            return False
        if nid == mgr.TRUE:
            return True
        supp = mgr.support_vars(nid)
        if not supp:
            # Constant non-FALSE/TRUE shouldn't happen, safeguard
            return True
        sz = mgr.dag_size(nid)
        fid = next_fid
        next_fid += 1
        factors[fid] = (nid, supp, sz)
        for v in supp:
            var_to_factors[v].add(fid)
        if len(factors) > mgr.ops["max_active_factors"]:
            mgr.ops["max_active_factors"] = len(factors)
        return True

    def remove_factor(fid: int) -> tuple[int, set[int], int]:
        nid, supp, sz = factors.pop(fid)
        for v in supp:
            var_to_factors[v].discard(fid)
        return nid, supp, sz

    # Elimination history stack for exact SAT witness reconstruction:
    # Entries are either:
    #   ("forced", var, val_bool)
    #   ("proj", var, list_of_bucket_node_ids)
    history: list[tuple[str, int, Any]] = []

    try:
        for cl in norm_clauses:
            nid = mgr.from_clause(cl)
            if not add_factor(nid):
                return {"status": "UNSAT", "assignment": None, "operations": mgr.ops}

        while factors:
            # 1. Check for any root-forced literal: lo(u) == FALSE => var=True, hi(u) == FALSE => var=False
            forced_var = None
            forced_val = False
            for fid, (nid, _supp, _sz) in factors.items():
                if mgr.node_lo[nid] == mgr.FALSE:
                    forced_var = mgr.var_order[mgr.node_rank[nid]]
                    forced_val = True
                    break
                if mgr.node_hi[nid] == mgr.FALSE:
                    forced_var = mgr.var_order[mgr.node_rank[nid]]
                    forced_val = False
                    break

            if forced_var is not None:
                mgr.ops["forced_propagations"] += 1
                history.append(("forced", forced_var, forced_val))
                r_forced = mgr.rank_of[forced_var]
                affected = list(var_to_factors[forced_var])
                for fid in affected:
                    nid, _supp, _sz = remove_factor(fid)
                    restricted = mgr.restrict(nid, r_forced, forced_val)
                    if not add_factor(restricted):
                        return {"status": "UNSAT", "assignment": None, "operations": mgr.ops}
                continue

            # 2. Pick next active variable to existentially project
            active_vars = [v for v, fids in var_to_factors.items() if fids]
            if not active_vars:
                break

            if elim_strategy == "order":
                # Eliminate in global Shannon order (top-down along DAG order)
                rank_min = min(mgr.rank_of[v] for v in active_vars)
                chosen_var = mgr.var_order[rank_min]
            else:
                # Min-bucket heuristic: prefer |bucket| == 1 (free projection),
                # then smallest bucket sum-of-sizes / degree / induced neighborhood
                def var_score(v: int) -> tuple[int, int, int, int]:
                    fids = var_to_factors[v]
                    deg = len(fids)
                    if deg == 1:
                        fid = next(iter(fids))
                        return (0, factors[fid][2], 0, mgr.rank_of[v])
                    total_sz = sum(factors[fid][2] for fid in fids)
                    nbr_vars: set[int] = set()
                    for fid in fids:
                        nbr_vars.update(factors[fid][1])
                    return (deg, total_sz, len(nbr_vars), mgr.rank_of[v])

                chosen_var = min(active_vars, key=var_score)

            bucket_fids = list(var_to_factors[chosen_var])
            bucket_nodes: list[int] = []
            for fid in bucket_fids:
                nid, _supp, _sz = remove_factor(fid)
                bucket_nodes.append(nid)

            history.append(("proj", chosen_var, bucket_nodes))
            r_x = mgr.rank_of[chosen_var]
            mgr.ops["projections"] += 1

            if len(bucket_nodes) == 1:
                mgr.ops["single_factor_projections"] += 1
                u = bucket_nodes[0]
                u1 = mgr.restrict(u, r_x, True)
                if u1 == mgr.TRUE:
                    mgr.ops["short_circuit_true"] += 1
                    continue
                u0 = mgr.restrict(u, r_x, False)
                if u0 == mgr.TRUE:
                    mgr.ops["short_circuit_true"] += 1
                    continue
                proj = mgr.apply_or(u1, u0)
                if not add_factor(proj):
                    return {"status": "UNSAT", "assignment": None, "operations": mgr.ops}
                continue

            # Multi-factor projection:
            # exists x. AND(bucket_nodes) == (AND u|_{x=1}) | (AND u|_{x=0})
            pos_list: list[int] = []
            pos_false = False
            for u in bucket_nodes:
                r1 = mgr.restrict(u, r_x, True)
                if r1 == mgr.FALSE:
                    pos_false = True
                    break
                if r1 != mgr.TRUE:
                    pos_list.append(r1)

            if not pos_false and not pos_list:
                # All bucket factors became TRUE under x=1 => exists x. bucket == TRUE
                mgr.ops["short_circuit_true"] += 1
                continue

            neg_list: list[int] = []
            neg_false = False
            for u in bucket_nodes:
                r0 = mgr.restrict(u, r_x, False)
                if r0 == mgr.FALSE:
                    neg_false = True
                    break
                if r0 != mgr.TRUE:
                    neg_list.append(r0)

            if not neg_false and not neg_list:
                # All bucket factors became TRUE under x=0 => exists x. bucket == TRUE
                mgr.ops["short_circuit_true"] += 1
                continue

            if pos_false and neg_false:
                mgr.ops["short_circuit_unsat"] += 1
                return {"status": "UNSAT", "assignment": None, "operations": mgr.ops}

            # If one branch is FALSE, the remaining branch is purely conjunctive:
            # keep its factors separated in F instead of multiplying them!
            if pos_false:
                for nid in neg_list:
                    if not add_factor(nid):
                        return {"status": "UNSAT", "assignment": None, "operations": mgr.ops}
                continue
            if neg_false:
                for nid in pos_list:
                    if not add_factor(nid):
                        return {"status": "UNSAT", "assignment": None, "operations": mgr.ops}
                continue

            # Factor out any identical sub-factors present in both branches:
            # (C & A) | (C & B) == C & (A | B)
            pos_set = set(pos_list)
            neg_set = set(neg_list)
            common = pos_set & neg_set
            if common:
                for c_nid in common:
                    if not add_factor(c_nid):
                        return {"status": "UNSAT", "assignment": None, "operations": mgr.ops}
                pos_list = [nid for nid in pos_list if nid not in common]
                neg_list = [nid for nid in neg_list if nid not in common]
                if not pos_list or not neg_list:
                    mgr.ops["short_circuit_true"] += 1
                    continue

            # Conjoin pos_list smallest-first
            pos_list = sorted(set(pos_list), key=mgr.dag_size)
            h_pos = pos_list[0]
            for nxt in pos_list[1:]:
                h_pos = mgr.apply_and(h_pos, nxt)
                if h_pos == mgr.FALSE:
                    break

            if h_pos == mgr.TRUE:
                mgr.ops["short_circuit_true"] += 1
                continue

            # Conjoin neg_list smallest-first
            neg_list = sorted(set(neg_list), key=mgr.dag_size)
            h_neg = neg_list[0]
            for nxt in neg_list[1:]:
                h_neg = mgr.apply_and(h_neg, nxt)
                if h_neg == mgr.FALSE:
                    break

            if h_neg == mgr.TRUE:
                mgr.ops["short_circuit_true"] += 1
                continue

            proj = mgr.apply_or(h_pos, h_neg)
            if not add_factor(proj):
                return {"status": "UNSAT", "assignment": None, "operations": mgr.ops}

        # All active factors eliminated without reaching FALSE => SAT!
        # Reconstruct witness backwards along history stack.
        assign_map: dict[int, bool] = {}
        for kind, var, payload in reversed(history):
            if kind == "forced":
                assign_map[var] = bool(payload)
            else:
                bucket_nodes = payload
                # Any variable in bucket_nodes other than `var` that was never assigned
                # (possible if an earlier short-circuit eliminated a sub-branch) gets False.
                for u in bucket_nodes:
                    for v in mgr.support_vars(u):
                        if v != var and v not in assign_map:
                            assign_map[v] = False
                assign_map[var] = True
                if all(mgr.eval_total(u, assign_map) for u in bucket_nodes):
                    continue
                assign_map[var] = False
                # Guaranteed by existential-projection invariant when True failed
                if not all(mgr.eval_total(u, assign_map) for u in bucket_nodes):
                    raise RuntimeError(
                        f"Internal witness reconstruction failure at var={var}"
                    )

        assignment = [assign_map.get(v, False) for v in range(1, nvars + 1)]
        if not _verify_assignment(clauses, assignment):
            raise RuntimeError("Internal verification failed: witness does not satisfy clauses")
        return {
            "status": "SAT",
            "assignment": assignment,
            "operations": mgr.ops,
        }

    except BudgetExhausted:
        return {
            "status": "UNKNOWN",
            "assignment": None,
            "operations": mgr.ops,
        }
