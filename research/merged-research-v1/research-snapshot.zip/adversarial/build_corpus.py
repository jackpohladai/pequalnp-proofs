"""Build a deterministic JSONL corpus and compact, exact-oracle manifest."""
import argparse
from collections import defaultdict
import hashlib
import json
from pathlib import Path
from cnf import parse_dimacs
from families import cases
from oracle import exhaustive


def build(destination):
    destination = Path(destination)
    destination.mkdir(parents=True, exist_ok=True)
    rows, seen = [], set()
    totals = defaultdict(lambda: {"cases": 0, "SAT": 0, "UNSAT": 0,
                                  "assignments_examined": 0, "max_vars": 0})
    for case_id, family, cnf, metadata in cases():
        assert case_id not in seen
        seen.add(case_id)
        assert parse_dimacs(cnf.dimacs()) == cnf
        answer = exhaustive(cnf.nvars, cnf.clauses)
        if "expected_by_construction" in metadata:
            assert answer["status"] == metadata["expected_by_construction"], case_id
        if "planted_assignment" in metadata:
            assert cnf.satisfied_by(metadata["planted_assignment"]), case_id
        if answer["first_witness"] is not None:
            assert cnf.satisfied_by(answer["first_witness"]), case_id
        row = {"id": case_id, "family": family, "nvars": cnf.nvars,
               "clauses": cnf.clauses, "metrics": cnf.metrics(), "oracle": answer,
               "cnf_sha256": hashlib.sha256(cnf.dimacs().encode()).hexdigest(),
               "metadata": metadata}
        rows.append(row)
        t = totals[family]
        t["cases"] += 1
        t[answer["status"]] += 1
        t["assignments_examined"] += answer["assignments_examined"]
        t["max_vars"] = max(t["max_vars"], cnf.nvars)
    encoded = "".join(json.dumps(r, sort_keys=True, separators=(",", ":")) + "\n"
                      for r in rows).encode()
    (destination / "corpus.jsonl").write_bytes(encoded)
    source_names = ["cnf.py", "oracle.py", "families.py", "build_corpus.py"]
    manifest = {
        "format": "sat-adversarial-corpus-v1", "corpus": "corpus.jsonl",
        "sha256": hashlib.sha256(encoded).hexdigest(), "bytes": len(encoded),
        "cases": len(rows), "families": dict(sorted(totals.items())),
        "total_assignments_examined": sum(t["assignments_examined"] for t in totals.values()),
        "oracle": "Independent exhaustive integer-bit enumeration, all 2^n assignments",
        "maximum_variables": max(r["nvars"] for r in rows),
        "checks": ["DIMACS round trip", "literal validity", "unique case IDs",
                   "all constructed expected statuses", "all planted witnesses",
                   "all oracle first witnesses"],
        "source_sha256": {name: hashlib.sha256((Path(__file__).parent/name).read_bytes()).hexdigest()
                          for name in source_names},
        "limits": "Finite tests establish these instances only, not asymptotic complexity or P=NP.",
    }
    (destination / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    return manifest


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", default=str(Path(__file__).parent / "corpus"))
    args = parser.parse_args()
    print(json.dumps(build(args.output), indent=2))
