"""Exponential reference candidate for harness self-test, not a proposed SAT advance.

Uses itertools.product; the separate oracle uses integer-bit enumeration. Charges
one operation per assignment and per inspected literal. This simple logical cost
model deliberately does not claim to count Python instructions or bit complexity.
"""
from itertools import product


def solve(nvars, clauses, budget):
    for assignment in product((False, True), repeat=nvars):
        budget.tick("assignment")
        all_satisfied = True
        for clause in clauses:
            satisfied = False
            for literal in clause:
                budget.tick("literal_test")
                if assignment[abs(literal)-1] == (literal > 0):
                    satisfied = True
                    break
            if not satisfied:
                all_satisfied = False
                break
        if all_satisfied:
            return {"status": "SAT", "assignment": list(assignment)}
    return {"status": "UNSAT"}
