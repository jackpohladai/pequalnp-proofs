"""Adapt solve(nvars, clauses, budget) to one request/response per JSON line."""
import argparse
import contextlib
import importlib.util
import json
from pathlib import Path
import sys
import time
from meter import Budget, BudgetExceeded


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("candidate", help="Python file implementing solve(nvars, clauses, budget)")
    parser.add_argument("--function", default="solve")
    args = parser.parse_args()
    candidate = Path(args.candidate).resolve()
    sys.path.insert(0, str(candidate.parent))
    spec = importlib.util.spec_from_file_location("sat_candidate", candidate)
    module = importlib.util.module_from_spec(spec)
    # Diagnostic printing by candidate imports and calls is not protocol output.
    with contextlib.redirect_stdout(sys.stderr):
        spec.loader.exec_module(module)
    solve = getattr(module, args.function)
    for line in sys.stdin:
        request = json.loads(line)
        budget = Budget(request.get("budget", {}).get("max_operations"))
        start = time.monotonic()
        try:
            with contextlib.redirect_stdout(sys.stderr):
                response = solve(request["nvars"], tuple(tuple(c) for c in request["clauses"]), budget)
            if not isinstance(response, dict):
                raise TypeError("solver must return a dictionary")
            response = dict(response)
        except BudgetExceeded as exc:
            response = {"status": "UNKNOWN", "reason": str(exc), "budget_exceeded": True}
        except Exception as exc:
            response = {"status": "ERROR", "reason": f"{type(exc).__name__}: {exc}"}
        response["id"] = request["id"]
        response["_harness"] = {"meter": budget.snapshot(),
                                "elapsed_seconds": time.monotonic() - start}
        print(json.dumps(response), flush=True)


if __name__ == "__main__":
    main()
