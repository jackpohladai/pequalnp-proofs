"""Targeted checks for parsing, oracle independence, generators, and response validation."""
import itertools
import json
import sys
import tempfile
import unittest
from cnf import CNF, parse_dimacs
from families import pigeonhole, tseitin
from meter import Budget, BudgetExceeded
from oracle import exhaustive
from run_candidate import judge, Worker, ProtocolError


class HarnessTests(unittest.TestCase):
    def test_dimacs(self):
        self.assertEqual(parse_dimacs("c header\np cnf 3 2\n1\n-2 0 0\n"),
                         CNF(3, ((1, -2), ())))
        for malformed in ["", "1 0", "p cnf 1 1\n1", "p cnf 1 0\n0",
                          "p cnf 1 1\n2 0", "p cnf -1 0", "p cnf 1 0\np cnf 1 0"]:
            with self.subTest(malformed=malformed), self.assertRaises(ValueError):
                parse_dimacs(malformed)

    def test_oracle_edges(self):
        self.assertEqual(exhaustive(0, [])['model_count'], 1)
        self.assertEqual(exhaustive(0, [()])['model_count'], 0)
        self.assertEqual(exhaustive(4, [(1,), (1, -2)])['model_count'], 8)
        self.assertEqual(exhaustive(3, [(1, -1), (2, 2)])['model_count'], 4)

    def test_truth_vectors_independently(self):
        # Boolean-product evaluation differs from the oracle's integer-bit loop.
        clauses = [(), (1,), (-1,), (2,), (-2,), (1, 2), (-1, -2)]
        for selected in itertools.product((False, True), repeat=len(clauses)):
            cnf = CNF.from_tuples(2, [c for c, use in zip(clauses, selected) if use])
            expected = sum(cnf.satisfied_by(a) for a in itertools.product((False, True), repeat=2))
            self.assertEqual(exhaustive(2, cnf.clauses)['model_count'], expected)

    def test_tseitin_versus_direct_parity(self):
        edges = list(itertools.combinations(range(4), 2))
        for charges in itertools.product((0, 1), repeat=4):
            cnf = tseitin(4, edges, charges)
            for a in itertools.product((False, True), repeat=6):
                direct = all(sum(a[i] for i, edge in enumerate(edges) if v in edge) % 2 == charges[v]
                             for v in range(4))
                self.assertEqual(cnf.satisfied_by(a), direct)

    def test_pigeonhole_and_isolation(self):
        for p, h in [(0, 0), (1, 0), (2, 1), (2, 2), (3, 2), (3, 3)]:
            cnf = pigeonhole(p, h)
            self.assertEqual(exhaustive(cnf.nvars, cnf.clauses)['status'], 'SAT' if p <= h else 'UNSAT')
        self.assertEqual(exhaustive(8, [(1,)])['model_count'], 128)

    def test_witnesses_and_status(self):
        cnf = CNF(2, ((1,),))
        self.assertEqual(judge(cnf, 'SAT', {'status': 'SAT', 'assignment': [True, False]})[0], 'correct')
        for assignment in [[False, False], [True], [True, 2], '11']:
            self.assertEqual(judge(cnf, 'SAT', {'status': 'SAT', 'assignment': assignment})[0], 'incorrect')
        self.assertEqual(judge(cnf, 'SAT', {'status': 'UNSAT'})[0], 'incorrect')
        self.assertEqual(judge(cnf, 'SAT', {'status': 'UNKNOWN'})[0], 'incomplete')
        self.assertEqual(judge(CNF(0, ((),)), 'UNSAT', {'status': 'UNSAT', 'assignment': None})[0], 'correct')

    def test_meter(self):
        meter = Budget(3)
        meter.tick('literal', 3)
        with self.assertRaises(BudgetExceeded):
            meter.tick('literal')
        self.assertEqual(meter.total, 4)
        with self.assertRaises(ValueError):
            meter.tick('negative', -1)

    def test_worker_wrong_id_and_timeout(self):
        payload = {'id': 'probe', 'nvars': 0, 'clauses': []}
        scripts = [
            ("import sys; sys.stdin.readline(); print('{\"id\":\"wrong\",\"status\":\"SAT\"}', flush=True)", ProtocolError),
            ("import sys,time; sys.stdin.readline(); time.sleep(10)", TimeoutError),
            ("import sys; sys.stdin.readline(); print('not json', flush=True)", ProtocolError),
        ]
        for script, error in scripts:
            with self.subTest(error=error), tempfile.TemporaryFile() as diagnostics:
                worker = Worker([sys.executable, '-u', '-c', script], diagnostics)
                try:
                    with self.assertRaises(error):
                        worker.request(payload, 0.1)
                finally:
                    worker.close()


if __name__ == '__main__':
    unittest.main()
