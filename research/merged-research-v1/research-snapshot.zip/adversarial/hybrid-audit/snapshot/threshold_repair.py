"""Exact, syntactically checked elimination of interchangeable guarded rows.
No general CNF block discovery or polynomial-time general SAT claim.
"""
from residual_dag import DAG
from itertools import combinations,product
from pathlib import Path
import random,json

def binary(d,op,a,b):
    ident,absorbing=(1,0)if op=='and'else(0,1)
    if a==absorbing or b==absorbing:return absorbing
    if a==ident:return b
    if b==ident:return a
    if a==b:return a
    return d.put((op,tuple(sorted((a,b)))))

def threshold(d,available,r):
    if r<=0:return 1
    if r>len(available):return 0
    state=[1]+[0]*r
    for a in available:
        old=state
        state=[1]+[binary(d,'or',old[j],binary(d,'and',a,old[j-1]))
                   for j in range(1,r+1)]
    return state[r]

def normalize_clauses(clauses):
    out=set()
    for c in clauses:
        c=frozenset(c)
        if any(-x in c for x in c):continue
        out.add(c)
    return out

def recognize(clauses,grid):
    """Grid is proposed, not guessed. Check every occurrence of its variables."""
    r=len(grid);h=len(grid[0]) if r else 0
    if not r or not h or any(len(row)!=h for row in grid):return None
    selectors=[x for row in grid for x in row]
    if 0 in selectors or len({abs(x)for x in selectors})!=r*h:return None
    hidden={abs(x)for x in selectors}
    position={-grid[i][j]:(i,j)for i in range(r)for j in range(h)}
    rowclauses={frozenset(row)for row in grid}
    collisions={frozenset((-grid[i][j],-grid[k][j]))
                for j in range(h)for i,k in combinations(range(r),2)}
    cs=normalize_clauses(clauses)
    if not rowclauses<=cs or not collisions<=cs:return None
    guards=[[set()for j in range(h)]for i in range(r)];context=[]
    for c in cs-rowclauses-collisions:
        hs=[x for x in c if abs(x)in hidden]
        if not hs:context.append(c);continue
        if len(hs)!=1 or hs[0]not in position:return None
        i,j=position[hs[0]]
        guards[i][j].add(c-{hs[0]})
    for j in range(h):
        if any(guards[i][j]!=guards[0][j]for i in range(1,r)):return None
    return dict(rows=r,holes=h,hidden=hidden,context=context,guards=guards[0])

def compress(clauses,grid):
    match=recognize(clauses,grid)
    if match is None:return None
    d=DAG()
    context=d.cnf(match['context'])
    available=[d.cnf(g)for g in match['guards']]
    before=len(d.nodes)
    t=threshold(d,available,match['rows'])
    dp_nodes=len(d.nodes)-before
    root=binary(d,'and',context,t)
    return d,root,match,dp_nodes

def evaluate_cnf(cs,a):
    return all(any(a[abs(x)]==(x>0)for x in c)for c in cs)

def make_formula(grid,guards,context):
    r=len(grid);h=len(grid[0])
    cs=[list(row)for row in grid]+[list(c)for c in context]
    cs += [[-grid[i][j],-grid[k][j]]for j in range(h)
           for i,k in combinations(range(r),2)]
    cs += [[-grid[i][j],*c]for i in range(r)for j in range(h)for c in guards[j]]
    return cs

def random_tests():
    rng=random.Random(2373001);checked=0;cases=0
    for r,h in [(1,1),(1,3),(2,2),(2,3),(3,2)]:
        for _ in range(24):
            vs=list(range(1,r*h+1));rng.shuffle(vs)
            grid=[[vs[i*h+j]*rng.choice((-1,1))for j in range(h)]for i in range(r)]
            remaining=[r*h+1,r*h+2]
            def cnf():
                return [rng.sample([*remaining,*[-x for x in remaining]],rng.randrange(0,3))
                        for _ in range(rng.randrange(0,4))]
            guards=[cnf()for _ in range(h)];context=cnf()
            cs=make_formula(grid,guards,context)
            result=compress(cs,grid);assert result is not None
            d,root,match,dp_nodes=result
            assert dp_nodes<=2*r*h
            for vals in product((False,True),repeat=2):
                a=dict(zip(remaining,vals))
                expected=any(evaluate_cnf(cs,a|dict(zip(range(1,r*h+1),bits)))
                             for bits in product((False,True),repeat=r*h))
                assert d.evaluate(root,a)==expected
                checked+=1
            cases+=1
    # Nonuniform row guards and unrecognized hidden-variable uses are refused.
    grid=[[1,2],[3,4]]
    cs=make_formula(grid,[[[5]],[[6]]],[])
    assert recognize(cs+[[-3,-5]],grid)is None
    assert recognize(cs+[[1,4]],grid)is None
    assert recognize(cs,[[1,2],[1,4]])is None
    return cases,checked

def php_tests():
    checked=0;details=[]
    for p,h in [(2,3),(3,3),(4,3),(3,2)]:
        for r in range(1,p+1):
            grid=[[1+i*h+j for j in range(h)]for i in range(r)]
            remaining=[[1+i*h+j for j in range(h)]for i in range(r,p)]
            context=[row for row in remaining]
            context += [[-remaining[i][j],-remaining[k][j]]
                        for j in range(h)for i,k in combinations(range(p-r),2)]
            guards=[[[-row[j]]for row in remaining]for j in range(h)]
            cs=make_formula(grid,guards,context)
            d,root,match,dp_nodes=compress(cs,grid)
            retained=[x for row in remaining for x in row]
            count=0
            for vals in product((False,True),repeat=len(retained)):
                a=dict(zip(retained,vals))
                expected=any(evaluate_cnf(cs,a|dict(zip(range(1,r*h+1),bits)))
                             for bits in product((False,True),repeat=r*h))
                assert d.evaluate(root,a)==expected
                checked+=1;count+=1
            details.append(dict(p=p,h=h,r=r,continuations=count,dp_nodes=dp_nodes,
                                final_dag_nodes=d.reachable(root)))
    return checked,details

if __name__=='__main__':
    cases,checked=random_tests();php_checked,details=php_tests()
    sizes=[]
    for h in (8,16,32,64):
        d=DAG();a=[d.literal(i+1)for i in range(h)];before=len(d.nodes)
        root=threshold(d,a,h//2)
        sizes.append(dict(h=h,r=h//2,dp_nodes=len(d.nodes)-before,
                          child_references=sum(len(data)for kind,data in d.nodes
                                               if kind in('and','or'))))
    out=dict(scope='Exact recognized-block repair; no general SAT complexity claim',
             randomized_signed_correlated_guard_cases=cases,
             randomized_continuations_checked=checked,php_continuations_checked=php_checked,
             php_cases=details,binary_threshold_sizes=sizes)
    Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))
