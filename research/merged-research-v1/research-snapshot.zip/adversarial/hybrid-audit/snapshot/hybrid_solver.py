"""Exact guarded-row preprocessing + residual-DAG SAT with witness lifting.

No worst-case polynomial bound. Counters expose allocations/children/cache
work; they are not a complete Python or bit-operation cost model.
"""
from collections import Counter
from pathlib import Path
import time
from residual_dag import DAG
from hybrid_recognition import find_block_metered,recognize_metered
from threshold_repair import threshold,binary

class Limit(Exception):pass
class PreprocessLimit(Exception):pass

class MeteredDAG(DAG):
    def __init__(self,budget,deadline,node_limit):
        self.budget=budget;self.deadline=deadline;self.node_limit=node_limit
        self.counts=Counter();super().__init__()
        self.counts['allocated_nodes']=2
    def tick(self,name,amount=1):
        self.counts[name]+=amount
        if self.budget is not None:self.budget.tick(name,amount)
        if time.monotonic()>self.deadline:raise Limit('time cap')
    def put(self,key):
        self.tick('node_intern_calls')
        if key[0]in('and','or'):self.tick('intern_input_child_refs',len(key[1]))
        before=len(self.nodes);out=super().put(key)
        if len(self.nodes)>before:
            self.counts['allocated_nodes']+=1
            if key[0]in('and','or'):self.counts['allocated_child_refs']+=len(key[1])
        if len(self.nodes)>self.node_limit:raise Limit('node cap')
        return out
    def junction(self,op,children):
        children=tuple(children)
        self.tick('junction_calls');self.tick('junction_input_child_refs',len(children))
        return super().junction(op,children)
    def cofactor(self,node,var,value):
        self.tick('cofactor_calls')
        if(node,var,value)in self.cofactor_cache:self.tick('cofactor_cache_hits')
        return super().cofactor(node,var,value)
    def evaluate_memoized(self,root,a):
        memo={0:False,1:True}
        def visit(node):
            if node not in memo:
                self.tick('witness_evaluation_nodes')
                kind,data=self.nodes[node]
                if kind=='lit':memo[node]=a[abs(data)]==(data>0)
                else:
                    self.tick('witness_evaluation_child_refs',len(data))
                    vals=[visit(c)for c in data]
                    memo[node]=all(vals)if kind=='and'else any(vals)
            return memo[node]
        return visit(root)
    def snapshot(self):
        return dict(self.counts)|dict(retained_nodes=len(self.nodes),
            retained_child_refs=sum(len(data)for kind,data in self.nodes if kind in('and','or')),
            cofactor_cache_entries=len(self.cofactor_cache))

def validate(nvars,clauses):
    if type(nvars)is not int or nvars<0:raise ValueError('nvars must be a nonnegative integer')
    if not isinstance(clauses,(list,tuple)):raise ValueError('clauses must be a sequence')
    out=[]
    for c in clauses:
        if not isinstance(c,(list,tuple)):raise ValueError('every clause must be a sequence')
        if any(type(x)is not int or x==0 or abs(x)>nvars for x in c):
            raise ValueError('literals must be nonzero integers within 1..nvars')
        out.append(tuple(c))
    return tuple(out)

def solve_with_options(nvars,clauses,budget=None,*,preprocess=True,seconds=10,node_limit=200000,
                       preprocess_work_limit=200000):
    start=time.monotonic()
    try:clauses=validate(nvars,clauses)
    except ValueError as e:return dict(status='ERROR',reason=str(e))
    if nvars>1000000:return dict(status='UNKNOWN',reason='assignment-size resource cap')
    d=MeteredDAG(budget,start+seconds,node_limit)
    matched=None;grid=None;trace=[];available=[];root=None;attempts=0
    preprocess_work=0;preprocess_exhausted=False
    def recognition_tick(name,amount=1):
        nonlocal preprocess_work
        d.tick(name,amount);preprocess_work+=amount
        if preprocess_work>preprocess_work_limit:raise PreprocessLimit()
    def response(status,**extra):
        return dict(status=status,seconds=round(time.monotonic()-start,6),
                    operations=d.snapshot(),preprocessing=dict(used=matched is not None,
                        rows=matched['rows'] if matched else 0,
                        holes=matched['holes'] if matched else 0,grid_attempts=attempts,
                        work_units=preprocess_work,work_cap_exhausted=preprocess_exhausted),
                    accounting_limit='Counters cover explicit finder loops; internal hash/set/sort/bit costs remain uncounted',
                    **extra)
    try:
        d.tick('input_literal_occurrences',sum(map(len,clauses)))
        if preprocess:
            try:
                grid,attempts=find_block_metered(clauses,recognition_tick)
                d.tick('recognizer_grid_attempts',attempts)
                if grid is not None:matched=recognize_metered(clauses,grid,recognition_tick)
            except PreprocessLimit:
                grid=None;matched=None;preprocess_exhausted=True
        if matched is None:
            root=d.cnf(clauses);hidden=set()
        else:
            hidden=matched['hidden']
            context=d.cnf(matched['context'])
            available=[d.cnf(g)for g in matched['guards']]
            root=binary(d,'and',context,threshold(d,available,matched['rows']))
        for var in range(1,nvars+1):
            if root in(0,1):break
            if var in hidden:continue
            d.tick('variable_eliminations')
            zero=d.cofactor(root,var,False);one=d.cofactor(root,var,True)
            trace.append((var,zero,one))
            root=d.junction('or',(zero,one))
        if root==0:return response('UNSAT',trace_entries=len(trace))
        if root!=1:return response('ERROR',reason='full projection did not become constant')
        d.tick('assignment_slots',nvars)
        assignment={i:False for i in range(1,nvars+1)}
        for var,zero,one in reversed(trace):
            if d.evaluate_memoized(zero,assignment):assignment[var]=False
            elif d.evaluate_memoized(one,assignment):assignment[var]=True
            else:return response('ERROR',reason='witness reconstruction invariant failed')
        if matched is not None:
            choices=[j for j,a in enumerate(available)if d.evaluate_memoized(a,assignment)]
            if len(choices)<len(grid):return response('ERROR',reason='insufficient available columns')
            for row in grid:
                for lit in row:assignment[abs(lit)]=lit<0
            for i,row in enumerate(grid):
                lit=row[choices[i]];assignment[abs(lit)]=lit>0
        for c in clauses:
            d.tick('witness_original_clause_literals',len(c))
            if not any(assignment[abs(x)]==(x>0)for x in c):
                return response('ERROR',reason='lifted witness failed original CNF')
        return response('SAT',assignment=[assignment[i]for i in range(1,nvars+1)],
                        trace_entries=len(trace))
    except Limit as e:return response('UNKNOWN',reason=str(e),trace_entries=len(trace))
    except RecursionError:return response('UNKNOWN',reason='interpreter recursion cap',trace_entries=len(trace))

def solve(nvars,clauses,budget):
    return solve_with_options(nvars,clauses,budget)
