"""Exact existential CNF projection with hash-consed common-factor DAGs.
Exploratory algorithm: no polynomial worst-case size/time bound is claimed.
"""
from functools import lru_cache
from itertools import product, combinations
import json
import random
from pathlib import Path


class DAG:
    def __init__(self):
        self.nodes = [('const', False), ('const', True)]
        self.intern = {x: i for i, x in enumerate(self.nodes)}
        self.cofactor_cache = {}
        self.factor_steps = 0

    def put(self, key):
        if key not in self.intern:
            self.intern[key] = len(self.nodes)
            self.nodes.append(key)
        return self.intern[key]

    def literal(self, x):
        return self.put(('lit', x))

    def junction(self, op, children):
        identity, absorbing = (1, 0) if op == 'and' else (0, 1)
        flat = set()
        for child in children:
            if child == absorbing:
                return absorbing
            if child == identity:
                continue
            kind, data = self.nodes[child]
            flat.update(data if kind == op else (child,))
        if not flat:
            return identity
        lits = {self.nodes[c][1] for c in flat if self.nodes[c][0] == 'lit'}
        if any(-x in lits for x in lits):
            return absorbing
        # Absorption: A AND (A OR B) = A, and its dual.
        dual = 'or' if op == 'and' else 'and'
        flat = {c for c in flat if not (
            self.nodes[c][0] == dual and set(self.nodes[c][1]) & flat)}
        if len(flat) == 1:
            return next(iter(flat))
        # Common conjunction factor extraction across OR alternatives.
        if op == 'or':
            factors = [set(self.nodes[c][1]) if self.nodes[c][0] == 'and'
                       else {c} for c in flat]
            common = set.intersection(*factors)
            if common:
                self.factor_steps += 1
                residuals = [self.junction('and', fs - common) for fs in factors]
                return self.junction('and', [*common, self.junction('or', residuals)])
        return self.put((op, tuple(sorted(flat))))

    def cnf(self, clauses):
        return self.junction('and', [self.junction('or', [self.literal(x) for x in c])
                                     for c in clauses])

    def cofactor(self, node, var, value):
        key = (node, var, value)
        if key in self.cofactor_cache:
            return self.cofactor_cache[key]
        kind, data = self.nodes[node]
        if kind == 'const':
            out = node
        elif kind == 'lit':
            out = int(value == (data > 0)) if abs(data) == var else node
        else:
            out = self.junction(kind, [self.cofactor(c, var, value) for c in data])
        self.cofactor_cache[key] = out
        return out

    def forget(self, node, var):
        return self.junction('or', [self.cofactor(node, var, False),
                                    self.cofactor(node, var, True)])

    def evaluate(self, node, assignment):
        kind, data = self.nodes[node]
        if kind == 'const':
            return data
        if kind == 'lit':
            return bool(assignment[abs(data)]) == (data > 0)
        vals = [self.evaluate(c, assignment) for c in data]
        return all(vals) if kind == 'and' else any(vals)

    def reachable(self, node):
        seen = set()
        def visit(x):
            if x in seen:
                return
            seen.add(x)
            kind, data = self.nodes[x]
            if kind in ('and', 'or'):
                for c in data:
                    visit(c)
        visit(node)
        return len(seen)


def check_random():
    rng = random.Random(1001)
    checked = 0
    for _ in range(120):
        n = rng.randrange(1, 7)
        clauses = []
        for _ in range(rng.randrange(1, 14)):
            vs = rng.sample(range(1, n + 1), rng.randrange(1, min(3, n) + 1))
            clauses.append([v * rng.choice((-1, 1)) for v in vs])
        d = DAG()
        root = d.cnf(clauses)
        order = list(range(1, n + 1))
        rng.shuffle(order)
        eliminated = []
        for index in range(n + 1):
            retained = order[index:]
            for values in product((False, True), repeat=len(retained)):
                a = dict(zip(retained, values))
                expected = False
                for old in product((False, True), repeat=len(eliminated)):
                    full = a | dict(zip(eliminated, old))
                    expected |= all(any(full[abs(lit)] == (lit > 0) for lit in c)
                                    for c in clauses)
                assert d.evaluate(root, a) == expected
                checked += 1
            if index < n:
                root = d.forget(root, order[index])
                eliminated.append(order[index])
    return checked


def selector_experiment(k):
    # xi are forgotten; yi,zi must remain as an exact continuation relation.
    d = DAG()
    clauses = []
    for i in range(1, k + 1):
        clauses += [(i, k+i), (-i, 2*k+i)]
    root = d.cnf(clauses)
    peak = d.reachable(root)
    for i in range(1, k + 1):
        root = d.forget(root, i)
        peak = max(peak, d.reachable(root))
    expected = d.cnf([(k+i, 2*k+i) for i in range(1, k+1)])
    assert root == expected
    return dict(k=k, incomparable_residual_cnfs=2**k,
                final_reachable_dag_nodes=d.reachable(root),
                peak_reachable_dag_nodes=peak,
                allocated_nodes=len(d.nodes), factor_steps=d.factor_steps)


if __name__ == '__main__':
    result = dict(scope='Exploratory exact representation, no general polynomial bound',
                  random_projection_assignments_checked=check_random(),
                  selector=[selector_experiment(k) for k in (1,2,4,8,16,32,64)])
    Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result, indent=2))
