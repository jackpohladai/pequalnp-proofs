"""Metered copies of the audited syntactic rules; originals are preserved."""
from itertools import combinations

def normalize(clauses,tick):
    out=set()
    for c in clauses:
        tick('recognition_clause_visits')
        c=frozenset(c);taut=False
        for x in c:
            tick('recognition_literal_visits')
            if -x in c:taut=True;break
        if not taut:out.add(c)
    return out

def recognize_metered(clauses,grid,tick):
    r=len(grid);h=len(grid[0])if r else 0
    if not r or not h or any(len(row)!=h for row in grid):return None
    selectors=[]
    for row in grid:
        tick('recognition_grid_cells',len(row));selectors.extend(row)
    if 0 in selectors or len({abs(x)for x in selectors})!=r*h:return None
    hidden={abs(x)for x in selectors}
    position={-grid[i][j]:(i,j)for i in range(r)for j in range(h)}
    rowclauses={frozenset(row)for row in grid};collisions=set()
    for j in range(h):
        for i,k in combinations(range(r),2):
            tick('recognition_collision_pairs');collisions.add(frozenset((-grid[i][j],-grid[k][j])))
    cs=normalize(clauses,tick)
    if not rowclauses<=cs or not collisions<=cs:return None
    guards=[[set()for j in range(h)]for i in range(r)];context=[]
    for c in cs-rowclauses-collisions:
        tick('recognition_guard_clause_visits');tick('recognition_guard_literal_visits',len(c))
        hs=[x for x in c if abs(x)in hidden]
        if not hs:context.append(c);continue
        if len(hs)!=1 or hs[0]not in position:return None
        i,j=position[hs[0]];guards[i][j].add(c-{hs[0]})
    for j in range(h):
        for i in range(1,r):
            tick('recognition_guard_comparisons')
            if guards[i][j]!=guards[0][j]:return None
    return dict(rows=r,holes=h,hidden=hidden,context=context,guards=guards[0])

def find_block_metered(clauses,tick):
    cs=normalize(clauses,tick)
    candidates=sorted([tuple(sorted(c,key=lambda x:(abs(x),x)))for c in cs if len(c)>=2],
                      key=lambda x:(-len(x),x))
    def align(a,b):
        tick('finder_alignment_calls')
        if len(a)!=len(b)or {abs(x)for x in a}&{abs(x)for x in b}:return None
        out=[]
        for x in a:
            choices=[]
            for y in b:
                tick('finder_collision_lookups')
                if frozenset((-x,-y))in cs:choices.append(y)
            if len(choices)!=1:return None
            out.append(choices[0])
        return out if len(set(out))==len(out)else None
    attempts=0
    for a in candidates:
        tick('finder_seed_rows');grid=[list(a)];used={abs(x)for x in a};pairs=[]
        for b in candidates:
            tick('finder_candidate_rows')
            if {abs(x)for x in b}&used:continue
            aligned=align(a,b)
            if aligned is None:continue
            if any(align(row,aligned)!=aligned for row in grid):continue
            pairs.append([list(a),aligned]);grid.append(aligned);used.update(abs(x)for x in aligned)
        if len(grid)>1:
            attempts+=1
            if recognize_metered(cs,grid,tick)is not None:return grid,attempts
        for pair in pairs:
            attempts+=1
            if recognize_metered(cs,pair,tick)is not None:return pair,attempts
    return None,attempts
