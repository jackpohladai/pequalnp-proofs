"""Reviewed frozen native hybrid and pinned dependencies; finite-test adapter."""
import importlib.util
from pathlib import Path
import sys
SNAPSHOT=Path(__file__).parent/'hybrid-audit'/'snapshot'
sys.path.insert(0,str(SNAPSHOT))
spec=importlib.util.spec_from_file_location('reviewed_hybrid',SNAPSHOT/'hybrid_solver.py')
native=importlib.util.module_from_spec(spec)
spec.loader.exec_module(native)
def solve(nvars,clauses,budget):
    return native.solve_with_options(nvars,clauses,budget,seconds=2,node_limit=30000,preprocess_work_limit=20000)
