"""Cooperative logical-operation counter, not an instruction profiler."""
from collections import Counter


class BudgetExceeded(RuntimeError):
    pass


class Budget:
    def __init__(self, maximum=None):
        if maximum is not None and (type(maximum) is not int or maximum < 0):
            raise ValueError("maximum operations must be a nonnegative integer")
        self.maximum = maximum
        self.total = 0
        self.categories = Counter()

    def tick(self, category="step", amount=1):
        if type(amount) is not int or amount < 0:
            raise ValueError("operation charge must be a nonnegative integer")
        self.total += amount
        self.categories[str(category)] += amount
        if self.maximum is not None and self.total > self.maximum:
            raise BudgetExceeded(f"operation budget {self.maximum} exceeded")

    def snapshot(self):
        return {"total": self.total, "categories": dict(self.categories),
                "maximum": self.maximum, "accounting": "cooperative explicit ticks"}
