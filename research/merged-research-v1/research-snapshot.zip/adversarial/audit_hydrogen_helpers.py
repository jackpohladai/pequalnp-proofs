"""Independent small-state checks of the reviewed frozen Hydrogen helpers."""
import itertools
import json
from pathlib import Path
from hydrogen_snapshot_wrapper import native, SOURCE
from oracle import exhaustive


def points(n, equations):
    return {x for x in range(1 << n)
            if all(((m & x).bit_count() & 1) == r for m, r in equations)}


def spaces(n):
    for selected in range(1, 1 << (1 << n)):
        pts = {x for x in range(1 << n) if selected >> x & 1}
        base = min(pts)
        dirs = {x ^ base for x in pts}
        if not all(a ^ b in dirs for a in dirs for b in dirs):
            continue
        equations = [(mask, (mask & base).bit_count() & 1) for mask in range(1, 1 << n)
                     if len({(mask & x).bit_count() & 1 for x in pts}) == 1]
        yield pts, equations


def main():
    report = {'source': str(SOURCE), 'f2_insertion_orders': 0, 'f2_prefixes': 0,
              'f2_failures': [], 'memo_states': 0, 'memo_collisions_checked': 0,
              'memo_sat_mismatches': [], 'clique_cases': 0,
              'clique_refutations': 0, 'clique_false_refutations': []}
    for n in (2, 3):
        for pts, equations in spaces(n):
            for order in itertools.permutations(equations):
                ops = native.OpsTracker(10000000)
                system = native.F2System(n, ops)
                prefix = []
                report['f2_insertion_orders'] += 1
                for mask, rhs in order:
                    prefix.append((mask, rhs))
                    system.add_equation(mask | (rhs << n))
                    expect = points(n, prefix)
                    actual_eq = [(row & system.var_mask, (row >> n) & 1) for row in system.rows.values()]
                    actual = points(n, actual_eq) if system.consistent else set()
                    witness = sum(v << i for i, v in enumerate(system.solve_any()))
                    strict = all(row & (1 << pivot) and
                                 not ((row & system.pivot_mask) ^ (1 << pivot))
                                 for pivot, row in system.rows.items())
                    units, equivs = system.extract_implied_le2()
                    deductions = all(all(((x >> v) & 1) == b for v, b in units.items()) and
                                     all((((x >> u) ^ (x >> v)) & 1) == b for u, v, b in equivs)
                                     for x in expect)
                    report['f2_prefixes'] += 1
                    if actual != expect or witness not in expect or not strict or not deductions:
                        report['f2_failures'].append({'n': n, 'prefix': prefix[:], 'rows': system.rows.copy()})
                        raise AssertionError(report['f2_failures'][-1])
    # Full serialized-state memo keys: equal keys must not mix SAT and UNSAT.
    cache = {}
    atoms = [(), (-1,), (1,), (-2,), (2,), (-1,-2), (-1,2), (1,-2), (1,2)]
    for pts, equations in spaces(2):
        for subset in range(1 << len(atoms)):
            clauses = [c for i, c in enumerate(atoms) if subset >> i & 1]
            ops = native.OpsTracker(10000000)
            system = native.F2System(2, ops)
            for mask, rhs in equations:
                system.add_equation(mask | (rhs << 2))
            expected = any(all(any(bool(x >> (abs(lit)-1) & 1) == (lit > 0) for lit in c)
                               for c in clauses) for x in pts)
            key = native._canonical_key(system, clauses, [0,1], ops)
            report['memo_states'] += 1
            if key in cache:
                report['memo_collisions_checked'] += 1
                if cache[key] != expected:
                    report['memo_sat_mismatches'].append({'equations':equations, 'clauses':clauses})
            cache[key] = expected
    # Every subset of all twelve non-tautological binary clauses on 3 variables,
    # also with a deterministic pair of ternary clauses to exercise mixed-width packing.
    binary = [tuple(a*x for a,x in zip(signs,variables))
              for variables in itertools.combinations(range(1,4),2)
              for signs in itertools.product((-1,1),repeat=2)]
    for subset in range(1 << len(binary)):
        base = [c for i,c in enumerate(binary) if subset >> i & 1]
        for extra in [[], [(1,2,3),(-1,-2,-3)]]:
            clauses = base + extra
            answer = native._conflict_clique_unsat(clauses, native.OpsTracker(10000000))
            report['clique_cases'] += 1
            if answer:
                report['clique_refutations'] += 1
                if exhaustive(3,clauses)['status'] != 'UNSAT':
                    report['clique_false_refutations'].append(clauses)
    report['limits'] = 'Finite helper checks, not a universal proof. Known component witness reconstruction failure is separate.'
    path = Path(__file__).parent/'hydrogen-audit'/'helper-audit.json'
    path.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))


if __name__ == '__main__':
    main()
