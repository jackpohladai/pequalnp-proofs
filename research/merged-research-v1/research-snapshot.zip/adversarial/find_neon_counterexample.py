"""Bounded targeted search for false UNSAT caused by the frozen affine-hull bug."""
import argparse
import json
from pathlib import Path
import random
import time
from cnf import CNF
from families import random_3cnf
from neon_snapshot_wrapper import native, SOURCE
from oracle import exhaustive


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--seconds', type=float, default=45)
    parser.add_argument('--output', type=Path, default=Path(__file__).parent/'neon-audit'/'full-solver-search.json')
    args = parser.parse_args()
    original_hull = native.affine_hull_equations
    bad_calls = []
    all_calls = 0
    current_id = None
    def observed_hull(a, b, nvars, ops):
        nonlocal all_calls
        all_calls += 1
        equations = original_hull(a, b, nvars, ops)
        if nvars <= 9:
            for value in range(1 << nvars):
                valid_a = all((value & m).bit_count() % 2 == r for m, r in a.pivots.values())
                valid_b = all((value & m).bit_count() % 2 == r for m, r in b.pivots.values())
                if (valid_a or valid_b) and any((value & m).bit_count() % 2 != r for m, r in equations):
                    if len(bad_calls) < 50:
                        bad_calls.append({'case': current_id, 'A': list(a.pivots.values()),
                                          'B': list(b.pivots.values()), 'equations': equations,
                                          'rejected_union_point': value})
                    break
        return equations
    native.affine_hull_equations = observed_hull
    started = time.monotonic()
    checked, statuses, counterexample = 0, {}, None
    for trial in range(2400):
        if time.monotonic()-started > args.seconds:
            break
        nvars = 4 + trial % 6
        ratio = [3, 4, 5, 6, 7][(trial//6) % 5]
        seed = 930000 + trial
        rng = random.Random(seed)
        planted = [bool(rng.randrange(2)) for _ in range(nvars)]
        cnf = random_3cnf(nvars, ratio*nvars, seed, planted)
        current_id = f'planted-target-{seed}'
        response = native.solve(nvars, cnf.clauses, 1000000)
        checked += 1
        status = response['status']
        statuses[status] = statuses.get(status, 0)+1
        assert cnf.satisfied_by(planted)
        if status == 'UNSAT':
            clauses = list(cnf.clauses)
            original_clauses = list(clauses)
            # Clause deletion preserves the planted witness, so no oracle is
            # needed during shrinking; the final artifact is also enumerated.
            changed = True
            while changed:
                changed = False
                for i in range(len(clauses)):
                    trial_clauses = clauses[:i]+clauses[i+1:]
                    if native.solve(nvars, trial_clauses, 1000000)['status'] == 'UNSAT':
                        clauses = trial_clauses
                        changed = True
                        break
            small = CNF.from_tuples(nvars, clauses)
            counterexample = {'id': current_id, 'nvars': nvars, 'clauses': clauses,
                              'original_clauses': original_clauses, 'planted_witness': planted,
                              'oracle': exhaustive(nvars, clauses),
                              'candidate': native.solve(nvars, clauses, 1000000)}
            assert small.satisfied_by(planted)
            args.output.with_suffix('.cnf').write_text(small.dimacs())
            break
    report = {'snapshot': str(SOURCE), 'cases_checked': checked, 'statuses': statuses,
              'hull_calls': all_calls, 'bad_hull_calls_prefix': bad_calls,
              'elapsed_seconds': time.monotonic()-started, 'counterexample': counterexample,
              'scope': 'Bounded seeded planted-SAT search targeted at the observed affine-hull bug; no exhaustive claim.'}
    args.output.write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k != 'bad_hull_calls_prefix'}, indent=2))
    print('Bad hull calls recorded:',len(bad_calls))


if __name__ == '__main__':
    main()
