"""Read-only pool inventory; parses source AST but never imports candidate code."""
import ast
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import statistics


def main():
    here = Path(__file__).resolve().parent
    pool = here.parent / 'pool'
    status = json.loads((pool/'status.json').read_text())
    screening_path = here/'screening-ledger.json'
    screening = json.loads(screening_path.read_text()) if screening_path.exists() else []
    screened = {r['job']:r for r in screening if r.get('origin') == 'pool'}
    records, sources, arms = [], defaultdict(list), defaultdict(list)
    terminal_states = {'completed','error','timeout','recovered'}
    for job, metadata in sorted(status['jobs'].items()):
        if not job.endswith('-proposal'):
            continue
        directory = pool/job
        row = {'job':job, 'status':metadata['status'], 'model':metadata.get('model'),
               'reasoning':metadata.get('reasoning','unspecified'), 'route_assigned':metadata.get('route'),
               'started':bool(metadata.get('started_utc')), 'terminal':metadata['status'] in terminal_states,
               'source_exists':False, 'source_parses':False, 'has_module_solve':False,
               'independent_screening':screened.get(job)}
        if metadata.get('started_utc') and metadata.get('ended_utc'):
            row['wall_seconds'] = (datetime.fromisoformat(metadata['ended_utc'].replace('Z','+00:00'))-
                                   datetime.fromisoformat(metadata['started_utc'].replace('Z','+00:00'))).total_seconds()
        candidate = directory/'candidate.py'
        if candidate.exists():
            encoded = candidate.read_bytes()
            row.update(source_exists=True, source_sha256=hashlib.sha256(encoded).hexdigest(), source_bytes=len(encoded))
            sources[row['source_sha256']].append(job)
            try:
                tree = ast.parse(encoded)
                row['source_parses'] = True
                funcs = [node for node in tree.body if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef))
                         and node.name == 'solve']
                row['has_module_solve'] = bool(funcs)
                row['imports_for_review'] = sorted({node.module or '' for node in ast.walk(tree) if isinstance(node,ast.ImportFrom)} |
                                                   {alias.name for node in ast.walk(tree) if isinstance(node,ast.Import) for alias in node.names})
            except (SyntaxError, UnicodeDecodeError) as exc:
                row['parse_error'] = str(exc)
        result = directory/'result.json'
        if result.exists():
            try:
                data = json.loads(result.read_text())
                row['self_reported_status'] = data.get('status')
                row['self_reported_mechanism'] = data.get('mechanism')
                row['self_reported_quadratic_cubic_verified'] = data.get('quadratic_cubic_claim_verified')
            except (json.JSONDecodeError, UnicodeDecodeError):
                row['result_read_incomplete'] = True
        records.append(row)
        if row['started']:
            arms[(row['model'],row['reasoning'])].append(row)
    summaries = []
    for (model,effort), rows in sorted(arms.items()):
        finished = [r for r in rows if r['terminal']]
        durations = [r['wall_seconds'] for r in finished if 'wall_seconds' in r]
        summaries.append({'model':model,'reasoning':effort,'started':len(rows),'terminal':len(finished),
                          'terminal_with_parseable_solve':sum(r['source_parses'] and r['has_module_solve'] for r in finished),
                          'terminal_unique_source_hashes':len({r['source_sha256'] for r in finished if r['source_exists']}),
                          'independently_executed_candidates':sum(r['independent_screening'] is not None for r in rows),
                          'terminal_wall_seconds_sum':sum(durations),
                          'terminal_wall_seconds_median':statistics.median(durations) if durations else None})
    report = {'snapshot_utc':datetime.now(timezone.utc).isoformat(),'proposal_target':status.get('proposal_target',100),
              'job_status_counts':dict(Counter(v['status'] for v in status['jobs'].values())),
              'comparison_arms':summaries,'exact_source_duplicates':[{'sha256':h,'jobs':jobs} for h,jobs in sources.items() if len(jobs)>1],
              'records':records,'independent_screening_ledger':screening,
              'limits':['AST parsing and a solve entry point identify potentially runnable code, not correctness or actual successful execution.',
                        'In-progress files may be incomplete; do not score them as terminal failures.',
                        'Self-reported proofs/mechanisms/timings are untrusted claims until reviewed.',
                        'Wall time includes tool/session overhead; job budgets and task families differ.',
                        'Do not infer low effort superiority before comparable completed and independently screened samples.']}
    (here/'pool-yield.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k not in ('records','independent_screening_ledger')},indent=2))


if __name__ == '__main__':
    main()
