"""Independent exhaustive oracle. Does not import any candidate or CNF evaluator."""


def exhaustive(nvars, clauses, max_vars=20):
    if type(nvars) is not int or not 0 <= nvars <= max_vars:
        raise ValueError(f"oracle requires 0 <= nvars <= {max_vars}")
    clauses = tuple(tuple(c) for c in clauses)
    for clause in clauses:
        for literal in clause:
            if type(literal) is not int or not 1 <= abs(literal) <= nvars:
                raise ValueError("invalid signed literal")
    count, first = 0, None
    for bits in range(1 << nvars):
        satisfied = True
        for clause in clauses:
            clause_satisfied = False
            for literal in clause:
                bit = (bits >> (abs(literal) - 1)) & 1
                if (literal > 0 and bit == 1) or (literal < 0 and bit == 0):
                    clause_satisfied = True
                    break
            if not clause_satisfied:
                satisfied = False
                break
        if satisfied:
            count += 1
            if first is None:
                first = [bool((bits >> i) & 1) for i in range(nvars)]
    return {"status": "SAT" if count else "UNSAT", "model_count": count,
            "first_witness": first, "assignments_examined": 1 << nvars}
