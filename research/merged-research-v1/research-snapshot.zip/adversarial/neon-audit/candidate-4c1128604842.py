"""
Mechanism 1 (APIC-1): Coupled F2-Affine-Parity, Implication/Unit, Clique-Counting,
and Depth-1 Affine-Hull Probing SAT Solver (deterministic, standard-library only).

Interface:
    solve(nvars, clauses, budget) -> dict
        status: 'SAT' | 'UNSAT' | 'UNKNOWN'
        assignment: list[bool]  (present iff status == 'SAT')
        operations: dict        (exact operation and bit-work accounting)

Soundness contract:
    - 'SAT' is returned ONLY after directly verifying the assignment against the
      original input clauses.
    - 'UNSAT' is returned ONLY when a sound deduction at decision depth 0
      (empty clause, unit/2-SAT conflict, F2 linear inconsistency 0 = 1,
      valid nonnegative integer/clique counting certificate, or both branches
      of a variable split soundly refuted) succeeds.
    - Budget exhaustion or incomplete fixed-point (no verified witness and no
      sound refutation) ALWAYS returns 'UNKNOWN'.
"""

from collections import defaultdict


class BudgetExceeded(Exception):
    pass


class OpCounter:
    __slots__ = (
        "budget",
        "total",
        "clause_scans",
        "xor_eliminations",
        "xor_bit_ops",
        "implication_steps",
        "clique_steps",
        "probes",
        "witness_checks",
    )

    def __init__(self, budget: int):
        self.budget = budget
        self.total = 0
        self.clause_scans = 0
        self.xor_eliminations = 0
        self.xor_bit_ops = 0
        self.implication_steps = 0
        self.clique_steps = 0
        self.probes = 0
        self.witness_checks = 0

    def charge(self, amount: int, bucket: str) -> None:
        if amount <= 0:
            return
        self.total += amount
        setattr(self, bucket, getattr(self, bucket) + amount)
        if self.total > self.budget:
            raise BudgetExceeded()

    def to_dict(self) -> dict:
        return {
            "budget": self.budget,
            "total": self.total,
            "clause_scans": self.clause_scans,
            "xor_eliminations": self.xor_eliminations,
            "xor_bit_ops": self.xor_bit_ops,
            "implication_steps": self.implication_steps,
            "clique_steps": self.clique_steps,
            "probes": self.probes,
            "witness_checks": self.witness_checks,
        }


class F2System:
    """
    Maintains a system of linear equations over F_2 in reduced row echelon form (RREF).
    Row format: int bitmask where bit (v - 1) is coefficient of variable v (1-based)
    and bit 0 of rhs is stored separately as `rhs` (0 or 1).
    We store `pivots: dict[int, tuple[int, int]]` mapping pivot_bit (highest set bit)
    to (mask, rhs).
    """

    __slots__ = ("nvars", "pivots", "inconsistent")

    def __init__(self, nvars: int, pivots=None, inconsistent: bool = False):
        self.nvars = nvars
        self.pivots = {} if pivots is None else dict(pivots)
        self.inconsistent = inconsistent

    def copy(self) -> "F2System":
        return F2System(self.nvars, self.pivots, self.inconsistent)

    def add_eq(self, mask: int, rhs: int, ops: OpCounter) -> bool:
        """
        Add equation (popcount(mask & x) % 2 == rhs), maintaining STRICT RREF:
          - Every pivot bit p appears ONLY in self.pivots[p] and in NO other row.
        Returns True if the equation was new (changed the basis or triggered inconsistency).
        """
        if self.inconsistent:
            return False
        rhs &= 1
        # Reduce ALL existing pivot bits present in `mask` (strict RREF invariant!)
        rem = mask
        while rem:
            p = rem.bit_length() - 1
            p_bit = 1 << p
            rem ^= p_bit
            row = self.pivots.get(p)
            if row is not None and (mask & p_bit):
                ops.charge(1, "xor_eliminations")
                ops.charge(max(1, (self.nvars + 63) // 64), "xor_bit_ops")
                mask ^= row[0]
                rhs ^= row[1]
        # Because existing rows are in strict RREF, eliminating pivot p only adds non-pivot bits!
        if mask == 0:
            if rhs == 1:
                self.inconsistent = True
                return True
            return False
        # Insert new pivot p (guaranteed not in self.pivots and containing no other pivot bits!)
        p = mask.bit_length() - 1
        p_bit = 1 << p
        for q in list(self.pivots.keys()):
            qm, qr = self.pivots[q]
            if qm & p_bit:
                ops.charge(1, "xor_eliminations")
                ops.charge(max(1, (self.nvars + 63) // 64), "xor_bit_ops")
                self.pivots[q] = (qm ^ mask, qr ^ rhs)
        self.pivots[p] = (mask, rhs)
        return True

    def implied_units_and_equivs(self, ops: OpCounter):
        """
        Extract from RREF:
          - units: dict[var_1based, bool] for rows with popcount == 1
          - equivs: list[(var_hi, var_lo, xor_const)] for rows with popcount == 2
        """
        units = {}
        equivs = []
        for p, (m, r) in self.pivots.items():
            ops.charge(1, "xor_eliminations")
            pc = m.bit_count()
            if pc == 1:
                units[p + 1] = bool(r)
            elif pc == 2:
                other_bit = m ^ (1 << p)
                q = other_bit.bit_length() - 1
                # x_{p+1} XOR x_{q+1} = r  =>  x_{p+1} = x_{q+1} XOR r
                equivs.append((p + 1, q + 1, r))
        return units, equivs

    def is_consistent_with_literals(self, lits, ops: OpCounter) -> bool:
        """
        Check whether the system remains consistent when every literal in `lits`
        is set to its specified truth value (as a temporary probe, without mutating self).
        """
        if self.inconsistent:
            return False
        tmp_pivots = {}
        for lit in lits:
            v = abs(lit) - 1
            m = 1 << v
            r = 1 if lit > 0 else 0
            # Reduce against self.pivots (strict RREF)
            row = self.pivots.get(v)
            if row is not None:
                ops.charge(1, "xor_eliminations")
                ops.charge(max(1, (self.nvars + 63) // 64), "xor_bit_ops")
                m ^= row[0]
                r ^= row[1]
            # Now m contains ONLY free variables of self.pivots; reduce against tmp_pivots
            while m:
                p = m.bit_length() - 1
                trow = tmp_pivots.get(p)
                if trow is None:
                    break
                ops.charge(1, "xor_eliminations")
                ops.charge(max(1, (self.nvars + 63) // 64), "xor_bit_ops")
                m ^= trow[0]
                r ^= trow[1]
            if m == 0:
                if r == 1:
                    return False
            else:
                tmp_pivots[m.bit_length() - 1] = (m, r)
        return True

    def sample_solution(self) -> list[bool]:
        """Return one solution x in {False, True}^nvars of the consistent RREF system."""
        assert not self.inconsistent
        vals = [False] * self.nvars
        # Free variables default to False; pivot variables are determined directly
        # because strict RREF means pivot rows have no other pivot bits set!
        for p, (m, r) in self.pivots.items():
            # Since all non-pivot bits are free and set to False, x_p = r
            vals[p] = bool(r)
        return vals


def affine_hull_equations(sys0: F2System, sys1: F2System, nvars: int, ops: OpCounter):
    """
    Given two consistent F2 systems sys0 (A0 x = b0) and sys1 (A1 x = b1),
    compute a generating set of linear equations satisfied by BOTH affine subspaces
    (i.e. equations defining aff(Sol(sys0) U Sol(sys1))).

    Exact linear-algebra method over F_2:
      Let x0 be a particular solution of sys0, and let B0 be a basis of ker(A0).
      Let x1 be a particular solution of sys1, and let B1 be a basis of ker(A1).
      Then aff(Sol(sys0) U Sol(sys1)) = x0 + span(B0 U B1 U {x0 ^ x1}).
      Its defining equations are c . x = c . x0 for every c in (span(B0 U B1 U {x0 ^ x1}))^perp!
    """
    def particular_and_kernel(sys_f2: F2System):
        # Particular solution (free vars = 0)
        x_part = 0
        for p, (m, r) in sys_f2.pivots.items():
            if r:
                x_part |= 1 << p
        # Kernel basis: for each free variable f, vector has bit f = 1 and bit p = (m_p >> f) & 1
        piv_set = sys_f2.pivots
        kern = []
        for f in range(nvars):
            if f in piv_set:
                continue
            vec = 1 << f
            f_bit = 1 << f
            for p, (m, _) in piv_set.items():
                if m & f_bit:
                    vec |= 1 << p
            kern.append(vec)
        return x_part, kern

    x0, k0 = particular_and_kernel(sys0)
    x1, k1 = particular_and_kernel(sys1)
    gens = k0 + k1
    diff = x0 ^ x1
    if diff:
        gens.append(diff)

    # Compute RREF of gens (each is an nvars-bit vector) -> subspace V of F_2^nvars
    rref = {}
    for v in gens:
        cur = v
        while cur:
            p = cur.bit_length() - 1
            row = rref.get(p)
            if row is None:
                break
            ops.charge(1, "xor_eliminations")
            cur ^= row
        if cur:
            p = cur.bit_length() - 1
            p_bit = 1 << p
            for q in list(rref.keys()):
                if rref[q] & p_bit:
                    ops.charge(1, "xor_eliminations")
                    rref[q] ^= cur
            rref[p] = cur

    # Compute orthogonal complement V^perp: for each non-pivot bit c, build equation vector eq
    eqs = []
    for c in range(nvars):
        if c in rref:
            continue
        eq_mask = 1 << c
        c_bit = 1 << c
        for p, row in rref.items():
            if row & c_bit:
                eq_mask |= 1 << p
        rhs = (eq_mask & x0).bit_count() & 1
        eqs.append((eq_mask, rhs))
    return eqs


def clean_clauses(nvars: int, raw_clauses, ops: OpCounter):
    """
    Validate and normalize clauses:
      - Deduplicate repeated literals within each clause.
      - Drop tautological clauses containing both v and -v.
      - Deduplicate identical clauses.
    Returns (clauses_list, has_empty_clause).
    """
    seen = set()
    cleaned = []
    for raw in raw_clauses:
        ops.charge(max(1, len(raw)), "clause_scans")
        lits = set()
        taut = False
        for lit in raw:
            if type(lit) is not int or lit == 0 or abs(lit) > nvars:
                raise ValueError(f"Invalid literal {lit} for nvars={nvars}")
            if -lit in lits:
                taut = True
                break
            lits.add(lit)
        if taut:
            continue
        if not lits:
            return [()], True
        cl = tuple(sorted(lits, key=lambda x: (abs(x), x)))
        if cl not in seen:
            seen.add(cl)
            cleaned.append(cl)
    return cleaned, False


def simplify_with_substitution(clauses, units: dict[int, bool], equivs: dict[int, tuple[int, int]], ops: OpCounter):
    """
    Apply known unit assignments (var -> bool) and equivalences (var -> (rep_var, xor_bit))
    to clauses. Returns (new_clauses, has_empty_clause, changed).
    """
    seen = set()
    out = []
    changed = False
    for cl in clauses:
        ops.charge(max(1, len(cl)), "clause_scans")
        new_lits = set()
        sat = False
        for lit in cl:
            v = abs(lit)
            pos = lit > 0
            # Apply equivalence substitution first
            if v in equivs:
                rep, xbit = equivs[v]
                v = rep
                if xbit:
                    pos = not pos
                changed = True
            if v in units:
                val = units[v]
                if val == pos:
                    sat = True
                    changed = True
                    break
                else:
                    changed = True
                    continue
            nlit = v if pos else -v
            if -nlit in new_lits:
                sat = True
                changed = True
                break
            new_lits.add(nlit)
        if sat:
            continue
        if not new_lits:
            return [()], True, True
        ncl = tuple(sorted(new_lits, key=lambda x: (abs(x), x)))
        if ncl != cl:
            changed = True
        if ncl not in seen:
            seen.add(ncl)
            out.append(ncl)
    if len(out) != len(clauses):
        changed = True
    return out, False, changed


def extract_parity_equations(clauses, f2: F2System, ops: OpCounter) -> bool:
    """
    Sound exact parity extraction:
    Group clauses of width k <= 6 by their sorted variable tuple V = (v_1, ..., v_k).
    A set of 2^(k-1) distinct clauses on V whose falsified assignments all have the
    SAME parity p (so every assignment with parity p is forbidden) implies:
        x_{v_1} XOR ... XOR x_{v_k} = 1 - p.
    More generally, if a subset of clauses on V forbids ALL assignments with parity p,
    the parity equation holds! (Checked exactly for k <= 6; handles Tseitin of degree <= 6.)
    """
    by_vars = defaultdict(list)
    for cl in clauses:
        k = len(cl)
        if 1 <= k <= 6:
            ops.charge(k, "clause_scans")
            vs = tuple(abs(l) for l in cl)
            by_vars[vs].append(cl)

    changed = False
    for vs, cls in by_vars.items():
        k = len(vs)
        need = 1 << (k - 1)
        if len(cls) < need:
            continue
        # Each clause forbids exactly one assignment to `vs`:
        # literal +v is falsified by 0, literal -v is falsified by 1.
        forb_even = set()
        forb_odd = set()
        for cl in cls:
            ops.charge(k, "clause_scans")
            pat = 0
            parity = 0
            for idx, lit in enumerate(cl):
                if lit < 0:
                    pat |= 1 << idx
                    parity ^= 1
            if parity == 0:
                forb_even.add(pat)
            else:
                forb_odd.add(pat)
        mask = 0
        for v in vs:
            mask |= 1 << (v - 1)
        if len(forb_even) == need:
            # All even-parity assignments forbidden => XOR == 1
            if f2.add_eq(mask, 1, ops):
                changed = True
                if f2.inconsistent:
                    return True
        if len(forb_odd) == need:
            # All odd-parity assignments forbidden => XOR == 0
            if f2.add_eq(mask, 0, ops):
                changed = True
                if f2.inconsistent:
                    return True
    return changed


def analyze_binary_implications(nvars: int, clauses, f2: F2System, ops: OpCounter) -> bool:
    """
    2-SAT implication graph analysis (Tarjan SCC):
      - Every binary clause (a v b) yields edges (~a -> b) and (~b -> a).
      - If v and ~v lie in the same SCC => UNSAT (mark f2.inconsistent).
      - If a and b lie in the same SCC => exact equivalence a == b (added to f2!).
      - If ~a reaches a => forced unit a = True (added to f2!).
    """
    # Literal encoding: lit -> node index in 0..2*nvars-1
    # +v -> 2*(v-1), -v -> 2*(v-1)+1
    def lit_node(lit: int) -> int:
        return 2 * (abs(lit) - 1) + (0 if lit > 0 else 1)

    def node_lit(u: int) -> int:
        v = (u // 2) + 1
        return v if (u % 2 == 0) else -v

    adj = defaultdict(list)
    active_nodes = set()
    for cl in clauses:
        if len(cl) == 2:
            a, b = cl
            na, nb = lit_node(a), lit_node(b)
            nna, nnb = na ^ 1, nb ^ 1
            adj[nna].append(nb)
            adj[nnb].append(na)
            active_nodes.update((na, nb, nna, nnb))
            ops.charge(2, "implication_steps")

    if not active_nodes:
        return False

    # Iterative Tarjan SCC over active_nodes
    index_counter = 0
    indices = {}
    lowlink = {}
    on_stack = set()
    stack = []
    comp_id = {}
    comps = []

    for start in sorted(active_nodes):
        if start in indices:
            continue
        call_stack = [(start, 0)]
        indices[start] = lowlink[start] = index_counter
        index_counter += 1
        stack.append(start)
        on_stack.add(start)
        while call_stack:
            u, ei = call_stack[-1]
            nbrs = adj.get(u, ())
            if ei < len(nbrs):
                call_stack[-1] = (u, ei + 1)
                w = nbrs[ei]
                ops.charge(1, "implication_steps")
                if w not in indices:
                    indices[w] = lowlink[w] = index_counter
                    index_counter += 1
                    stack.append(w)
                    on_stack.add(w)
                    call_stack.append((w, 0))
                elif w in on_stack:
                    if indices[w] < lowlink[u]:
                        lowlink[u] = indices[w]
            else:
                call_stack.pop()
                if call_stack:
                    parent = call_stack[-1][0]
                    if lowlink[u] < lowlink[parent]:
                        lowlink[parent] = lowlink[u]
                if lowlink[u] == indices[u]:
                    cid = len(comps)
                    comp = []
                    while True:
                        w = stack.pop()
                        on_stack.remove(w)
                        comp_id[w] = cid
                        comp.append(w)
                        if w == u:
                            break
                    comps.append(comp)

    changed = False
    # Check conflicts and equivalences within each SCC
    for comp in comps:
        if len(comp) < 2:
            continue
        rep_lit = node_lit(comp[0])
        rep_v = abs(rep_lit)
        rep_pos = rep_lit > 0
        for u in comp[1:]:
            lit = node_lit(u)
            v = abs(lit)
            pos = lit > 0
            if v == rep_v:
                # Same variable and opposite polarity in same SCC => UNSAT!
                f2.inconsistent = True
                return True
            # lit == rep_lit  <=>  x_v XOR x_{rep_v} = (pos != rep_pos)
            mask = (1 << (v - 1)) | (1 << (rep_v - 1))
            rhs = 1 if (pos != rep_pos) else 0
            if f2.add_eq(mask, rhs, ops):
                changed = True
                if f2.inconsistent:
                    return True

    # Check direct forced units via reachability on the tiny condensation DAG?
    # Note: in a 2-SAT implication graph, if ~a reaches a, then a MUST be True!
    # Check reachability only for active variables (fast bitset DP on SCC DAG in reverse topo order).
    n_comps = len(comps)
    dag_adj = [set() for _ in range(n_comps)]
    for u in active_nodes:
        cu = comp_id[u]
        for w in adj.get(u, ()):
            cw = comp_id[w]
            if cu != cw:
                dag_adj[cu].add(cw)
    # Tarjan produces SCCs in reverse topological order (sinks first: index 0..n_comps-1)
    reach = [1 << c for c in range(n_comps)]
    for c in range(n_comps):
        r = reach[c]
        for nxt in dag_adj[c]:
            ops.charge(1, "implication_steps")
            r |= reach[nxt]
        reach[c] = r

    checked_vars = {u // 2 for u in active_nodes}
    for v0 in checked_vars:
        pos_u = 2 * v0
        neg_u = 2 * v0 + 1
        cp, cn = comp_id[pos_u], comp_id[neg_u]
        if (reach[cn] >> cp) & 1:
            # ~v -> v => v = True
            if f2.add_eq(1 << v0, 1, ops):
                changed = True
                if f2.inconsistent:
                    return True
        if (reach[cp] >> cn) & 1:
            # v -> ~v => v = False
            if f2.add_eq(1 << v0, 0, ops):
                changed = True
                if f2.inconsistent:
                    return True
    return changed


def clique_counting_refutation(clauses, ops: OpCounter) -> bool:
    """
    Sound integer/counting refutation for pigeonhole / at-most-one / at-least-one blocks
    (avoids characteristic-2 cancellation over F_2!).

    Build the binary conflict graph on literals: an edge (a, b) exists iff (~a v ~b) is a clause.
    Any clique K in this graph implies sum_{lit in K} val(lit) <= 1.
    Any clause C implies sum_{lit in C} val(lit) >= 1.
    If there exists a set of pairwise-disjoint clauses P_1, ..., P_m and a set of cliques
    K_1, ..., K_h such that:
      - every literal occurrence in union(P_i) is covered by at least one K_j (i.e. each literal
        lit in P_1 U ... U P_m appears in at least as many K_j as P_i), AND
      - m > h,
    then summing sum_{i=1}^m (sum_{lit in P_i} val(lit)) >= m
    and summing sum_{j=1}^h (sum_{lit in K_j} val(lit)) <= h
    yields m <= h, a sound UNSAT refutation!

    We check this efficiently by partitioning all literals occurring in disjoint positive/general
    at-least-one clauses into greedy cliques of the binary conflict graph.
    """
    # Build conflict adjacency: conflict[lit] = set of lits l2 such that (-lit, -l2) is a binary clause
    conflict = defaultdict(set)
    for cl in clauses:
        if len(cl) == 2:
            a, b = cl
            conflict[-a].add(-b)
            conflict[-b].add(-a)
            ops.charge(2, "clique_steps")
    if not conflict:
        return False

    # Collect candidate at-least-one clauses whose literals all appear in conflict graph
    # Prefer pairwise-disjoint clauses (e.g. pigeon clauses in PHP(m,n)!)
    cand_clauses = [cl for cl in clauses if len(cl) >= 2 and all(l in conflict for l in cl)]
    if len(cand_clauses) < 2:
        return False

    # Sort by length ascending to greedily pack pairwise-disjoint at-least-one clauses
    cand_clauses.sort(key=len)
    disjoint_pls = []
    used_lits = set()
    for cl in cand_clauses:
        ops.charge(len(cl), "clique_steps")
        if all(l not in used_lits for l in cl):
            disjoint_pls.append(cl)
            used_lits.update(cl)

    m = len(disjoint_pls)
    if m < 2:
        return False

    # Greedily cover `used_lits` by cliques in `conflict` (every literal l in a clique K
    # must conflict with every other literal in K).
    # Order literals by highest conflict degree within `used_lits` first.
    rem = set(used_lits)
    cliques = []
    while rem:
        # Pick literal with max degree inside rem
        best = max(rem, key=lambda l: len(conflict[l] & rem))
        clique = [best]
        cands = sorted(conflict[best] & rem, key=lambda l: -len(conflict[l] & rem))
        for u in cands:
            ops.charge(len(clique), "clique_steps")
            if all(u in conflict[w] for w in clique):
                clique.append(u)
        cliques.append(clique)
        for u in clique:
            rem.remove(u)

    h = len(cliques)
    # Soundness check:
    # 1. All clauses in disjoint_pls are pairwise disjoint => each lit in used_lits has coeff 1 on LHS.
    # 2. Cliques partition used_lits => each lit in used_lits has coeff 1 on RHS.
    # 3. Every clique K is a verified clique in conflict => sum_{l in K} l <= 1.
    # 4. Every clause P in disjoint_pls => sum_{l in P} l >= 1.
    # Therefore m <= sum_{l in used_lits} l <= h. If m > h => SOUND UNSAT!
    if m > h:
        # Double-check clique validity defensively before returning True
        for K in cliques:
            for i in range(len(K)):
                for j in range(i + 1, len(K)):
                    if K[j] not in conflict[K[i]]:
                        return False
        return True
    return False


def close_state(nvars: int, clauses, f2: F2System, ops: OpCounter):
    """
    Fixed-point closure under:
      1. Unit extraction from clauses -> F2
      2. Exact parity extraction (widths <= 6) -> F2
      3. Binary implication SCC & forced units -> F2
      4. F2 RREF -> unit & equivalence substitution into clauses
      5. F2 clause consistency check (detects clauses whose negation is F2-inconsistent
         or clauses forced by F2 to drop literals!)
      6. Clique-counting refutation (PHP / cardinality)
    Returns (clauses, f2, unsat: bool).
    """
    if f2.inconsistent:
        return [()], f2, True

    while True:
        progress = False

        # 1. Absorb unit clauses into F2
        for cl in clauses:
            if len(cl) == 0:
                f2.inconsistent = True
                return [()], f2, True
            if len(cl) == 1:
                lit = cl[0]
                if f2.add_eq(1 << (abs(lit) - 1), 1 if lit > 0 else 0, ops):
                    progress = True
                    if f2.inconsistent:
                        return [()], f2, True

        # 2. Extract units and equivalences from F2 and substitute into clauses
        units, equiv_list = f2.implied_units_and_equivs(ops)
        equiv_map = {v_hi: (v_lo, xbit) for v_hi, v_lo, xbit in equiv_list}
        if units or equiv_map:
            clauses, has_empty, sub_changed = simplify_with_substitution(clauses, units, equiv_map, ops)
            if has_empty:
                f2.inconsistent = True
                return [()], f2, True
            if sub_changed:
                progress = True
                continue  # re-absorb any newly created unit clauses immediately

        # 3. Extract exact parity equations from clause groups
        if extract_parity_equations(clauses, f2, ops):
            if f2.inconsistent:
                return [()], f2, True
            progress = True
            continue

        # 4. 2-SAT implication graph SCC + forced units
        if analyze_binary_implications(nvars, clauses, f2, ops):
            if f2.inconsistent:
                return [()], f2, True
            progress = True
            continue

        # 5. Check clauses against F2 basis:
        #    If for clause C = (l1 v ... v lk), negating ALL literals of C is F2-inconsistent,
        #    then C is already implied by F2 (can drop C).
        #    If for some literal l_i, negating all OTHER literals + l_i? Wait: if negating
        #    all literals EXCEPT l_i is F2-inconsistent? No: if negating l_i alone is F2-inconsistent,
        #    l_i is already a unit in F2 (caught in step 2). If negating ALL literals of C is
        #    inconsistent, C is redundant modulo F2.
        #    Also: if for a binary/ternary clause C, setting ALL literals of C to False except one
        #    is F2-inconsistent? Wait: that's NOT enough to force that literal; what DOES force
        #    a unit/shrinking is if l_i = True is F2-inconsistent (already caught by step 2),
        #    OR if for every assignment satisfying F2, l_1=0 & ... & l_k=0 is impossible (redundant).
        if f2.pivots and clauses:
            kept = []
            dropped = False
            for cl in clauses:
                if len(cl) <= 6 and not f2.is_consistent_with_literals([-l for l in cl], ops):
                    dropped = True
                else:
                    kept.append(cl)
            if dropped:
                clauses = kept
                progress = True

        # 6. Clique-counting refutation (catches PHP and at-most-one/at-least-one systems!)
        if clique_counting_refutation(clauses, ops):
            f2.inconsistent = True
            return [()], f2, True

        if not progress:
            break

    return clauses, f2, False


def depth1_affine_probe(nvars: int, clauses, f2: F2System, ops: OpCounter):
    """
    Depth-1 lookahead with Affine-Hull Join (APIC-1):
    For each active variable v (appearing in clauses or non-unit in f2):
      - Branch 0: close_state(clauses, f2 + (x_v = 0))
      - Branch 1: close_state(clauses, f2 + (x_v = 1))
      - If BOTH branches are UNSAT => SOUND UNSAT!
      - If ONE branch is UNSAT => assert the opposite value permanently into f2!
      - If BOTH branches survive => compute aff(Sol(f2_0) U Sol(f2_1)) and add all
        shared linear equations (units, equivalences, AND multi-variable parities!) to f2!
    Repeats until no new equations are discovered (at most nvars+1 rank increases!).
    """
    while True:
        clauses, f2, unsat = close_state(nvars, clauses, f2, ops)
        if unsat or not clauses:
            return clauses, f2, unsat

        active_vars = sorted({abs(l) for cl in clauses for l in cl})
        learned = False
        for v in active_vars:
            ops.charge(1, "probes")
            # Branch 0: x_v = 0
            f2_0 = f2.copy()
            f2_0.add_eq(1 << (v - 1), 0, ops)
            _, f2_0, unsat0 = close_state(nvars, clauses, f2_0, ops)

            # Branch 1: x_v = 1
            f2_1 = f2.copy()
            f2_1.add_eq(1 << (v - 1), 1, ops)
            _, f2_1, unsat1 = close_state(nvars, clauses, f2_1, ops)

            if unsat0 and unsat1:
                f2.inconsistent = True
                return [()], f2, True
            if unsat0:
                if f2.add_eq(1 << (v - 1), 1, ops):
                    learned = True
                # Also absorb all equations of f2_1!
                for _, (m, r) in f2_1.pivots.items():
                    if f2.add_eq(m, r, ops):
                        learned = True
                if f2.inconsistent:
                    return [()], f2, True
                break
            if unsat1:
                if f2.add_eq(1 << (v - 1), 0, ops):
                    learned = True
                for _, (m, r) in f2_0.pivots.items():
                    if f2.add_eq(m, r, ops):
                        learned = True
                if f2.inconsistent:
                    return [()], f2, True
                break

            # Both branches survived: harvest shared affine-hull equations!
            # Only worthwhile if either branch gained rank over f2
            if len(f2_0.pivots) > len(f2.pivots) and len(f2_1.pivots) > len(f2.pivots):
                shared_eqs = affine_hull_equations(f2_0, f2_1, nvars, ops)
                for m, r in shared_eqs:
                    if f2.add_eq(m, r, ops):
                        learned = True
                if learned:
                    if f2.inconsistent:
                        return [()], f2, True
                    break

        if not learned:
            return clauses, f2, False


def verify_assignment(nvars: int, raw_clauses, assignment: list[bool], ops: OpCounter) -> bool:
    if len(assignment) != nvars:
        return False
    for cl in raw_clauses:
        ops.charge(max(1, len(cl)), "witness_checks")
        if not any(assignment[abs(lit) - 1] == (lit > 0) for lit in cl):
            return False
    return True


def solve(nvars: int, clauses: list[list[int]], budget: int) -> dict:
    """
    Required candidate interface.
    """
    if type(nvars) is not int or nvars < 0:
        raise ValueError("nvars must be a nonnegative integer")
    if type(budget) is not int or budget <= 0:
        raise ValueError("budget must be a positive integer")

    ops = OpCounter(budget)

    try:
        cleaned, has_empty = clean_clauses(nvars, clauses, ops)
        if has_empty:
            return {"status": "UNSAT", "operations": ops.to_dict()}
        if not cleaned:
            asgn = [False] * nvars
            assert verify_assignment(nvars, clauses, asgn, ops)
            return {"status": "SAT", "assignment": asgn, "operations": ops.to_dict()}

        # Phase 1: Sound depth-0 + depth-1 APIC-1 global closure
        f2 = F2System(nvars)
        rem_clauses, f2, unsat = depth1_affine_probe(nvars, cleaned, f2, ops)
        if unsat:
            return {"status": "UNSAT", "operations": ops.to_dict()}

        # If all clauses are eliminated modulo F2, sample an exact solution of F2!
        if not rem_clauses:
            asgn = f2.sample_solution()
            if verify_assignment(nvars, clauses, asgn, ops):
                return {"status": "SAT", "assignment": asgn, "operations": ops.to_dict()}
            return {"status": "UNKNOWN", "operations": ops.to_dict()}

        # Phase 2: Deterministic greedy self-reduction guided by APIC-1 (NO exponential backtracking!)
        # If greedy self-reduction reaches a verified model => SOUND SAT.
        # If it hits a contradiction after making an unproved choice => UNKNOWN (never unproved UNSAT!).
        cur_clauses = rem_clauses
        cur_f2 = f2.copy()
        while cur_clauses:
            # Pick first active variable
            active = sorted({abs(l) for cl in cur_clauses for l in cl})
            v = active[0]
            # Try value 0 first under APIC-1; if refuted, try 1; if both refuted after a guess => UNKNOWN
            chosen = False
            for val in (0, 1):
                ops.charge(1, "probes")
                cand_f2 = cur_f2.copy()
                cand_f2.add_eq(1 << (v - 1), val, ops)
                cand_clauses, cand_f2, cand_unsat = depth1_affine_probe(nvars, cur_clauses, cand_f2, ops)
                if not cand_unsat:
                    cur_clauses, cur_f2 = cand_clauses, cand_f2
                    chosen = True
                    break
            if not chosen:
                return {"status": "UNKNOWN", "operations": ops.to_dict()}

        asgn = cur_f2.sample_solution()
        if verify_assignment(nvars, clauses, asgn, ops):
            return {"status": "SAT", "assignment": asgn, "operations": ops.to_dict()}
        return {"status": "UNKNOWN", "operations": ops.to_dict()}

    except BudgetExceeded:
        return {"status": "UNKNOWN", "operations": ops.to_dict()}
