"""Adapter for the reviewed, frozen Neon snapshot with a known affine-hull bug."""
import importlib.util
from pathlib import Path
SOURCE = Path(__file__).resolve().parent / "neon-audit" / "candidate-4c1128604842.py"
spec = importlib.util.spec_from_file_location("frozen_neon_candidate", SOURCE)
native = importlib.util.module_from_spec(spec)
spec.loader.exec_module(native)


def solve(nvars, clauses, budget):
    limit = budget.maximum if budget.maximum is not None else 10000000
    if limit == 0:
        return {"status": "UNKNOWN", "reason": "zero operation budget"}
    result = native.solve(nvars, clauses, limit)
    count = result.get("operations", {}).get("total", 0)
    budget.tick("prototype_reported_operations", count)
    return result
