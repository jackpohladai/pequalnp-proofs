"""Independent bit-vector audit of every existential projection stage."""
import argparse
import hashlib
import json
from pathlib import Path
import time
from residual_dag_wrapper import native, SOURCE


def audit(row, order, node_cap):
    nvars = row["nvars"]
    all_ones = (1 << (1 << nvars)) - 1
    low = {v: all_ones // ((1 << (1 << (v-1))) + 1) for v in range(1, nvars+1)}
    def literal(lit):
        return (all_ones ^ low[lit]) if lit > 0 else low[-lit]
    truth = all_ones
    for clause in row["clauses"]:
        clause_truth = 0
        for lit in clause:
            clause_truth |= literal(lit)
        truth &= clause_truth
    assert truth.bit_count() == row["oracle"]["model_count"]
    dag, vectors = native.DAG(), []
    def semantic(node):
        if len(dag.nodes) > node_cap:
            raise RuntimeError(f"node cap {node_cap} exceeded")
        for i in range(len(vectors), len(dag.nodes)):
            kind, data = dag.nodes[i]
            if kind == "const":
                value = all_ones if data else 0
            elif kind == "lit":
                value = literal(data)
            else:
                assert kind in ("and", "or")
                assert all(0 <= child < i for child in data), "DAG acyclicity violated"
                value = all_ones if kind == "and" else 0
                for child in data:
                    value = value & vectors[child] if kind == "and" else value | vectors[child]
            vectors.append(value)
        return vectors[node]
    root = dag.cnf(row["clauses"])
    assert semantic(root) == truth, "CNF construction changed the function"
    for var in order:
        # Quantify the truth table directly; no candidate evaluator is used.
        shift = 1 << (var-1)
        base = (truth & low[var]) | ((truth >> shift) & low[var])
        truth = base | (base << shift)
        root = dag.forget(root, var)
        assert semantic(root) == truth, f"existential projection mismatch at variable {var}"
    assert root in (0, 1), "full projection is syntactically nonconstant"
    assert (root == 1) == (row["oracle"]["status"] == "SAT")
    return {"case": row["id"], "order": order, "stages": len(order)+1,
            "allocated_nodes": len(dag.nodes), "factor_steps": dag.factor_steps}


def main():
    here = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--node-cap", type=int, default=100000)
    parser.add_argument("--output", default=str(here / "residual-dag-audit.json"))
    args = parser.parse_args()
    encoded = (here / "corpus" / "corpus.jsonl").read_bytes()
    manifest = json.loads((here / "corpus" / "manifest.json").read_text())
    assert hashlib.sha256(encoded).hexdigest() == manifest["sha256"]
    checks, failures = [], []
    start = time.monotonic()
    for line in encoded.splitlines():
        row = json.loads(line)
        order = list(range(1, row["nvars"]+1))
        orders = [order, list(reversed(order))] if len(order) > 1 else [order]
        for selected in orders:
            try:
                checks.append(audit(row, selected, args.node_cap))
            except Exception as exc:
                failures.append({"case": row["id"], "order": selected,
                                 "error": f"{type(exc).__name__}: {exc}"})
                break
        if failures:
            break
    report = {"candidate_source": str(SOURCE),
              "candidate_sha256": hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
              "corpus_sha256": manifest["sha256"], "cases_in_corpus": manifest["cases"],
              "case_orders_completed": len(checks), "stages_checked": sum(x["stages"] for x in checks),
              "max_allocated_nodes": max(x["allocated_nodes"] for x in checks),
              "failures": failures, "elapsed_seconds": time.monotonic()-start,
              "scope": "Exact full truth tables at every projection stage, ascending/descending orders. Finite test, no complexity conclusion.",
              "checks": checks}
    Path(args.output).write_text(json.dumps(report, indent=2)+"\n")
    print(json.dumps({k:v for k,v in report.items() if k != "checks"}, indent=2))
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
