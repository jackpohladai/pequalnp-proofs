"""Small deterministic generators, independent of any candidate algorithm."""
import itertools
import random
from cnf import CNF


def tseitin(vertices, edges, charges):
    """Incident-edge XOR equals charge at every vertex, encoded as CNF."""
    if len(charges) != vertices or any(x not in (0, 1) for x in charges):
        raise ValueError("one Boolean charge per vertex is required")
    normalized = [tuple(sorted(e)) for e in edges]
    if len(set(normalized)) != len(edges) or any(
            len(e) != 2 or not 0 <= e[0] < e[1] < vertices for e in normalized):
        raise ValueError("expected a simple undirected graph")
    clauses = []
    for v in range(vertices):
        incident = [i + 1 for i, edge in enumerate(normalized) if v in edge]
        for bits in itertools.product((0, 1), repeat=len(incident)):
            if sum(bits) % 2 != charges[v]:
                # This clause excludes exactly this wrong-parity assignment.
                clauses.append(tuple(-x if b else x for x, b in zip(incident, bits)))
    return CNF.from_tuples(len(edges), clauses)


def pigeonhole(pigeons, holes, functional=False):
    if pigeons < 0 or holes < 0:
        raise ValueError("negative pigeonhole parameter")
    def var(p, h):
        return 1 + p * holes + h
    clauses = [tuple(var(p, h) for h in range(holes)) for p in range(pigeons)]
    for h in range(holes):
        for p, q in itertools.combinations(range(pigeons), 2):
            clauses.append((-var(p, h), -var(q, h)))
    if functional:
        for p in range(pigeons):
            for h, k in itertools.combinations(range(holes), 2):
                clauses.append((-var(p, h), -var(p, k)))
    return CNF.from_tuples(pigeons * holes, clauses)


def random_3cnf(nvars, nclauses, seed, planted=None):
    if nvars < 3:
        raise ValueError("3-CNF generator needs at least 3 variables")
    rng = random.Random(seed)
    clauses = []
    for _ in range(nclauses):
        variables = rng.sample(range(1, nvars + 1), 3)
        clause = [v if rng.randrange(2) else -v for v in variables]
        if planted is not None and not any(bool(planted[abs(x)-1]) == (x > 0) for x in clause):
            j = rng.randrange(3)
            clause[j] = -clause[j]
        clauses.append(tuple(clause))
    return CNF.from_tuples(nvars, clauses)


def cases():
    # Every subset of the nine canonical, non-tautological clauses over 2 variables.
    # Repeated clauses/literals are covered separately because these are syntactic tests.
    atoms = [(), (-1,), (1,), (-2,), (2,), (-1, -2), (-1, 2), (1, -2), (1, 2)]
    for mask in range(1 << len(atoms)):
        yield f"exhaustive2-{mask:03d}", "exhaustive2", CNF.from_tuples(
            2, [c for i, c in enumerate(atoms) if mask >> i & 1]), {}
    edge_cases = [
        ("empty-zero-vars", 0, []), ("false-zero-vars", 0, [()]),
        ("isolated-empty", 8, []), ("isolated-unit", 12, [(1,)]),
        ("isolated-conflict", 12, [(1,), (-1,)]),
        ("sparse-high-index", 16, [(16,), (-1, 16)]),
        ("sparse-high-index-conflict", 16, [(16,), (-16,)]),
        ("tautology", 3, [(1, -1)]), ("duplicate-literal", 3, [(2, 2, 2), (-2,)]),
        ("duplicate-clause", 4, [(1, 2), (1, 2), (-1,), (-2,)]),
        ("isolated-last", 8, [(1, -2, 3), (-3, 4), (4,)]),
    ]
    for name, nvars, clauses in edge_cases:
        yield name, "edge-cases", CNF.from_tuples(nvars, clauses), {}
    graphs = {
        "K4": (4, list(itertools.combinations(range(4), 2))),
        "K33": (6, [(a, b) for a in range(3) for b in range(3, 6)]),
        "cube": (8, [(v, v ^ (1 << b)) for v in range(8) for b in range(3)
                      if v < v ^ (1 << b)]),
        "cycle5": (5, [(i, (i + 1) % 5) for i in range(5)]),
    }
    for name, (vertices, edges) in graphs.items():
        for charge_vertices in [(), (0,), (0, 1)]:
            charges = [int(v in charge_vertices) for v in range(vertices)]
            expected = "UNSAT" if sum(charges) % 2 else "SAT"
            yield f"tseitin-{name}-{'-'.join(map(str,charge_vertices)) or 'zero'}", \
                "tseitin", tseitin(vertices, edges, charges), {
                    "vertices": vertices, "edges": edges, "charges": charges,
                    "expected_by_construction": expected}
    for vertices, edges, charges in [(1, [], [0]), (1, [], [1]),
                                      (4, [(0, 1), (2, 3)], [1, 0, 1, 0])]:
        yield f"tseitin-disconnected-{vertices}-{''.join(map(str,charges))}", \
            "tseitin", tseitin(vertices, edges, charges), {
                "vertices": vertices, "edges": edges, "charges": charges,
                "expected_by_construction": "SAT" if not any(charges) else "UNSAT"}
    for p, h in [(0, 0), (1, 0), (2, 1), (2, 2), (3, 2), (3, 3), (4, 3)]:
        for functional in [False, True]:
            yield f"php-{p}-{h}-{'functional' if functional else 'ordinary'}", \
                "pigeonhole", pigeonhole(p, h, functional), {
                    "pigeons": p, "holes": h, "functional": functional,
                    "expected_by_construction": "SAT" if p <= h else "UNSAT"}
    for nvars in [3, 4, 5, 6, 7, 8]:
        for ratio in [1, 4, 6]:
            for variant in range(2):
                seed = 10000 + 100 * nvars + 10 * ratio + variant
                yield f"random3-{nvars}-{ratio}-{variant}", "random3", \
                    random_3cnf(nvars, nvars * ratio, seed), {"seed": seed}
        seed = 20000 + nvars
        assignment = [bool((i + nvars) % 3) for i in range(nvars)]
        yield f"planted3-{nvars}", "planted3", \
            random_3cnf(nvars, 4 * nvars, seed, assignment), {
                "seed": seed, "planted_assignment": assignment,
                "expected_by_construction": "SAT"}


def scaled_family(family, size, seed=0):
    """Deterministic larger inputs for a specific later complexity hypothesis."""
    if family == "php":
        return pigeonhole(size + 1, size)
    if family == "random3":
        return random_3cnf(size, 4 * size, seed)
    if family == "planted3":
        return random_3cnf(size, 4 * size, seed, [bool(i % 2) for i in range(size)])
    if family == "isolated":
        return CNF.from_tuples(size, [(1,)]) if size else CNF(0, ())
    raise ValueError("unknown scaled family")
