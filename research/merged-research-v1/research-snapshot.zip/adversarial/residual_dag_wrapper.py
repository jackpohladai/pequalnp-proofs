"""Adapter for the manually reviewed native residual-DAG prototype.

Only counts exposed API calls/child entries, not all Python/set/sort/bit work.
This is a correctness-test adapter, not an asymptotic complexity certificate.
"""
import importlib.util
from pathlib import Path

SOURCE = Path(__file__).resolve().parent.parent / "native-search" / "residual_dag.py"
spec = importlib.util.spec_from_file_location("reviewed_residual_dag", SOURCE)
native = importlib.util.module_from_spec(spec)
spec.loader.exec_module(native)


def solve(nvars, clauses, budget):
    class MeteredDAG(native.DAG):
        def put(self, key):
            budget.tick("node_intern_call")
            return super().put(key)

        def junction(self, op, children):
            children = tuple(children)
            budget.tick("junction_call")
            budget.tick("junction_input_child", len(children))
            return super().junction(op, children)

        def cofactor(self, node, var, value):
            budget.tick("cofactor_call")
            return super().cofactor(node, var, value)

    dag = MeteredDAG()
    root = dag.cnf(clauses)
    for var in range(1, nvars + 1):
        budget.tick("variable_elimination")
        root = dag.forget(root, var)
    if root not in (0, 1):
        return {"status": "ERROR", "reason": "all-variable projection remained nonconstant"}
    return {"status": "SAT" if root == 1 else "UNSAT",
            "operations": {"allocated_nodes": len(dag.nodes),
                           "cofactor_cache_entries": len(dag.cofactor_cache),
                           "factor_steps": dag.factor_steps},
            "accounting_limit": "API/child counters omit hash, set, sort and bit costs"}
