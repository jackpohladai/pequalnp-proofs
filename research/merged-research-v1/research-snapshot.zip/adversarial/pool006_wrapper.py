"""Reviewed frozen pool006 factored ROBDD adapter. Counters are incomplete estimates."""
import importlib.util
from pathlib import Path
SOURCE = Path(__file__).parent / "pool-snapshots" / 'pool006-d6647923a78a.py'
spec=importlib.util.spec_from_file_location("reviewed_pool006", SOURCE)
native=importlib.util.module_from_spec(spec)
spec.loader.exec_module(native)
def solve(nvars, clauses, budget):
    limit=budget.maximum if budget.maximum is not None else 10000000
    if limit == 0:return {"status":"UNKNOWN", "reason":"zero budget"}
    response=native.solve(nvars, clauses, {"max_ops":limit,"max_bit_ops":limit,"max_nodes":max(2,min(limit,100000))})
    budget.tick("candidate_reported_bit_estimate",response.get("operations",{}).get("bit_ops_estimate",0))
    return response
