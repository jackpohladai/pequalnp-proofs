"""Independent guarded-witness, validation and resource-fallback checks."""
import itertools
import json
from pathlib import Path
import random
from cnf import CNF
from meter import Budget, BudgetExceeded
from oracle import exhaustive
from hybrid_snapshot_wrapper import native


def guard_cnf(truth, first):
    return [tuple(-(first+i) if (bits >> i)&1 else first+i for i in range(2))
            for bits in range(4) if not (truth >> bits)&1]


def check(nvars, clauses, **options):
    cnf = CNF.from_tuples(nvars, clauses)
    expected = exhaustive(nvars, clauses)
    response = native.solve_with_options(nvars, clauses, Budget(5000000), seconds=2,
                                         node_limit=30000, **options)
    assert response['status'] == expected['status'], (cnf, expected, response)
    if response['status'] == 'SAT':
        assert cnf.satisfied_by(response.get('assignment')), response
    return response


def main():
    report = {'guarded_formulas':0, 'guarded_conditioned_cases':0,
              'guarded_SAT':0, 'guarded_UNSAT':0, 'preprocessing_used':0,
              'validation_cases':0, 'fallback_checks':[], 'resource_checks':[]}
    rng = random.Random(1826015)
    for rows, holes in [(2,2),(2,3),(3,2)]:
        hidden = rows*holes
        nvars = hidden+2
        for signed in (False, True):
            for pattern in range(16):
                selectors = list(range(1,hidden+1))
                rng.shuffle(selectors)
                grid = [[selectors[i*holes+j] * (-1 if signed and (i+j)%2 else 1)
                         for j in range(holes)] for i in range(rows)]
                truths = [pattern, ((pattern<<1)|(pattern>>3))&15, 6][:holes]
                guards = [guard_cnf(truth, hidden+1) for truth in truths]
                clauses = [tuple(row) for row in grid]
                for j in range(holes):
                    clauses.extend((-grid[a][j],-grid[b][j]) for a,b in itertools.combinations(range(rows),2))
                    for row in grid:
                        clauses.extend((-row[j],*c) for c in guards[j])
                clauses.extend(guard_cnf(15 if pattern%3==0 else pattern|1, hidden+1))
                # Tautologies and repeated clauses may not invalidate a sound match.
                clauses.append((grid[0][0],-grid[0][0]))
                clauses.append(tuple(grid[0]))
                perm = list(range(1,nvars+1))
                rng.shuffle(perm)
                renamed = [tuple((1 if x>0 else -1)*perm[abs(x)-1] for x in c) for c in clauses]
                response = check(nvars,renamed,preprocess_work_limit=20000)
                report['guarded_formulas'] += 1
                report['guarded_'+response['status']] += 1
                report['preprocessing_used'] += int(response['preprocessing']['used'])
                for retained in range(4):
                    conditioned = renamed + [(perm[hidden+i] if (retained>>i)&1 else -perm[hidden+i],)
                                             for i in range(2)]
                    response = check(nvars,conditioned,preprocess_work_limit=20000)
                    report['guarded_conditioned_cases'] += 1
                    report['guarded_'+response['status']] += 1
                    report['preprocessing_used'] += int(response['preprocessing']['used'])
    invalid = [(-1,[]),(True,[]),(1.0,[]),(1,[[0]]),(1,[[True]]),(1,[[1.0]]),
               (1,[['1']]),(1,[[2]]),(1,[[-2]]),(1,[{1}]),(1,'1 0'),(1,['1'])]
    for nvars,clauses in invalid:
        result = native.solve_with_options(nvars,clauses)
        assert result['status'] == 'ERROR', (nvars,clauses,result)
        report['validation_cases'] += 1
    # Force local preprocessing exhaustion. It must discard partial recognition
    # and solve the original CNF, preserving both SAT and UNSAT outcomes.
    for nvars,clauses in [(4,[(1,2),(3,4),(-1,-3),(-2,-4)]),
                          (6,[(1,2),(3,4),(5,6),(-1,-3),(-1,-5),(-3,-5),
                              (-2,-4),(-2,-6),(-4,-6)])]:
        for cap in [0,1,5]:
            result = check(nvars,clauses,preprocess_work_limit=cap)
            assert result['preprocessing']['work_cap_exhausted']
            assert not result['preprocessing']['used']
            report['fallback_checks'].append({'nvars':nvars,'cap':cap,'status':result['status']})
        result = check(nvars,clauses,preprocess=False)
        report['fallback_checks'].append({'nvars':nvars,'preprocess':False,'status':result['status']})
    for options in [dict(seconds=0),dict(node_limit=2)]:
        result = native.solve_with_options(2,[(1,2)],Budget(10000),**options)
        assert result['status'] == 'UNKNOWN'
        report['resource_checks'].append({'options':options,'status':result['status'],'reason':result['reason']})
    try:
        native.solve_with_options(2,[(1,2)],Budget(1))
    except BudgetExceeded:
        report['resource_checks'].append({'global_budget':1,'result':'BudgetExceeded propagated to candidate bridge, which returns UNKNOWN'})
    else:
        raise AssertionError('global budget was not enforced')
    huge = native.solve_with_options(1000001,[])
    assert huge['status'] == 'UNKNOWN'
    report['resource_checks'].append({'nvars':1000001,'status':huge['status'],'reason':huge['reason']})
    report['limits'] = 'All finite checks completed. Counters omit primitive set/hash/sort/bit work; internal caps are cooperative, not hard wall-clock isolation.'
    (Path(__file__).parent/'hybrid-audit'/'targeted-report.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))


if __name__ == '__main__':
    main()
