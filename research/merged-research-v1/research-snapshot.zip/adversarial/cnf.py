"""Strict DIMACS and signed, 1-based literal interfaces; no solver logic."""
from dataclasses import dataclass
from typing import Iterable


@dataclass(frozen=True)
class CNF:
    nvars: int
    clauses: tuple[tuple[int, ...], ...]

    def __post_init__(self):
        if type(self.nvars) is not int or self.nvars < 0:
            raise ValueError("nvars must be a nonnegative integer")
        for clause in self.clauses:
            for literal in clause:
                if type(literal) is not int or not 1 <= abs(literal) <= self.nvars:
                    raise ValueError("literals must be nonzero integers within nvars")

    @classmethod
    def from_tuples(cls, nvars: int, clauses: Iterable[Iterable[int]]):
        return cls(nvars, tuple(tuple(c) for c in clauses))

    def dimacs(self) -> str:
        return f"p cnf {self.nvars} {len(self.clauses)}\n" + "".join(
            " ".join(map(str, (*c, 0))) + "\n" for c in self.clauses
        )

    def metrics(self) -> dict:
        literals = [x for c in self.clauses for x in c]
        return {
            "nvars": self.nvars,
            "referenced_variables": len(set(map(abs, literals))),
            "clauses": len(self.clauses),
            "literal_occurrences": len(literals),
            "literal_index_bits": sum(abs(x).bit_length() + 1 for x in literals),
            "structural_size": self.nvars + len(self.clauses) + len(literals),
            "dimacs_bytes": len(self.dimacs().encode("ascii")),
        }

    def satisfied_by(self, assignment) -> bool:
        if not isinstance(assignment, (tuple, list)) or len(assignment) != self.nvars:
            return False
        if any(type(v) not in (int, bool) or v not in (0, 1) for v in assignment):
            return False
        return all(any(bool(assignment[abs(lit)-1]) == (lit > 0) for lit in c)
                   for c in self.clauses)


def parse_dimacs(text: str) -> CNF:
    header = None
    tokens = []
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("c"):
            continue
        if line.startswith("p"):
            parts = line.split()
            if header is not None or tokens or len(parts) != 4 or parts[:2] != ["p", "cnf"]:
                raise ValueError("expected one p cnf header before all clauses")
            nvars, nclauses = map(int, parts[2:])
            if min(nvars, nclauses) < 0:
                raise ValueError("negative header count")
            header = (nvars, nclauses)
        else:
            if header is None:
                raise ValueError("clause before header")
            tokens.extend(map(int, line.split()))
    if header is None:
        raise ValueError("missing p cnf header")
    clauses, current = [], []
    for token in tokens:
        if token == 0:
            clauses.append(tuple(current))
            current = []
        else:
            current.append(token)
    if current:
        raise ValueError("unterminated clause")
    if len(clauses) != header[1]:
        raise ValueError("clause count differs from header")
    return CNF(header[0], tuple(clauses))
