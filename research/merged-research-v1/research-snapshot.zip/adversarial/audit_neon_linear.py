"""Explicit-source regression audit for reviewed Neon F2 helpers only.

Does not import the full candidate. Executes four manually reviewed definitions
selected by AST. Review a changed source before choosing it with --source.
"""
import argparse
import ast
import hashlib
import itertools
import json
from pathlib import Path


def points(n, equations):
    return {x for x in range(1 << n)
            if all((m & x).bit_count() % 2 == r for m, r in equations)}


def audit(source):
    encoded = source.read_bytes()
    names = {"BudgetExceeded", "OpCounter", "F2System", "affine_hull_equations"}
    selected = ast.Module(body=[node for node in ast.parse(encoded).body
                               if isinstance(node, (ast.ClassDef, ast.FunctionDef)) and node.name in names],
                          type_ignores=[])
    namespace = {}
    exec(compile(selected, str(source) + " (selected reviewed definitions)", "exec"), namespace)
    F, O, hull = [namespace[k] for k in ["F2System", "OpCounter", "affine_hull_equations"]]
    report = {"source": str(source.resolve()), "sha256": hashlib.sha256(encoded).hexdigest(),
              "method": "Independent enumeration of affine point sets and equation systems",
              "rref_sequences_checked": 0, "rref_failure_count": 0, "rref_examples": [],
              "hull_pairs_checked": 0, "hull_failure_count": 0, "hull_examples": []}
    report.update(consistent_insertion_orders_checked=0, consistent_insertion_prefixes_checked=0,
                  consistent_insertion_failures=0, consistent_insertion_examples=[])
    for equations in itertools.product([(m, r) for m in range(8) for r in (0, 1)], repeat=3):
        fs, ops = F(3), O(10**9)
        for m, r in equations:
            fs.add_eq(m, r, ops)
        expected = points(3, equations)
        actual = set() if fs.inconsistent else points(3, fs.pivots.values())
        sample = None if fs.inconsistent else fs.sample_solution()
        sample_bits = None if sample is None else sum(int(x) << i for i, x in enumerate(sample))
        reduced = all((mask >> pivot) & 1 and all(not ((mask >> other) & 1)
                                                for other in fs.pivots if other != pivot)
                      for pivot, (mask, _) in fs.pivots.items())
        report['rref_sequences_checked'] += 1
        if actual != expected or (expected and (sample_bits not in expected or not reduced)):
            report['rref_failure_count'] += 1
            if len(report['rref_examples']) < 3:
                report['rref_examples'].append({'equations': equations, 'pivots': fs.pivots,
                                                'sample': sample, 'expected_points': sorted(expected)})
    for n in [2, 3]:
        spaces = []
        for subset in range(1, 1 << (1 << n)):
            pts = {x for x in range(1 << n) if subset >> x & 1}
            base = min(pts)
            direction = {x ^ base for x in pts}
            if not all(a ^ b in direction for a in direction for b in direction):
                continue
            equations = [(m, (m & base).bit_count() % 2) for m in range(1, 1 << n)
                         if len({(m & x).bit_count() % 2 for x in pts}) == 1]
            fs, ops = F(n), O(10**9)
            for m, r in equations:
                fs.add_eq(m, r, ops)
            spaces.append((pts, equations, fs))
            # Every consistent nonzero-equation system is a subset of one of
            # these complete equation sets. Every ordering of such a subset is
            # a prefix of a permutation below (duplicates/zero rows tested above).
            for insertion_order in itertools.permutations(equations):
                trial, trial_ops = F(n), O(10**9)
                prefix = []
                report['consistent_insertion_orders_checked'] += 1
                for m, r in insertion_order:
                    prefix.append((m, r))
                    trial.add_eq(m, r, trial_ops)
                    expected_prefix = points(n, prefix)
                    actual_prefix = set() if trial.inconsistent else points(n, trial.pivots.values())
                    sample = None if trial.inconsistent else trial.sample_solution()
                    sample_bits = None if sample is None else sum(int(x) << i for i,x in enumerate(sample))
                    strict = all((mask >> pivot) & 1 and all(not ((mask >> other) & 1)
                                 for other in trial.pivots if other != pivot)
                                 for pivot,(mask,_) in trial.pivots.items())
                    report['consistent_insertion_prefixes_checked'] += 1
                    if actual_prefix != expected_prefix or sample_bits not in expected_prefix or not strict:
                        report['consistent_insertion_failures'] += 1
                        if len(report['consistent_insertion_examples']) < 3:
                            report['consistent_insertion_examples'].append({'nvars':n,'prefix':prefix[:],
                                                                           'pivots':trial.pivots.copy()})
        for a, ea, sa in spaces:
            for b, eb, sb in spaces:
                equations = hull(sa, sb, n, O(10**9))
                actual = points(n, equations)
                base = min(a | b)
                direction = {0}
                for x in a | b:
                    direction |= {v ^ x ^ base for v in tuple(direction)}
                expected = {base ^ v for v in direction}
                report['hull_pairs_checked'] += 1
                if actual != expected:
                    report['hull_failure_count'] += 1
                    if len(report['hull_examples']) < 3:
                        report['hull_examples'].append({
                            'nvars': n, 'A_points': sorted(a), 'B_points': sorted(b),
                            'A_equations': ea, 'B_equations': eb,
                            'returned_equations': equations,
                            'expected_hull_points': sorted(expected), 'returned_points': sorted(actual),
                            'valid_union_points_rejected': sorted((a | b) - actual)})
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    result = audit(args.source)
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))
    raise SystemExit(1 if result['rref_failure_count'] or result['hull_failure_count'] or
                     result['consistent_insertion_failures'] else 0)
