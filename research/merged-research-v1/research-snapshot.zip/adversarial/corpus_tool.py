"""Export a corpus case to DIMACS, or independently solve a small DIMACS input."""
import argparse
import json
from pathlib import Path
from cnf import CNF, parse_dimacs
from oracle import exhaustive


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    modes = parser.add_mutually_exclusive_group(required=True)
    modes.add_argument("--export", help="case ID to print as DIMACS")
    modes.add_argument("--oracle", help="DIMACS file to enumerate, at most 20 variables")
    parser.add_argument("--corpus", default=str(Path(__file__).parent / "corpus" / "corpus.jsonl"))
    args = parser.parse_args()
    if args.oracle:
        cnf = parse_dimacs(Path(args.oracle).read_text())
        print(json.dumps({"metrics": cnf.metrics(), "oracle": exhaustive(cnf.nvars, cnf.clauses)}, indent=2))
        return
    for line in Path(args.corpus).read_text().splitlines():
        row = json.loads(line)
        if row['id'] == args.export:
            print(CNF.from_tuples(row['nvars'], row['clauses']).dimacs(), end="")
            return
    parser.error("case ID not found")


if __name__ == '__main__':
    main()
