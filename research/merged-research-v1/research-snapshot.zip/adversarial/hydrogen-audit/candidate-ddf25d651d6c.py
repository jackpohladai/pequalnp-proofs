"""Candidate SAT solver (Hydrogen - Attempt 1: Global F2-Affine + 2-SCC + Canonical Residual Memoization).

Strictly standard-library-only. Returns UNKNOWN if operation budget is exhausted.
Does not claim an asymptotic polynomial worst-case bound without proof.
"""
from __future__ import annotations

from collections import defaultdict, deque


class BudgetExhausted(Exception):
    pass


class OpsTracker:
    def __init__(self, budget: int):
        if type(budget) is not int or budget <= 0:
            raise ValueError("budget must be a positive integer")
        self.budget = budget
        self.parse_ops = 0
        self.lin_ops = 0
        self.scc_ops = 0
        self.reduce_ops = 0
        self.search_nodes = 0
        self.memo_hits = 0

    @property
    def total(self) -> int:
        return self.parse_ops + self.lin_ops + self.scc_ops + self.reduce_ops + self.search_nodes

    def tick(self, bucket: str, amount: int = 1) -> None:
        setattr(self, bucket, getattr(self, bucket) + amount)
        if self.total > self.budget:
            raise BudgetExhausted()

    def report(self) -> dict:
        return {
            "budget": self.budget,
            "total_ops": self.total,
            "parse_ops": self.parse_ops,
            "lin_ops": self.lin_ops,
            "scc_ops": self.scc_ops,
            "reduce_ops": self.reduce_ops,
            "search_nodes": self.search_nodes,
            "memo_hits": self.memo_hits,
        }


class F2System:
    """RREF linear system over F2 on 0-based variables [0..n-1] using Python int bitmasks.

    Row representation: mask has bit i set for var i (0 <= i < n), and bit n set for RHS constant.
    Equation is: parity(mask & ((1 << n) - 1)) == ((mask >> n) & 1).
    """

    def __init__(self, n: int, ops: OpsTracker):
        self.n = n
        self.ops = ops
        self.word_cost = max(1, (n + 63) // 64)
        self.rhs_bit = 1 << n
        self.var_mask = self.rhs_bit - 1
        self.rows: dict[int, int] = {}  # pivot_var -> row_mask (RREF)
        self.pivot_mask = 0
        self.consistent = True

    def clone(self) -> "F2System":
        c = F2System(self.n, self.ops)
        c.rows = dict(self.rows)
        c.pivot_mask = self.pivot_mask
        c.consistent = self.consistent
        self.ops.tick("lin_ops", max(1, len(self.rows)) * self.word_cost)
        return c

    def add_equation(self, mask: int) -> tuple[bool, bool]:
        """Add equation over F2 maintaining strict RREF. Returns (consistent, changed_system)."""
        if not self.consistent:
            return False, False
        m = mask
        # Dynamically reduce against all active pivots present in m
        while True:
            hit = m & self.pivot_mask
            if not hit:
                break
            lsb = hit & -hit
            p = lsb.bit_length() - 1
            m ^= self.rows[p]
            self.ops.tick("lin_ops", self.word_cost)
        vpart = m & self.var_mask
        if vpart == 0:
            if m & self.rhs_bit:
                self.consistent = False
                return False, True
            return True, False
        lsb = vpart & -vpart
        new_p = lsb.bit_length() - 1
        for p in list(self.rows.keys()):
            if (self.rows[p] >> new_p) & 1:
                self.rows[p] ^= m
                self.ops.tick("lin_ops", self.word_cost)
        self.rows[new_p] = m
        self.pivot_mask |= (1 << new_p)
        return True, True

    def extract_implied_le2(self) -> tuple[dict[int, int], list[tuple[int, int, int]]]:
        """Return (units: var->0/1, equivs: [(v_rep, v_pivot, xor_const)]) implied by RREF."""
        units: dict[int, int] = {}
        raw_pairs: list[tuple[int, int, int]] = []
        by_tail: dict[int, tuple[int, int]] = {}
        for p, row in self.rows.items():
            self.ops.tick("lin_ops", self.word_cost)
            rhs = (row >> self.n) & 1
            tail = (row & self.var_mask) ^ (1 << p)
            if tail == 0:
                units[p] = rhs
                continue
            if (tail & (tail - 1)) == 0:
                q = tail.bit_length() - 1
                raw_pairs.append((min(p, q), max(p, q), rhs))
            prev = by_tail.get(tail)
            if prev is None:
                by_tail[tail] = (p, rhs)
            else:
                p0, rhs0 = prev
                raw_pairs.append((min(p, p0), max(p, p0), rhs ^ rhs0))

        # Union-find with parity over all implied 2-variable equivalences
        parent = list(range(self.n))
        parity = [0] * self.n

        def find(x: int) -> tuple[int, int]:
            px = 0
            cur = x
            while parent[cur] != cur:
                px ^= parity[cur]
                cur = parent[cur]
            # Path compression
            root = cur
            cur = x
            acc = px
            while parent[cur] != root:
                nxt = parent[cur]
                old_p = parity[cur]
                parent[cur] = root
                parity[cur] = acc
                acc ^= old_p
                cur = nxt
            return root, px

        for u, v, r in raw_pairs:
            ru, pu = find(u)
            rv, pv = find(v)
            if ru != rv:
                if ru < rv:
                    parent[rv] = ru
                    parity[rv] = pu ^ pv ^ r
                else:
                    parent[ru] = rv
                    parity[ru] = pu ^ pv ^ r
            # Note: if consistent, pu ^ pv == r automatically

        equivs: list[tuple[int, int, int]] = []
        for v in range(self.n):
            if v in units:
                continue
            rv, pv = find(v)
            if rv != v:
                if rv in units:
                    units[v] = units[rv] ^ pv
                else:
                    equivs.append((rv, v, pv))
        return units, equivs

    def solve_any(self) -> list[int]:
        """Return a satisfying assignment [0/1]*n assuming consistent."""
        vals = [0] * self.n
        for p, row in self.rows.items():
            rhs = (row >> self.n) & 1
            # Non-pivot bits default to 0, so vals[p] = rhs
            vals[p] = rhs
        return vals


def _extract_xor_groups(clauses: list[tuple[int, ...]], ops: OpsTracker) -> tuple[list[tuple[int, int]], set[int]]:
    """Detect exact k-XOR blocks (2^(k-1) clauses on k vars of matching parity) for any k >= 2
    with 2^(k-1) <= len(clauses) (so k <= 1 + floor(log2(m)) automatically).
    """
    m = len(clauses)
    max_k = m.bit_length() + 1 if m > 0 else 2
    by_vars: dict[tuple[int, ...], set[int]] = defaultdict(set)
    clause_indices_by_vars: dict[tuple[int, ...], list[int]] = defaultdict(list)
    for idx, c in enumerate(clauses):
        ops.tick("reduce_ops")
        if 2 <= len(c) <= max_k:
            vs = tuple(abs(l) for l in c)
            forb = 0
            for pos, l in enumerate(c):
                if l < 0:
                    forb |= (1 << pos)
            by_vars[vs].add(forb)
            clause_indices_by_vars[vs].append(idx)

    eqs: list[tuple[int, int]] = []  # (var_tuple_idx -> (vs_mask, rhs)) stored as (vars, rhs)
    consumed_indices: set[int] = set()
    for vs, forbs in by_vars.items():
        k = len(vs)
        target_cnt = 1 << (k - 1)
        if len(forbs) == target_cnt:
            parities = {f.bit_count() & 1 for f in forbs}
            if len(parities) == 1:
                # Forbidden assignments all have parity p => allowed assignments have parity 1 - p
                forb_p = next(iter(parities))
                rhs = 1 - forb_p
                vmask = 0
                for v in vs:
                    vmask |= (1 << (v - 1))  # assume 1-based active vars
                eqs.append((vmask, rhs))
                consumed_indices.update(clause_indices_by_vars[vs])
    return eqs, consumed_indices


def _twosat_scc_and_units(n_active: int, clauses: list[tuple[int, ...]], ops: OpsTracker):
    """Run Tarjan SCC on 2-clauses and check forced units via transitive closure on SCC DAG."""
    adj: list[list[int]] = [[] for _ in range(2 * n_active)]
    has_binary = False
    for c in clauses:
        if len(c) == 2:
            has_binary = True
            l1, l2 = c
            # lit to node: v in 1..n -> 2*(v-1) for +v, 2*(v-1)+1 for -v
            u1 = 2 * (abs(l1) - 1) + (1 if l1 < 0 else 0)
            u2 = 2 * (abs(l2) - 1) + (1 if l2 < 0 else 0)
            adj[u1 ^ 1].append(u2)
            adj[u2 ^ 1].append(u1)
            ops.tick("scc_ops", 2)
    if not has_binary:
        return True, {}, []

    # Iterative Tarjan SCC
    index_counter = 0
    indices = [-1] * (2 * n_active)
    lowlink = [0] * (2 * n_active)
    on_stack = [False] * (2 * n_active)
    stack: list[int] = []
    comp = [-1] * (2 * n_active)
    num_comps = 0

    for start in range(2 * n_active):
        if indices[start] != -1:
            continue
        call_stack = [(start, 0)]
        indices[start] = lowlink[start] = index_counter
        index_counter += 1
        stack.append(start)
        on_stack[start] = True
        while call_stack:
            v, ni = call_stack[-1]
            ops.tick("scc_ops")
            if ni < len(adj[v]):
                call_stack[-1] = (v, ni + 1)
                w = adj[v][ni]
                if indices[w] == -1:
                    indices[w] = lowlink[w] = index_counter
                    index_counter += 1
                    stack.append(w)
                    on_stack[w] = True
                    call_stack.append((w, 0))
                elif on_stack[w]:
                    if indices[w] < lowlink[v]:
                        lowlink[v] = indices[w]
            else:
                call_stack.pop()
                if call_stack:
                    parent = call_stack[-1][0]
                    if lowlink[v] < lowlink[parent]:
                        lowlink[parent] = lowlink[v]
                if lowlink[v] == indices[v]:
                    cid = num_comps
                    num_comps += 1
                    while True:
                        w = stack.pop()
                        on_stack[w] = False
                        comp[w] = cid
                        if w == v:
                            break

    # Check satisfiability & extract equivalences within same SCC
    # Also compute bitset reachability on SCC DAG to find forced units (+v ->* -v)
    for v in range(n_active):
        if comp[2 * v] == comp[2 * v + 1]:
            return False, {}, []

    # Tarjan emits SCCs in topological order from sinks (0) to sources (num_comps-1),
    # i.e. edges only go cu -> cw with cu > cw.
    comp_words = max(1, (num_comps + 63) // 64)
    reach = [1 << c for c in range(num_comps)]
    dag_adj = [set() for _ in range(num_comps)]
    for u in range(2 * n_active):
        cu = comp[u]
        for w in adj[u]:
            cw = comp[w]
            if cu != cw:
                dag_adj[cu].add(cw)
    for c in range(num_comps):
        rc = 1 << c
        for nxt in dag_adj[c]:
            rc |= reach[nxt]
            ops.tick("scc_ops", comp_words)
        reach[c] = rc

    units: dict[int, int] = {}
    for v in range(n_active):
        c_pos = comp[2 * v]
        c_neg = comp[2 * v + 1]
        pos_to_neg = bool((reach[c_pos] >> c_neg) & 1)
        neg_to_pos = bool((reach[c_neg] >> c_pos) & 1)
        if pos_to_neg and neg_to_pos:
            return False, {}, []
        if pos_to_neg:
            units[v] = 0
        elif neg_to_pos:
            units[v] = 1

    # Extract equivalences from shared SCCs: group nodes by SCC
    scc_nodes: dict[int, list[int]] = defaultdict(list)
    for u in range(2 * n_active):
        v = u // 2
        if v not in units:
            scc_nodes[comp[u]].append(u)
    equivs: list[tuple[int, int, int]] = []
    for cid, nodes in scc_nodes.items():
        if len(nodes) > 1:
            u0 = nodes[0]
            v0, p0 = u0 // 2, u0 & 1
            for uk in nodes[1:]:
                vk, pk = uk // 2, uk & 1
                if vk != v0:
                    # (v0 ^ p0) == (vk ^ pk) => v0 ^ vk = p0 ^ pk
                    equivs.append((v0, vk, p0 ^ pk))
    return True, units, equivs


def _normalize_clauses(clauses: list[tuple[int, ...]], f2: F2System, ops: OpsTracker):
    """Substitute implied units and 2-XORs from f2 into clauses, dedup, drop tautologies/subsumed."""
    while True:
        units, equivs = f2.extract_implied_le2()
        # Build substitution map for units and 2-XORs (only if non-trivial!)
        sub_map: dict[int, tuple[int, int]] = {}  # var0 -> (rep_var0_or_-1, const_flip)
        for v, val in units.items():
            sub_map[v] = (-1, val)
        for rep, piv, rhs in equivs:
            # piv = rep ^ rhs
            if piv not in sub_map:
                sub_map[piv] = (rep, rhs)

        new_clauses_set: set[tuple[int, ...]] = set()
        changed = False
        for c in clauses:
            ops.tick("reduce_ops")
            taut = False
            lits: dict[int, int] = {}  # var1 -> polarity(0/1)
            c_changed = False
            for lit in c:
                v0 = abs(lit) - 1
                pol = 1 if lit > 0 else 0
                if v0 in sub_map:
                    c_changed = True
                    rep, flp = sub_map[v0]
                    if rep == -1:
                        if (pol ^ (1 - flp)) == 1:
                            # Wait: lit is true iff val == pol.
                            pass
                        if flp == pol:
                            taut = True
                            break
                        else:
                            continue
                    else:
                        v0 = rep
                        pol ^= flp
                v1 = v0 + 1
                prev = lits.get(v1)
                if prev is None:
                    lits[v1] = pol
                elif prev != pol:
                    taut = True
                    break
                else:
                    c_changed = True
            if taut:
                changed = True
                continue
            if not lits:
                return False, []
            norm_c = tuple(v if lits[v] == 1 else -v for v in sorted(lits))
            if len(norm_c) == 1:
                v0 = abs(norm_c[0]) - 1
                val = 1 if norm_c[0] > 0 else 0
                ok_eq, _ = f2.add_equation((1 << v0) | (val << f2.n))
                if not ok_eq:
                    return False, []
                changed = True
                continue
            if norm_c != c or c_changed:
                changed = True
            new_clauses_set.add(norm_c)

        # If f2 changed during clause normalization (e.g. unit clause extracted),
        # re-substitute immediately before running XOR/SCC/pure-literal rules.
        if changed:
            clauses = sorted(new_clauses_set, key=lambda cl: (len(cl), cl))
            continue

        # Sort clauses by length then lexicographically
        clauses = sorted(new_clauses_set, key=lambda cl: (len(cl), cl))
        # Check if newly reduced clauses formed XOR groups or 2-SCC units/equivs
        xor_eqs, consumed = _extract_xor_groups(clauses, ops)
        if xor_eqs:
            for vm, rhs in xor_eqs:
                ok_eq, _ = f2.add_equation(vm | (rhs << f2.n))
                if not ok_eq:
                    return False, []
            clauses = [c for i, c in enumerate(clauses) if i not in consumed]
            continue

        ok_scc, scc_units, scc_equivs = _twosat_scc_and_units(f2.n, clauses, ops)
        if not ok_scc:
            return False, []
        if scc_units or scc_equivs:
            scc_changed = False
            for v, val in scc_units.items():
                ok_eq, chg = f2.add_equation((1 << v) | (val << f2.n))
                if not ok_eq:
                    return False, []
                scc_changed |= chg
            for v0, vk, rhs in scc_equivs:
                ok_eq, chg = f2.add_equation((1 << v0) | (1 << vk) | (rhs << f2.n))
                if not ok_eq:
                    return False, []
                scc_changed |= chg
            if scc_changed:
                continue

        # Safe pure-literal elimination ONLY on variables absent from ALL f2 rows
        if clauses:
            f2_vars_mask = 0
            for p, row in f2.rows.items():
                f2_vars_mask |= row & f2.var_mask
            pos_mask = 0
            neg_mask = 0
            for c in clauses:
                for lit in c:
                    b = 1 << (abs(lit) - 1)
                    if lit > 0:
                        pos_mask |= b
                    else:
                        neg_mask |= b
            pure_pos = pos_mask & ~neg_mask & ~f2_vars_mask
            pure_neg = neg_mask & ~pos_mask & ~f2_vars_mask
            if pure_pos or pure_neg:
                m = pure_pos
                while m:
                    lsb = m & -m
                    m ^= lsb
                    ok_eq, _ = f2.add_equation(lsb | (1 << f2.n))
                    if not ok_eq:
                        return False, []
                m = pure_neg
                while m:
                    lsb = m & -m
                    m ^= lsb
                    ok_eq, _ = f2.add_equation(lsb)
                    if not ok_eq:
                        return False, []
                changed = True

        if not changed:
            break
    return True, clauses


def _conflict_clique_unsat(clauses: list[tuple[int, ...]], ops: OpsTracker) -> bool:
    """Sound global cardinality obstruction: if r pairwise-literal-disjoint clauses are covered
    by s < r pairwise-disjoint conflict cliques (where every pair in a clique has (-a, -b) in clauses),
    then the formula is unsatisfiable.
    """
    conflict_adj: dict[int, set[int]] = defaultdict(set)
    for c in clauses:
        if len(c) == 2:
            a, b = c
            conflict_adj[-a].add(-b)
            conflict_adj[-b].add(-a)
            ops.tick("reduce_ops", 2)
    if not conflict_adj:
        return False

    # Collect candidate clauses whose literals all appear in conflict_adj
    cand_clauses = [
        c for c in clauses
        if len(c) >= 1 and all(lit in conflict_adj for lit in c)
    ]
    if len(cand_clauses) <= 1:
        return False

    # Greedily select a maximal set of pairwise-literal-disjoint candidate clauses
    # (prefer clauses with highest conflict degree / shortest length)
    cand_clauses.sort(key=lambda c: (len(c), -sum(len(conflict_adj[l]) for l in c)))
    used_lits: set[int] = set()
    chosen_clauses: list[tuple[int, ...]] = []
    for c in cand_clauses:
        ops.tick("reduce_ops")
        if all(l not in used_lits for l in c):
            chosen_clauses.append(c)
            used_lits.update(c)

    r = len(chosen_clauses)
    if r <= 1:
        return False

    # Partition used_lits into disjoint conflict cliques greedily (largest cliques first)
    rem = set(used_lits)
    num_cliques = 0
    while rem:
        # Start with literal of highest remaining conflict degree
        seed = max(rem, key=lambda l: len(conflict_adj[l] & rem))
        clique = [seed]
        cands = sorted(conflict_adj[seed] & rem, key=lambda l: -len(conflict_adj[l] & rem))
        for u in cands:
            ops.tick("reduce_ops")
            if all(u in conflict_adj[w] for w in clique):
                clique.append(u)
        for u in clique:
            rem.remove(u)
        num_cliques += 1
        if num_cliques >= r:
            return False
    return num_cliques < r


def _wl_colors(f2: F2System, clauses: list[tuple[int, ...]], active_vars: list[int], ops: OpsTracker) -> dict[int, int]:
    """Signed bipartite 1-WL color refinement on (variables, clauses, F2 rows)."""
    active_set = set(active_vars)
    var_pos: dict[int, list[int]] = defaultdict(list)
    var_neg: dict[int, list[int]] = defaultdict(list)
    for ci, c in enumerate(clauses):
        for lit in c:
            v = abs(lit) - 1
            if lit > 0:
                var_pos[v].append(ci)
            else:
                var_neg[v].append(ci)

    f2_rows: list[tuple[list[int], int]] = []
    var_f2: dict[int, list[int]] = defaultdict(list)
    for p, row in f2.rows.items():
        if p in active_set:
            vm = row & f2.var_mask
            vs = []
            valid = True
            while vm:
                lsb = vm & -vm
                v = lsb.bit_length() - 1
                vm ^= lsb
                if v not in active_set:
                    valid = False
                    break
                vs.append(v)
            if valid:
                ri = len(f2_rows)
                rhs = (row >> f2.n) & 1
                f2_rows.append((vs, rhs))
                for v in vs:
                    var_f2[v].append(ri)

    # Initial colors
    v_col = {v: (len(var_pos[v]), len(var_neg[v]), len(var_f2[v])) for v in active_vars}
    c_col = [(len(c),) for c in clauses]
    r_col = [(len(vs), rhs) for vs, rhs in f2_rows]

    def compress(sigs):
        uniq = sorted(set(sigs))
        mp = {s: i for i, s in enumerate(uniq)}
        return [mp[s] for s in sigs], len(uniq)

    vc_list, prev_vc = compress([v_col[v] for v in active_vars])
    v_col = {v: vc_list[i] for i, v in enumerate(active_vars)}
    c_col, _ = compress(c_col)
    r_col, _ = compress(r_col)

    total_lits = sum(len(c) for c in clauses)
    max_rounds = min(8, len(active_vars))
    log_cost = max(1, (len(active_vars) + len(clauses)).bit_length())
    for _ in range(max_rounds):
        ops.tick("reduce_ops", (len(active_vars) + len(clauses) + total_lits + len(f2_rows)) * log_cost)
        new_c_sigs = []
        for c in clauses:
            sig = tuple(sorted((v_col[abs(l) - 1], 1 if l > 0 else 0) for l in c))
            new_c_sigs.append(sig)
        c_col, _ = compress(new_c_sigs)

        new_r_sigs = []
        for vs, rhs in f2_rows:
            sig = (rhs, tuple(sorted(v_col[v] for v in vs)))
            new_r_sigs.append(sig)
        r_col, _ = compress(new_r_sigs)

        new_v_sigs = []
        for v in active_vars:
            sig = (
                v_col[v],
                tuple(sorted(c_col[ci] for ci in var_pos[v])),
                tuple(sorted(c_col[ci] for ci in var_neg[v])),
                tuple(sorted(r_col[ri] for ri in var_f2[v])),
            )
            new_v_sigs.append(sig)
        vc_list, num_vc = compress(new_v_sigs)
        v_col = {v: vc_list[i] for i, v in enumerate(active_vars)}
        if num_vc == prev_vc or num_vc == len(active_vars):
            break
        prev_vc = num_vc
    return v_col


def _canonical_key(f2: F2System, clauses: list[tuple[int, ...]], active_vars: list[int], ops: OpsTracker, v_col: dict[int, int] | None = None) -> tuple:
    """1-WL-guided canonical hashable signature of residual component (F2 + CNF)."""
    if v_col is None:
        v_col = _wl_colors(f2, clauses, active_vars, ops)
    # Bipartite BFS (variables -> clauses -> variables) in O(sum |c|)
    var_to_clauses: dict[int, list[int]] = defaultdict(list)
    for ci, c in enumerate(clauses):
        for lit in c:
            var_to_clauses[abs(lit) - 1].append(ci)
    ordered: list[int] = []
    placed: set[int] = set()
    visited_c: set[int] = set()
    rem = sorted(active_vars, key=lambda v: (v_col[v], v))
    ops.tick("reduce_ops", len(active_vars) + sum(len(c) for c in clauses))
    while len(ordered) < len(active_vars):
        seed = next(v for v in rem if v not in placed)
        q = deque([seed])
        placed.add(seed)
        while q:
            u = q.popleft()
            ordered.append(u)
            nbrs_set: set[int] = set()
            for ci in var_to_clauses[u]:
                if ci not in visited_c:
                    visited_c.add(ci)
                    for lit in clauses[ci]:
                        w = abs(lit) - 1
                        if w not in placed:
                            nbrs_set.add(w)
            for w in sorted(nbrs_set, key=lambda x: (v_col[x], x)):
                placed.add(w)
                q.append(w)

    vmap = {v: i for i, v in enumerate(ordered)}
    ops.tick("reduce_ops", len(ordered) + len(clauses) + len(f2.rows) * f2.word_cost)
    norm_clauses = tuple(sorted(
        tuple(sorted((vmap[abs(l) - 1] + 1) * (1 if l > 0 else -1) for l in c))
        for c in clauses
    ))
    active_set = set(active_vars)
    norm_rows = []
    for p, row in f2.rows.items():
        if p in active_set:
            vm = row & f2.var_mask
            new_m = 0
            valid = True
            while vm:
                lsb = vm & -vm
                v = lsb.bit_length() - 1
                vm ^= lsb
                if v not in vmap:
                    valid = False
                    break
                new_m |= (1 << vmap[v])
            if valid:
                rhs = (row >> f2.n) & 1
                norm_rows.append((new_m, rhs))
    return (len(ordered), tuple(sorted(norm_rows)), norm_clauses)


def _solve_component(f2: F2System, clauses: list[tuple[int, ...]], memo: set[tuple], ops: OpsTracker):
    """Exact solver on reduced state (f2, clauses). Returns assignment dict {var0: 0/1} or None if UNSAT."""
    ops.tick("search_nodes")
    ok, clauses = _normalize_clauses(clauses, f2, ops)
    if not ok:
        return None
    if not clauses:
        return {v: val for v, val in enumerate(f2.solve_any())}

    # Connected components across BOTH clauses AND ALL non-unit F2 rows (full transitive closure).
    clause_vars: set[int] = set()
    adj: dict[int, list[int]] = defaultdict(list)
    for c in clauses:
        vs = [abs(l) - 1 for l in c]
        clause_vars.update(vs)
        for i in range(len(vs) - 1):
            adj[vs[i]].append(vs[i + 1])
            adj[vs[i + 1]].append(vs[i])
    for p, row in f2.rows.items():
        vm = row & f2.var_mask
        tail = vm ^ (1 << p)
        if tail == 0:
            continue
        ops.tick("lin_ops", f2.word_cost)
        vs = []
        m = vm
        while m:
            lsb = m & -m
            vs.append(lsb.bit_length() - 1)
            m ^= lsb
        for i in range(len(vs) - 1):
            adj[vs[i]].append(vs[i + 1])
            adj[vs[i + 1]].append(vs[i])

    visited: set[int] = set()
    comps: list[set[int]] = []
    for v in sorted(clause_vars):
        if v in visited:
            continue
        comp_v: set[int] = set()
        q = deque([v])
        visited.add(v)
        while q:
            u = q.popleft()
            comp_v.add(u)
            for w in adj[u]:
                if w not in visited:
                    visited.add(w)
                    q.append(w)
        comps.append(comp_v)
    active_set = visited

    if len(comps) > 1:
        merged_vals = {v: val for v, val in enumerate(f2.solve_any())}
        for comp_v in comps:
            sub_clauses = [c for c in clauses if (abs(c[0]) - 1) in comp_v]
            if not sub_clauses:
                continue
            sub_f2 = F2System(f2.n, ops)
            for p, row in f2.rows.items():
                if p in comp_v:
                    sub_f2.rows[p] = row
                    sub_f2.pivot_mask |= (1 << p)
            sub_sol = _solve_component(sub_f2, sub_clauses, memo, ops)
            if sub_sol is None:
                return None
            for v in comp_v:
                merged_vals[v] = sub_sol[v]
        # Recompute strict-RREF pivot values for complete F2 consistency
        for p, row in f2.rows.items():
            rhs = (row >> f2.n) & 1
            tail = (row & f2.var_mask) ^ (1 << p)
            parity = rhs
            while tail:
                lsb = tail & -tail
                parity ^= merged_vals[lsb.bit_length() - 1]
                tail ^= lsb
            merged_vals[p] = parity
        return merged_vals

    if _conflict_clique_unsat(clauses, ops):
        return None

    active_list = sorted(active_set)
    v_col = _wl_colors(f2, clauses, active_list, ops)
    key = _canonical_key(f2, clauses, active_list, ops, v_col=v_col)
    if key in memo:
        ops.memo_hits += 1
        return None

    # Choose branching variable: max occurrence in shortest clauses, tie-broken by 1-WL color
    min_len = min(len(c) for c in clauses)
    score: dict[int, int] = defaultdict(int)
    for c in clauses:
        w = 4 if len(c) == min_len else 1
        for lit in c:
            score[abs(lit) - 1] += w
    branch_v = max(active_list, key=lambda v: (score[v], -v_col[v], -v))

    for val in (1, 0):
        f2_next = f2.clone()
        ok_eq, _ = f2_next.add_equation((1 << branch_v) | (val << f2_next.n))
        if ok_eq:
            sol = _solve_component(f2_next, list(clauses), memo, ops)
            if sol is not None:
                return sol

    memo.add(key)
    return None


def _verify_assignment(nvars: int, clauses: list[list[int]], assignment: list[bool]) -> bool:
    if len(assignment) != nvars:
        return False
    for c in clauses:
        if not any(assignment[abs(l) - 1] == (l > 0) for l in c):
            return False
    return True


def solve(nvars: int, clauses: list[list[int]], budget: int) -> dict:
    if type(nvars) is not int or nvars < 0:
        raise ValueError("nvars must be a nonnegative integer")
    if type(budget) is not int or budget <= 0:
        raise ValueError("budget must be a positive integer")

    ops = OpsTracker(budget)
    try:
        # Validate and collect referenced variables (so isolated vars don't inflate F2System)
        ref_vars: set[int] = set()
        for c in clauses:
            ops.tick("parse_ops")
            for lit in c:
                ops.tick("parse_ops")
                if type(lit) is not int or not 1 <= abs(lit) <= nvars:
                    raise ValueError("invalid literal")
                ref_vars.add(abs(lit))

        if not clauses:
            return {"status": "SAT", "assignment": [False] * nvars, "operations": ops.report()}
        if any(len(c) == 0 for c in clauses):
            return {"status": "UNSAT", "assignment": None, "operations": ops.report()}

        active_sorted = sorted(ref_vars)
        v_to_idx = {v: i + 1 for i, v in enumerate(active_sorted)}  # 1-based active
        n_act = len(active_sorted)

        norm_clauses: list[tuple[int, ...]] = []
        seen: set[tuple[int, ...]] = set()
        for c in clauses:
            ops.tick("parse_ops", len(c))
            lits: dict[int, int] = {}
            taut = False
            for lit in c:
                v1 = v_to_idx[abs(lit)]
                pol = 1 if lit > 0 else 0
                prev = lits.get(v1)
                if prev is None:
                    lits[v1] = pol
                elif prev != pol:
                    taut = True
                    break
            if taut:
                continue
            nc = tuple(v if lits[v] == 1 else -v for v in sorted(lits))
            if nc not in seen:
                seen.add(nc)
                norm_clauses.append(nc)

        if not norm_clauses:
            return {"status": "SAT", "assignment": [False] * nvars, "operations": ops.report()}

        f2 = F2System(n_act, ops)
        memo: set[tuple] = set()
        sol = _solve_component(f2, norm_clauses, memo, ops)
        if sol is None:
            return {"status": "UNSAT", "assignment": None, "operations": ops.report()}

        assignment = [False] * nvars
        for idx, orig_v in enumerate(active_sorted):
            assignment[orig_v - 1] = bool(sol.get(idx, 0))
        if not _verify_assignment(nvars, clauses, assignment):
            raise RuntimeError("Internal soundness guard failed on SAT witness")
        return {"status": "SAT", "assignment": assignment, "operations": ops.report()}

    except BudgetExhausted:
        return {"status": "UNKNOWN", "assignment": None, "operations": ops.report()}
