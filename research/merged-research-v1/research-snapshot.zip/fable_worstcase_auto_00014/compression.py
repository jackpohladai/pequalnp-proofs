"""Bounded BLQ compression with an independent full certificate check.

Discovery uses bounded vector-space enumeration and a greedy compatible basis,
not Fable's unproved polynomial atom-descent procedure. Compression runs once
at the root. Any skip preserves the original input for the existing solver.
"""
import itertools as it
import time

LIMITS = dict(max_variables=12, max_block_width=8, max_clauses=256,
              max_space_points=16384, max_verification_work=8000000)


def parity(x):
    return bin(x).count('1') % 2


def basis(vectors):
    rows = {}
    for v in vectors:
        while v:
            pivot = v.bit_length() - 1
            if pivot in rows:
                v ^= rows[pivot]
            else:
                rows[pivot] = v
                break
    return tuple(rows[k] for k in sorted(rows, reverse=True))


def span(vectors):
    result = {0}
    for v in basis(vectors):
        result |= {x ^ v for x in result}
    return result


def points(support):
    return [sum(bit << (v - 1) for v, bit in zip(support, bits))
            for bits in it.product((0, 1), repeat=len(support))]


def dense_formula(formula, ids):
    mapping = {v: i + 1 for i, v in enumerate(ids)}
    return [tuple(mapping[abs(l)] if l > 0 else -mapping[abs(l)] for l in c) for c in formula]


def evaluate(formula, assignment):
    return all(any(bool(assignment & (1 << (abs(l) - 1))) == (l > 0) for l in c) for c in formula)


def project(assignment, forms):
    return sum(parity(assignment & v) << i for i, v in enumerate(forms))


def lift(assignment, columns):
    result = 0
    for i, column in enumerate(columns):
        if assignment & (1 << i):
            result ^= column
    return result


def verify_certificate(formula, cert):
    """No reliance on stabilizers, hulls, basis discovery, or rank routines.

    This checks F(x)=G(project x) and project(lift y)=y for every bounded input.
    A valid certificate therefore preserves SAT in both directions.
    """
    ids = sorted({abs(l) for c in formula for l in c})
    if cert.get('variables') != ids or len(ids) > LIMITS['max_variables']:
        return False
    n, forms, quotient, columns = len(ids), cert['basis_forms'], cert['quotient'], cert['right_inverse']
    r = len(forms)
    if not (0 < r < n) or len(columns) != r:
        return False
    if any(type(v) is not int or not 0 <= v < 2 ** n for v in forms + columns):
        return False
    if any(type(l) is not int or not 1 <= abs(l) <= r for c in quotient for l in c):
        return False
    original = dense_formula(formula, ids)
    for x in range(2 ** n):
        if evaluate(original, x) != evaluate(quotient, project(x, forms)):
            return False
    for y in range(2 ** r):
        if project(lift(y, columns), forms) != y:
            return False
    return True


def compress_root(formula, **limits):
    limits = dict(LIMITS, **limits)
    if any(type(v) is not int or v < 0 for v in limits.values()):
        raise ValueError('Compression budgets must be nonnegative integers')
    start = time.monotonic()
    ids = sorted({abs(l) for c in formula for l in c})
    n = len(ids)
    def skip(reason):
        return dict(status='skipped', reason=reason, original_variables=n,
                    original_clauses=len(formula), seconds=time.monotonic()-start)
    if n == 0 or n > min(limits['max_variables'], LIMITS['max_variables']):
        return skip('variable_budget_or_trivial')
    if len(formula) > limits['max_clauses']:
        return skip('clause_budget')
    if (2 ** n) * sum(map(len, formula)) > limits['max_verification_work']:
        return skip('verification_work_budget')
    dense = dense_formula(formula, ids)
    blocks = {}
    for clause in dense:
        support = tuple(sorted(map(abs, clause)))
        if len(support) > limits['max_block_width']:
            return skip('block_width_budget')
        z = sum(1 << (abs(l)-1) for l in clause if l < 0)
        blocks.setdefault(support, set()).add(z)
    if sum(2 ** len(s) for s in blocks) > limits['max_space_points']:
        return skip('space_budget')
    frozen = {v for support, z in blocks.items() if len(z) % 2 for v in support}
    if len(frozen) == n:
        return skip('all_variables_in_odd_blocks')
    data = []
    for support, z in sorted(blocks.items()):
        z0 = min(z)
        w = {a ^ z0 for a in z if {b ^ a ^ z0 for b in z} == z}
        wb = basis(w)
        annihilator = {a for a in points(support) if all(parity(a & d) == 0 for d in wb)}
        data.append(dict(support=support, forbidden=z, stabilizer=w, forms=annihilator))
    candidates = set().union(*(d['forms'] for d in data)) - {0}
    candidates = sorted(candidates, key=lambda v: (-sum(v in d['forms'] for d in data), bin(v).count('1'), v))
    chosen, chosen_span = [], {0}
    for v in candidates:
        if v not in chosen_span:
            chosen.append(v)
            chosen_span |= {a ^ v for a in chosen_span}
    if not 0 < len(chosen) < n:
        return skip('no_dimension_reduction')
    if any(span(v for v in chosen if v in d['forms']) != d['forms'] for d in data):
        return skip('incompatible_greedy_basis')
    rewritten, details = [], []
    for d in data:
        indices = [i for i, v in enumerate(chosen) if v in d['forms']]
        forbidden = {tuple(parity(z & chosen[i]) for i in indices) for z in d['forbidden']}
        clauses = [tuple(-(i+1) if bit else i+1 for i, bit in zip(indices, t)) for t in sorted(forbidden)]
        rewritten.extend(clauses)
        details.append(dict(support=list(d['support']), forbidden_points=len(d['forbidden']),
                            stabilizer_size=len(d['stabilizer']), quotient_clauses=len(clauses)))
    # Only bounded discovery: select a lift of each quotient unit vector.
    columns = [None] * len(chosen)
    for x in range(2 ** n):
        image = project(x, chosen)
        if image and image & (image-1) == 0:
            i = image.bit_length()-1
            if columns[i] is None:
                columns[i] = x
    if any(x is None for x in columns):
        return skip('no_right_inverse')
    cert = dict(variables=ids, basis_forms=chosen, quotient=[list(c) for c in rewritten], right_inverse=columns)
    if not verify_certificate(formula, cert):
        return skip('certificate_rejected')
    return dict(status='compressed', original_variables=n, original_clauses=len(formula),
                quotient_variables=len(chosen), quotient_clauses=len(rewritten), certificate=cert,
                blocks=details, verification_assignments=2 ** n + 2 ** len(chosen),
                seconds=time.monotonic()-start, certificate_verified=True,
                general_polynomial_sat_proof=False)
