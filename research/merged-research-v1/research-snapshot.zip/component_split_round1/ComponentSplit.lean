import UnitPreparedDecision

namespace PEqualNP.Outside.ComponentSplit
open PEqualNP.Search
open PEqualNP.Outside.SparseDualHornAlgorithm (support support_covers)

abbrev Separated (parts : List CNF) : Prop :=
  parts.Pairwise (fun F G => Disjoint (support F) (support G))

def glue (F : CNF) (left right : Assignment) : Assignment :=
  fun x => if x ∈ support F then left x else right x

theorem clause_eval_agree (a b : Assignment) (C : Clause)
    (agree : ∀ literal ∈ C, a literal.1 = b literal.1) :
    Clause.eval a C = Clause.eval b C := by
  induction C with
  | nil => rfl
  | cons literal rest ih =>
      change (Literal.eval a literal || Clause.eval a rest) =
        (Literal.eval b literal || Clause.eval b rest)
      have head : Literal.eval a literal = Literal.eval b literal := by
        simp only [Literal.eval, agree literal (by simp)]
      rw [head, ih (fun l hl => agree l (List.mem_cons_of_mem _ hl))]

theorem cnf_eval_agree (a b : Assignment) (F : CNF)
    (agree : ∀ C ∈ F, ∀ literal ∈ C, a literal.1 = b literal.1) :
    CNF.eval a F = CNF.eval b F := by
  induction F with
  | nil => rfl
  | cons C rest ih =>
      change (Clause.eval a C && CNF.eval a rest) = (Clause.eval b C && CNF.eval b rest)
      rw [clause_eval_agree a b C (agree C (by simp)),
        ih (fun D hD => agree D (List.mem_cons_of_mem _ hD))]

theorem glue_left (F : CNF) (a b : Assignment) :
    CNF.eval (glue F a b) F = CNF.eval a F := by
  apply cnf_eval_agree
  intro C hC literal hl
  simp [glue, support_covers F C hC literal hl]

theorem glue_right (F G : CNF) (a b : Assignment)
    (separate : Disjoint (support F) (support G)) :
    CNF.eval (glue F a b) G = CNF.eval b G := by
  apply cnf_eval_agree
  intro C hC literal hl
  have outside : literal.1 ∉ support F := by
    intro inside
    exact Finset.disjoint_left.mp separate inside (support_covers G C hC literal hl)
  simp [glue, outside]

theorem sat_append_disjoint (F G : CNF)
    (separate : Disjoint (support F) (support G)) :
    Satisfiable (F ++ G) ↔ Satisfiable F ∧ Satisfiable G := by
  constructor
  · rintro ⟨a, model⟩
    have both : CNF.eval a F = true ∧ CNF.eval a G = true := by
      simpa [CNF.eval, List.all_append] using model
    exact ⟨⟨a,both.1⟩,⟨a,both.2⟩⟩
  · rintro ⟨⟨a,left⟩,⟨b,right⟩⟩
    refine ⟨glue F a b, ?_⟩
    have lhs := (glue_left F a b).trans left
    have rhs := (glue_right F G a b separate).trans right
    simpa [CNF.eval, List.all_append] using And.intro lhs rhs

theorem support_flatten (parts : List CNF) (x : Nat) :
    x ∈ support parts.flatten ↔ ∃ G ∈ parts, x ∈ support G := by
  simp only [support, List.mem_toFinset, List.mem_flatMap, List.mem_map, List.mem_flatten]
  constructor
  · rintro ⟨C, ⟨G,hG,hC⟩, literal, hl, eq⟩
    exact ⟨G,hG,C,hC,literal,hl,eq⟩
  · rintro ⟨G,hG,C,hC,literal,hl,eq⟩
    exact ⟨C,⟨G,hG,hC⟩,literal,hl,eq⟩

theorem separated_head (F : CNF) (parts : List CNF)
    (separate : ∀ G ∈ parts, Disjoint (support F) (support G)) :
    Disjoint (support F) (support parts.flatten) := by
  apply Finset.disjoint_left.mpr
  intro x left right
  obtain ⟨G,hG,member⟩ := (support_flatten parts x).mp right
  exact Finset.disjoint_left.mp (separate G hG) left member

theorem flatten_sat_iff (parts : List CNF) (separate : Separated parts) :
    Satisfiable parts.flatten ↔ ∀ G ∈ parts, Satisfiable G := by
  induction parts with
  | nil => simp [Satisfiable, CNF.eval]
  | cons F parts ih =>
      have separated := List.pairwise_cons.mp separate
      rw [List.flatten_cons, sat_append_disjoint F parts.flatten (separated_head F parts separated.1),
        ih separated.2]
      simp

theorem sat_of_perm (F G : CNF) (perm : F.Perm G) : Satisfiable F ↔ Satisfiable G := by
  constructor
  · rintro ⟨a,model⟩
    refine ⟨a, List.all_eq_true.mpr ?_⟩
    intro C member
    exact List.all_eq_true.mp model C (perm.mem_iff.mpr member)
  · rintro ⟨a,model⟩
    refine ⟨a, List.all_eq_true.mpr ?_⟩
    intro C member
    exact List.all_eq_true.mp model C (perm.mem_iff.mp member)

/-- Check exact clause multiplicities (up to order) and independent supports. -/
def check (F : CNF) (parts : List CNF) : Bool :=
  decide (parts.flatten.Perm F) && decide (Separated parts)

theorem check_iff (F : CNF) (parts : List CNF) :
    check F parts = true ↔ parts.flatten.Perm F ∧ Separated parts := by simp [check]

theorem checked_sat_iff (F : CNF) (parts : List CNF) (accepted : check F parts = true) :
    Satisfiable F ↔ ∀ G ∈ parts, Satisfiable G := by
  obtain ⟨perm,separate⟩ := (check_iff F parts).mp accepted
  exact (sat_of_perm parts.flatten F perm).symm.trans (flatten_sat_iff parts separate)

def verdict (F : CNF) : Bool := (UnitPreparedDecision.solveCNF F).getD false

theorem verdict_iff (F : CNF) : verdict F = true ↔ Satisfiable F := by
  rw [← UnitPreparedDecision.solveCNF_sat F]
  cases result : UnitPreparedDecision.solveCNF F <;> simp [verdict, result]

def solveParts (parts : List CNF) : Bool := parts.all verdict

def solve (F : CNF) (parts : List CNF) : Option Bool :=
  if check F parts then some (solveParts parts) else none

theorem solve_sat (F : CNF) (parts : List CNF) (accepted : check F parts = true) :
    solve F parts = some true ↔ Satisfiable F := by
  simp only [solve, accepted, ↓reduceIte, Option.some.injEq, solveParts, List.all_eq_true]
  simpa only [verdict_iff] using (checked_sat_iff F parts accepted).symm

theorem solve_unsat (F : CNF) (parts : List CNF) (accepted : check F parts = true) :
    solve F parts = some false ↔ ¬ Satisfiable F := by
  have sat := solve_sat F parts accepted
  cases result : solveParts parts <;> simp [solve, accepted, result] at sat ⊢
  all_goals tauto

theorem solve_rejects (F : CNF) (parts : List CNF) (rejected : check F parts = false) :
    solve F parts = none := by simp [solve, rejected]

#print axioms glue_left
#print axioms glue_right
#print axioms sat_append_disjoint
#print axioms flatten_sat_iff
#print axioms checked_sat_iff
#print axioms solve_sat
#print axioms solve_unsat
end PEqualNP.Outside.ComponentSplit
