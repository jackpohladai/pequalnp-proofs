import ComponentFixtures

namespace PEqualNP.Outside.ComponentExtraction.Fixtures
open PEqualNP.Search

def runLarge (m shift : Nat) : IO Unit := do
  let F := pairedXor m shift
  if !ComponentSplit.check F (extract F) then
    throw (IO.userError "partition rejected before attempting large case")
  let before ← IO.monoNanosNow
  match solveCNFCounted F with
  | some (true, calls) =>
    let after ← IO.monoNanosNow
    if calls != 2*m then throw (IO.userError "unexpected large XOR leaf count")
    IO.println s!"m={m} shift={shift} calls={calls} ns={after-before}"
  | _ => throw (IO.userError "expected split SAT")

#eval runLarge 64 0
#eval runLarge 100 0
#eval runLarge 100 (2^80)

#print axioms runLarge

end PEqualNP.Outside.ComponentExtraction.Fixtures
