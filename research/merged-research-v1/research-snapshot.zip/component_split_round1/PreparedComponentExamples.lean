import PreparedComponents

namespace PEqualNP.Outside.PreparedComponents.Examples
open PEqualNP.Search

def pairs : CNF := [[(0,true),(1,true)],[(0,false),(1,false)],
  [(2,true),(3,true)],[(2,false),(3,false)]]

def bridged : CNF := pairs ++ [[(4,true)],[(4,true),(0,true),(2,true)]]

theorem prepare_removes_bridge : UnitPreparedDecision.prepare bridged = pairs := by decide
theorem originally_connected : (ComponentExtraction.extract bridged).length = 1 := by decide
theorem newly_separated :
    (ComponentExtraction.extract (UnitPreparedDecision.prepare bridged)).length = 2 := by decide

#eval (ComponentExtraction.solveCNFCounted bridged, solveCNFCounted bridged)
#guard ComponentExtraction.solveCNFCounted bridged == some (true,6)
#guard solveCNFCounted bridged == some (true,4)
#guard solveCNF bridged == some true
#guard solveCNFCounted [[(0,true)],[(0,false)]] == some (false,0)
#guard solveCNFCounted [] == some (true,0)
#guard solveCNFCounted [[]] == some (false,0)
#guard ComponentSplit.check [[(0,true)],[(2,false)],[(1,true)]]
  [[[(1,true)],[(0,true)]],[[(2,false)]]] == true

#print axioms prepare_removes_bridge
#print axioms originally_connected
#print axioms newly_separated
end PEqualNP.Outside.PreparedComponents.Examples
