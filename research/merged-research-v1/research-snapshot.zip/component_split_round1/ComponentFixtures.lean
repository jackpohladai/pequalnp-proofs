import ComponentExecution

namespace PEqualNP.Outside.ComponentExtraction.Fixtures
open PEqualNP.Search

def pairedXor (m : Nat) (shift : Nat := 0) : CNF :=
  (List.range m).flatMap fun i =>
    let x := shift + 2*i
    let y := x + 1
    [[(x,true),(y,true)],[(x,false),(y,false)]]

private def contradiction : CNF := [[(0,true)],[(0,false)]]

private def bridge : CNF := [[(0,true),(1,false)],[(0,true)],[(1,true)]]

private def withEmpties : CNF := [[],[(0,true)],[],[(0,true)]]

#guard ComponentSplit.solve contradiction [[[(0,true)]],[[(0,false)]]] == none
#guard ComponentSplit.check [[(0,true)],[(0,true)]] [[[(0,true)]]] == false
#guard solveCNF contradiction == some false
#guard (extract bridge).length == 1
#guard ((extract withEmpties).flatten.count ([] : Clause)) == 2
#guard solveCNFCounted withEmpties == some (false, 0)
#guard solveCNFCounted [] == some (true, 0)

/-- Time a single run of each actual counted entry point, after constructing
the same input. The timing does not replace the checked leaf counts. -/
def runSmall (m oldExpected : Nat) : IO Unit := do
  let F := pairedXor m
  if UnitPreparedDecision.prepare F != F then throw (IO.userError "expected no unit changes")
  if !ComponentSplit.check F (extract F) then throw (IO.userError "partition rejected")
  let beforeOld ← IO.monoNanosNow
  match UnitPreparedDecision.solveCNFCounted F with
  | some (true, oldCalls) =>
    let afterOld ← IO.monoNanosNow
    let beforeSplit ← IO.monoNanosNow
    match solveCNFCounted F with
    | some (true, splitCalls) =>
      let afterSplit ← IO.monoNanosNow
      if oldCalls != oldExpected || splitCalls != 2*m then
        throw (IO.userError "unexpected paired XOR leaf count")
      IO.println s!"m={m} old_calls={oldCalls} split_calls={splitCalls} old_ns={afterOld-beforeOld} split_ns={afterSplit-beforeSplit}"
    | _ => throw (IO.userError "expected split SAT")
  | _ => throw (IO.userError "expected baseline SAT")

#eval ([(1,2),(2,6),(3,22),(4,86),(5,342),(6,1366)] : List (Nat × Nat)).forM
  (fun (m,n) => runSmall m n)

#print axioms runSmall

end PEqualNP.Outside.ComponentExtraction.Fixtures
