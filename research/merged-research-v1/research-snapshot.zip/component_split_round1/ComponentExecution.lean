import ExtractComponents
import ComponentSplit

namespace PEqualNP.Outside.ComponentExtraction
open PEqualNP.Search

theorem extract_check (F : CNF) : ComponentSplit.check F (extract F) = true :=
  (ComponentSplit.check_iff F (extract F)).mpr ⟨extract_perm F, extract_separated F⟩

/-- Validate the discovered partition before solving its independent
components. A rejected partition uses the original solver. -/
def solveCNF (F : CNF) : Option Bool :=
  match ComponentSplit.solve F (extract F) with
  | some verdict => some verdict
  | none => UnitPreparedDecision.solveCNF F

theorem solveCNF_eq_checked (F : CNF) : solveCNF F = ComponentSplit.solve F (extract F) := by
  simp [solveCNF, ComponentSplit.solve, extract_check]

theorem solveCNF_sat (F : CNF) : solveCNF F = some true ↔ Satisfiable F := by
  rw [solveCNF_eq_checked]
  exact ComponentSplit.solve_sat F (extract F) (extract_check F)

theorem solveCNF_unsat (F : CNF) : solveCNF F = some false ↔ ¬ Satisfiable F := by
  rw [solveCNF_eq_checked]
  exact ComponentSplit.solve_unsat F (extract F) (extract_check F)

theorem solveCNF_ne_none (F : CNF) : solveCNF F ≠ none := by
  simp [solveCNF_eq_checked, ComponentSplit.solve, extract_check]

/-- Count leaf calls returned by the actual unit-prepared solver for each
visited component. Stop visiting components after the first UNSAT. -/
def countParts : List CNF → Option (Bool × Nat)
  | [] => some (true, 0)
  | part :: rest =>
    match UnitPreparedDecision.solveCNFCounted part with
    | none => none
    | some (false, n) => some (false, n)
    | some (true, n) => (countParts rest).map (fun tail => (tail.1, n + tail.2))

theorem countParts_erases (parts : List CNF) :
    (countParts parts).map Prod.fst = some (ComponentSplit.solveParts parts) := by
  induction parts with
  | nil => rfl
  | cons part rest ih =>
    have erases := UnitPreparedDecision.solveCNFCounted_erases part
    cases result : UnitPreparedDecision.solveCNFCounted part with
    | none =>
      have impossible : UnitPreparedDecision.solveCNF part = none := by
        simpa [result] using erases.symm
      exact (UnitPreparedDecision.solveCNF_ne_none part impossible).elim
    | some pair =>
      rcases pair with ⟨b,n⟩
      have observed : UnitPreparedDecision.solveCNF part = some b := by
        simpa [result] using erases.symm
      have same : ComponentSplit.verdict part = b := by simp [ComponentSplit.verdict, observed]
      cases b
      · simp [countParts, result, ComponentSplit.solveParts, same]
      · simpa [countParts, result, ComponentSplit.solveParts, same, Option.map_map,
          Function.comp_def] using ih

def solveCNFCounted (F : CNF) : Option (Bool × Nat) :=
  let parts := extract F
  if ComponentSplit.check F parts then countParts parts
  else UnitPreparedDecision.solveCNFCounted F

theorem solveCNFCounted_erases (F : CNF) :
    (solveCNFCounted F).map Prod.fst = solveCNF F := by
  simp [solveCNFCounted, extract_check, countParts_erases, solveCNF_eq_checked, ComponentSplit.solve]

#print axioms extract_check
#print axioms solveCNF_sat
#print axioms solveCNF_unsat
#print axioms solveCNF_ne_none
#print axioms countParts_erases
#print axioms solveCNFCounted_erases

end PEqualNP.Outside.ComponentExtraction
