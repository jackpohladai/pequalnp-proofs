import EmptyFirstComponents
namespace PEqualNP.Outside.EmptyFirstComponents.Examples
open PEqualNP.Search

def pairs (m : Nat) : CNF := (List.range m).flatMap fun i =>
  [[(2*i,true),(2*i+1,true)],[(2*i,false),(2*i+1,false)]]
def emptyLast : CNF := pairs 6 ++ [[]]
def positiveParts : CNF := (List.range 3).map fun i => [(2*i,true),(2*i+1,true)]

#eval (PreparedComponents.solveCNFCounted emptyLast, solveCNFCounted emptyLast)
#guard PreparedComponents.solveCNFCounted emptyLast == some (false,12)
#guard solveCNFCounted emptyLast == some (false,0)
#eval (UnitPreparedDecision.solveCNFCounted positiveParts, solveCNFCounted positiveParts)
#guard UnitPreparedDecision.solveCNFCounted positiveParts == some (true,1)
#guard solveCNFCounted positiveParts == some (true,3)
#guard solveCNFCounted [] == some (true,0)
#guard solveCNFCounted [[]] == some (false,0)
#guard solveCNFCounted [[(0,true)],[(0,false)]] == some (false,0)
#guard solveCNFCounted (pairs 4) == some (true,8)
end PEqualNP.Outside.EmptyFirstComponents.Examples
