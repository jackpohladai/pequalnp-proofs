import PreparedComponents

namespace PEqualNP.Outside.EmptyFirstComponents
open PEqualNP.Search
open UnitPropagation

def solveCNF (F : CNF) : Option Bool :=
  let reduced := UnitPreparedDecision.prepare F
  if hasEmpty reduced then some false else ComponentExtraction.solveCNF reduced

theorem solveCNF_sat (F : CNF) : solveCNF F = some true ↔ Satisfiable F := by
  by_cases empty : hasEmpty (UnitPreparedDecision.prepare F) = true
  · have impossible : ¬ Satisfiable F :=
      fun model => hasEmpty_unsat _ empty ((UnitPreparedDecision.prepare_sat_iff F).mpr model)
    simp [solveCNF, empty, impossible]
  · simpa [solveCNF, empty] using
      (ComponentExtraction.solveCNF_sat _).trans (UnitPreparedDecision.prepare_sat_iff F)

theorem solveCNF_unsat (F : CNF) : solveCNF F = some false ↔ ¬ Satisfiable F := by
  by_cases empty : hasEmpty (UnitPreparedDecision.prepare F) = true
  · have impossible : ¬ Satisfiable F :=
      fun model => hasEmpty_unsat _ empty ((UnitPreparedDecision.prepare_sat_iff F).mpr model)
    simp [solveCNF, empty, impossible]
  · simpa [solveCNF, empty] using
      (ComponentExtraction.solveCNF_unsat _).trans (not_congr (UnitPreparedDecision.prepare_sat_iff F))

theorem solveCNF_ne_none (F : CNF) : solveCNF F ≠ none := by
  by_cases empty : hasEmpty (UnitPreparedDecision.prepare F) = true
  · simp [solveCNF, empty]
  · simpa [solveCNF, empty] using ComponentExtraction.solveCNF_ne_none (UnitPreparedDecision.prepare F)

def solveCNFCounted (F : CNF) : Option (Bool × Nat) :=
  let reduced := UnitPreparedDecision.prepare F
  if hasEmpty reduced then some (false,0) else ComponentExtraction.solveCNFCounted reduced

theorem solveCNFCounted_erases (F : CNF) :
    (solveCNFCounted F).map Prod.fst = solveCNF F := by
  by_cases empty : hasEmpty (UnitPreparedDecision.prepare F) = true
  · simp [solveCNFCounted, solveCNF, empty]
  · simpa [solveCNFCounted, solveCNF, empty] using
      ComponentExtraction.solveCNFCounted_erases (UnitPreparedDecision.prepare F)

theorem known_empty_zero_calls (F : CNF)
    (empty : hasEmpty (UnitPreparedDecision.prepare F) = true) :
    solveCNFCounted F = some (false,0) := by simp [solveCNFCounted, empty]

theorem solveCNFCounted_calls (F : CNF) (verdict : Bool) (calls : Nat)
    (returned : solveCNFCounted F = some (verdict,calls)) :
    calls ≤ ComponentExtraction.Cost.partsBound
      (ComponentExtraction.extract (UnitPreparedDecision.prepare F)) := by
  by_cases empty : hasEmpty (UnitPreparedDecision.prepare F) = true
  · have same : (false,0) = (verdict,calls) := Option.some.inj (by
      simpa [solveCNFCounted, empty] using returned)
    have zero := congrArg Prod.snd same
    change 0 = calls at zero
    omega
  · apply ComponentExtraction.Cost.solveCNFCounted_calls _ verdict calls
    simpa [solveCNFCounted, empty] using returned

theorem counted_total_bound (F : CNF) :
    ∃ verdict calls, solveCNFCounted F = some (verdict,calls) ∧
      calls ≤ ComponentExtraction.Cost.partsBound
        (ComponentExtraction.extract (UnitPreparedDecision.prepare F)) := by
  cases observed : solveCNFCounted F with
  | none =>
      have impossible : solveCNF F = none := by simpa [observed] using (solveCNFCounted_erases F).symm
      exact (solveCNF_ne_none F impossible).elim
  | some result =>
      rcases result with ⟨verdict,calls⟩
      exact ⟨verdict,calls,rfl,solveCNFCounted_calls F verdict calls observed⟩

#print axioms solveCNF_sat
#print axioms solveCNF_unsat
#print axioms solveCNF_ne_none
#print axioms solveCNFCounted_erases
#print axioms known_empty_zero_calls
#print axioms solveCNFCounted_calls
#print axioms counted_total_bound
end PEqualNP.Outside.EmptyFirstComponents
