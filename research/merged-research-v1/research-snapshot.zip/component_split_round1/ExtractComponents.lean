import UnitPreparedDecision

namespace PEqualNP.Outside.ComponentExtraction

open PEqualNP.Search
open PEqualNP.Outside.SparseDualHornAlgorithm (support)

def sharesVariable (C : Clause) (part : CNF) : Bool :=
  !decide (Disjoint (support [C]) (support part))

/-- Merge all existing components touched by the clause. An empty clause
touches none and remains in its own component. -/
def insertClause (C : Clause) (parts : List CNF) : List CNF :=
  let touches := sharesVariable C
  (C :: (parts.filter touches).flatten) :: parts.filter (fun P => !touches P)

def extract : CNF → List CNF
  | [] => []
  | C :: rest => insertClause C (extract rest)

theorem insertClause_perm (C : Clause) (parts : List CNF) :
    (insertClause C parts).flatten.Perm (C :: parts.flatten) := by
  have rearranged := (List.filter_append_perm (sharesVariable C) parts).flatMap_right id
  simpa [insertClause, List.flatMap_append] using rearranged.cons C

theorem extract_perm (F : CNF) : (extract F).flatten.Perm F := by
  induction F with
  | nil => rfl
  | cons C rest ih => exact (insertClause_perm C (extract rest)).trans (ih.cons C)

private theorem support_member (x : Nat) (F : CNF) :
    x ∈ support F ↔ ∃ C ∈ F, ∃ l ∈ C, l.1 = x := by
  simp only [support, List.mem_toFinset, List.mem_flatMap, List.mem_map]

private theorem separate_distinct (parts : List CNF)
    (sep : parts.Pairwise (fun A B => Disjoint (support A) (support B)))
    (A B : CNF) (aIn : A ∈ parts) (bIn : B ∈ parts) (different : A ≠ B) :
    Disjoint (support A) (support B) := by
  induction parts with
  | nil => simp at aIn
  | cons first rest ih =>
    rcases List.pairwise_cons.mp sep with ⟨firstSeparate, restSeparate⟩
    rcases List.mem_cons.mp aIn with rfl | aRest
    · rcases List.mem_cons.mp bIn with rfl | bRest
      · exact (different rfl).elim
      · exact firstSeparate B bRest
    · rcases List.mem_cons.mp bIn with rfl | bRest
      · exact (firstSeparate A aRest).symm
      · exact ih restSeparate aRest bRest

theorem insertClause_separated (C : Clause) (parts : List CNF)
    (prior : parts.Pairwise (fun A B => Disjoint (support A) (support B))) :
    (insertClause C parts).Pairwise (fun A B => Disjoint (support A) (support B)) := by
  unfold insertClause
  apply List.pairwise_cons.mpr
  refine ⟨?_, List.pairwise_filter.mpr (prior.imp (fun sep _ _ => sep))⟩
  intro B bListed
  obtain ⟨bOriginal, bMisses⟩ := List.mem_filter.mp bListed
  have clauseSeparate : Disjoint (support [C]) (support B) := by
    simpa [sharesVariable] using bMisses
  apply Finset.disjoint_left.mpr
  intro x xMerged xB
  obtain ⟨D, dMerged, literal, inD, value⟩ := (support_member _ _).mp xMerged
  rcases List.mem_cons.mp dMerged with equal | hit
  · subst D
    have xC : x ∈ support [C] := (support_member _ _).mpr ⟨C, by simp, literal, inD, value⟩
    exact (Finset.disjoint_left.mp clauseSeparate) xC xB
  · obtain ⟨A, aList, dInA⟩ := List.mem_flatten.mp hit
    obtain ⟨aOriginal, aTouches⟩ := List.mem_filter.mp aList
    have different : A ≠ B := by
      intro same
      rw [same] at aTouches
      simp [aTouches] at bMisses
    have separate := separate_distinct parts prior A B aOriginal bOriginal different
    have xA : x ∈ support A := (support_member _ _).mpr ⟨D, dInA, literal, inD, value⟩
    exact (Finset.disjoint_left.mp separate) xA xB

theorem extract_separated (F : CNF) :
    (extract F).Pairwise (fun A B => Disjoint (support A) (support B)) := by
  induction F with
  | nil => exact .nil
  | cons C rest ih => exact insertClause_separated C (extract rest) ih

#print axioms extract_perm
#print axioms extract_separated

end PEqualNP.Outside.ComponentExtraction
