from pathlib import Path
import json,tempfile,subprocess,os,time,sys
base=Path(__file__).resolve().parent;name=sys.argv[1] if len(sys.argv)>1 else 'ComponentSplit'
tmp=Path(tempfile.mkdtemp(prefix='pnp-component-split-'));s=base/(name+'.lean');(tmp/s.name).write_bytes(s.read_bytes())
parent=json.load(open(base.parent/'unit_propagation_round1/unit-decision-validation.json'))
env=dict(os.environ,LEAN_PATH=str(base/'build/lib/lean')+':'+str(base/'extraction-build/lib/lean')+':'+parent['reusable_lean_path'])
cmd=['/Users/jackpohlad/.elan/toolchains/leanprover--lean4---v4.36.0/bin/lean','-j','1','-DElab.async=false','-o',str(tmp/(name+'.olean')),str(tmp/s.name)]
t=time.time();p=subprocess.run(cmd,cwd=tmp,env=env,text=True,capture_output=True,timeout=120)
(base/(name+'-attempt.json')).write_text(json.dumps({'command':cmd,'lean_path':env['LEAN_PATH'],'exit_code':p.returncode,'output':p.stdout+p.stderr,'elapsed_seconds':time.time()-t,'tmp':str(tmp)},indent=2));print(p.returncode,p.stdout+p.stderr)
