import ComponentCost

namespace PEqualNP.Outside.PreparedComponents
open PEqualNP.Search

/-- Verified global unit propagation can reveal independent residual
components before extraction; this is still an exponential SAT solver. -/
def solveCNF (F : CNF) : Option Bool :=
  ComponentExtraction.solveCNF (UnitPreparedDecision.prepare F)

theorem solveCNF_sat (F : CNF) : solveCNF F = some true ↔ Satisfiable F :=
  (ComponentExtraction.solveCNF_sat _).trans (UnitPreparedDecision.prepare_sat_iff F)

theorem solveCNF_unsat (F : CNF) : solveCNF F = some false ↔ ¬ Satisfiable F :=
  (ComponentExtraction.solveCNF_unsat _).trans (not_congr (UnitPreparedDecision.prepare_sat_iff F))

theorem solveCNF_ne_none (F : CNF) : solveCNF F ≠ none :=
  ComponentExtraction.solveCNF_ne_none _

def solveCNFCounted (F : CNF) : Option (Bool × Nat) :=
  ComponentExtraction.solveCNFCounted (UnitPreparedDecision.prepare F)

theorem solveCNFCounted_erases (F : CNF) :
    (solveCNFCounted F).map Prod.fst = solveCNF F :=
  ComponentExtraction.solveCNFCounted_erases _

theorem solveCNFCounted_calls (F : CNF) (verdict : Bool) (calls : Nat)
    (returned : solveCNFCounted F = some (verdict,calls)) :
    calls ≤ ComponentExtraction.Cost.partsBound
      (ComponentExtraction.extract (UnitPreparedDecision.prepare F)) :=
  ComponentExtraction.Cost.solveCNFCounted_calls _ verdict calls returned

theorem counted_total_bound (F : CNF) :
    ∃ verdict calls, solveCNFCounted F = some (verdict,calls) ∧
      calls ≤ ComponentExtraction.Cost.partsBound
        (ComponentExtraction.extract (UnitPreparedDecision.prepare F)) :=
  ComponentExtraction.Cost.counted_total_bound _

#print axioms solveCNF_sat
#print axioms solveCNF_unsat
#print axioms solveCNF_ne_none
#print axioms solveCNFCounted_erases
#print axioms solveCNFCounted_calls
#print axioms counted_total_bound
end PEqualNP.Outside.PreparedComponents
