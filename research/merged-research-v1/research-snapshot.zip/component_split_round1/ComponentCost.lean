import ComponentExecution

namespace PEqualNP.Outside.ComponentExtraction.Cost
open PEqualNP.Search
open PEqualNP.Outside.ConstructorBoundary
open PEqualNP.Outside.UnitPropagation

/-- Leaf-solver invocation budget for one prepared component. -/
def perPartBound (F : CNF) : Nat :=
  2 ^ (negativeVars (UnitPreparedDecision.prepare F).get).length

def partsBound (parts : List CNF) : Nat := (parts.map perPartBound).sum

theorem prepared_calls (F : CNF) (verdict : Bool) (calls : Nat)
    (returned : UnitPreparedDecision.solveCNFCounted F = some (verdict,calls)) :
    calls ≤ perPartBound F := by
  by_cases empty : hasEmpty (UnitPreparedDecision.prepare F) = true
  · have same : (false,0) = (verdict,calls) := Option.some.inj (by
      simpa [UnitPreparedDecision.solveCNFCounted, empty] using returned)
    have zero := congrArg Prod.snd same
    change 0 = calls at zero
    omega
  · have observed : Lazy.solveCNFCounted (UnitPreparedDecision.prepare F) = some (verdict,calls) := by
      simpa [UnitPreparedDecision.solveCNFCounted, empty] using returned
    exact Lazy.solveCNFCounted_calls _ _ _ observed

theorem countParts_calls (parts : List CNF) (verdict : Bool) (calls : Nat)
    (returned : countParts parts = some (verdict,calls)) : calls ≤ partsBound parts := by
  induction parts generalizing verdict calls with
  | nil =>
      have same : (true,0) = (verdict,calls) := Option.some.inj returned
      have zero := congrArg Prod.snd same
      change 0 = calls at zero
      simp [partsBound, ← zero]
  | cons part rest ih =>
      cases head : UnitPreparedDecision.solveCNFCounted part with
      | none => simp [countParts, head] at returned
      | some result =>
          rcases result with ⟨decision,n⟩
          have headBound := prepared_calls part decision n head
          cases decision with
          | false =>
              have same : (false,n) = (verdict,calls) := Option.some.inj (by
                simpa [countParts, head] using returned)
              have eq := congrArg Prod.snd same
              change n = calls at eq
              change calls ≤ perPartBound part + partsBound rest
              omega
          | true =>
              cases tail : countParts rest with
              | none => simp [countParts, head, tail] at returned
              | some result =>
                  rcases result with ⟨decision,m⟩
                  have tailBound := ih decision m tail
                  have same : (decision,n+m) = (verdict,calls) := Option.some.inj (by
                    simpa [countParts, head, tail] using returned)
                  have eq := congrArg Prod.snd same
                  change n+m = calls at eq
                  change calls ≤ perPartBound part + partsBound rest
                  omega

/-- The actual automatic extracted-component solver receives an additive
leaf-call bound. Partitioning, validation, preparation, and work per leaf
are deliberately not counted here. -/
theorem solveCNFCounted_calls (F : CNF) (verdict : Bool) (calls : Nat)
    (returned : ComponentExtraction.solveCNFCounted F = some (verdict,calls)) :
    calls ≤ partsBound (extract F) := by
  apply countParts_calls (extract F) verdict calls
  simpa [ComponentExtraction.solveCNFCounted, extract_check] using returned

theorem counted_result_and_calls (F : CNF) (verdict : Bool) (calls : Nat)
    (returned : ComponentExtraction.solveCNFCounted F = some (verdict,calls)) :
    ComponentExtraction.solveCNF F = some verdict ∧ calls ≤ partsBound (extract F) := by
  constructor
  · simpa [returned] using (ComponentExtraction.solveCNFCounted_erases F).symm
  · exact solveCNFCounted_calls F verdict calls returned

theorem counted_total_bound (F : CNF) :
    ∃ verdict calls, ComponentExtraction.solveCNFCounted F = some (verdict,calls) ∧
      calls ≤ partsBound (extract F) := by
  cases observed : ComponentExtraction.solveCNFCounted F with
  | none =>
      have impossible : ComponentExtraction.solveCNF F = none := by
        simpa [observed] using (ComponentExtraction.solveCNFCounted_erases F).symm
      exact (ComponentExtraction.solveCNF_ne_none F impossible).elim
  | some result =>
      rcases result with ⟨verdict,calls⟩
      exact ⟨verdict,calls,rfl,solveCNFCounted_calls F verdict calls observed⟩

#print axioms counted_total_bound
#print axioms prepared_calls
#print axioms countParts_calls
#print axioms solveCNFCounted_calls
#print axioms counted_result_and_calls
end PEqualNP.Outside.ComponentExtraction.Cost
