"""Read-only computation from fixed-window usage ledgers; sanitized output only."""
import collections
import hashlib
import json
import math
from pathlib import Path
import sqlite3
import statistics
from datetime import datetime

OUT = Path(__file__).resolve().parent
BASE = OUT.parent / 'input-usage-26h'
START = datetime.fromisoformat('2026-11-25T13:23:10+00:00')
END = datetime.fromisoformat('2026-11-26T15:23:10+00:00')

def load(name):
    return json.loads((BASE / name).read_text())

def inside(value):
    return bool(value) and START <= datetime.fromisoformat(value.replace('Z', '+00:00')) < END

def stats(values):
    v = sorted(values)
    return dict(n=len(v), total=sum(v), mean=sum(v)/len(v), median=statistics.median(v),
                p95_nearest_rank=v[math.ceil(.95*len(v))-1], maximum=max(v)) if v else dict(n=0)

codex = [json.loads(line) for line in (BASE/'codex-response-input-records.jsonl').read_text().splitlines()]
api = [json.loads(line) for line in (BASE/'codex-openai-api-response-input-records.jsonl').read_text().splitlines()]
cs = load('codex-summary.json')
fs = load('fable-summary.json')
gs = load('gemini-audit.json')
claude_calls = {}
for name,key in [('fable-transcript-audit.json','rows'),('fable-raw-audit.json','calls'),('fable-raw-billing-audit.json','calls')]:
    for row in load(name)[key]:
        if inside(row.get('first')):
            if row['message_id'] in claude_calls:
                assert claude_calls[row['message_id']]['usage'] == row['usage']
            else:
                claude_calls[row['message_id']] = row
assert len(claude_calls) == 36728

def claude_input(row):
    return sum(row['usage'].values())

models = sorted({r['model'] for r in claude_calls.values()})
fable = [r for r in claude_calls.values() if r['model']=='claude-fable-5-2']
fable_paths = sorted({r['path'] for r in load('fable-transcript-audit.json')['rows'] if r['model']=='claude-fable-5-2'})
spawns = {}; compactions = {}; toolcalls = {}; fable_compact_records = []; fable_reads = collections.Counter()
for src in sorted({r['source'] for r in codex}):
    for number,line in enumerate(Path(src).open(),1):
        event = json.loads(line); q=event.get('payload',{})
        if not inside(event.get('timestamp')):
            continue
        if event.get('type')=='response_item' and q.get('type')=='function_call':
            key=q.get('call_id') or q.get('id')
            toolcalls.setdefault(key,q.get('name'))
            if q.get('name')=='spawn_agent':
                arg=json.loads(q['arguments'])
                spawns.setdefault(key,dict(task_name=arg.get('task_name'),fork_turns=arg.get('fork_turns','omitted'),
                                          brief_chars=len(arg.get('message','')),source=src,line=number))
        if event.get('type')=='compacted':
            key=q.get('compaction_response_id')
            if key:
                compactions.setdefault(key,dict(source=src,line=number,timestamp=event['timestamp'],
                                                replacement_history_items=len(q.get('replacement_history',[]))))
for src in fable_paths:
    seen_tools=set()
    for number,line in enumerate(Path(src).open(),1):
        event=json.loads(line)
        if not inside(event.get('timestamp')):
            continue
        if 'compact' in str(event.get('type','')).lower() or 'compact' in str(event.get('subtype','')).lower():
            fable_compact_records.append(dict(source=src,line=number,event_type=event.get('type'),subtype=event.get('subtype')))
        if event.get('type')=='assistant':
            for block in event.get('message',{}).get('content',[]):
                if isinstance(block,dict) and block.get('type')=='tool_use' and block.get('id') not in seen_tools:
                    seen_tools.add(block.get('id'))
                    if block.get('name')=='Read':
                        path=block.get('input',{}).get('file_path')
                        if isinstance(path,str):
                            fable_reads[path]+=1

hermes = sqlite3.connect('file:/Users/jackpohlad/.hermes/state.db?mode=ro',uri=True)
summaries=[]
for sid in sorted({r['session_id'] for r in gs['hermes']['records']}):
    for row in hermes.execute('select session_id,timestamp,length(content) from messages where session_id=? and _compressed_summary=1 and timestamp>=? and timestamp<?',(sid,START.timestamp(),END.timestamp())):
        summaries.append(dict(session_id=row[0],timestamp_epoch=row[1],summary_characters=row[2]))

threads=[]
for tid,row in cs['by_thread'].items():
    records=sorted([r for r in codex if r['thread_id']==tid],key=lambda r:r['timestamp'])
    threads.append(dict(thread_id=tid,agent=row['agent_path'] or '/root',input_tokens=row['total_input_tokens'],
                        input_share=row['total_input_tokens']/cs['all_available_local_codex_logs']['total_input_tokens'],
                        cached_input_tokens=row['cached_input_tokens'],fresh_input_tokens=row['uncached_input_tokens'],
                        responses=len(records),per_response=stats([r['input_tokens'] for r in records]),
                        first_response_input_tokens=records[0]['input_tokens'],
                        history_fork_observed=bool(row['forked_from_id'])))
threads.sort(key=lambda r:r['input_tokens'],reverse=True)
top_fable=[]
for path in sorted({r['path'] for r in fable}):
    rows=[r for r in fable if r['path']==path]
    top_fable.append(dict(source=path,input_tokens=sum(map(claude_input,rows)),per_response=stats(list(map(claude_input,rows)))))
top_fable.sort(key=lambda r:r['input_tokens'],reverse=True)

ratios={
    'codex_cached_share':998197632/1006451575,
    'codex_non_cached_share':8253943/1006451575,
    'claude_cache_read_share':629256916/799707021,
    'claude_cache_creation_share':170374993/799707021,
    'claude_uncached_input_field_share':75112/799707021,
    'claude_non_read_input_share':(170374993+75112)/799707021,
    'fable_cache_read_share':153574173/159410637,
    'gemini_known_subset_cache_read_share':93265823/(93265823+24632474),
    'gemini_cache_read_share_lower_bound_of_recorded_input':93265823/118661667,
    'gemini_cache_read_share_upper_bound_of_recorded_input':(93265823+763370)/118661667,
}
compaction_pairs=[]
for tid in {r['thread_id'] for r in codex}:
    ordered=sorted([r for r in codex if r['thread_id']==tid],key=lambda r:r['timestamp'])
    for index,row in enumerate(ordered[:-1]):
        if not row['matched_token_count']:
            following=ordered[index+1]
            compaction_pairs.append(dict(thread_id=tid,compaction_request_input=row['input_tokens'],
                                         next_response_input=following['input_tokens'],
                                         ratio=following['input_tokens']/row['input_tokens']))
result=dict(
    window=dict(start_inclusive=START.isoformat(),end_exclusive=END.isoformat()),
    method='Input is total request context, including cached input; p95 uses nearest rank. No prompt, response, or reasoning text is included. Counts deduplicate inherited Codex call/compaction records and Claude message IDs.',
    ratios=ratios,
    per_response_input=dict(
        codex_all=stats([r['input_tokens'] for r in codex]),
        codex_non_compaction=stats([r['input_tokens'] for r in codex if r['matched_token_count']]),
        codex_new_non_cached=stats([r['input_tokens']-r['cached_input_tokens'] for r in codex]),
        claude_identified_calls=stats(list(map(claude_input,claude_calls.values()))),
        claude_by_model={m:stats([claude_input(r) for r in claude_calls.values() if r['model']==m]) for m in models},
        api_openai=stats([r['input_tokens'] for r in api]),
        gemini_direct_receipts_only=stats([r['input_tokens_including_cache'] for r in gs['direct_receipts']['records']]),
        gemini_hermes=dict(api_calls=4462,total_input_tokens=117898297,mean_per_call=117898297/4462,
                           median=None,p95=None,maximum=None,note='Only session/model usage aggregates survive; cannot infer per-call quantiles. Direct receipts are a small different subset.')),
    codex_threads=threads,
    fable_identified_calls_by_transcript=top_fable,
    codex_spawns=dict(unique_calls=len(spawns),fork_turns_counts=dict(collections.Counter(r['fork_turns'] for r in spawns.values())),records=list(spawns.values())),
    compaction=dict(codex_unique_events=len(compactions),codex_records=list(compactions.values()),
                    codex_usage=cs['counter_crosscheck']['compaction_usage_absent_from_token_count'],
                    codex_input_share=7655538/1006451575,
                    codex_next_response_comparison=dict(
                        pairs=compaction_pairs,
                        median_compaction_request_input=statistics.median(r['compaction_request_input'] for r in compaction_pairs),
                        median_next_response_input=statistics.median(r['next_response_input'] for r in compaction_pairs),
                        median_next_to_compaction_ratio=statistics.median(r['ratio'] for r in compaction_pairs),
                        note='Descriptive before/next requests, not a controlled efficiency comparison or prediction of safe earlier compaction.'),
                    fable_local_compaction_event_count=len(fable_compact_records),
                    fable_note='No compact-type/subtype event in the five retained Fable transcripts during the window; not proof that provider-side context transformations never occurred.',
                    gemini_hermes_summary_events=summaries),
    fable_explicit_read_tool_top=[dict(path=p,read_calls=n) for p,n in fable_reads.most_common(10)],
    limitations=[
        'Cache hits are successfully reused prefixes, not a count of wasted or unnecessary tokens. Fresh input is not a count of novel ideas.',
        'Claude quantiles cover 36,728 individually identified calls, excluding aggregate-only supplements; totals in fable-summary remain authoritative.',
        'Gemini retains no full per-response usage ledger; missing direct usage and unknown cache splits preclude an exact full-workload fresh/cache proportion.',
        'OpenAI API cached input was not logged; unknown is not zero.',
        'No model/settings/effort/timeouts or running process was changed. This audit does not establish counterfactual savings or answer quality.',
    ],
    source_sha256={str(BASE/n):hashlib.sha256((BASE/n).read_bytes()).hexdigest() for n in ['codex-summary.json','fable-summary.json','gemini-audit.json','codex-response-input-records.jsonl']}
)
(OUT/'context-reuse-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['ratios','per_response_input']},indent=2))
print(json.dumps({'top_codex':threads[:5],'fable_by_transcript':top_fable,'spawns':result['codex_spawns']['fork_turns_counts'],
                  'codex_compactions':len(compactions),'fable_compactions':len(fable_compact_records),'hermes_compactions':summaries},indent=2))
