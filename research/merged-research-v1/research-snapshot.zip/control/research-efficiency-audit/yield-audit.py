"""Read-only, fixed-window research yield audit; emits no source or prompt text."""
import ast
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sqlite3
import statistics
import sys
import warnings

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
HUB = Path('/Users/jackpohlad/Desktop/P vs NP Research Hub')
START = datetime.fromisoformat('2026-11-25T13:23:10+00:00')
END = datetime.fromisoformat('2026-11-26T15:23:10+00:00')
def dt(s):
    return datetime.fromisoformat(s.replace('Z', '+00:00')) if s else None
def inside(s):
    return bool(s and START <= dt(s) < END)
def counter(items):
    return dict(sorted(Counter(items).items(), key=lambda x: str(x[0])))
def sha(data):
    return hashlib.sha256(data).hexdigest()

connection = sqlite3.connect('file:' + str(HUB / 'workspace.sqlite') + '?mode=ro', uri=True)
connection.row_factory = sqlite3.Row
connection.execute('BEGIN')
rows = [dict(row) for row in connection.execute('SELECT * FROM jobs')]
meta = {row['key']: json.loads(row['value_json']) for row in connection.execute('SELECT * FROM meta')}
connection.rollback()
connection.close()
snapshot_fingerprint = sha(json.dumps(rows, sort_keys=True).encode())
for row in rows:
    row['metadata'] = json.loads(row.pop('metadata_json'))
by_id = {row['id']: row for row in rows}
gens = [row for row in rows if row['metadata'].get('kind') == 'generation' and inside(row['ended_at'])]
reviews = [row for row in rows if row['metadata'].get('kind') in ('review', 'model_review') and inside(row['ended_at'])]
tests = [row for row in rows if row['metadata'].get('kind') == 'independent_test' and inside(row['ended_at'])]
done_reviews = [row for row in reviews if row['status'] == 'review_complete']
saved = [row for row in gens if row['status'] == 'generated']
parsing = [row for row in saved if row['parse_ok']]
tested_ids = {row['metadata']['candidate_id'] for row in tests}
reviewed_ids = {row['metadata']['candidate_id'] for row in done_reviews}
receipts, checks, tested_records = Counter(), Counter(), []
sources, asts = defaultdict(list), defaultdict(list)
normalized_test_asts = set()
for row in tests:
    report = row['metadata'].get('test_report', {})
    candidate = by_id[row['metadata']['candidate_id']]
    cid = candidate['id']
    status = report.get('status')
    sources[row['source_sha256']].append(status)
    asts[candidate['ast_sha256']].append(status)
    checks['report_matches_job_source_hash'] += report.get('source_sha256') == row['source_sha256']
    checks['sandboxed'] += report.get('sandboxed') is True
    checks['finite_cases_observed'] += report.get('cases_checked', 0) > 0
    source = Path(candidate['path']) / 'candidate.py'
    raw = source.read_bytes()
    checks['current_source_matches_test_hash'] += sha(raw) == row['source_sha256']
    try:
        fingerprint = sha(ast.dump(ast.parse(raw), include_attributes=False).encode())
        normalized_test_asts.add(fingerprint)
        checks['recomputed_ast_matches_candidate'] += fingerprint == candidate['ast_sha256']
    except SyntaxError:
        checks['current_ast_parse_errors'] += 1
    for label, path in [('test_receipt', Path(row['path']) / 'test-receipt.json'),
                        ('worker_log', Path(row['path']) / 'run.log')]:
        try:
            receipt = json.loads(path.read_text())
            receipts[label + '_matches_db'] += receipt == report
        except (OSError, ValueError):
            receipts[label + '_missing_or_unparseable'] += 1
    checks['candidate_report_matches_test_report'] += candidate['metadata'].get('independent_test_report') == report
    if status == 'independent_pass':
        checks['passes_meet_full_finite_suite_contract'] += all([
            report.get('cases_total') == 524, report.get('cases_checked') == 524,
            report.get('resolved_cases') == 524, report.get('unknown_cases') == 0,
            report.get('exception_cases') == 0, report.get('termination') == 'completed',
            report.get('counterexample') is None,
            report.get('suite_version') == 'sat-indep-suite-v1',
            report.get('suite_sha256') == '3eab2944aea5006c5f65ceb01607a8f9f5776704c659d85f4d564b073a2ea60f'])
    ce = report.get('counterexample')
    if status == 'independent_fail':
        n, clauses = ce['nvars'], ce['clauses']
        def satisfies(a):
            return all(any(a[abs(lit)-1] == (lit > 0) for lit in clause) for clause in clauses)
        sat = any(satisfies([bool(mask & (1 << bit)) for bit in range(n)]) for mask in range(1 << n))
        checks['counterexample_oracle_rechecked'] += ce['oracle'] == ('SAT' if sat else 'UNSAT')
        kind = ce['kind']
        if kind == 'false_unsat':
            checks['substantive_counterexample_rechecked'] += sat and ce.get('candidate_status') == 'UNSAT'
        elif kind == 'wrong_sat_witness':
            checks['substantive_counterexample_rechecked'] += not satisfies(ce['candidate_assignment'])
    tested_records.append({'candidate_id': cid, 'source_sha256': row['source_sha256'],
        'ast_sha256': candidate['ast_sha256'], 'status': status, 'ended_at': row['ended_at'],
        'cases_checked': report.get('cases_checked', 0),
        'counterexample_kind': ce.get('kind') if ce else None})

eligible = set()
for row in done_reviews:
    report = row['metadata'].get('review_report', {})
    candidate = by_id.get(row['metadata'].get('candidate_id'))
    if (candidate and report.get('safe_to_execute') is True
        and report.get('source_sha256') == candidate['source_sha256']
        and candidate['status'] == 'generated' and candidate['parse_ok']
        and not candidate['duplicate_of'] and not candidate['metadata'].get('independent_test_excluded')):
        eligible.add(candidate['id'])

input_summary = json.loads((HERE.parent / 'input-usage-26h/combined-summary.json').read_text())
denominator = input_summary['recorded_input']['expanded_all_research_sum']
status_counts = Counter(record['status'] for record in tested_records)
answer_failures = sum(record['counterexample_kind'] in ('false_unsat','wrong_sat_witness') for record in tested_records)
observed = sum(record['cases_checked'] > 0 for record in tested_records)
rates = {key: value * 100_000_000 / denominator for key, value in {
    'distinct_test_attempts': len(tests), 'distinct_candidates_with_observed_finite_tests': observed,
    'finite_suite_passes': status_counts['independent_pass'],
    'independent_failures_including_contract': status_counts['independent_fail'],
    'substantive_sat_answer_refutations': answer_failures,
    'verified_general_polynomial_hypotheses': 0}.items()}
formal = [row for row in rows if row['metadata'].get('kind','').startswith('formal')
          and inside(row['ended_at'] or row['created_at'])]
lean = meta.get('lean_checker', {})
durations = [row['metadata'].get('test_report', {}).get('duration_seconds', 0) for row in tests]
normalized_generation_asts = set()
generation_source_checks = Counter()
with warnings.catch_warnings():
    warnings.simplefilter('ignore', SyntaxWarning)
    for row in saved:
        try:
            raw = (Path(row['path']) / 'candidate.py').read_bytes()
            generation_source_checks['source_matches_saved_hash'] += sha(raw) == row['source_sha256']
            normalized_generation_asts.add(sha(ast.dump(ast.parse(raw), include_attributes=False).encode()))
        except (OSError, SyntaxError):
            generation_source_checks['missing_or_unparseable'] += 1
summary = {
    'audit_generated_at_utc': datetime.now(timezone.utc).isoformat(),
    'window_start_inclusive_utc': START.isoformat(), 'window_end_exclusive_utc': END.isoformat(),
    'numerator_scope': 'Hub board independent-test completions; excludes earlier workspace research and formal component audits.',
    'db_rows_snapshot_sha256': snapshot_fingerprint,
    'independent_tests': {
        'attempts': len(tests), 'distinct_candidate_ids': len(tested_ids),
        'distinct_source_hashes': len(sources), 'distinct_ast_hashes': len(asts),
        'distinct_recomputed_ast_hashes_single_interpreter': len(normalized_test_asts),
        'recomputed_ast_python_version': sys.version.split()[0],
        'duplicate_source_test_attempts': len(tests) - len(sources),
        'duplicate_ast_test_attempts': len(tests) - len(asts),
        'source_groups_with_conflicting_verdicts': sum(len(set(x)) > 1 for x in sources.values()),
        'candidates_with_observed_finite_cases': observed, 'verdicts': dict(status_counts),
        'failure_kinds': counter(r['counterexample_kind'] for r in tested_records if r['status']=='independent_fail'),
        'substantive_sat_answer_refutations': answer_failures,
        'source_and_receipt_checks': dict(checks), 'receipt_copy_checks': dict(receipts),
        'finite_suite_max_variables': 5, 'finite_suite_cases': 524,
        'first_completion_utc': min(row['ended_at'] for row in tests),
        'last_completion_utc': max(row['ended_at'] for row in tests),
        'median_worker_seconds': statistics.median(durations), 'sum_worker_seconds': sum(durations),
        'inconclusive_terminations': counter(row['metadata']['test_report'].get('termination') for row in tests if row['metadata']['test_report'].get('status')=='inconclusive')},
    'generation': {'attempts_completed_or_terminal': len(gens), 'status_counts': counter(row['status'] for row in gens),
        'generated': len(saved), 'generated_distinct_source_hashes': len({row['source_sha256'] for row in saved}),
        'generated_distinct_ast_hashes': len({row['ast_sha256'] for row in parsing}),
        'generated_marked_ast_duplicates': sum(bool(row['duplicate_of']) for row in saved),
        'generated_distinct_recomputed_ast_hashes_single_interpreter': len(normalized_generation_asts),
        'generated_duplicate_rows_recomputed_ast': len(saved) - len(normalized_generation_asts),
        'source_checks': dict(generation_source_checks),
        'generated_without_completed_model_review': len({row['id'] for row in saved} - reviewed_ids)},
    'reviews': {'attempts': len(reviews), 'status_counts': counter(row['status'] for row in reviews),
        'complete': len(done_reviews), 'distinct_reviewed_candidates': len(reviewed_ids),
        'completed_reviews_beyond_one_per_candidate': len(done_reviews) - len(reviewed_ids),
        'verdicts_model_opinions_only': counter(row['metadata'].get('review_report',{}).get('verdict') for row in done_reviews),
        'goal_categories_model_opinions_only': counter(row['metadata'].get('review_report',{}).get('goal_category') or 'missing' for row in done_reviews),
        'safe_test_eligible_candidates_current_row_state': len(eligible),
        'safe_test_eligible_but_untested_current_row_state': len(eligible - tested_ids),
        'attempts_by_candidate_histogram': counter(Counter(row['metadata'].get('candidate_id') for row in reviews).values())},
    'general_proof': {'verified_general_polynomial_hypotheses': 0,
        'board_proof_checked_flags': sum(row['review_status']=='proof_checked' or row['metadata'].get('proof_checked') is True for row in rows),
        'formal_job_status_counts_separate_from_general_proof': counter(row['status'] for row in formal),
        'lean_general_polynomial_sat_proof': lean.get('general_polynomial_sat_proof'),
        'lean_general_finite_cnf_decider_verified': lean.get('general_finite_cnf_decider_verified')},
    'denominator': {'recorded_all_research_input_lower_bound': denominator,
        'rates_per_100m_recorded_input': rates,
        'interpretation': 'Descriptive hub-only yield against all-research recorded input. Holding the hub numerator fixed, missing input makes these ratios upper bounds on the corresponding true-input yield. Because earlier research outcomes are omitted, these are not an upper or lower bound on total all-research yield.',
        'input_coverage_limits': input_summary['limits']},
    'limits': ['Source/AST distinctness is a syntactic proxy, not semantic or hypothesis uniqueness.',
        'Recorded AST hashes mix Python versions: 566 tested hashes reproduce on Python 3.12 and the remaining 898 reproduce on system Python 3.9. Single-interpreter recomputation is reported separately.',
        'Each test job is counted once; DB reports, candidate metadata, test-receipt.json and run.log are duplicate copies.',
        'Counters use completion timestamps; current generation/review row classifications are not an append-only historical snapshot.',
        'Finite passes cover 524 cases with at most five variables and do not prove general correctness, termination or polynomial complexity.',
        'Model review flaw_found and goal_category are assessment evidence, not independently executed counterexamples.',
        'Formal components are scoped lemmas and can be integration/recompile jobs; their job count is not new theorem count.']}
(HERE / 'yield-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
(HERE / 'deduplicated-test-outcomes.jsonl').write_text(''.join(json.dumps(record, sort_keys=True) + '\n' for record in tested_records))
print(json.dumps(summary, indent=2))
