#!/usr/bin/env python3
"""Read-only fixed-window receipt reconciliation; writes sanitized audit output only.

The prior input audit fixes request identities, input buckets, and time allocation.
This extends those exact identities with recorded output/reasoning without
making provider calls, modifying workers, or retaining message content/secrets.
"""
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import sqlite3
import re

WORK = Path('/Users/jackpohlad/Documents/Codex/2026-11-25/fetch-and-follow-the-instructions-at')
BASE = WORK / 'work/alg001/control/input-usage-26h'
OUT = WORK / 'work/alg001/control/research-efficiency-audit'
HUB = Path('/Users/jackpohlad/Desktop/P vs NP Research Hub')
START = datetime.fromisoformat('2026-11-25T13:23:10+00:00')
END = datetime.fromisoformat('2026-11-26T15:23:10+00:00')
ROOT_ID = '01a2140b-1532-7e52-bfe1-e5a91b564549'

def load(name): return json.loads((BASE/name).read_text())
def dt(s): return datetime.fromisoformat(s.replace('Z','+00:00'))
def inside(s): return bool(s) and START <= dt(s) < END
def sha(s): return hashlib.sha256(s.encode()).hexdigest()
def read_jsonl(p):
    for n,line in enumerate(p.open(errors='replace'),1):
        try: yield n,json.loads(line)
        except json.JSONDecodeError: pass
def save(name,obj): (OUT/name).write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
def ratio(o,i): return o/i if i else None

# Codex: use the already deduplicated per-response ledger and re-read exact lines.
codex_input = [json.loads(l) for l in (BASE/'codex-response-input-records.jsonl').open()]
by_file = defaultdict(dict)
for r in codex_input: by_file[r['source']][r['line']] = r
codex = []
for path, wanted in by_file.items():
    for line,e in read_jsonl(Path(path)):
        if line not in wanted: continue
        r = wanted[line]; u=e['payload']['usage']
        assert e['type']=='token_usage_record' and sha(e['payload']['response_id'])==r['response_id_sha256']
        assert u['input_tokens']==r['input_tokens'] and inside(e['timestamp'])
        o=u.get('output_tokens'); t=u.get('reasoning_output_tokens')
        assert isinstance(o,int) and isinstance(t,int) and 0<=t<=o
        codex.append({**r,'output_tokens_including_reasoning':o,'reasoning_tokens_subset':t})
assert len(codex)==len(codex_input)
def codex_sum(rs):
    i=sum(r['input_tokens'] for r in rs);o=sum(r['output_tokens_including_reasoning'] for r in rs)
    t=sum(r['reasoning_tokens_subset'] for r in rs)
    return dict(requests=len(rs),input_tokens=i,output_tokens_including_reasoning=o,reasoning_tokens_subset=t,
                visible_output_tokens=o-t,output_input_ratio=ratio(o,i),reasoning_output_fraction=ratio(t,o),
                max_output_tokens_per_request=max((r['output_tokens_including_reasoning'] for r in rs),default=None),
                max_reasoning_tokens_per_request=max((r['reasoning_tokens_subset'] for r in rs),default=None))
codex_result={
    'route':'Codex app/session usage; current local auth_mode=chatgpt and no API key; not the OpenAI API generator route',
    'totals':codex_sum(codex),
    'root_chat':codex_sum([r for r in codex if r['thread_id']==ROOT_ID]),
    'research_subagents':codex_sum([r for r in codex if r['thread_id']!=ROOT_ID]),
    'by_model':{m:codex_sum([r for r in codex if r['model']==m]) for m in sorted({r['model'] for r in codex})},
    'semantics':'output_tokens already includes reasoning_output_tokens; subtract to obtain visible output, never add twice.',
    'actual_invoice_or_credit_deduction_usd':None,
    'limitations':['Auth mode is a current local observation, not a historical provider billing export. Token use does not establish an API charge or an exact ChatGPT credit deduction.']}

# OpenAI API: same per-receipt response identities as the input audit.
api_input = [json.loads(l) for l in (BASE/'codex-openai-api-response-input-records.jsonl').open()]
api=[];cache={}
for r in api_input:
    if r['source'] not in cache:cache[r['source']]=json.loads(Path(r['source']).read_text())
    receipt=cache[r['source']];response=receipt['responses'][r['response_index']];u=response['usage']
    assert u['input_tokens']==r['input_tokens']
    o=u.get('output_tokens');t=(u.get('output_tokens_details') or {}).get('reasoning_tokens')
    assert isinstance(o,int)
    api.append({**r,'output_tokens_including_reasoning':o,'reasoning_tokens_subset':t,
                'requested_service_tier':receipt.get('requested_service_tier'),
                'served_service_tier':response.get('service_tier'),'requested_reasoning':receipt.get('reasoning')})
def api_sum(rs):
    i=sum(r['input_tokens'] for r in rs);o=sum(r['output_tokens_including_reasoning'] for r in rs)
    return dict(requests=len(rs),input_tokens=i,output_tokens_including_reasoning=o,
        reasoning_tokens_subset=None if any(r['reasoning_tokens_subset'] is None for r in rs) else sum(r['reasoning_tokens_subset'] for r in rs),
        output_input_ratio=ratio(o,i),max_output_tokens_per_request=max((r['output_tokens_including_reasoning'] for r in rs),default=None),
        requests_missing_reasoning_detail=sum(r['reasoning_tokens_subset'] is None for r in rs))
api_result={'route':'OpenAI API research generators and standalone probes','totals':api_sum(api),
    'by_model':{m:api_sum([r for r in api if r['model']==m]) for m in sorted({r['model'] for r in api})},
    'tier_reasoning_counts':dict(Counter(str((r['model'],r['requested_service_tier'],r['served_service_tier'],r['requested_reasoning'])) for r in api)),
    'actual_invoice_or_credit_deduction_usd':None,
    'limitations':load('codex-openai-api-summary.json')['limitations']+['Logger retains total output_tokens but discards output_tokens_details, so reasoning output is unknown, not zero.']}

# Claude: select exactly the old request IDs, then take each message's largest
# observed usage fragment (stream fragments repeat and evolve the same message).
raws=[load(n) for n in ['fable-raw-audit.json','fable-raw-billing-audit.json']]
transcript=load('fable-transcript-audit.json')
billing=load('fable-billing-attempts.json')
claude_ledger=load('fable-session-ledger.json')
selected={}
paths=set()
for r in transcript['rows']+[r for raw in raws for r in raw['calls']]:
    if inside(r.get('first')):
        selected[r['message_id']]=r;paths.add(r['path'])
allowed_sessions=set()
for raw in raws:
    for r in raw['sessions']:
        paths.update(r['paths'])
        if inside(r.get('first')) and inside(r.get('last')):allowed_sessions.add(r['session_id'])
call_usage={}; aggregate=defaultdict(dict); route_evidence=defaultdict(set); model_cost={};source_init=defaultdict(set)
out_fields=('output_tokens','thinking_tokens')
max_thinking_request=None;max_output_request=None
def add_aggregate(sid,model,u,source):
    key=(sid,model);rec=aggregate[key]
    for old,new in [('outputTokens','output_tokens'),('thinkingTokens','thinking_tokens'),
                    ('cacheCreationEphemeral5mInputTokens','cache_5m_tokens'),('cacheCreationEphemeral1hInputTokens','cache_1h_tokens')]:
        if isinstance(u.get(old),int):rec[new]=max(rec.get(new,0),u[old])
    if isinstance(u.get('costUSD'),(int,float)):model_cost[key]=max(model_cost.get(key,0),u['costUSD'])
    rec.setdefault('sources',set()).add(source)
for path in sorted(paths):
    p=Path(path)
    if not p.is_absolute():p=WORK/p
    if not p.exists():continue
    for line,e in read_jsonl(p):
        sid=e.get('session_id') or e.get('sessionId')
        if e.get('type')=='system' and e.get('subtype')=='init':
            marker=e.get('apiKeySource')
            source_init[sid].add(str(marker))
            if marker=='ANTHROPIC_API_KEY':route_evidence[sid].add('api_backup')
            elif marker=='none':route_evidence[sid].add('subscription')
        m=e.get('message') or {}
        if not isinstance(m,dict):m={}
        mid=m.get('id')
        if mid in selected:
            if e.get('timestamp') and not inside(e['timestamp']):continue
            u=m.get('usage') or {};known=call_usage.setdefault(mid,{})
            o=u.get('output_tokens');t=(u.get('output_tokens_details') or {}).get('thinking_tokens')
            if isinstance(o,int) and ('output_tokens' not in known or o>known['output_tokens']):
                known['output_tokens']=o
                known['output_provenance']={'source':str(p),'line':line,'timestamp':e.get('timestamp'),'stop_reason':m.get('stop_reason')}
            if isinstance(t,int) and ('thinking_tokens' not in known or t>known['thinking_tokens']):
                known['thinking_tokens']=t
                known['thinking_provenance']={'source':str(p),'line':line,'timestamp':e.get('timestamp'),'stop_reason':m.get('stop_reason')}
            for ttl,field in [('ephemeral_5m_input_tokens','cache_5m_tokens'),('ephemeral_1h_input_tokens','cache_1h_tokens')]:
                value=(u.get('cache_creation') or {}).get(ttl)
                if isinstance(value,int):known[field]=max(known.get(field,0),value)
            if u.get('speed'):known.setdefault('speed',set()).add(u['speed'])
        if e.get('type')=='result' and sid in allowed_sessions:
            for model,u in (e.get('modelUsage') or {}).items():add_aggregate(sid,model,u,str(p))
for r in billing:
    if inside(r.get('started_at')) and inside(r.get('ended_at')):
        if r.get('session_id') and r.get('route'):route_evidence[r['session_id']].add(r['route'])
        for model,u in (r.get('model_usage') or {}).items():add_aggregate(r['session_id'],model,u,r['path'])
round2=WORK/'work/alg001/fable_synthesis_round2/response.json'
d=json.loads(round2.read_text())
for model,u in d['modelUsage'].items():add_aggregate(d['session_id'],model,u,str(round2))
assert json.loads(round2.with_name('process.json').read_text())['subscription_only'] is True
route_evidence[d['session_id']].add('subscription')
claude_calls=defaultdict(Counter)
speed_counts=defaultdict(Counter)
for mid,r in selected.items():
    u=call_usage.get(mid,{})
    key=(r['session_id'],r['model'])
    for speed in u.get('speed',[]):speed_counts[r['model']][speed]+=1
    for f in out_fields+('cache_5m_tokens','cache_1h_tokens'):
        if f in u:claude_calls[key][f]+=u[f];claude_calls[key][f+'_reported_requests']+=1
    if 'thinking_tokens' in u and (max_thinking_request is None or u['thinking_tokens']>max_thinking_request['tokens']):
        max_thinking_request={'tokens':u['thinking_tokens'],'model':r['model'],'message_id_sha256':sha(mid),**u['thinking_provenance']}
    if 'output_tokens' in u and (max_output_request is None or u['output_tokens']>max_output_request['tokens']):
        max_output_request={'tokens':u['output_tokens'],'model':r['model'],'message_id_sha256':sha(mid),**u['output_provenance']}
claude=[]
for r in claude_ledger:
    key=(r['session_id'],r['model']);calls=claude_calls[key];a=aggregate[key]
    routes=route_evidence[r['session_id']]
    if len(routes)>1:raise AssertionError('Conflicting routes '+r['session_id'])
    route=next(iter(routes)) if routes else 'unknown'
    o=max(calls.get('output_tokens',0),a.get('output_tokens',0)) if 'output_tokens' in calls or 'output_tokens' in a else None
    t=max(calls.get('thinking_tokens',0),a.get('thinking_tokens',0)) if 'thinking_tokens' in calls or 'thinking_tokens' in a else None
    assert t is None or o is None or t<=o
    cache5=max(calls.get('cache_5m_tokens',0),a.get('cache_5m_tokens',0))
    cache1=max(calls.get('cache_1h_tokens',0),a.get('cache_1h_tokens',0))
    assert cache5+cache1 <= r['input_usage']['cache_creation_input_tokens']
    item=dict(session_id=r['session_id'],model=r['model'],route=route,input_tokens=sum(r['input_usage'].values()),input_usage=r['input_usage'],
      cache_creation_5m_tokens_reported=cache5,cache_creation_1h_tokens_reported=cache1,
      cache_creation_ttl_unknown_tokens=r['input_usage']['cache_creation_input_tokens']-cache5-cache1,
      output_tokens_including_thinking=o,thinking_tokens_reported_subset=t,
      thinking_coverage_complete=(t is not None and ('thinking_tokens' in a or calls['thinking_tokens_reported_requests']==r['identified_call_count'])),
      identified_requests=r['identified_call_count'],requests_with_output=calls['output_tokens_reported_requests'],
      requests_with_thinking=calls['thinking_tokens_reported_requests'],
      call_output=calls.get('output_tokens'),terminal_output=a.get('output_tokens'),
      call_thinking=calls.get('thinking_tokens'),terminal_thinking=a.get('thinking_tokens'),
      cli_modeled_cost_usd=model_cost.get(key),init_api_key_source_markers=sorted(source_init[r['session_id']]))
    claude.append(item)
def claude_sum(rs):
    i=sum(r['input_tokens'] for r in rs);o=sum(r['output_tokens_including_thinking'] or 0 for r in rs)
    t=sum(r['thinking_tokens_reported_subset'] or 0 for r in rs)
    return dict(sessions=len(rs),input_tokens=i,output_tokens_including_thinking=o,
                sessions_missing_all_output_counts=sum(r['output_tokens_including_thinking'] is None for r in rs),
                recorded_usage_only=True,
                input_usage={f:sum(r['input_usage'][f] for r in rs) for f in ['input_tokens','cache_creation_input_tokens','cache_read_input_tokens']},
                cache_creation_5m_tokens_reported=sum(r['cache_creation_5m_tokens_reported'] for r in rs),
                cache_creation_1h_tokens_reported=sum(r['cache_creation_1h_tokens_reported'] for r in rs),
                cache_creation_ttl_unknown_tokens=sum(r['cache_creation_ttl_unknown_tokens'] for r in rs),
                thinking_tokens_reported_subset=t,thinking_coverage_complete=all(r['thinking_coverage_complete'] for r in rs),
                sessions_missing_complete_thinking_detail=sum(not r['thinking_coverage_complete'] for r in rs),
                output_input_ratio=ratio(o,i),recorded_thinking_output_fraction=ratio(t,o),
                cli_modeled_cost_usd=sum(r['cli_modeled_cost_usd'] or 0 for r in rs),
                sessions_with_modeled_cost=sum(r['cli_modeled_cost_usd'] is not None for r in rs),
                actual_invoice_or_credit_deduction_usd=None)
claude_result={'route':'Mixed Claude subscription CLI and Anthropic API backup; route evidence retained per session',
    'totals':claude_sum(claude),
    'by_model':{m:claude_sum([r for r in claude if r['model']==m]) for m in sorted({r['model'] for r in claude})},
    'by_route':{route:claude_sum([r for r in claude if r['route']==route]) for route in sorted({r['route'] for r in claude})},
    'by_route_and_model':{route:{m:claude_sum([r for r in claude if r['route']==route and r['model']==m]) for m in sorted({r['model'] for r in claude if r['route']==route})} for route in sorted({r['route'] for r in claude})},
    'max_reported_thinking_per_request':max_thinking_request,'max_reported_output_per_request':max_output_request,
    'per_message_served_speed_counts_by_model':{m:dict(c) for m,c in speed_counts.items()},
    'semantics':'Claude output_tokens / outputTokens include thinkingTokens; do not add thinking to total output. Message fragments are deduplicated by original message ID and use maxima; session output is the larger of its deduplicated call sum or terminal aggregate, never their sum.',
    'cost_semantics':'CLI modelUsage.costUSD is a model-priced usage estimate, including on subscription sessions. It is not a provider invoice, API account balance change, or Claude subscription credit deduction.',
    'limitations':load('fable-summary.json')['unreported_or_excluded']}
save('claude-output-session-ledger.json',claude)

# Gemini: exact original primary keys, verified by canonical hash; same direct receipts.
g=load('gemini-audit.json');con=sqlite3.connect('file:/Users/jackpohlad/.hermes/state.db?mode=ro',uri=True);con.row_factory=sqlite3.Row
all_g=[dict(r) for r in con.execute("SELECT * FROM session_model_usage WHERE lower(model) LIKE '%gemini%' OR billing_provider='gemini'")]
con.close()
key_fields=('session_id','model','billing_provider','billing_base_url','billing_mode','task')
index={sha(json.dumps([r[k] for k in key_fields],sort_keys=True,separators=(',',':'))):r for r in all_g}
gemini=[]
for old in g['hermes']['records']:
    r=index[old['source_primary_key_sha256']]
    assert all(old[k]==r[k] for k in ['input_tokens','cache_read_tokens','cache_write_tokens','api_call_count','first_seen','last_seen'])
    assert START.timestamp()<=r['first_seen']<=r['last_seen']<END.timestamp()
    assert 0<=r['reasoning_tokens']<=r['output_tokens']
    gemini.append(dict(model=r['model'],scope='hermes',calls=r['api_call_count'],input_tokens=r['input_tokens']+r['cache_read_tokens']+r['cache_write_tokens'],
        output_tokens_including_thinking=r['output_tokens'],thinking_tokens_subset=r['reasoning_tokens'],
        estimated_cost_usd=r['estimated_cost_usd'],actual_cost_usd_field=r['actual_cost_usd'],
        cost_status=r['cost_status'],cost_source=r['cost_source'],task=r['task'],source_primary_key_sha256=old['source_primary_key_sha256']))
for old in g['direct_receipts']['records']:
    r=json.loads(Path(old['source']).read_text());u=r['api_usage']
    assert u['prompt_tokens']==old['input_tokens_including_cache']
    gemini.append(dict(model=old['model'],scope='direct',calls=1,input_tokens=u['prompt_tokens'],
        output_tokens_including_thinking=u.get('completion_tokens'),thinking_tokens_subset=None,source=old['source']))
def gemini_sum(rs):
    i=sum(r['input_tokens'] for r in rs);o=sum(r['output_tokens_including_thinking'] or 0 for r in rs)
    t=sum(r['thinking_tokens_subset'] or 0 for r in rs) if any(r['thinking_tokens_subset'] is not None for r in rs) else None
    return dict(recorded_calls=sum(r['calls'] for r in rs),input_tokens=i,output_tokens_including_thinking=o,
        thinking_tokens_reported_subset=t,thinking_coverage_complete=all(r['thinking_tokens_subset'] is not None for r in rs),
        direct_calls_missing_thinking_detail=sum(r['calls'] for r in rs if r['thinking_tokens_subset'] is None),
        output_input_ratio=ratio(o,i),recorded_thinking_output_fraction=ratio(t,o) if t is not None else None,
        locally_modeled_cost_usd=sum(r.get('estimated_cost_usd',0) for r in rs) if any('estimated_cost_usd' in r for r in rs) else None,
        actual_invoice_or_credit_deduction_usd=None)
# Main request logs independently retain total output and total-token consistency.
# They are a crosscheck of database rows, never additional billable records.
ids={r['session_id'] for r in g['hermes']['records']};seen=set();log_output=defaultdict(Counter)
patt=re.compile(r'\[([^]]+)\].*API call #(\d+): model=(gemini[^ ]+) provider=\S+ in=(\d+) out=(\d+) total=(\d+)')
for p in [Path('/Users/jackpohlad/.hermes/logs/agent.log.1'),Path('/Users/jackpohlad/.hermes/logs/agent.log')]:
    for line in p.open(errors='replace'):
        m=patt.search(line)
        if not m or m[1] not in ids:continue
        rid=re.search(r' id=(\S+)',line);key=(m[1],rid[1]) if rid else (m[1],line[:23],m[2])
        if key in seen:continue
        seen.add(key);v=log_output[m[3]];v['calls']+=1;v['output_tokens']+=int(m[5])
        v['max_output_tokens_per_main_request']=max(v['max_output_tokens_per_main_request'],int(m[5]))
        gap=int(m[6])-int(m[4])-int(m[5]);v['total_minus_prompt_minus_output']+=gap;v['nonzero_gap_calls']+=bool(gap)
for model,v in log_output.items():
    assert v['output_tokens']==sum(r['output_tokens_including_thinking'] for r in gemini if r['scope']=='hermes' and r['model']==model and r['task']=='')
    assert v['nonzero_gap_calls']==0
gemini_result={'route':'Gemini API via Hermes plus direct review/probe requests','totals':gemini_sum(gemini),
    'by_model':{m:gemini_sum([r for r in gemini if r['model']==m]) for m in sorted({r['model'] for r in gemini})},
    'by_scope':{s:gemini_sum([r for r in gemini if r['scope']==s]) for s in ['hermes','direct']},
    'main_request_log_crosscheck':{m:dict(v) for m,v in log_output.items()},
    'max_thinking_tokens_per_request':None,
    'cost_status_counts':dict(Counter(str((r.get('cost_status'),r.get('cost_source'))) for r in gemini if r['scope']=='hermes')),
    'actual_cost_field_semantics':'Every selected actual_cost_usd field is zero, with no actual billing status; this is a default/unpopulated field, not proof of zero charges.',
    'semantics':'Native adapter folds candidatesTokenCount + thoughtsTokenCount into completion_tokens/output_tokens and retains thoughts as reasoning subset. Direct receipt logger discards the subset, so do not add Hermes reasoning to output again.',
    'missing_usage':g['missing_usage'],
    'limitations':['2,901 known successful direct generation calls lack usage receipts; other failed/interrupted/unrecorded calls may also be missing.',
      'Per-request thinking maxima cannot be reconstructed from the persisted Hermes per-session/model aggregates; per-request logs retain only total output. Main logs crosscheck database output exactly. Their total=prompt+output is computed by CanonicalUsage.total_tokens, not a separate check against original provider totalTokenCount.',
      'Reasoning totals are the recorded nonzero subset. Hermes normalizes absent reasoning fields to zero; persisted zero fields alone cannot establish that the provider explicitly reported zero thinking on each call. Original provider per-call metadata is not retained here.']}
save('gemini-output-records.json',gemini)
result={'window':{'start_inclusive':START.isoformat(),'end_exclusive':END.isoformat(),'hours':26},
    'created_at':datetime.now(timezone.utc).isoformat(),'codex':codex_result,'openai_api':api_result,'claude':claude_result,'gemini':gemini_result,
    'source_input_audit_directory':str(BASE),'invoice_or_balance_access_performed':False,
    'current_fable_runner_limits':{'source':str(WORK/'work/alg001/fable_synthesis_round5/run.py'),'lines':[4,5,8,9],
      'requested_effort':'max','local_process_timeout_seconds':None,'configured_output_token_cap':65536,
      'configured_api_timeout_ms':7200000,'configured_retries':0,'started_at':'2026-11-26T15:26:55.148121+00:00',
      'inside_fixed_window':False,'meaning':'No local subprocess wall-clock cutoff does not mean unlimited generation: output token cap and API timeout remain. This audit does not stop or alter the running process.'},
    'previous_fable_round4':{'local_process_timeout_seconds':None,'configured_output_token_cap':32768,
      'finished_at':'2026-11-26T15:23:57.510591+00:00','terminal_receipt_excluded_after_cutoff':True}}
combined_i=sum(result[k]['totals']['input_tokens'] for k in ['codex','openai_api','claude','gemini'])
combined_o=sum(result[k]['totals'].get('output_tokens_including_thinking',result[k]['totals'].get('output_tokens_including_reasoning')) for k in ['codex','openai_api','claude','gemini'])
result['combined_recorded_token_volume']={'input_tokens':combined_i,'output_tokens_including_reasoning':combined_o,
    'output_input_ratio':ratio(combined_o,combined_i),'warning':'Mixed subscription/API routes and different tokenizers; volume comparison only, not a billing estimate or complete provider usage.'}
# Pricing below was separately checked by the parent against the official page;
# it is a transparent list-price equivalent, not a fetched bill or credit delta.
def claude_list_cost(r,rates):
    u=r['input_usage'];fresh,cache5,cache1,read,output=rates
    inp=(u['input_tokens']*fresh+r['cache_creation_5m_tokens_reported']*cache5+r['cache_creation_1h_tokens_reported']*cache1+u['cache_read_input_tokens']*read)/1e6
    out=r['output_tokens_including_thinking']*output/1e6
    return {'input_list_equivalent_usd':inp,'output_list_equivalent_usd':out,'total_list_equivalent_usd':inp+out,
      'output_fraction_of_list_equivalent':ratio(out,inp+out),
      'reported_thinking_list_equivalent_usd':r['thinking_tokens_reported_subset']*output/1e6,
      'actual_invoice_or_credit_deduction_usd':None}
result['illustrative_current_list_price_equivalents']={
    'source':'https://platform.claude.com/docs/en/about-claude/pricing','verified_by':'parent agent public-source check, no account/billing access',
    'fable_subscription_recorded_usage':claude_list_cost(claude_result['by_model']['claude-fable-5-2'],(8,10,16,.2,40)),
    'opus_confirmed_api_backup_recorded_usage':claude_list_cost(claude_result['by_route']['api_backup'],(4,5,8,.2,20)),
    'meaning':'All identified requests have speed=standard. Reasoning is a subset of output and is not added twice. Subscription list-equivalent dollars do not imply API charges or determine plan credit consumption. Failed/unrecorded calls and unknown routes are not estimated.'}
save('output-billing-summary.json',result)
print(json.dumps({k:result[k]['totals'] for k in ['codex','openai_api','claude','gemini']},indent=2))
