from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, Flowable, KeepTogether
from datetime import datetime
from zoneinfo import ZoneInfo
from pathlib import Path
from urllib.parse import quote
import json, hashlib

OUT=Path('/tmp/P_vs_NP_Fable_Max_Plan.pdf')
BASE=Path('/Users/jackpohlad/Documents/Codex/2026-11-25/fetch-and-follow-the-instructions-at')
NAVY=colors.HexColor('#183442'); TEAL=colors.HexColor('#28665C'); INK=colors.HexColor('#253C46'); MUTED=colors.HexColor('#566973'); LIGHT=colors.HexColor('#EDF4F2'); LINE=colors.HexColor('#D9E3E4'); GOLD=colors.HexColor('#B86D27')
W=524
styles={
 'kicker':ParagraphStyle('kicker',fontName='Helvetica-Bold',fontSize=8.5,leading=11,textColor=TEAL,spaceAfter=10),
 'title':ParagraphStyle('title',fontName='Helvetica-Bold',fontSize=25,leading=29,textColor=NAVY,spaceAfter=10),
 'subtitle':ParagraphStyle('subtitle',fontName='Helvetica',fontSize=11,leading=15,textColor=MUTED,spaceAfter=14),
 'h':ParagraphStyle('h',fontName='Helvetica-Bold',fontSize=12,leading=15,textColor=NAVY,spaceBefore=10,spaceAfter=6),
 'body':ParagraphStyle('body',fontName='Helvetica',fontSize=10.2,leading=14,textColor=INK,spaceAfter=7),
 'small':ParagraphStyle('small',fontName='Helvetica',fontSize=8.6,leading=11.5,textColor=MUTED,spaceAfter=5),
 'cell':ParagraphStyle('cell',fontName='Helvetica',fontSize=9.4,leading=12.5,textColor=INK),
 'head':ParagraphStyle('head',fontName='Helvetica-Bold',fontSize=9.2,leading=12,textColor=NAVY),
 'metric':ParagraphStyle('metric',fontName='Helvetica-Bold',fontSize=19,leading=23,textColor=TEAL),
 'label':ParagraphStyle('label',fontName='Helvetica',fontSize=8.3,leading=10.5,textColor=MUTED),
}
def P(s,style='body'):return Paragraph(s,styles[style])
def box(text):
 t=Table([[P(text)]],colWidths=[W]);t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,-1),LIGHT),('BOX',(0,0),(-1,-1),.5,LINE),('LEFTPADDING',(0,0),(-1,-1),12),('RIGHTPADDING',(0,0),(-1,-1),12),('TOPPADDING',(0,0),(-1,-1),10),('BOTTOMPADDING',(0,0),(-1,-1),5)]));return t

def grid(headers,rows,widths):
 data=[[P(x,'head') for x in headers]]+[[P(x,'cell') for x in row] for row in rows]
 t=Table(data,colWidths=widths,hAlign='LEFT',repeatRows=1)
 t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),LIGHT),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),9),('RIGHTPADDING',(0,0),(-1,-1),9),('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6),('LINEBELOW',(0,0),(-1,0),.6,LINE),('LINEBELOW',(0,1),(-1,-1),.4,LINE)]))
 return t

class Pipeline(Flowable):
 def __init__(self):Flowable.__init__(self);self.width=W;self.height=49
 def draw(self):
  c=self.canv;labels=['Choose a precise claim','Try to break it','Prove it in Lean','Check the full cost'];bw=119;gap=16
  for i,label in enumerate(labels):
   x=i*(bw+gap);c.setFillColor(LIGHT);c.setStrokeColor(LINE);c.roundRect(x,6,bw,33,5,stroke=1,fill=1);c.setFillColor(NAVY);c.setFont('Helvetica-Bold',8);c.drawCentredString(x+bw/2,19,label)
   if i<3:
    c.setStrokeColor(TEAL);c.setLineWidth(1);c.line(x+bw+3,22,x+bw+gap-3,22);c.line(x+bw+gap-7,25,x+bw+gap-3,22);c.line(x+bw+gap-7,19,x+bw+gap-3,22)

stamp=datetime.now(ZoneInfo('America/Chicago')).strftime('%b %d, %Y | %-I:%M %p Central')
def footer(c,doc):
 c.saveState();c.setStrokeColor(LINE);c.line(44,39,568,39);c.setFillColor(MUTED);c.setFont('Helvetica',7.5);c.drawString(44,26,'Research plan | '+stamp);c.drawRightString(568,26,str(doc.page)+' / 2');c.restoreState()

story=[P('P VS NP  /  FABLE MAX RESEARCH PLAN','kicker'),P('Fable Max: the next<br/>attack on P vs NP','title'),P('Primary target: any checked polynomial-time general SAT algorithm. Practical quadratic or cubic speed is a later milestone.','subtitle')]
story.append(box('<b>The goal:</b> an always-correct SAT solver whose total running time is bounded by a fixed polynomial in the input length. SAT asks whether a collection of yes/no rules has a solution. Proving such a bound for every input would establish P=NP, even if the algorithm is initially impractical. Faster powers, constants and memory can be improved afterward.'))
story.append(P('What is already real','h'))
metrics=Table([[P('10,000','metric'),P('1,640','metric'),P('17','metric'),P('0','metric')],[P('saved proposals','label'),P('completed review reports','label'),P('local proof families','label'),P('qualified general fast-SAT leads','label')]],colWidths=[131]*4)
metrics.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),0),('RIGHTPADDING',(0,0),(-1,-1),10),('BOTTOMPADDING',(0,0),(-1,-1),3)]));story.append(metrics);story.append(Spacer(1,6))
story.append(P('Lean checks the correctness of our general solver and useful supporting results. Its worst-case search is still exponential. On one six-pair example, independent splitting cut search attempts from <b>1,366 to 12</b>. That is a specific improvement, not the missing general speed proof.'))
story.append(P('The next work, in order','h'))
steps=[('1','Give Fable one deep synthesis assignment first.','Fable at maximum effort combines the checked building blocks and known failures. It must return an explicit algorithm, its key lemma, a proposed proof, and the first unresolved step.'),('2','Develop three distinct mechanisms, then attack them.','Try implied variable relationships, compact matching reasoning, and safe reuse of equivalent residual problems. Concentrate on connected formulas that survive existing shortcuts; independently try to break each candidate.'),('3','Concentrate the next round on the surviving proof gap.','Use counterexamples to reject or repair a mechanism. For a survivor, prove both complete solution coverage and a polynomial bound on all remaining work. Then formalize the exact claims in Lean.')]
for n,title,body in steps:
 t=Table([[P(n,'metric'),P('<b>'+title+'</b><br/>'+body)]],colWidths=[29,W-29]);t.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),0),('RIGHTPADDING',(0,0),(-1,-1),5),('BOTTOMPADDING',(0,0),(-1,-1),4)]));story.append(t)
story.append(Pipeline())
story.append(P('A useful research result closes a named proof gap or produces a counterexample that rules out a route. More proposals, model agreement and small test passes are separate measures.','small'))
story.append(PageBreak())
story.extend([P('EXECUTION  /  ROLES AND CHECKPOINTS','kicker'),P('Assignments and evidence','title'),P('Fable leads mathematical synthesis. Separate testing and formal verification decide whether any proposed idea actually works.','subtitle')])
story.append(grid(['Workstream','Who / what','Concrete deliverable'],[
 ('Deep mathematical synthesis','Fable at maximum effort; Codex supplies checked context and coordinates follow-ups.','One strongest concrete candidate, up to two alternatives, and exact unproved lemmas.'),
 ('Independent attack','Opus or another available independent reviewer; local deterministic counterexample tests.','Counterexamples or surviving cases on connected formulas, both possible and impossible.'),
 ('Formal verification','Codex formalizes; the local Lean checker verifies the statement and proof.','Correctness and coverage lemmas, followed by a bound on total work. Model agreement is not a proof.')
],[105,205,214]))
story.append(P('How we expand the idea generation','h'))
story.append(P('After the first Fable result confirms access, give separate assignments to distinct mechanisms and feed counterexamples back. Use the existing 10,000 proposals as evidence. Judge each new idea by its missing theorem, not by volume.'))
story.append(P('Checkpoints and timing','h'))
story.append(grid(['Active work estimate','Reviewable result'],[
 ('First bounded run','Verify post-reset Fable inference and save its exact proposal. A signed-in account alone does not verify remaining quota.'),
 ('Next 30-90 active minutes','Run bounded attacks; keep, repair or reject each route with saved evidence.'),
 ('Then 1-4 active hours per manageable lemma','Attempt the Lean proof and an independent audit. A hard lemma can take much longer.')
],[133,391]))
story.append(P('These are work estimates, not a solution deadline. There is no defensible date for the P=NP breakthrough.','small'))
story.append(P('Capacity and the finish line','h'))
story.append(P('<b>Current status:</b> you reported a Fable account reset, and its subscription sign-in is confirmed. A maximum-effort synthesis request has been submitted. Other provider limits remain unverified after the reset; only scale a route after a successful response.'))
story.append(box('<b>The finish line:</b> one explicit algorithm, a checked answer for every valid input, and a checked total time bound covering input reading, simplification, search and verification. Measure constants and memory. Project credit still requires its strict checking and acceptance.'))
story.append(Spacer(1,7))
links=[]
for label,rel in [('Component solver','component_split_round1/integration-validation.json'),('Binary dispatch','two_sat_dispatch_round1/integration-validation.json'),('Supplied-variable solver','fixed_backdoor_round1/integration-validation.json')]:
 path=BASE/'work/alg001'/rel;links.append('<link href="file://'+quote(str(path))+'" color="#28665C">'+label+'</link>')
story.append(P('Evidence: local dashboard snapshot and audited Lean receipts, Nov 26. '+ ' | '.join(links)+'.<br/>Communication: research updates stay in Codex and the local board. Text messages are disabled.','small'))
doc=SimpleDocTemplate(str(OUT),pagesize=letter,rightMargin=44,leftMargin=44,topMargin=40,bottomMargin=48,title='P vs NP - Fable Max Research Plan',author='P vs NP Research Hub')
doc.build(story,onFirstPage=footer,onLaterPages=footer)
print(OUT)
