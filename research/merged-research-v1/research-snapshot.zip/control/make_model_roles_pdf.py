from pathlib import Path
import json
import datetime
from zoneinfo import ZoneInfo
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.colors import HexColor, white
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.pagesizes import letter

ROOT = Path(__file__).resolve().parents[3]
OUT = ROOT / 'output/pdf/P_vs_NP_Which_Model_Does_What.pdf'
S = json.loads((ROOT / 'work/alg001/control/model-plan-snapshot.json').read_text())
stamp = datetime.datetime.now(ZoneInfo('America/Chicago')).strftime('%b %d, %Y, %-I:%M %p Central')
F = Path('/Users/jackpohlad/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/poppler/poppler/fonts')
pdfmetrics.registerFont(TTFont('U', str(F / 'Ubuntu-R.ttf')))
pdfmetrics.registerFont(TTFont('UB', str(F / 'Ubuntu-B.ttf')))
pdfmetrics.registerFontFamily('U',normal='U',bold='UB',italic='U',boldItalic='UB')
NAVY=HexColor('#173247'); TEAL=HexColor('#087F8C'); INK=HexColor('#273C49')
MUTED=HexColor('#536773'); LIGHT=HexColor('#EDF5F5'); LINE=HexColor('#D8E3E7')
W,H=letter; WIDTH=W-96
styles={
 'k':ParagraphStyle('k',fontName='UB',fontSize=9,leading=12,textColor=TEAL,spaceAfter=12),
 'title':ParagraphStyle('title',fontName='UB',fontSize=29,leading=33,textColor=NAVY,spaceAfter=13),
 'sub':ParagraphStyle('sub',fontName='U',fontSize=12.5,leading=17,textColor=MUTED,spaceAfter=16),
 'h':ParagraphStyle('h',fontName='UB',fontSize=14.5,leading=18,textColor=NAVY,spaceBefore=14,spaceAfter=7),
 'b':ParagraphStyle('b',fontName='U',fontSize=10.5,leading=14.5,textColor=INK,spaceAfter=8),
 'small':ParagraphStyle('small',fontName='U',fontSize=9,leading=12.2,textColor=MUTED,spaceAfter=7),
 'tiny':ParagraphStyle('tiny',fontName='U',fontSize=8,leading=10.5,textColor=MUTED,spaceAfter=5),
 'cell':ParagraphStyle('cell',fontName='U',fontSize=9.6,leading=13.3,textColor=INK),
 'head':ParagraphStyle('head',fontName='UB',fontSize=9.6,leading=13.3,textColor=NAVY),
 'call':ParagraphStyle('call',fontName='UB',fontSize=12,leading=16,textColor=NAVY),
}
def p(s,style='b'):return Paragraph(s,styles[style])
def tab(rows,widths,header=False):
 t=Table([[p(v,'head' if (i==0 and header) or j==0 else 'cell') for j,v in enumerate(row)] for i,row in enumerate(rows)],colWidths=widths,hAlign='LEFT')
 t.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),9),('RIGHTPADDING',(0,0),(-1,-1),9),('TOPPADDING',(0,0),(-1,-1),9),('BOTTOMPADDING',(0,0),(-1,-1),9),('LINEBELOW',(0,0),(-1,-1),.5,LINE),('ROWBACKGROUNDS',(0,0),(-1,-1),[white,HexColor('#F6F9FA')])]))
 if header:t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),LIGHT)]))
 return t
def box(s):
 t=Table([[p(s,'call')]],colWidths=[WIDTH]);t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,-1),LIGHT),('BOX',(0,0),(-1,-1),.5,LINE),('LEFTPADDING',(0,0),(-1,-1),13),('RIGHTPADDING',(0,0),(-1,-1),13),('TOPPADDING',(0,0),(-1,-1),12),('BOTTOMPADDING',(0,0),(-1,-1),12)]));return t
def footer(c,doc):
 c.saveState();c.setFillColor(TEAL);c.rect(0,H-8,W,8,fill=1,stroke=0)
 c.setStrokeColor(LINE);c.line(48,45,W-48,45);c.setFillColor(MUTED);c.setFont('U',7.8)
 c.drawString(48,29,'Model allocation plan | '+stamp);c.drawRightString(W-48,29,f'{doc.page} / 2');c.restoreState()

story=[p('P = NP RESEARCH  /  MODEL ALLOCATION','k'),p('Which model does what','title'),
 p('Fast idea generation, focused coding, selective deep review, and independent proof checking.','sub'),
 box('New proposal jobs use Hydrogen at LOW effort. Sonnet LOW handles focused implementation. Fable MAX handles the hardest mathematical work.'),Spacer(1,13),
 tab([
  ('Model / tool','Effort and mode','Assigned job'),
  ('Gemini Hydrogen','LOW','Generate many short, executable algorithm candidates. Each job writes code, tries small tests, and identifies the missing proof. Also handles tightly scoped repairs.'),
  ('Claude Sonnet 5.5','LOW<br/>Standard mode','Turn precise ideas into clean code; fix localized bugs; write and run small tests. Its first component passed independent testing.'),
  ('Claude Fable 5.2','MAX<br/>Fast mode ON<br/>Ultracode ON','Work on difficult global mathematical arguments, challenge promising approaches, and identify hidden gaps. Used selectively rather than for routine drafting.'),
  ('Codex coordinator + subagents','Current session;\ntask-specific roles','Choose tasks, compare outputs, run independent tests, reproduce failures, and formalize useful statements in Lean.'),
  ('Gemini Neon / Carbon','Specialist reserve','No fixed share of new routine generation. Neon completed a targeted repair; Carbon\'s long exploratory pass was stopped with its work retained. Use either again only for a concrete need.'),
  ('Lean proof checker','Not an AI model','Check formal proof steps. A model\'s confidence or a passing example does not count as proof acceptance.'),
 ],[110,104,WIDTH-214]),
 Spacer(1,9),
 p('<b>About "fast Sonnet":</b> Sonnet 5.5 supports low effort, but Claude Code\'s dedicated fast mode does not support Sonnet. Its pilot ran at low effort in standard mode. Fable is the model using the paid fast-mode setting.','small'),
 p('These are starting assignments, not a claim that one model is best at everything. We will change the allocation using observed correctness, useful output, elapsed time, and cost.','small'),
 PageBreak(),
 p('P = NP RESEARCH  /  HOW WE CHOOSE','k'),p('How the work moves<br/>between models','title'),
 tab([
  ('1. Generate broadly','Target: 200 candidate-generation jobs, with up to 12 pool workers at once. New jobs use Hydrogen LOW and a short code-first prompt. Older calls may finish on their original settings.'),
  ('2. Screen cheaply','Parse the code, remove exact duplicates, review what it does, then compare selected candidates with independently known answers. Incorrect SAT or UNSAT claims go back for repair or are rejected.'),
  ('3. Implement and repair','Use Sonnet LOW or a focused low-effort author task when the required change is clear. Spend extra reasoning only if a concrete obstacle remains.'),
  ('4. Review deeply','Use Fable MAX and independent Codex reviewers on distinctive surviving ideas. Examine global correctness, hidden search, memory growth, and the full running-time argument.'),
  ('5. Prove and check','Formalize precise useful claims in Lean. A complete result needs correctness and a uniform time bound for every input, with standard definitions of P and NP.'),
 ],[116,WIDTH-116]),
 p('What the first measurements say','h'),
 p(f'<b>Hydrogen LOW:</b> {S["hydrogen_low_completed_at_measurement"]} proposal jobs had finished at the measurement snapshot, with a median duration of about {round(S["hydrogen_low_median_seconds"])} seconds. Proposal screening continues. A separate focused repair passed <b>632 independently checked regression cases</b>, including checks of every returned SAT witness.'),
 p('<b>Sonnet 5.5 LOW:</b> one linear-algebra component finished in about <b>54 seconds</b>; Claude Code estimated <b>$0.13</b> at list prices. Independent testing passed <b>97,732 exhaustive small cases</b>, plus random and structural checks. Its affine hull may add points, so this helper cannot generally replace exact branch search.'),
 p('These were different tasks and small samples. They do not establish a head-to-head winner or a reliable total research price. The useful measure is how many distinct, correct, testable ideas survive per minute and per dollar.','small'),
 box('Quantity is the discovery stage. Independent tests and rigorous proof determine which ideas deserve more work.'),
 Spacer(1,9),
 p('This updates the earlier allocation: 200 now refers to proposal jobs, with deeper reviews selected after screening. There is still no checked P = NP proof or verified general quadratic/cubic SAT solver.','small'),
 p('<link href="https://code.claude.com/docs/en/fast-mode" color="#087F8C">Claude Code fast-mode support</link>  |  <link href="https://code.claude.com/docs/en/model-config" color="#087F8C">Effort and Ultracode settings</link>  |  <link href="https://pequalnp.com/lemma#L-alg-001" color="#087F8C">Project goal: L-alg-001</link>','tiny')]

SimpleDocTemplate(str(OUT),pagesize=letter,leftMargin=48,rightMargin=48,topMargin=37,bottomMargin=59,
 title='P vs NP: Which Model Does What',author='Research coordination for Jack Pohlad').build(story,onFirstPage=footer,onLaterPages=footer)
print(OUT)
