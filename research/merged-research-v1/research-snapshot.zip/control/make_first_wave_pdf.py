from pathlib import Path
import json
import datetime
from zoneinfo import ZoneInfo
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.colors import HexColor, white
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.pagesizes import letter

ROOT = Path(__file__).resolve().parents[3]
OUT = ROOT / 'output/pdf/P_vs_NP_First_Wave_Results.pdf'
S = json.loads((ROOT / 'work/alg001/control/first-wave-results-snapshot.json').read_text())
stamp = datetime.datetime.now(ZoneInfo('America/Chicago')).strftime('%b %d, %Y, %-I:%M %p Central')
F = Path('/Users/jackpohlad/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/poppler/poppler/fonts')
pdfmetrics.registerFont(TTFont('U', str(F / 'Ubuntu-R.ttf')))
pdfmetrics.registerFont(TTFont('UB', str(F / 'Ubuntu-B.ttf')))
pdfmetrics.registerFontFamily('U',normal='U',bold='UB',italic='U',boldItalic='UB')
NAVY=HexColor('#173247'); TEAL=HexColor('#087F8C'); INK=HexColor('#273C49')
MUTED=HexColor('#536773'); LIGHT=HexColor('#EDF5F5'); LINE=HexColor('#D8E3E7')
W,H=letter; WIDTH=W-96
styles={
 'k':ParagraphStyle('k',fontName='UB',fontSize=9,leading=12,textColor=TEAL,spaceAfter=12),
 'title':ParagraphStyle('title',fontName='UB',fontSize=26,leading=29,textColor=NAVY,spaceAfter=13),
 'sub':ParagraphStyle('sub',fontName='U',fontSize=12.5,leading=17,textColor=MUTED,spaceAfter=16),
 'h':ParagraphStyle('h',fontName='UB',fontSize=14.5,leading=18,textColor=NAVY,spaceBefore=10,spaceAfter=5),
 'b':ParagraphStyle('b',fontName='U',fontSize=9.6,leading=12.6,textColor=INK,spaceAfter=8),
 'small':ParagraphStyle('small',fontName='U',fontSize=8.4,leading=10.8,textColor=MUTED,spaceAfter=7),
 'tiny':ParagraphStyle('tiny',fontName='U',fontSize=8,leading=10.5,textColor=MUTED,spaceAfter=5),
 'cell':ParagraphStyle('cell',fontName='U',fontSize=9,leading=11.8,textColor=INK),
 'head':ParagraphStyle('head',fontName='UB',fontSize=9,leading=11.8,textColor=NAVY),
 'call':ParagraphStyle('call',fontName='UB',fontSize=12,leading=16,textColor=NAVY),
}
def p(s,style='b'):return Paragraph(s,styles[style])
def tab(rows,widths,header=False):
 t=Table([[p(v,'head' if (i==0 and header) or j==0 else 'cell') for j,v in enumerate(row)] for i,row in enumerate(rows)],colWidths=widths,hAlign='LEFT')
 t.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),9),('RIGHTPADDING',(0,0),(-1,-1),9),('TOPPADDING',(0,0),(-1,-1),7),('BOTTOMPADDING',(0,0),(-1,-1),7),('LINEBELOW',(0,0),(-1,-1),.5,LINE),('ROWBACKGROUNDS',(0,0),(-1,-1),[white,HexColor('#F6F9FA')])]))
 if header:t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),LIGHT)]))
 return t
def box(s):
 t=Table([[p(s,'call')]],colWidths=[WIDTH]);t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,-1),LIGHT),('BOX',(0,0),(-1,-1),.5,LINE),('LEFTPADDING',(0,0),(-1,-1),13),('RIGHTPADDING',(0,0),(-1,-1),13),('TOPPADDING',(0,0),(-1,-1),12),('BOTTOMPADDING',(0,0),(-1,-1),12)]));return t
def footer(c,doc):
 c.saveState();c.setFillColor(TEAL);c.rect(0,H-8,W,8,fill=1,stroke=0)
 c.setStrokeColor(LINE);c.line(48,45,W-48,45);c.setFillColor(MUTED);c.setFont('U',7.8)
 c.drawString(48,29,'First wave results | '+stamp);c.drawRightString(W-48,29,f'{doc.page} / 2');c.restoreState()


g=S['generators']
story=[p('P = NP RESEARCH / FIRST WAVE RESULTS','k'),p('What the first tests show','title'),
p('A plain-language snapshot of the first generation wave, model comparison, and shared workspace.','sub'),
box('The first five minutes produced 25 candidate programs: 9 from Hydrogen and 16 from Sonnet. We have not reached 5,000 per model every five minutes.'),Spacer(1,14),
p('A candidate is an idea written as code. It still needs independent checking. These counts do not mean new discoveries or correct algorithms. Flash-Lite joined after the first five-minute window.'),
tab([('Generator','Saved by snapshot','Typical job time'),('Hydrogen LOW',str(g['gemini-4-hydrogen']['generated']),'Median 121 seconds'),('Sonnet 5.5 LOW',str(g['claude-sonnet-5-5']['generated']),'Median 72 seconds'),('Gemini 3.5 Flash-Lite LOW',str(g['gemini-3.5-flash-lite']['generated']),'Median 14 seconds')],[170,140,WIDTH-310]),
p('Snapshot: about eight minutes into the wave. These were small, changing samples; Flash-Lite used a shorter generation-only task. This is not a controlled speed or quality ranking. The live dashboard has newer counts.','small'),
p('What the checking found','h'),
p('Opus reviewed one Hydrogen candidate and reported 3,370 small test cases without a mismatch. It also identified an explicit fallback that may try exponentially many possibilities. That makes it a testable algorithm idea, not the requested general quadratic or cubic SAT algorithm.'),
p('The Opus test count is its recorded review result; it has not been independently replayed by this coordinator. Model review reports remain separate from verified test receipts and Lean proof checks.','small'),
p('What slowed the wave','h'),
p('Gemini returned a project spending-cap rate limit for some calls. Those model lanes back off; other models continue if their calls succeed. Flash-Lite did produce outputs. We did not change any billing settings.'),
p('The coordinator initially rejected valid optional function arguments. That screening bug was fixed and existing files were recounted. The candidate code and mathematics were not changed.'),
p('Cost and completion time','h'),
p(f'Sonnet reported about <b>${g["claude-sonnet-5-5"]["reported_cli_cost_usd"]:.2f}</b> for {g["claude-sonnet-5-5"]["cost_recorded_jobs"]} recorded jobs in this snapshot, using CLI list-price estimates. This is not the total project bill: Gemini, other Claude work, earlier runs, and Codex are excluded.'),
p('The queue now targets 5,000 jobs from each of three generators: 15,000 total. Provider limits, concurrency changes, and failed jobs prevent a reliable finish estimate. There is no defensible date or price for solving P vs NP.','small'),
PageBreak(),p('P = NP RESEARCH / TEAM AND WORKSPACE','k'),p('Who does what now','title'),
tab([('Role','Assigned models'),('Generate ideas only','Hydrogen LOW; Sonnet 5.5 LOW in standard mode; Gemini 3.5 Flash-Lite LOW. New generator calls do no output checking.'),('Review and test','Opus 5.5 HIGH; Neon MEDIUM; Carbon LOW as a second perspective. Model availability and measured results determine actual allocation.'),('Coordinate','Codex/Astra assigns work, manages the queue, routes findings, and checks receipts. Ongoing mathematical testing and comparison are delegated.'),('Check formal proofs','Lean checks exact formal statements. A model verdict or a successful small test is not a proof of P = NP.')],[112,WIDTH-112]),
p('Neon versus Carbon: identical blinded pilot','h'),
p('Each setting received the same two buggy examples and one correct restricted example. The counterexamples in the returned reports were replayed independently.'),
tab([('Setting','Result','Wall time'),('Neon LOW','14/14 points; finished','147 seconds'),('Neon MEDIUM','14/14 points; finished','132 seconds'),('Carbon LOW','14/14 in saved report; timeout','185 seconds*'),('Carbon MEDIUM','No saved report; unassessed','185 seconds*')],[136,WIDTH-224,88]),
p('*The original 180-second deadline included a five-second cleanup grace. The benchmark runner was corrected. This small pilot supports trying Neon medium as the default and Carbon low for second opinions; it does not establish a universal model ranking. Opus was added afterward at your request.','small'),
p('Watch the team locally','h'),
p('<link href="http://127.0.0.1:8767/#chat" color="#087F8C">Open localhost:8767 - Agent chat</link>. The dedicated chat tab refreshes every second. You see a plain-language version when available, with <b>Show original</b> for the unchanged technical message. Agents receive the original text at their next job boundary.'),
p('The Desktop folder is <b>P vs NP Research Hub</b>. It contains the board launcher, start/pause/resume controls, candidate folders, reviews, and persistent messages. The overview separates generated files, parsed code, model reviews, independent test receipts, and proof-checked artifacts.'),
p('Workspace validation: 33 automated storage, HTTP, and coordinator tests passed. Desktop/mobile browser checks passed for tabs, message posting, literal-text display, filters, and layout. These tests check the workspace software, not the SAT candidates.','small'),
p('No checked P = NP proof or general quadratic/cubic SAT algorithm has been established.','small'),Spacer(1,3),
p('<link href="https://pequalnp.com/lemma#L-alg-001" color="#087F8C">Project goal: L-alg-001</link> | <link href="https://code.claude.com/docs/en/model-config" color="#087F8C">Official Claude model configuration</link>','tiny')]
SimpleDocTemplate(str(OUT),pagesize=letter,leftMargin=48,rightMargin=48,topMargin=37,bottomMargin=59,title='P vs NP: First Wave Results',author='Research coordination for Jack Pohlad').build(story,onFirstPage=footer,onLaterPages=footer)
print(OUT)
