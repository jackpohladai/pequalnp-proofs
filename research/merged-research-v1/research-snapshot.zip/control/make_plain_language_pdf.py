from pathlib import Path
import json
from reportlab.pdfgen import canvas
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, Flowable
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.colors import HexColor, white
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import letter

ROOT = Path(__file__).resolve().parents[3]
OUT = ROOT / 'output/pdf/P_vs_NP_Goal_Progress_Time_and_Cost.pdf'
SNAP = json.loads((ROOT / 'work/alg001/control/plain-language-report-snapshot.json').read_text())
FONTDIR = Path('/Users/jackpohlad/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/poppler/poppler/fonts')
pdfmetrics.registerFont(TTFont('Ubuntu', str(FONTDIR / 'Ubuntu-R.ttf')))
pdfmetrics.registerFont(TTFont('UbuntuBold', str(FONTDIR / 'Ubuntu-B.ttf')))
pdfmetrics.registerFontFamily('Ubuntu', normal='Ubuntu', bold='UbuntuBold', italic='Ubuntu', boldItalic='UbuntuBold')
NAVY = HexColor('#173247')
TEAL = HexColor('#087F8C')
INK = HexColor('#273C49')
MUTED = HexColor('#536773')
LIGHT = HexColor('#EDF5F5')
LINE = HexColor('#D8E3E7')
AMBER = HexColor('#AD5C1E')
W, H = letter
CONTENT = W - 96

styles = {
    'kicker': ParagraphStyle('kicker', fontName='UbuntuBold', fontSize=9, leading=12, textColor=TEAL, spaceAfter=12),
    'title': ParagraphStyle('title', fontName='UbuntuBold', fontSize=29, leading=33, textColor=NAVY, spaceAfter=14),
    'subtitle': ParagraphStyle('subtitle', fontName='Ubuntu', fontSize=13, leading=18, textColor=MUTED, spaceAfter=18),
    'h': ParagraphStyle('h', fontName='UbuntuBold', fontSize=15, leading=19, textColor=NAVY, spaceBefore=15, spaceAfter=8),
    'body': ParagraphStyle('body', fontName='Ubuntu', fontSize=10.8, leading=15, textColor=INK, spaceAfter=9),
    'small': ParagraphStyle('small', fontName='Ubuntu', fontSize=9, leading=12.5, textColor=MUTED, spaceAfter=7),
    'tiny': ParagraphStyle('tiny', fontName='Ubuntu', fontSize=8, leading=10.5, textColor=MUTED, spaceAfter=4),
    'cell': ParagraphStyle('cell', fontName='Ubuntu', fontSize=10, leading=14, textColor=INK),
    'cellb': ParagraphStyle('cellb', fontName='UbuntuBold', fontSize=10, leading=14, textColor=NAVY),
    'callout': ParagraphStyle('callout', fontName='UbuntuBold', fontSize=12, leading=16, textColor=NAVY),
}


def p(text, style='body'):
    return Paragraph(text, styles[style])


def box(text, fill=LIGHT):
    t = Table([[p(text, 'callout')]], colWidths=[CONTENT])
    t.setStyle(TableStyle([('BACKGROUND', (0,0), (-1,-1), fill), ('BOX', (0,0), (-1,-1), .6, LINE),
                          ('LEFTPADDING',(0,0),(-1,-1),14), ('RIGHTPADDING',(0,0),(-1,-1),14),
                          ('TOPPADDING',(0,0),(-1,-1),12), ('BOTTOMPADDING',(0,0),(-1,-1),12)]))
    return t


def table(rows, widths):
    cells = [[p(str(c), 'cellb' if j == 0 else 'cell') for j,c in enumerate(row)] for row in rows]
    t = Table(cells, colWidths=widths, hAlign='LEFT')
    t.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'TOP'), ('LINEBELOW',(0,0),(-1,-1),.5,LINE),
                          ('LEFTPADDING',(0,0),(-1,-1),8), ('RIGHTPADDING',(0,0),(-1,-1),8),
                          ('TOPPADDING',(0,0),(-1,-1),8), ('BOTTOMPADDING',(0,0),(-1,-1),8),
                          ('ROWBACKGROUNDS',(0,0),(-1,-1),[white,HexColor('#F6F9FA')])]))
    return t


class Metrics(Flowable):
    def __init__(self):
        Flowable.__init__(self)
        self.width, self.height = CONTENT, 78
    def draw(self):
        c = self.canv
        values = [('200','research jobs scheduled'),('3','local proof checks passed'),('0','complete P = NP proofs')]
        cw = (CONTENT - 16) / 3
        for i,(num,label) in enumerate(values):
            x = i * (cw + 8)
            c.setFillColor(LIGHT); c.roundRect(x,0,cw,78,5,fill=1,stroke=0)
            c.setFillColor(TEAL); c.setFont('UbuntuBold',25); c.drawString(x+12,42,num)
            c.setFillColor(INK); c.setFont('Ubuntu',8.5); c.drawString(x+12,20,label)


def decorate(c, doc):
    c.saveState()
    c.setFillColor(TEAL); c.rect(0,H-8,W,8,fill=1,stroke=0)
    c.setStrokeColor(LINE); c.line(48,45,W-48,45)
    c.setFillColor(MUTED); c.setFont('Ubuntu',8)
    c.drawString(48,29,'P = NP research brief | Snapshot: Nov 25, 2026, 9:43 p.m. Central')
    c.drawRightString(W-48,29,f'{doc.page} / 3')
    c.restoreState()


story = []
story += [p('PLAIN-LANGUAGE BRIEF  /  01 THE GOAL','kicker'),
          p('What we are trying<br/>to solve','title'),
          p('The goal, the work underway, and an honest view of time and cost.','subtitle'),
          Metrics(), Spacer(1,13),
          box('Research is underway. We have checked useful building blocks, but we have not proved P = NP or built the requested fast general solver.'),
          p('The idea in everyday terms','h'),
          p('Imagine a huge puzzle made of yes/no choices. Checking a completed answer can be quick, while finding that answer can require trying an enormous number of possibilities. P versus NP asks whether every problem whose answer is quick to check also has a quick way to find an answer.'),
          p('Our target is SAT: given a set of logical rules, determine whether any combination of yes/no choices satisfies all of them. A fast, always-correct method for <b>every</b> SAT input would settle P = NP.'),
          p('What you mean by n-squared or n-cubed','h'),
          p('Here, <b>n</b> means the length of the input. With an n-squared method, doubling the input would make the main work grow roughly fourfold; with n-cubed, roughly eightfold. We want a proved worst-case bound, including the difficult inputs, plus an implementation with practical memory use and manageable overhead.'),
          p('What would count as success','h'),
          p('<b>1.</b> A specific algorithm that answers every valid SAT question correctly.<br/><b>2.</b> A rigorous proof that its total work stays within the promised bound.<br/><b>3.</b> A proof accepted by Lean, the mathematical proof-checking software, using the standard meaning of P and NP.'),
          p('A result for small examples, a special puzzle family, or a theorem that assumes a fast SAT solver is useful research, but does not complete this goal.','small'),
          PageBreak()]

story += [p('PLAIN-LANGUAGE BRIEF  /  02 THE WORK','kicker'),
          p('What is happening now','title'),
          p('Parallel invention, independent attempts to break each idea, then formal checking.','subtitle'),
          table([
              ('Research team','Hydrogen, Neon, and Carbon are developing algorithms. Three Codex subagents handle tests, mathematical structure, and Lean proofs. Claude Fable 5.2 has joined at max effort, with fast mode and Ultracode enabled.'),
              ('Expanded search','200 Gemini jobs are scheduled: 100 proposal jobs and 100 independent reviews. The queue runs up to 12 jobs at once to preserve machine resources.'),
              ('Snapshot of the queue','22 jobs have started: 12 are running and 10 have ended. Some ended at time or tool limits. Another 178 are queued. These counts change as the batch runs.'),
          ],[116,CONTENT-116]),
          p('The workflow','h'),
          p('<b>Propose a method</b> &gt; build a small implementation &gt; compare it with exhaustive answers on small puzzles &gt; challenge difficult families &gt; prove the useful parts in Lean &gt; check the total time cost.'),
          p('Concrete progress so far','h'),
          p('<b>Three local proof checks passed.</b> They verify how formulas can be simplified, how possible answers are preserved when choices are removed, and how a particular assignment structure can be compressed. They establish correctness of mathematical building blocks, not the final speed guarantee.'),
          p('<b>Independent tests are catching real errors.</b> The baseline corpus contains 594 cases with exhaustively verified answers. A reviewer found a nine-variable puzzle with 20 valid answers that one candidate wrongly rejected. That candidate needs repair before we trust it.'),
          p('<b>One compression method now handles a difficult structured family.</b> Broader tests still show growing memory and work. A method that works well on selected families still needs an argument covering every input.'),
          box('The central unsolved step: keep all the information needed for correct answers while proving that the total work never explodes.'),
          Spacer(1,9),
          p('The project currently marks L-alg-001 as unavailable for a desk lease. This round is local research; these new checks have not been submitted or credited on the website.','small'),
          PageBreak()]

story += [p('PLAIN-LANGUAGE BRIEF  /  03 TIME AND COST','kicker'),
          p('How long, and how much?','title'),
          table([
              ('This 200-job batch','Roughly 1-3 more hours at the current settings. This is a scheduling estimate based on parallel jobs with per-job limits; retries, slow responses, and deeper follow-up can extend it.'),
              ('Checking a strong lead','Hours to days or longer, depending on what must be proved and whether the approach survives testing. A candidate can fail after substantial work.'),
              ('A complete P = NP proof','No defensible completion date. It could require much more research or never succeed. If P is not equal to NP, the requested general fast algorithm cannot exist.'),
          ],[116,CONTENT-116]),
          p('What we can currently measure','h'),
          p('<b>About $3.99 in estimated Gemini pool usage was logged across 21 started sessions at the cost snapshot.</b> This is Hermes\' software estimate, not a verified invoice, and many sessions were unfinished. It excludes the three main Gemini chats, Fable, Codex, and earlier work.'),
          p('The P vs NP project itself charges nothing to participate. AI usage is billed through your connected providers. The existing Lean setup runs locally. There is no verified all-in total yet, and no fixed dollar ceiling was set for this research pass.'),
          p('Planning examples, not a price quote','h'),
          table([
              ('Average cost per pool job','$0.25','$1.00','$5.00'),
              ('Cost for 200 such jobs','$50','$200','$1,000'),
          ],[CONTENT-210,70,70,70]),
          Spacer(1,7),
          p('These examples show how spending scales; they are not forecasts. Add the main researchers and Fable separately. Fable 5.2 fast-mode list pricing is $16 per million input tokens and $80 per million output tokens. For example, 100,000 input plus 20,000 output tokens is $3.20 before caching adjustments or other charges.','small'),
          box('More compute buys more attempts and stronger checks. It does not buy a guaranteed mathematical breakthrough.'),
          p('Evidence and assumptions','h'),
          p('Local checker receipts and the research queue were inspected for this brief. Queue counts are a 9:43 p.m. Central snapshot; the cost snapshot was taken just before it. Three accepted local checks are intermediate results, with no full P = NP proof or general quadratic/cubic solver established.','tiny'),
          p('<link href="https://pequalnp.com/lemma#L-alg-001" color="#087F8C">Project goal: L-alg-001</link>  |  <link href="https://pequalnp.com/how" color="#087F8C">How the project counts results</link>  |  <link href="https://pequalnp.com/join.txt" color="#087F8C">Participation instructions</link>  |  <link href="https://code.claude.com/docs/en/fast-mode" color="#087F8C">Fable fast-mode pricing</link>','tiny')]

doc = SimpleDocTemplate(str(OUT), pagesize=letter, leftMargin=48, rightMargin=48,
                        topMargin=37, bottomMargin=59, title='P vs NP: Goal, Progress, Time and Cost',
                        author='Research coordination for Jack Pohlad', subject='Plain-language research status and planning assumptions')
doc.build(story, onFirstPage=decorate, onLaterPages=decorate)
print(OUT)
