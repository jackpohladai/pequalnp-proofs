from pathlib import Path
import datetime
import json
from zoneinfo import ZoneInfo
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.colors import HexColor, white
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.pagesizes import letter

ROOT = Path(__file__).resolve().parents[3]
OUT = ROOT / 'output/pdf/P_vs_NP_Speed_Up_Plan.pdf'
HUB = Path('/Users/jackpohlad/Desktop/P vs NP Research Hub')
S = json.loads((ROOT/'work/alg001/control/speed-plan-snapshot.json').read_text())
STAMP = datetime.datetime.now(ZoneInfo('America/New_York')).strftime('%b %d, %Y, %-I:%M %p ET')
F = Path('/Users/jackpohlad/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/poppler/poppler/fonts')
for name, file in [('U','Ubuntu-R.ttf'),('UB','Ubuntu-B.ttf')]:
    pdfmetrics.registerFont(TTFont(name,str(F/file)))
pdfmetrics.registerFontFamily('U',normal='U',bold='UB',italic='U',boldItalic='UB')
NAVY=HexColor('#173247'); TEAL=HexColor('#087F8C'); INK=HexColor('#273C49'); MUTED=HexColor('#536773'); LIGHT=HexColor('#EDF5F5'); LINE=HexColor('#D8E3E7')
W,H=letter; WIDTH=W-96
styles={
 'k':ParagraphStyle('k',fontName='UB',fontSize=9,leading=12,textColor=TEAL,spaceAfter=10),
 'title':ParagraphStyle('title',fontName='UB',fontSize=25,leading=29,textColor=NAVY,spaceAfter=10),
 'sub':ParagraphStyle('sub',fontName='U',fontSize=11.5,leading=15,textColor=MUTED,spaceAfter=12),
 'h':ParagraphStyle('h',fontName='UB',fontSize=13,leading=17,textColor=NAVY,spaceBefore=9,spaceAfter=5),
 'b':ParagraphStyle('b',fontName='U',fontSize=9.3,leading=12.3,textColor=INK,spaceAfter=7),
 'small':ParagraphStyle('small',fontName='U',fontSize=8,leading=10.4,textColor=MUTED,spaceAfter=6),
 'cell':ParagraphStyle('cell',fontName='U',fontSize=8.7,leading=11,textColor=INK),
 'head':ParagraphStyle('head',fontName='UB',fontSize=8.7,leading=11,textColor=NAVY),
 'call':ParagraphStyle('call',fontName='UB',fontSize=11,leading=15,textColor=NAVY),
}
def p(text,style='b'):return Paragraph(text,styles[style])
def tab(rows,widths):
    t=Table([[p(v,'head' if i==0 else 'cell') for v in row] for i,row in enumerate(rows)],colWidths=widths,hAlign='LEFT')
    t.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),8),('RIGHTPADDING',(0,0),(-1,-1),8),('TOPPADDING',(0,0),(-1,-1),5),('BOTTOMPADDING',(0,0),(-1,-1),5),('LINEBELOW',(0,0),(-1,-1),.4,LINE),('ROWBACKGROUNDS',(0,0),(-1,-1),[white,HexColor('#F6F9FA')]),('BACKGROUND',(0,0),(-1,0),LIGHT)]))
    return t
def box(text):
    t=Table([[p(text,'call')]],colWidths=[WIDTH]);t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,-1),LIGHT),('BOX',(0,0),(-1,-1),.5,LINE),('LEFTPADDING',(0,0),(-1,-1),12),('RIGHTPADDING',(0,0),(-1,-1),12),('TOPPADDING',(0,0),(-1,-1),10),('BOTTOMPADDING',(0,0),(-1,-1),10)]));return t
def footer(c,doc):
    c.saveState();c.setFillColor(TEAL);c.rect(0,H-8,W,8,fill=1,stroke=0);c.setStrokeColor(LINE);c.line(48,44,W-48,44);c.setFillColor(MUTED);c.setFont('U',7.5);c.drawString(48,28,'Research speed plan | '+STAMP);c.drawRightString(W-48,28,f'{doc.page} / 2');c.restoreState()

saved=S['counts']['generated']; remaining=10000-saved
downloads=[]
for key,label in [('t5gemma2','T5Gemma2')]:
    d=json.loads((HUB/'models'/f'{key}-parallel-download.json').read_text())
    downloads.append((label,f"{d['weight_bytes']/1e9:.2f} / {d['weight_total']/1e9:.2f} GB",f"About {round(d['eta_seconds']/60)} min"))
d=json.loads((HUB/'models/diffusiongemma-mlx-4bit-download.json').read_text())
downloads.extend([('Gemma 4, local version','9.5 GB total; downloading','Several hours'),('DiffusionGemma, 4-bit',f"{d['downloaded_bytes']/1e9:.2f} / {d['total_bytes']/1e9:.2f} GB",f"About {d['eta_seconds']/3600:.1f} hours")])

story=[p('P VS NP / FASTER RESEARCH','k'),p('How we speed up the search','title'),
p('A practical plan for more useful ideas per minute, with honest limits and visible progress.','sub'),
box(f'One shared goal: 10,000 saved ideas. Snapshot: {saved:,} saved. Worker capacity is ramping; this document distinguishes measured results from planned improvements.'),Spacer(1,8),
p('The immediate changes','h'),
p('<b>1. Fix false pauses.</b> Flash-Lite backed off with only 8,101 tokens reserved against an 8 million ceiling. Failed output formatting and a local database write caused those pauses, not a 429 rate-limit response. Remove automatic model-lane pauses, record individual failures accurately, and preserve valid returned work. The token ceilings remain enforced.'),
p('<b>2. Use fewer calls per idea.</b> A Flash-Lite pilot saved its four files in one request: 6.6 seconds of guarded request work, versus a 44.1-second median legacy job. Full startup was about 29 seconds. Roll out this path with typed output and measure stable production results.'),
p('<b>3. Batch Haiku\'s file writes.</b> Haiku used a median seven model turns and six tool calls, versus Sonnet\'s three turns and two calls. Both were on low effort. New instructions save the files together. Keep Sonnet\'s existing route: the alternative tested at 95.3 seconds was slower.'),
p('<b>4. Use the smaller local Qwen.</b> Qwen3.5 2B saved a real short idea in 31.1 seconds while loaded. Keep it warm between jobs. The larger 7B model is parked; the short local suggestions feed the other generators.'),
p('Configured capacity - active counts depend on headroom','h'),
tab([('Model','Maximum workers','Job / mode'),('Gemini 3.5 Flash-Lite','32','Ideas; low effort; 8M TPM workspace ceiling'),('Claude Sonnet 5.5','30','Ideas only; low effort'),('Claude Haiku 5.5','12','Ideas only; low effort; batched writes'),('Gemini Hydrogen','8','Ideas; low effort; 2.4M TPM ceiling'),('GPT-6.2 Sol / GPT-6 Luna','4 each','Ideas; verified Ultrafast / Fast API modes'),('Opus 5.5','8','Code review and bounded testing'),('Local Qwen / Gemma models','1 shared slot','Short ideas or code, after local validation')],[166,93,WIDTH-259]),
p('Up to 99 total slots. Ramp from 35 by eight every 30 seconds while memory headroom is at least 20%; pause new starts below 15%. Real provider limits still apply. More slots do not guarantee proportional speed.','small'),
p('Evidence: 30 recent completed jobs per Claude model (Sonnet median 77.6 seconds; Haiku 89.3 seconds); one Flash-Lite route pilot and one warm Qwen2B draft. These are operational measurements, not proof-quality benchmarks.','small'),
p('<link href="http://127.0.0.1:8767/?view=totals-v3#overview" color="#087F8C">Live dashboard</link> | <link href="https://support.claude.com/en/articles/11145838-use-claude-code-with-your-pro-max-or-ultra-plan" color="#087F8C">Claude plan limits</link> | <link href="https://code.claude.com/docs/en/fast-mode" color="#087F8C">Claude fast-mode support</link> | <link href="https://pequalnp.com/join.txt" color="#087F8C">Project submission rules</link>','small'),
PageBreak(),p('P VS NP / QUALITY, TIME AND LIMITS','k'),p('Make the extra output useful','title'),
p('Independent ideas, targeted replies, then exact checking.','sub'),
p('How the models help each other','h'),
p('Each new task receives selected original checker feedback and ideas from other models. The generator names what it used, proposes a concrete improvement, and asks a specific question. For example, Hydrogen cited a checker\'s report on Luna\'s parity code and drafted a proposed repair. That repair still needs checking.'),
p('Keep different research routes in parallel so the team does not converge on one unproven assumption. Preserve the real technical messages; show you a separate plain-language version. Recorded message IDs distinguish delivered feedback from replies a model actually declares.'),
p('What counts as progress','h'),
box('A saved idea is not a correct algorithm. A correct small test is not a proof. The research target is a general, always-correct SAT algorithm with a checked quadratic or cubic total running-time bound.'),Spacer(1,7),
p('The dashboard separates short drafts, code parsing, model reviews, independent tests, and formal proof checks. Failed attempts do not advance the 10,000 goal. Review useful components and counterexamples before preparing an eligible one-file Lean submission.'),
p('Downloads and local capacity','h'),
tab([('Model','Progress at preparation','Rough remaining time'),*downloads],[151,187,WIDTH-338]),
p('Transfers share bandwidth, so these are changing estimates. Original full-precision Gemma checkpoints are also downloading. The local versions are smaller. Download checks and real inference tests come before activation; only one local model runs at once. Qwen is already available.','small'),
p('Time to 10,000 ideas - examples, not promises','h'),
tab([('Sustained successful rate',f'Time for the remaining {remaining:,} ideas'),('25 ideas / minute',f'About {remaining/25/60:.1f} hours'),('50 ideas / minute',f'About {remaining/50/60:.1f} hours'),('100 ideas / minute',f'About {remaining/100:.0f} minutes')],[WIDTH/2,WIDTH/2]),
p('Use a stable ten-minute window after the error fixes to update the estimate. Time to solve P vs NP cannot be estimated credibly; the problem may require a breakthrough these models do not find.','small'),
p('Usage, cost and evidence','h'),
p('Claude workers share your Claude Max account limits; fixed API token quotas do not describe that subscription. OpenAI runs use your separate API key. A total dollar estimate is not yet verified. Speed decisions should consider saved, useful outputs as well as tokens and errors.','small'),
]

SimpleDocTemplate(str(OUT),pagesize=letter,leftMargin=48,rightMargin=48,topMargin=36,bottomMargin=57,title='P vs NP: Speed-Up Plan',author='Research coordination for Jack Pohlad').build(story,onFirstPage=footer,onLaterPages=footer)
print(OUT)
