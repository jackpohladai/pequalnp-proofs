import ExecutableEdgeLift

namespace PEqualNP.Outside.GuardedCNFEncoding

open PEqualNP.Search

private def visibleExample : Assignment :=
  fun x => x == 3 || x == 14 || x == 16

private def edgeExample (i k : Fin 2) : Bool :=
  !(i == k)

private def exampleValues : List Bool :=
  [3, 4, 10, 11, 12, 13, 14, 15, 16].map (liftAssignment 10 visibleExample edgeExample)

-- Both pairing branches occur. IDs 14, 15 and 16 decode outside the grid.
#eval exampleValues
example : liftAssignment 10 visibleExample edgeExample
    (freshEdge 10 ((0 : Fin 2), (1 : Fin 2))) = true :=
  (liftAssignment_at_edge 10 visibleExample edgeExample 0 1).trans (by decide)
example : liftAssignment 10 visibleExample edgeExample 3 = true := by
  calc
    _ = visibleExample 3 := liftAssignment_below _ _ _ _ (by decide)
    _ = true := by decide

example : decodeFreshEdge 0 2 10 10 = none := by decide
example : decodeFreshEdge 2 0 10 10 = none := by decide
#eval (decodeFreshEdge 0 2 10 10).isNone && (decodeFreshEdge 2 0 10 10).isNone

-- Two very large Nat IDs still go through offset subtraction and unpairing.
private def largeOffset : Nat := 2 ^ 100
private def largeValues : List Bool :=
  [largeOffset - 1, largeOffset + 1, largeOffset + 3, largeOffset + 1024].map
    (liftAssignment largeOffset (fun _ => true) edgeExample)
#eval largeValues

private def retained : CNF := [[(0, true)], [(1, true)]]
private def neighbors (_ : Fin 2) : Finset (Fin 1) := {0}
private def guards (i : Fin 2) : Clause := if i = 0 then [(0, true)] else [(1, false)]
private def visible : Assignment := fun x => decide (x < 2)
private def validEdges (i : Fin 2) (_ : Fin 1) : Bool := i == 1
private def collidingEdges (_ : Fin 2) (_ : Fin 1) : Bool := true

-- The second row is active, the first is guarded, and the selected edge is unique.
#eval (CNF.eval (liftAssignment 2 visible validEdges)
  (encode retained neighbors guards (freshEdge 2)),
  CNF.eval (liftAssignment 2 visible collidingEdges)
  (encode retained neighbors guards (freshEdge 2)))

end PEqualNP.Outside.GuardedCNFEncoding
