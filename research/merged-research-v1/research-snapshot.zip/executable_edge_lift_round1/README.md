# Executable assignment lift for fresh guarded edges

`liftAssignment` extends a supplied visible assignment with supplied edge bits. For an ID below the offset it returns the visible bit. For any other ID it subtracts the offset, applies `Nat.unpair`, and checks both coordinates against the finite row and hole bounds. A pair inside the grid selects the supplied edge bit. An ID outside the grid keeps its visible bit.

## Lean statements

- `decodeFreshEdge_at_edge` and `decodeFreshEdge_sound` characterize the decoded pairs using the existing fresh IDs `offset + Nat.pair i k`.
- `liftAssignment_at_edge`, `liftAssignment_below`, and `liftAssignment_outside` give the assignment value at each kind of ID.
- `liftClause_eval` and `liftCNF_eval` preserve Boolean evaluation when the original variables lie below the offset.
- `liftEncoding_eval` applies the prior encoder equivalence to the computed assignment. Under the offset premises, it characterizes acceptance by the visible retained CNF, the guard-or-edge rows, and column uniqueness among actual neighbors.
- `lift_witness` uses supplied edge bits that satisfy those obligations to certify the actual computed assignment against the encoded CNF.

The evaluator uses computable natural-number arithmetic and finite bounds. Lean reports no axiom dependencies for `decodeFreshEdge` and `liftAssignment`. The correctness theorems use the standard axioms listed in the receipt.

## Verification and scope

The Lean examples exercise both pairing branches, visible IDs below the offset and outside each grid dimension, empty row or hole dimensions, IDs around a \(2^{100}\) offset, and full encoded CNF evaluation with both valid and colliding supplied edges.

A lookup uses an offset comparison and, on the decoding path, one subtraction, one `Nat.unpair` with natural-number square root, two bounds checks, and the selected assignment callback. Execution requires computable visible and edge callbacks. Finding suitable edge bits, recognizing decompositions of arbitrary CNFs, and proving an end-to-end encoded-bit runtime are separate obligations. The lift applies to the explicit guarded CNF constructor.

Run the local build from the workspace root.

```sh
PYTHONDONTWRITEBYTECODE=1 python3 -S work/alg001/executable_edge_lift_round1/build.py
```

The [compile receipt](compile-receipt.json) records the pinned compiler, commands, source and artifact hashes, dependency hashes, and executable output. The build keeps the compiled modules and verified local dependencies under `build/lib/lean`. Use the receipt's `lean_path` and `import ExecutableEdgeLift` in a downstream file.
