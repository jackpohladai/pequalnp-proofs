"""Check and export the executable edge lift with its verified installed dependencies."""

from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import tempfile
import time


HERE = Path(__file__).resolve().parent
ALG = HERE.parent
PROJECT = ALG.parent / "pequalnp-sparse/lean"
LEAN = Path.home() / ".elan/toolchains/leanprover--lean4---v4.36.0/bin/lean"
SOURCE_MODULES = ("ExecutableEdgeLift", "EdgeLiftExamples")
STANDARD_AXIOMS = {"propext", "Classical.choice", "Quot.sound"}
EXPECTED_EXECUTION = [
    "[true, false, false, true, true, false, true, false, true]",
    "true",
    "[true, true, false, true]",
    "(true, false)",
]


def digest(content):
    return hashlib.sha256(content).hexdigest()


def matched_bytes(path, expected):
    data = path.read_bytes()
    if digest(data) != expected:
        raise ValueError(f"SHA-256 mismatch for {path}")
    return data


def read_dependencies(library, durable):
    encoding = ALG / "guarded_cnf_encoding_round1/compile-receipt.json"
    hall = ALG / "hall_projection_round1/compile-receipt.json"
    prior = json.loads(encoding.read_bytes())
    hall_check = json.loads(hall.read_bytes())
    if prior["exit_code"] != 0 or hall_check["exit_code"] != 0:
        raise ValueError("Existing dependency compiler checks did not pass")
    dependencies = [{
        "source": hall_check["source"], "source_sha256": hall_check["source_sha256"],
        "artifact": prior["guarded_hall_artifact"],
        "artifact_sha256": prior["guarded_hall_artifact_sha256"],
    }]
    for name in ("GuardedCNFEncoding", "FreshGuardedCNF"):
        entry = next(row for row in prior["checks"] if Path(row["source"]).stem == name)
        if entry["exit_code"] != 0 or "sorryAx" in entry["output"]:
            raise ValueError(f"Existing check failed for {name}")
        dependencies.append({key: entry[key] for key in dependencies[0]})

    for entry in dependencies:
        source = Path(entry["source"])
        artifact = Path(entry["artifact"])
        if artifact.name != source.stem + ".olean":
            raise ValueError(f"Artifact name does not match {source}")
        matched_bytes(source, entry["source_sha256"])
        origin = artifact if artifact.is_file() else durable / artifact.name
        (library / artifact.name).write_bytes(matched_bytes(origin, entry["artifact_sha256"]))
        entry["verified_copy_source"] = str(origin)
    records = {
        str(path): digest(path.read_bytes()) for path in (encoding, hall)
    }
    project_manifest = ALG / "checked_components_v2/source-manifest.json"
    project_pin = json.loads(project_manifest.read_bytes())["project"]
    for file, key in (
        ("lake-manifest.json", "lake_manifest_sha256"),
        ("PEqualNP/Defs/Search.lean", "project_search_source_sha256"),
        (".lake/build/lib/lean/PEqualNP/Defs/Search.olean", "project_search_olean_sha256"),
    ):
        matched_bytes(PROJECT / file, project_pin[key])
    paths = [Path(path) for path in prior["lean_path"].split(os.pathsep)]
    project_paths = [path for path in paths if path.is_relative_to(PROJECT) and path.is_dir()]
    return dependencies, records, project_pin, project_paths


def axioms_from(output):
    result = {}
    for name, axiom_list in re.findall(
            r"'([^']+)' (?:depends on axioms: \[([^]]+)\]|does not depend on any axioms)", output):
        result[name] = [item.strip() for item in axiom_list.split(",") if item.strip()]
    return result


def run_build(build, scratch):
    version = subprocess.check_output([LEAN, "--version"], text=True, timeout=15).strip()
    if "version 4.36.0," not in version or "commit 611c117bfaf7b7ae1cfcf246ce6fba31e8f509e9," not in version:
        raise ValueError(f"Unexpected Lean {version}")
    staged_sources = scratch / "source"
    staged_library = scratch / "lib"
    staged_sources.mkdir()
    staged_library.mkdir()
    library = build / "lib/lean"
    dependencies, receipts, project_pin, paths = read_dependencies(staged_library, library)
    env = dict(os.environ, LEAN_PATH=os.pathsep.join(map(str, [staged_library, *paths])))
    checks = {}
    for name in SOURCE_MODULES:
        original = HERE / (name + ".lean")
        staged = staged_sources / original.name
        source_data = original.read_bytes()
        staged.write_bytes(source_data)
        artifact = staged_library / (name + ".olean")
        command = [str(LEAN), "-j", "1", "-DElab.async=false", "-R", str(staged_sources),
                   "-o", str(artifact), str(staged)]
        start = time.monotonic()
        process = subprocess.run(command, cwd=staged_sources, env=env, text=True,
                                 stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=180)
        record = {
            "command": command, "source": str(original), "source_sha256": digest(source_data),
            "exit_code": process.returncode, "elapsed_seconds": round(time.monotonic() - start, 3),
            "output": process.stdout, "axioms": axioms_from(process.stdout),
        }
        checks[name] = record
        if process.returncode or not artifact.is_file() or "sorryAx" in process.stdout or any(
                set(items) - STANDARD_AXIOMS for items in record["axioms"].values()):
            print(process.stdout, end="", flush=True)
            break
        record["artifact_sha256"] = digest(artifact.read_bytes())
        print(f"{name} checked in {record['elapsed_seconds']}s", flush=True)

    main_axioms = checks["ExecutableEdgeLift"]["axioms"]
    computational_axioms_free = all(
        main_axioms.get("PEqualNP.Outside.GuardedCNFEncoding." + name) == []
        for name in ("decodeFreshEdge", "liftAssignment"))
    execution = checks.get("EdgeLiftExamples", {}).get("output", "").splitlines()
    execution_verified = execution == EXPECTED_EXECUTION
    passed = (len(checks) == len(SOURCE_MODULES) and computational_axioms_free and execution_verified
              and all("artifact_sha256" in record for record in checks.values()))
    if passed:
        source_directory = build / "source"
        source_directory.mkdir(exist_ok=True)
        library.mkdir(parents=True, exist_ok=True)
        for name, record in checks.items():
            origin = staged_sources / (name + ".lean")
            data = matched_bytes(origin, record["source_sha256"])
            matched_bytes(Path(record["source"]), record["source_sha256"])
            (source_directory / origin.name).write_bytes(data)
        for path in staged_library.iterdir():
            (library / path.name).write_bytes(path.read_bytes())
        for name, record in checks.items():
            artifact = library / (name + ".olean")
            matched_bytes(artifact, record["artifact_sha256"])
            record["artifact"] = str(artifact)
        for entry in dependencies:
            artifact = library / Path(entry["artifact"]).name
            matched_bytes(artifact, entry["artifact_sha256"])
            entry["durable_artifact"] = str(artifact)
    receipt = {
        "checked_at_utc": datetime.now(timezone.utc).isoformat(), "lean_version": version,
        "compile_working_directory": str(staged_sources), "compile_lean_path": env["LEAN_PATH"],
        "lean_path": os.pathsep.join(map(str, [library, *paths])), "modules": checks,
        "dependencies": dependencies, "dependency_receipt_sha256": receipts, "project": project_pin,
        "computational_axioms_free": computational_axioms_free,
        "execution_examples_verified": execution_verified, "expected_execution_output": EXPECTED_EXECUTION,
        "verified": passed,
        "formal_encoded_bit_runtime_bound": False, "upstream_checker": False,
    }
    temporary = HERE / "compile-receipt.json.tmp"
    temporary.write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    temporary.replace(HERE / "compile-receipt.json")
    return 0 if passed else 1


def main():
    build = HERE / "build"
    build.mkdir(mode=0o700, exist_ok=True)
    info = build.lstat()
    if not stat.S_ISDIR(info.st_mode) or info.st_uid != os.getuid() or info.st_mode & 0o077:
        raise ValueError("Expected a private, owner-controlled build directory")
    with (build / ".lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        with tempfile.TemporaryDirectory(prefix="pnp-executable-edge-lift-") as scratch:
            return run_build(build, Path(scratch).resolve())


if __name__ == "__main__":
    raise SystemExit(main())
