"""Compile the hash-checked local components with the installed Lean dependencies."""

import argparse
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import tempfile
import time


HERE = Path(__file__).resolve().parent
WORK = HERE.parents[1]
DEFAULT_LEAN = Path.home() / ".elan/toolchains/leanprover--lean4---v4.36.0/bin/lean"
DEFAULT_PROJECT = WORK / "pequalnp-sparse/lean"
LEAN_RELEASE = "4.36.0"
LEAN_COMMIT = "611c117bfaf7b7ae1cfcf246ce6fba31e8f509e9"
COMPONENTS = {
    "ParityExtraction": ("parity_extraction_round1", "verification.txt"),
    "StalledParity": ("synthesis_round1", "compile-receipt.json"),
    "RankObstruction": ("rank_obstruction_round1", "compile-receipt.json"),
    "GuardedHall": ("hall_projection_round1", "compile-receipt.json"),
    "PairedUnion": ("paired_union_round1", "compile-receipt.json"),
}


def digest(content):
    return hashlib.sha256(content).hexdigest()


def write_json(path, payload):
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    temporary.replace(path)


def verify_sources():
    sources = {}
    entries = {}
    for name, (folder, receipt_name) in COMPONENTS.items():
        filename = name + ".lean"
        component = HERE.parent / folder
        source = component / filename
        receipt = component / receipt_name
        source_bytes = source.read_bytes()
        receipt_bytes = receipt.read_bytes()
        if receipt.suffix == ".json":
            metadata = json.loads(receipt_bytes)
            if metadata.get("exit_code") != 0 or f"version {LEAN_RELEASE}," not in metadata.get("lean_version", ""):
                raise ValueError(f"Invalid compiler receipt for {name}")
            expected = metadata["source_sha256"]
        else:
            receipt_text = receipt_bytes.decode("utf-8")
            if "Lean exit status 0." not in receipt_text or f"version {LEAN_RELEASE}," not in receipt_text:
                raise ValueError(f"Invalid compiler receipt for {name}")
            match = re.search(rf"^([a-f0-9]{{64}})  {re.escape(filename)}$", receipt_text, re.MULTILINE)
            if match is None:
                raise ValueError(f"Missing source digest in {receipt}")
            expected = match[1]
        if digest(source_bytes) != expected:
            raise ValueError(f"Source digest differs from the existing receipt for {name}")
        sources[name] = source_bytes
        entries[name] = {
            "source": str(source.relative_to(HERE.parent)),
            "source_sha256": expected,
            "original_receipt": str(receipt.relative_to(HERE.parent)),
            "original_receipt_sha256": digest(receipt_bytes),
        }
    return sources, entries


def project_paths(project):
    manifest_path = project / "lake-manifest.json"
    manifest_bytes = manifest_path.read_bytes()
    manifest = json.loads(manifest_bytes)
    packages = project / manifest["packagesDir"]
    library_paths = [project / ".lake/build/lib/lean"]
    packages_without_build = []
    for package in manifest["packages"]:
        package_root = packages / package["name"] / (package.get("subDir") or "")
        library = package_root / ".lake/build/lib/lean"
        if library.is_dir():
            library_paths.append(library)
        else:
            packages_without_build.append(package["name"])
    expected = json.loads((HERE.parent / "synthesis_round1/compile-receipt.json").read_bytes())[
        "project_search_definitions_sha256"]
    search_source = project / "PEqualNP/Defs/Search.lean"
    search_module = library_paths[0] / "PEqualNP/Defs/Search.olean"
    if digest(search_source.read_bytes()) != expected or not search_module.is_file():
        raise ValueError("Expected the checked project Search source and its compiled module")
    return library_paths, {
        "lake_manifest_sha256": digest(manifest_bytes),
        "project_search_source_sha256": expected,
        "project_search_olean_sha256": digest(search_module.read_bytes()),
        "manifest_packages_without_local_build": packages_without_build,
    }


def compile_module(name, lean, stages, libraries, environment):
    source = stages / (name + ".lean")
    artifact = libraries / (name + ".olean")
    command = [str(lean), "-j", "1", "-DElab.async=false", "-R", str(stages),
               "-o", str(artifact), str(source)]
    start = time.monotonic()
    try:
        proc = subprocess.run(command, cwd=stages, env=environment, text=True,
                              stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=180)
        output = proc.stdout
        exit_code = proc.returncode
    except subprocess.TimeoutExpired as exc:
        output = (exc.output or b"").decode("utf-8", errors="replace")
        exit_code = 124
    elapsed = round(time.monotonic() - start, 3)
    checked = exit_code == 0 and "sorryAx" not in output and artifact.is_file()
    print(f"{name} {'passed' if checked else 'failed'} after {elapsed}s", flush=True)
    return {
        "command": command,
        "exit_code": exit_code,
        "elapsed_seconds": elapsed,
        "verified": checked,
        "output": output,
        "artifact": str(artifact),
        "artifact_sha256": digest(artifact.read_bytes()) if checked else None,
    }


def build(lean, project, workers, build_root, scratch):
    version = subprocess.check_output([lean, "--version"], text=True, timeout=15).strip()
    if f"version {LEAN_RELEASE}," not in version or f"commit {LEAN_COMMIT}," not in version:
        raise ValueError(f"Unexpected Lean release: {version}")
    sources, entries = verify_sources()
    dependencies, project_evidence = project_paths(project)
    smoke = "CheckedComposition"
    sources[smoke] = (HERE / (smoke + ".lean")).read_bytes()
    stages = scratch / "source"
    libraries = scratch / "lib/lean"
    stages.mkdir()
    libraries.mkdir(parents=True)
    for name, content in sources.items():
        (stages / (name + ".lean")).write_bytes(content)
    write_json(HERE / "source-manifest.json", {
        "components": entries,
        "composition_source_sha256": digest(sources[smoke]),
        "project": project_evidence,
    })
    environment = dict(os.environ, LEAN_PATH=os.pathsep.join(map(str, [libraries, *dependencies])))
    with ThreadPoolExecutor(max_workers=workers) as executor:
        jobs = {name: executor.submit(compile_module, name, lean, stages, libraries, environment)
                for name in entries}
        checks = {name: future.result() for name, future in jobs.items()}
    if all(record["verified"] for record in checks.values()):
        checks[smoke] = compile_module(smoke, lean, stages, libraries, environment)
    passed = smoke in checks and all(record["verified"] for record in checks.values())
    retained_libraries = build_root / "lib/lean"
    retained_lean_path = os.pathsep.join(map(str, [retained_libraries, *dependencies]))
    if passed:
        retained_sources = build_root / "source"
        retained_sources.mkdir(exist_ok=True)
        retained_libraries.mkdir(parents=True, exist_ok=True)
        for name, content in sources.items():
            (retained_sources / (name + ".lean")).write_bytes(content)
        for staged in libraries.iterdir():
            if staged.is_file():
                (retained_libraries / staged.name).write_bytes(staged.read_bytes())
        for name, check in checks.items():
            retained = retained_libraries / (name + ".olean")
            if digest(retained.read_bytes()) != check["artifact_sha256"]:
                raise ValueError(f"Copied module digest differs for {name}")
            check["reusable_artifact"] = str(retained)
    write_json(HERE / "build-receipt.json", {
        "checked_at_utc": datetime.now(timezone.utc).isoformat(),
        "lean_version": version,
        "cwd": str(stages),
        "compile_lean_path": environment["LEAN_PATH"],
        "lean_path": retained_lean_path,
        "modules": checks,
        "verified": passed,
    })
    return 0 if passed else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lean", type=Path, default=DEFAULT_LEAN)
    parser.add_argument("--project", type=Path, default=DEFAULT_PROJECT)
    parser.add_argument("--workers", type=int, choices=(1, 2, 3), default=3)
    options = parser.parse_args()
    build_root = HERE / "build"
    build_root.mkdir(mode=0o700, exist_ok=True)
    info = build_root.lstat()
    if not stat.S_ISDIR(info.st_mode) or info.st_uid != os.getuid() or info.st_mode & 0o077:
        raise ValueError("Expected a private, owner-controlled build directory")
    with (build_root / ".lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        with tempfile.TemporaryDirectory(prefix="pnp-checked-components-") as scratch:
            return build(options.lean.resolve(), options.project.resolve(), options.workers,
                         build_root, Path(scratch).resolve())


if __name__ == "__main__":
    raise SystemExit(main())
