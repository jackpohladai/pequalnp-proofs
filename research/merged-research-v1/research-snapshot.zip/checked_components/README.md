# Checked Lean components

This local build connects five previously checked components under Lean 4.36.0. The build checks each source against its existing receipt, copies it byte-for-byte into the private build directory, and compiles the matching module name. It uses the installed project and package libraries listed by the pinned Lake manifest. The source manifest records the component hashes, original receipt hashes, and the exact project Search source and compiled-module hashes.

## Typed composition

`CheckedComposition.lean` imports `ParityExtraction`, `StalledParity`, `RankObstruction`, `GuardedHall`, and `PairedUnion` together. It type-checks a named theorem from each module. It also proves equality of the parity extractor’s literal, clause, and CNF Boolean evaluation with `PEqualNP.Search` evaluation for natural-number variables. The theorem `PEqualNP.Outside.CheckedComposition.project_parity_replacement` applies the parity replacement directly to `PEqualNP.Search.CNF.eval`, keeping the original theorem’s coverage and clause-permutation hypotheses and preserving the entire remaining CNF.

The composed theorem concerns a single parity rewrite. The other imported theorems retain their individual mathematical scopes. A general SAT decision procedure and its runtime require separate results.

## Local usage

Run the rebuild from the workspace root.

```sh
PYTHONDONTWRITEBYTECODE=1 python3 -S work/alg001/checked_components/build.py
```

The reusable module files are under `build/lib/lean`. The build receipt gives the exact `LEAN_PATH`, compiler arguments, exit codes, and axiom output. To consume the built library, set `LEAN_PATH` to the receipt’s value and import `CheckedComposition` or the individual module required.

- [Source manifest](source-manifest.json)
- [Compile and axiom receipt](build-receipt.json)
