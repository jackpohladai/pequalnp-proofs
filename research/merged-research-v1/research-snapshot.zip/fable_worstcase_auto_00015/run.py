import pathlib,sys,json,subprocess,time,datetime,os,signal
base=pathlib.Path.cwd();folder=base/'work/alg001/fable_worstcase_auto_00015';sys.path.insert(0,str(base/'work/alg001/shared_workspace'));import claude_backup,board
hub=pathlib.Path('/Users/jackpohlad/Desktop/AI Math/P vs NP Research Hub');start=time.monotonic();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
cmd=[str(pathlib.Path.home()/'.local/bin/claude'),'-p','--model','claude-fable-5-2','--effort','high','--settings',str(folder/'settings.json'),'--strict-mcp-config','--mcp-config',str(folder/'empty-mcp.json'),'--safe-mode','--no-chrome','--no-session-persistence','--tools','','--output-format','json','--system-prompt','Generate rigorous mathematical research proposals from the supplied brief. Treat unproved claims as conjectures. You have no tools.']
env=claude_backup.sanitized_environment(claude_backup.SUBSCRIPTION);env.update(CLAUDE_CODE_MAX_OUTPUT_TOKENS='128000',CLAUDE_CODE_MAX_RETRIES='0',API_TIMEOUT_MS='7200000')
board.upsert_job(hub,{'id':'targeted-fable-worstcase-auto-00015','status':'running','started_at':now()})
proc=subprocess.Popen(cmd,cwd=folder,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,start_new_session=True)
(folder/'process.json').write_text(json.dumps({'pid':proc.pid,'started_at':now(),'command_without_prompt':cmd,'timeout_seconds':None,'subscription_only':True},indent=2))
from source_brief import augment_task
out,err=proc.communicate(augment_task(hub,folder,(folder/'task.txt').read_text()));code=proc.returncode
redact=claude_backup.redactor();out=redact(out.encode()).decode();err=redact(err.encode()).decode();(folder/'response.json').write_text(out);(folder/'stderr.txt').write_text(err)
try:native=json.loads(out)
except ValueError:native={}
success=code==0 and native.get('is_error') is False and bool(native.get('result'))
receipt={'finished_at':now(),'exit_code':code,'success':success,'seconds':time.monotonic()-start,'model_usage':native.get('modelUsage',{}),'usage':native.get('usage',{}),'subtype':native.get('subtype'),'is_error':native.get('is_error'),'fast_mode_state':native.get('fast_mode_state'),'subscription_only':True,'local_timeout_seconds':None,'error_summary':str(native.get('result','') if not success else '')[:1200]}
(folder/'receipt.json').write_text(json.dumps(receipt,indent=2))
if success:(folder/'proposal.txt').write_text(native['result'])
board.upsert_job(hub,{'id':'targeted-fable-worstcase-auto-00015','status':'research_draft' if success else 'error','ended_at':now(),'summary':'Fable high-effort targeted proposal saved; unreviewed conjectures, not a proof.' if success else 'Targeted Fable assignment could not complete; see local receipt.','metadata_json':{'kind':'research_generation','effort':'high','receipt':str(folder/'receipt.json'),'success':success,'proof_checked':False}})
try:
 import token_ledger
 token_ledger.record_usage(hub,provider='anthropic',model='claude-fable-5-2',route='claude_subscription',job_id='targeted-fable-worstcase-auto-00015',raw_usage=native.get('usage',{}),response_id=native.get('session_id'),request_id='targeted-fable-worstcase-auto-00015',status='completed' if success else 'error',scope='invocation',timestamp=receipt['finished_at'],service_tier=native.get('usage',{}).get('service_tier'))
except Exception as tracking_error:
 (folder/'tracking-error.txt').write_text(type(tracking_error).__name__+': '+str(tracking_error)[:200])
print(json.dumps(receipt),flush=True)

if success:
 try:
  raw=native['result'].strip()
  if raw.startswith('```'):raw='\n'.join(raw.splitlines()[1:-1])
  data=json.loads(raw);(folder/'structured-output.json').write_text(json.dumps(data,indent=2))
  check=subprocess.run(['/usr/bin/python3',str(folder/'check_fixture.py')],cwd=folder,capture_output=True,text=True,timeout=90)
  if check.returncode:raise ValueError(check.stderr[-500:])
 except Exception as exc:
  (folder/'test-receipt.json').write_text(json.dumps({'status':'inconclusive','summary':'The automatic finite fixture check could not complete: '+type(exc).__name__,'general_polynomial_sat_proof':False},indent=2))
 t=json.loads((folder/'test-receipt.json').read_text())
 board.upsert_job(hub,{'id':'targeted-fable-worstcase-auto-00015-tests','model':'independent-local-test','status':'completed','ended_at':now(),'path':str(folder),'summary':t['summary'],'metadata_json':{'kind':'focused_independent_test','test_verdict':t['status'],'general_polynomial_sat_proof':False}})
 board.post_message(hub,'independent-test',json.dumps(t),kind='tested_result',job_id='targeted-fable-worstcase-auto-00015-tests',plain_body=t['summary'])
