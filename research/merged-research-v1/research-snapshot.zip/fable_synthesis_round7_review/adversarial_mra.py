import itertools as it,json,time
from pathlib import Path
from test_mra import cyclic,mra,models
started=time.time();rows=[]
for n in range(3,9):
    # All eight clauses on three shared variables are UNSAT. Sharing y1 makes
    # the variable-incidence graph connected, while preserving width-three clauses.
    corevars=[n+1,2*n+1,2*n+2]
    core=[tuple(sign*v for sign,v in zip(signs,corevars)) for signs in it.product((-1,1),repeat=3)]
    f=cyclic(n)+core
    assert not models(core,corevars)
    slow=mra(f,list(range(1,2*n+3)),True)
    fast_order=corevars+[v for v in range(1,2*n+3) if v not in corevars]
    fast=mra(f,fast_order,True)
    width=max(layer['post_prune'] for layer in slow['layers'])
    assert slow['sat'] is False and fast['sat'] is False
    assert width==2**n and slow['terminal_calls']==2**(n+1)
    rows.append({'n':n,'variables':2*n+2,'clauses':len(f),'x_first_max_states':width,
                 'x_first_terminal_calls':slow['terminal_calls'],'core_first_max_states':max([1]+[x['post_prune'] for x in fast['layers']]),
                 'core_first_terminal_calls':fast['terminal_calls'],'both_return_unsat':True})
out={'mechanism':'Connected F_n plus all eight signed 3-clauses on y1,z1,z2; exact MRA canonicalization and 2SAT dispatch enabled.',
     'results':rows,'elapsed_seconds':time.time()-started,
     'scope':'Adversarial fixed-order scaling for the actual proposed MRA solver, not a lower bound for all variable orders or arbitrary SAT algorithms. Core-first ordering solves this family quickly.',
     'general_polynomial_claim_refuted':False}
Path(__file__).with_name('adversarial-receipt.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
