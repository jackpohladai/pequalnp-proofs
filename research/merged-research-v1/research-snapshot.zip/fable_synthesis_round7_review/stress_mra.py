import sys,json,random,itertools as it,time
from pathlib import Path
from test_mra import mra,models
rng=random.Random(20261126);start=time.time();sat=unsat=runs=0;failures=[]
for i in range(500):
 n=4+i%3
 clauses=[tuple(s*v for s,v in zip(signs,vs)) for vs in it.combinations(range(1,n+1),3) for signs in it.product((-1,1),repeat=3)]
 f=rng.sample(clauses,min(len(clauses),rng.randint(3*n,6*n)))
 expected=bool(models(f,list(range(1,n+1))))
 sat+=expected;unsat+=not expected
 shuffled=list(range(1,n+1));rng.shuffle(shuffled)
 for order in (list(range(1,n+1)),list(range(n,0,-1)),shuffled):
  got=mra(f,order,True);runs+=1
  if got['sat']!=expected:failures.append({'formula':f,'order':order,'expected':expected,'observed':got})
out={'seed':20261126,'formulas':500,'variables':'4 through 6','sat_formulas':sat,'unsat_formulas':unsat,'solver_runs':runs,'wrong_answers':len(failures),'counterexamples':failures[:3],'elapsed_seconds':time.time()-start,'scope':'Finite seeded stress test against exhaustive truth-table oracle, not a universal proof.'}
Path(__file__).with_name('stress-receipt.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
