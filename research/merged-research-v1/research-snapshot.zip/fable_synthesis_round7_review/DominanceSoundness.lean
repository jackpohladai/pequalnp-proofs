namespace MRAIndependent
universe u
abbrev Clause (L : Type u) := List L
abbrev CNF (L : Type u) := List (Clause L)
def ClauseSat {L : Type u} (v : L → Prop) (c : Clause L) : Prop := ∃ l, l ∈ c ∧ v l
def Sat {L : Type u} (v : L → Prop) (f : CNF L) : Prop := ∀ c, c ∈ f → ClauseSat v c
def Dominates {L : Type u} (g h : CNF L) : Prop :=
  ∀ d, d ∈ h → ∃ c, c ∈ g ∧ ∀ l, l ∈ c → l ∈ d

theorem clause_subset_sound {L : Type u} {v : L → Prop} {c d : Clause L}
    (hsub : ∀ l, l ∈ c → l ∈ d) (hc : ClauseSat v c) : ClauseSat v d := by
  obtain ⟨l, hl, hv⟩ := hc
  exact ⟨l, hsub l hl, hv⟩

theorem dominance_sound {L : Type u} {v : L → Prop} {g h : CNF L}
    (hdom : Dominates g h) (hg : Sat v g) : Sat v h := by
  intro d hd
  obtain ⟨c, hc, hsub⟩ := hdom d hd
  exact clause_subset_sound hsub (hg c hc)

theorem drop_dominated_preserves_models {L : Type u} {v : L → Prop} {g h : CNF L}
    (hdom : Dominates g h) : (Sat v g ∨ Sat v h) ↔ Sat v h := by
  constructor
  · intro hs
    cases hs with
    | inl hg => exact dominance_sound hdom hg
    | inr hh => exact hh
  · intro hh
    exact Or.inr hh

theorem cover_pruning_preserves_models {L : Type u} {v : L → Prop}
    {original kept : List (CNF L)}
    (hkept : ∀ h, h ∈ kept → h ∈ original)
    (hcover : ∀ g, g ∈ original → ∃ h, h ∈ kept ∧ Dominates g h) :
    (∃ g, g ∈ original ∧ Sat v g) ↔ (∃ h, h ∈ kept ∧ Sat v h) := by
  constructor
  · intro hs
    obtain ⟨g, hg, hsat⟩ := hs
    obtain ⟨h, hh, hdom⟩ := hcover g hg
    exact ⟨h, hh, dominance_sound hdom hsat⟩
  · intro hs
    obtain ⟨h, hh, hsat⟩ := hs
    exact ⟨h, hkept h hh, hsat⟩

def UnsatCore (a b c : Bool) : Bool :=
  (a || b || c) && (a || b || !c) && (a || !b || c) && (a || !b || !c) &&
  (!a || b || c) && (!a || b || !c) && (!a || !b || c) && (!a || !b || !c)
theorem core_unsat : ∀ a b c : Bool, UnsatCore a b c = false := by decide
#print axioms clause_subset_sound
#print axioms dominance_sound
#print axioms drop_dominated_preserves_models
#print axioms cover_pruning_preserves_models
#print axioms core_unsat
end MRAIndependent
