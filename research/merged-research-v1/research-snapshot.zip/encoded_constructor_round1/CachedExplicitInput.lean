import ExplicitConstructorInput
import CachedAutomaticConstructor

namespace PEqualNP.Outside.ExplicitConstructorInput.Cached
open PEqualNP.Search
open PEqualNP.Outside.AutomaticConstructor

def prepareAdjacency (input : Input) : Array (List (Fin input.holeBound)) :=
  (input.rows.map (fun row => toNeighbors input.holeBound row.neighbors)).toArray

def prepareGuards (input : Input) : Array Clause :=
  (input.rows.map Row.guard).toArray

def fromArray (table : Array α) (size : table.size = n) (i : Fin n) : α :=
  table[i.val]'(by simpa [size] using i.isLt)

theorem prepared_adjacency_eq (input : Input) :
    (fromArray (prepareAdjacency input) (by simp [prepareAdjacency])) = adjacency input := by
  funext i
  simp [fromArray, prepareAdjacency, adjacency, List.get_eq_getElem]

theorem prepared_guards_eq (input : Input) :
    (fromArray (prepareGuards input) (by simp [prepareGuards])) = guards input := by
  funext i
  simp [fromArray, prepareGuards, guards, List.get_eq_getElem]

/-- Reject malformed neighbors first. Then prepare both typed adjacency
and guard arrays once, outside the callbacks passed to the solver. -/
def solve (input : Input) : Outcome :=
  if neighborCheck input then
    let adjTable := prepareAdjacency input
    let guardTable := prepareGuards input
    AutomaticConstructor.Cached.solve (r := input.rows.length) (h := input.holeBound)
      input.offset input.retained
      (fromArray adjTable (by simp [adjTable, prepareAdjacency]))
      (fromArray guardTable (by simp [guardTable, prepareGuards]))
  else .unsupported

theorem solve_eq_original (input : Input) : solve input = ExplicitConstructorInput.solve input := by
  by_cases checked : neighborCheck input = true
  · simp only [solve, ExplicitConstructorInput.solve, ite_eq_left checked]
    rw [AutomaticConstructor.Cached.solve_eq_original, prepared_adjacency_eq, prepared_guards_eq]
  · simp [solve, ExplicitConstructorInput.solve, checked]

theorem solve_correct (input : Input) :
    AutomaticConstructor.Correct (formula input) (solve input) := by
  rw [solve_eq_original]
  exact ExplicitConstructorInput.solve_correct input

theorem solve_ne_inconclusive (input : Input) : solve input ≠ .inconclusive := by
  rw [solve_eq_original]
  exact ExplicitConstructorInput.solve_ne_inconclusive input

theorem supported_solve_decisive (input : Input)
    (supported : supportedCheck input = true) : Decisive (solve input) := by
  rw [solve_eq_original]
  exact ExplicitConstructorInput.supported_solve_decisive input supported

theorem rejected_neighbor_is_unsupported (input : Input)
    (invalid : neighborCheck input = false) : solve input = .unsupported := by
  simp [solve, invalid]

#print axioms prepared_adjacency_eq
#print axioms prepared_guards_eq
#print axioms solve_eq_original
#print axioms solve_correct
#print axioms supported_solve_decisive
end PEqualNP.Outside.ExplicitConstructorInput.Cached
