import AutomaticConstructor
open PEqualNP.Outside.AutomaticConstructor
open PEqualNP.Outside.GuardedCNFEncoding
set_option maxRecDepth 16384

private def checkedIndex (bound id : Nat) : IO (Fin bound) :=
  if valid : id < bound then pure ⟨id, valid⟩
  else throw (IO.userError s!"identifier {id} outside {bound}")

private def graph (m : Nat) : List (List Nat) :=
  [List.range (m+1)] ++ ((List.range m).map (fun j => [j+1])) ++
    ((List.range m).map (fun j => [m+j+1, 2*m+j+1])) ++
    ((List.range m).map (fun j => [0,m+j+1]))

private def verify (m : Nat) : IO Unit := do
  let count := 3*m+1
  let rows ← (graph m).mapM (fun row => row.mapM (checkedIndex count))
  let rows := rows.toArray
  if rows.size != count then throw (IO.userError "row count mismatch")
  let request := fun (i : Fin count) => rows[i.val]!
  let start ← IO.monoNanosNow
  match solve 0 [] request (fun _ => []) with
  | .sat assignment =>
    let stop ← IO.monoNanosNow
    let checks ← (List.finRange count).mapM fun i => do
      let expected := if i.val ≤ m then i.val else
        if i.val ≤ 2*m then i.val + m else i.val - m
      let k ← checkedIndex count expected
      pure (assignment (freshEdge 0 (i,k)))
    if !checks.all id then throw (IO.userError "unexpected matching")
    IO.println s!"{m} SAT; {checks.length} expected witness edges true; {stop-start} ns"
  | _ => throw (IO.userError "expected SAT")
#eval ([8,16,24,32] : List Nat).forM verify
