import collections,json
def run(m):
 adj=[list(range(m+1))]+[[i] for i in range(1,m+1)]+[[m+j,2*m+j] for j in range(1,m+1)]+[[0,m+j] for j in range(1,m+1)]
 states=[]; latest={}; counter=collections.Counter(); late_core=0
 def row(i,upto):
  for j,k in reversed(states[:upto]):
   counter['row_equality_tests']+=1
   if j==i:return k
  return None
 def owner(h):
  for t in range(len(states)-1,-1,-1):
   i,k=states[t]
   counter['owner_equality_tests']+=1
   if h==k:return i
   if row(i,t)==h:return None
  return None
 def bfs(root,count_core):
  nonlocal late_core
  parents={};seen={root};todo=collections.deque([root])
  while todo:
   i=todo.popleft()
   for h in adj[i]:
    if h in parents:continue
    parents[h]=i
    before=counter['row_equality_tests']
    j=owner(h)
    if count_core and i==0 and 1<=h<=m:
     late_core+=counter['row_equality_tests']-before
    if j is None:
     reverse=[]
     while True:
      x=parents[h];reverse.append((x,h))
      h=latest.get(x)
      if h is None:
       assert x==root
       return reverse
    if j not in seen:seen.add(j);todo.append(j)
  raise AssertionError('unexpected deficiency')
 for root in range(len(adj)):
  late=root>2*m
  path=bfs(root,late)
  if late:
   j=root-2*m
   assert path==[(m+j,2*m+j),(root,m+j)]
  else:assert path==[(root,adj[root][0])]
  for i,h in path:
   states.append((i,h));latest[i]=h
 assert len(set(latest.values()))==len(adj)
 minimum=m*m*sum(m+j for j in range(1,m+1))
 assert late_core>=minimum
 return {'m':m,'rows':len(adj),'edges':sum(map(len,adj)),'one_bfs_all_row_equality_tests':counter['row_equality_tests'],'late_core_row_equality_tests':late_core,'lower_bound_late_core':minimum}
print(json.dumps([run(m) for m in (4,8,16,24,32,48)]))
