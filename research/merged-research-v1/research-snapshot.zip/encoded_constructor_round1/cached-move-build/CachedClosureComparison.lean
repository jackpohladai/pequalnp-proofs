import CachedAutomaticConstructor
open PEqualNP.Outside.AutomaticConstructor
set_option maxRecDepth 16384
def sz (m : Nat) := 3*m+1
def hole (m k : Nat) : Fin (sz m) :=
  ⟨k % sz m, Nat.mod_lt _ (by unfold sz; omega)⟩
def neighbors (m : Nat) (i : Fin (sz m)) : List (Fin (sz m)) :=
  if i.val = 0 then (List.range (m+1)).map (hole m)
  else if i.val ≤ m then [hole m i.val]
  else if i.val ≤ 2*m then [hole m i.val,hole m (i.val+m)]
  else [hole m 0,hole m (i.val-m)]
def label (out : Outcome) : String :=
  match out with
  | .sat _ => "sat"
  | .unsat => "unsat"
  | .unsupported => "unsupported"
  | .inconclusive => "inconclusive"
def trial (m : Nat) : IO Unit := do
  let rows := ((List.finRange (sz m)).map (neighbors m)).toArray
  let adj := fun (i : Fin (sz m)) => rows[i.val]!
  let start ← IO.monoNanosNow
  let original := label (solve 0 [] adj (fun _ => []))
  let middle ← IO.monoNanosNow
  let cached := label (Cached.solve 0 [] adj (fun _ => []))
  let finish ← IO.monoNanosNow
  if original != "sat" || cached != "sat" then
    throw (IO.userError s!"Unexpected outcome {m} {original} {cached}")
  IO.println s!"{m} {original} {cached} {middle - start} {finish - middle}"
#eval ([16, 32, 64] : List Nat).forM trial
