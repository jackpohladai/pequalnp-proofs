import AutomaticConstructor
open PEqualNP.Outside.AutomaticConstructor
set_option maxRecDepth 16384
def sz (m : Nat) := 3*m+1
def hole (m k : Nat) : Fin (sz m) :=
  ⟨k % sz m, Nat.mod_lt _ (by unfold sz; omega)⟩
def neighbors (m : Nat) (i : Fin (sz m)) : List (Fin (sz m)) :=
  if i.val = 0 then (List.range (m+1)).map (hole m)
  else if i.val ≤ m then [hole m i.val]
  else if i.val ≤ 2*m then [hole m i.val,hole m (i.val+m)]
  else [hole m 0,hole m (i.val-m)]
def trial (m : Nat) : IO Unit := do
  let rows := ((List.finRange (sz m)).map (neighbors m)).toArray
  let beginTime ← IO.monoNanosNow
  let label := match solve 0 [] (fun (i : Fin (sz m)) => rows[i.val]!) (fun _ => []) with
    | .sat _ => "sat"
    | .unsat => "unsat"
    | .unsupported => "unsupported"
    | .inconclusive => "inconclusive"
  let stopTime ← IO.monoNanosNow
  IO.println s!"{m} {label} {stopTime - beginTime}"
#eval ([6, 8, 12, 16, 24, 32, 48, 64] : List Nat).forM trial
