import CachedExplicitInput
import ExplicitInputExamples

namespace PEqualNP.Outside.ExplicitConstructorInput.Cached.Examples
open PEqualNP.Outside.ExplicitConstructorInput.Examples

theorem ordinary_outcomes :
    [matching, deficient, outOfBounds, zeroBound, duplicates, negativeGuard, negativeSyntax].map
      (fun input => tag (Cached.solve input)) = [3, 2, 0, 0, 3, 0, 0] := by decide

theorem duplicate_array_entries :
    ((prepareAdjacency duplicates)[0]'(by decide)).map Fin.val = [0, 0, 0] := by decide

#eval [matching, deficient, outOfBounds, zeroBound, duplicates, negativeGuard,
  negativeSyntax, wideHoles, wideOffset].map (fun input => tag (Cached.solve input))
#eval values (Cached.solve wideOffset) [2^80-1, 2^80]
#eval ((prepareAdjacency wideHoles)[0]'(by decide)).map Fin.val
#print axioms ordinary_outcomes
#print axioms duplicate_array_entries
end PEqualNP.Outside.ExplicitConstructorInput.Cached.Examples
