import CachedMove
import RawMatchingPathComposition

namespace PEqualNP.Outside.MatchingCached
open PEqualNP.Outside.MatchingAugmentation
open PEqualNP.Outside.MatchingCertificates
open PEqualNP.Outside.MatchingPaths
open PEqualNP.Outside.MatchingLoop
variable {r h : Nat}

/-- Same guarded reverse replay, with the previous hole cached before
each new owner closure is constructed. -/
def augmentRowsCached (N : Fin r → Finset (Fin h)) :
    List (Fin r) → State r h → Fin h → Option (State r h)
  | [], _, _ => none
  | i :: rest, s, k =>
      if s.owner k = none ∧ k ∈ N i then
        let next := moveCached s i k
        match s.rowMatch i with
        | none => if rest = [] then some next else none
        | some previous => augmentRowsCached N rest next previous
      else none

theorem augmentRowsCached_eq (N : Fin r → Finset (Fin h)) (rows : List (Fin r))
    (s : State r h) (hole : Fin h) :
    augmentRowsCached N rows s hole = augmentRows N rows s hole := by
  induction rows generalizing s hole with
  | nil => rfl
  | cons i rest ih =>
      simp only [augmentRowsCached, augmentRows, moveCached_eq_move]
      by_cases permitted : s.owner hole = none ∧ hole ∈ N i
      · simp only [ite_eq_left permitted]
        cases previous : s.rowMatch i with
        | none => rfl
        | some k => exact ih (move s i hole) k
      · simp only [ite_eq_right permitted]

def tryPathCached (N : Fin r → Finset (Fin h)) (g : Fin r → Bool)
    (s : State r h) (root : Fin r) (hole : Fin h) (rows : List (Fin r)) :
    Option (State r h) :=
  if rows.all (fun i => !g i) then
    match augmentRowsCached N rows s hole with
    | none => none
    | some next => if (next.rowMatch root).isSome then some next else none
  else none

theorem tryPathCached_eq (N : Fin r → Finset (Fin h)) (g : Fin r → Bool)
    (s : State r h) (root : Fin r) (hole : Fin h) (rows : List (Fin r)) :
    tryPathCached N g s root hole rows = tryPath N g s root hole rows := by
  simp only [tryPathCached, tryPath, augmentRowsCached_eq]
  by_cases active : rows.all (fun i => !g i) = true
  · simp only [ite_eq_left active]
    cases augmentRows N rows s hole <;> rfl
  · simp only [ite_eq_right active]

def visitCached (N : Fin r → Finset (Fin h)) (g : Fin r → Bool)
    (propose : State r h → Fin r → Proposal r h) :
    List (Fin r) → State r h → Result r h
  | [], s => .success s.rowMatch
  | root :: todo, s =>
      if g root = false ∧ s.rowMatch root = none then
        match propose s root with
        | .path hole rows =>
            match tryPathCached N g s root hole rows with
            | none => .inconclusive
            | some next => visitCached N g propose todo next
        | .cut rows => if failureCheck N g rows then .failure rows else .inconclusive
        | .inconclusive => .inconclusive
      else visitCached N g propose todo s

theorem visitCached_eq (N : Fin r → Finset (Fin h)) (g : Fin r → Bool)
    (propose : State r h → Fin r → Proposal r h) (todo : List (Fin r)) (s : State r h) :
    visitCached N g propose todo s = visit N g propose todo s := by
  induction todo generalizing s with
  | nil => rfl
  | cons root todo ih =>
      simp only [visitCached, visit, tryPathCached_eq]
      by_cases need : g root = false ∧ s.rowMatch root = none
      · simp only [ite_eq_left need]
        cases proposed : propose s root with
        | inconclusive => rfl
        | cut rows => rfl
        | path hole rows =>
            cases replayed : tryPath N g s root hole rows with
            | none => simp only [replayed]
            | some next => simpa only [replayed] using ih next
      · simp only [ite_eq_right need]
        exact ih s

def solve (adj : Fin r → List (Fin h)) (g : Fin r → Bool) : Result r h :=
  visitCached (fun i => (adj i).toFinset) g
    (proposeFromBfs adj (fun s root => rawSearchPath adj s root r)) (List.finRange r) empty

/-- Exact equality includes the returned matching/cut and its assignment
functions. This is a semantic refinement, not a runtime-complexity theorem. -/
theorem solve_eq_raw (adj : Fin r → List (Fin h)) (g : Fin r → Bool) :
    solve adj g = RawMatchingPathComposition.solve adj g := by
  unfold solve RawMatchingPathComposition.solve solveFromBfs solveWith
  exact visitCached_eq _ _ _ _ _

#print axioms augmentRowsCached_eq
#print axioms tryPathCached_eq
#print axioms visitCached_eq
#print axioms solve_eq_raw
end PEqualNP.Outside.MatchingCached
