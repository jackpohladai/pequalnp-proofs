import RawSearchRounds

namespace PEqualNP.Outside.MatchingRoundCost
open PEqualNP.Outside.MatchingAugmentation
open PEqualNP.Outside.MatchingCertificates
open PEqualNP.Outside.MatchingLoop
variable {r h : Nat}

structure CountedResult (r h : Nat) where
  result : Result r h
  visits : Nat
  rawRounds : Nat

def addVisit (rounds : Nat) (next : CountedResult r h) : CountedResult r h :=
  ⟨next.result, next.visits + 1, rounds + next.rawRounds⟩

/-- Instrument exactly the existing root loop. `visits` counts each
examined root, even a skipped disabled/already-matched row. `rawRounds`
adds the proposal callback's measured raw-path row expansions. -/
def visitMeter (N : Fin r → Finset (Fin h)) (g : Fin r → Bool)
    (propose : State r h → Fin r → Proposal r h × Nat) :
    List (Fin r) → State r h → CountedResult r h
  | [], s => ⟨.success s.rowMatch, 0, 0⟩
  | root :: todo, s =>
      if g root = false ∧ s.rowMatch root = none then
        let proposed := propose s root
        match proposed.1 with
        | .path hole rows =>
            match tryPath N g s root hole rows with
            | none => ⟨.inconclusive, 1, proposed.2⟩
            | some next => addVisit proposed.2 (visitMeter N g propose todo next)
        | .cut rows =>
            ⟨if failureCheck N g rows then .failure rows else .inconclusive, 1, proposed.2⟩
        | .inconclusive => ⟨.inconclusive, 1, proposed.2⟩
      else addVisit 0 (visitMeter N g propose todo s)

theorem visitMeter_correct (N : Fin r → Finset (Fin h)) (g : Fin r → Bool)
    (propose : State r h → Fin r → Proposal r h × Nat)
    (bound : Nat) (perCall : ∀ s root, (propose s root).2 ≤ bound)
    (todo : List (Fin r)) (s : State r h) :
    (visitMeter N g propose todo s).result = visit N g (fun s root => (propose s root).1) todo s ∧
    (visitMeter N g propose todo s).visits ≤ todo.length ∧
    (visitMeter N g propose todo s).rawRounds ≤ todo.length * bound := by
  induction todo generalizing s with
  | nil => simp [visitMeter, visit]
  | cons root todo ih =>
      by_cases need : g root = false ∧ s.rowMatch root = none
      · cases proposed : propose s root with
        | mk proposal rounds =>
          have callBound : rounds ≤ bound := by simpa only [proposed] using perCall s root
          cases proposal with
          | inconclusive =>
              simp only [visitMeter, visit, ite_eq_left need, proposed, List.length_cons]
              constructor
              · trivial
              constructor
              · omega
              · simp only [Nat.add_mul, Nat.one_mul]
                omega
          | cut rows =>
              simp only [visitMeter, visit, ite_eq_left need, proposed, List.length_cons]
              constructor
              · trivial
              constructor
              · omega
              · simp only [Nat.add_mul, Nat.one_mul]
                omega
          | path hole rows =>
              cases replay : tryPath N g s root hole rows with
              | none =>
                  simp only [visitMeter, visit, ite_eq_left need, proposed, replay, List.length_cons]
                  constructor
                  · trivial
                  constructor
                  · omega
                  · simp only [Nat.add_mul, Nat.one_mul]
                    omega
              | some next =>
                  have rest := ih next
                  simp only [visitMeter, visit, ite_eq_left need, proposed, replay, addVisit,
                    List.length_cons]
                  refine ⟨rest.1, ?_, ?_⟩
                  · omega
                  · simp only [Nat.add_mul, Nat.one_mul]
                    omega
      · have rest := ih s
        simp only [visitMeter, visit, ite_eq_right need, addVisit, List.length_cons]
        refine ⟨rest.1, ?_, ?_⟩
        · omega
        · simp only [Nat.add_mul, Nat.one_mul]
          omega

def solveMeter (adj : Fin r → List (Fin h)) (g : Fin r → Bool) : CountedResult r h :=
  visitMeter (fun i => (adj i).toFinset) g (proposeMeter adj) (List.finRange r) empty

theorem solveMeter_erase (adj : Fin r → List (Fin h)) (g : Fin r → Bool) :
    (solveMeter adj g).result = RawMatchingPathComposition.solve adj g := by
  have same : (fun s root => (proposeMeter adj s root).1) =
      proposeFromBfs adj (fun s root => PEqualNP.Outside.MatchingPaths.rawSearchPath adj s root r) := by
    funext s root
    exact (proposeMeter_correct adj s root).1
  have measured := visitMeter_correct (fun i => (adj i).toFinset) g (proposeMeter adj) r
    (fun s root => (proposeMeter_correct adj s root).2) (List.finRange r) empty
  simpa only [solveMeter, RawMatchingPathComposition.solve, solveFromBfs, solveWith, same] using
    measured.1

/-- Exact outer root visits are at most the number of rows. -/
theorem solveMeter_visits_le (adj : Fin r → List (Fin h)) (g : Fin r → Bool) :
    (solveMeter adj g).visits ≤ r := by
  have measured := visitMeter_correct (fun i => (adj i).toFinset) g (proposeMeter adj) r
    (fun s root => (proposeMeter_correct adj s root).2) (List.finRange r) empty
  simpa [solveMeter] using measured.2.1

/-- Total nonempty row expansions in all additional raw path searches are
at most r². This excludes plain BFS, neighbor scans, replay, validation,
allocation, function application and encoded-bit arithmetic costs. -/
theorem solveMeter_rawRounds_le_square (adj : Fin r → List (Fin h)) (g : Fin r → Bool) :
    (solveMeter adj g).rawRounds ≤ r * r := by
  have measured := visitMeter_correct (fun i => (adj i).toFinset) g (proposeMeter adj) r
    (fun s root => (proposeMeter_correct adj s root).2) (List.finRange r) empty
  simpa [solveMeter] using measured.2.2

#print axioms visitMeter_correct
#print axioms solveMeter_erase
#print axioms solveMeter_visits_le
#print axioms solveMeter_rawRounds_le_square
end PEqualNP.Outside.MatchingRoundCost
