import ExplicitConstructorInput

namespace PEqualNP.Outside.ExplicitConstructorInput.Examples
open PEqualNP.Outside.AutomaticConstructor
def tag : Outcome → Nat
  | .unsupported => 0
  | .inconclusive => 1
  | .unsat => 2
  | .sat _ => 3

def values (result : Outcome) (ids : List Nat) : List Bool :=
  match result with
  | .sat assignment => ids.map assignment
  | _ => []

def matching : Input := ⟨0, 2, [], [⟨[0,1], []⟩, ⟨[0], []⟩]⟩
def deficient : Input := ⟨0, 1, [], [⟨[0], []⟩, ⟨[0], []⟩]⟩
def outOfBounds : Input := ⟨0, 2, [], [⟨[2], []⟩]⟩
def zeroBound : Input := ⟨0, 0, [], [⟨[0], []⟩]⟩
def duplicates : Input := ⟨0, 1, [], [⟨[0,0,0], []⟩]⟩
def negativeGuard : Input := ⟨1, 0, [], [⟨[], [(0,false)]⟩]⟩
def negativeSyntax : Input := ⟨2, 0, [[(0,false),(1,false)]], []⟩
def wideHoles : Input := ⟨0, 2^80+2, [],
  [⟨[2^80,2^80+1], []⟩, ⟨[2^80], []⟩]⟩
def wideOffset : Input := ⟨2^80, 1, [[(2^80-1,false)]],
  [⟨[0], [(2^80-1,true)]⟩]⟩

example : [matching, deficient, outOfBounds, zeroBound, duplicates,
    negativeGuard, negativeSyntax].map (fun input => tag (solve input)) =
    [3,2,0,0,3,0,0] := by decide
example : (adjacency duplicates ⟨0, by decide⟩).map Fin.val = [0,0,0] := by decide

#eval [matching, deficient, outOfBounds, zeroBound, duplicates,
  negativeGuard, negativeSyntax, wideHoles, wideOffset].map (fun input => tag (solve input))
#eval [matching, deficient, outOfBounds, zeroBound, duplicates,
  negativeGuard, negativeSyntax, wideHoles, wideOffset].map supportedCheck
#eval values (solve wideOffset) [2^80-1, 2^80]
#eval (adjacency wideHoles ⟨0, by decide⟩).map Fin.val
end PEqualNP.Outside.ExplicitConstructorInput.Examples
