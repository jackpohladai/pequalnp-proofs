import AugmentingReassignment

namespace PEqualNP.Outside.MatchingAugmentation

/-- Save the old hole once before constructing the updated owner function.
No existing matching implementation imports this variant. -/
def moveCached (s : State r h) (i : Fin r) (k : Fin h) : State r h :=
  let previous := s.rowMatch i
  { rowMatch := fun j => if j = i then some k else s.rowMatch j
    owner := fun l =>
      if l = k then some i
      else if previous = some l then none
      else s.owner l }

theorem moveCached_eq_move (s : State r h) (i : Fin r) (k : Fin h) :
    moveCached s i k = move s i k := by
  rfl

#print axioms moveCached_eq_move

end PEqualNP.Outside.MatchingAugmentation
