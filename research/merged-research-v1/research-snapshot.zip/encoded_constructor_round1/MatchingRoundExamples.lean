import MatchingRoundCost

namespace PEqualNP.Outside.MatchingRoundCost.Examples
open PEqualNP.Outside.MatchingAugmentation

def counts (adj : Fin r → List (Fin h)) (g : Fin r → Bool) : Nat × Nat :=
  let measured := solveMeter adj g
  (measured.visits, measured.rawRounds)

def twoRows (i : Fin 2) : List (Fin 2) := if i = 0 then [0, 1] else [0]
def ladder (i : Fin 5) : List (Fin 5) :=
  if i = 0 then [0, 1] else if i = 1 then [1, 2] else
  if i = 2 then [2, 3] else if i = 3 then [3, 4] else [0]

theorem forced_reassignment_count : counts twoRows (fun _ => false) = (2, 3) := by decide
theorem late_long_path_count : counts ladder (fun _ => false) = (5, 9) := by decide
theorem disabled_rows_count : counts ladder (fun _ => true) = (5, 0) := by decide
theorem immediate_failure_count :
    counts (fun _ : Fin 3 => ([] : List (Fin 0))) (fun _ => false) = (1, 0) := by decide
theorem late_failure_count :
    counts (fun _ : Fin 3 => ([0, 1] : List (Fin 2))) (fun _ => false) = (3, 2) := by decide
theorem zero_rows_count :
    counts (h := 0) (fun i : Fin 0 => nomatch i) (fun _ => false) = (0, 0) := by decide
theorem zero_fuel_count : (rawMeter twoRows empty 0 0).2 = 0 := by decide
theorem no_queued_row_count :
    (exploreMeter twoRows empty 4 ⟨∅, []⟩).2 = 0 := by decide

#eval [counts twoRows (fun _ => false), counts ladder (fun _ => false),
  counts ladder (fun _ => true),
  counts (fun _ : Fin 3 => ([] : List (Fin 0))) (fun _ => false),
  counts (fun _ : Fin 3 => ([0, 1] : List (Fin 2))) (fun _ => false)]
#print axioms forced_reassignment_count
#print axioms late_long_path_count
#print axioms late_failure_count
end PEqualNP.Outside.MatchingRoundCost.Examples
