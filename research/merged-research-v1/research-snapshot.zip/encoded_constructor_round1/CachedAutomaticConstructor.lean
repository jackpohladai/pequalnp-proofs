import CachedMatching
import AutomaticConstructorTotal

namespace PEqualNP.Outside.AutomaticConstructor.Cached

open PEqualNP.Search
open PEqualNP.Outside.SparseDualHornAlgorithm
open PEqualNP.Outside.CertifiedConstructorSolver

variable {r h : Nat}

/-- Build the retained assignment once for the matching guard callback. -/
def useMatching (offset : Nat) (F : CNF) (adj : Fin r → List (Fin h))
    (guards : Fin r → Clause) (T : Finset Nat) : Outcome :=
  let visible := state (support F) T
  match MatchingCached.solve adj (fun i => Clause.eval visible (guards i)) with
  | .inconclusive => .inconclusive
  | .success certificate => convertResult
      (processCertificate offset F (fun i => (adj i).toFinset) guards T (.success certificate))
  | .failure rows => convertResult
      (processCertificate offset F (fun i => (adj i).toFinset) guards T (.failure rows))

theorem useMatching_eq_original (offset : Nat) (F : CNF)
    (adj : Fin r → List (Fin h)) (guards : Fin r → Clause) (T : Finset Nat) :
    useMatching offset F adj guards T = AutomaticConstructor.useMatching offset F adj guards T := by
  unfold useMatching AutomaticConstructor.useMatching
  dsimp only
  rw [MatchingCached.solve_eq_raw]
  cases RawMatchingPathComposition.solve adj (fun i => Clause.eval (state (support F) T) (guards i)) <;>
    rfl

/-- The new executable preserves the checks and result of the original. -/
def solve (offset : Nat) (F : CNF) (adj : Fin r → List (Fin h))
    (guards : Fin r → Clause) : Outcome :=
  if inputCheck offset F guards then
    match checkedSolve F with
    | none => .unsupported
    | some none => .unsat
    | some (some T) => useMatching offset F adj guards T
  else .unsupported

theorem solve_eq_original (offset : Nat) (F : CNF) (adj : Fin r → List (Fin h))
    (guards : Fin r → Clause) :
    solve offset F adj guards = AutomaticConstructor.solve offset F adj guards := by
  by_cases supported : inputCheck offset F guards = true
  · cases checked : checkedSolve F with
    | none => simp [solve, AutomaticConstructor.solve, supported, checked]
    | some result =>
        cases result <;> simp [solve, AutomaticConstructor.solve, supported, checked,
          useMatching_eq_original]
  · simp [solve, AutomaticConstructor.solve, supported]

theorem solve_correct (offset : Nat) (F : CNF) (adj : Fin r → List (Fin h))
    (guards : Fin r → Clause) :
    AutomaticConstructor.Correct (encoded offset F adj guards) (solve offset F adj guards) := by
  rw [solve_eq_original]
  exact AutomaticConstructor.solve_correct offset F adj guards

theorem solve_ne_inconclusive (offset : Nat) (F : CNF) (adj : Fin r → List (Fin h))
    (guards : Fin r → Clause) : solve offset F adj guards ≠ .inconclusive := by
  rw [solve_eq_original]
  exact AutomaticConstructor.solve_ne_inconclusive offset F adj guards

theorem supported_solve_decisive (offset : Nat) (F : CNF)
    (adj : Fin r → List (Fin h)) (guards : Fin r → Clause)
    (inputs : inputCheck offset F guards = true) (dual : dualHornCheck F = true) :
    Decisive (solve offset F adj guards) := by
  rw [solve_eq_original]
  exact AutomaticConstructor.supported_solve_decisive offset F adj guards inputs dual

theorem returned_sat_is_model (offset : Nat) (F : CNF) (adj : Fin r → List (Fin h))
    (guards : Fin r → Clause) (assignment : Assignment)
    (returned : solve offset F adj guards = .sat assignment) :
    CNF.eval assignment (encoded offset F adj guards) = true := by
  simpa [returned, AutomaticConstructor.Correct] using solve_correct offset F adj guards

#print axioms useMatching_eq_original
#print axioms solve_eq_original
#print axioms solve_correct
#print axioms solve_ne_inconclusive
#print axioms supported_solve_decisive
#print axioms returned_sat_is_model

end PEqualNP.Outside.AutomaticConstructor.Cached
