import RawMatchingCompleteness

namespace PEqualNP.Outside.MatchingRoundCost
open PEqualNP.Outside.MatchingAugmentation
open PEqualNP.Outside.MatchingPaths
open PEqualNP.Outside.MatchingSearch
open PEqualNP.Outside.MatchingLoop
variable {r h : Nat}

/-- Count actual nonempty-row expansions in the raw path search.
Each expansion performs one adjacency scan. Empty queues and exhausted
fuel contribute zero. The count does not measure scan lengths or bit cost. -/
def exploreMeter (adj : Fin r → List (Fin h)) (s : State r h) :
    Nat → PathWork r → Option (Fin h × List (Fin r)) × Nat
  | 0, _ => (none, 0)
  | fuel + 1, work =>
      match work.queue with
      | [] => (none, 0)
      | [] :: _ => (none, 0)
      | (row :: rest) :: queue =>
          match scanPaths s (row :: rest) (adj row) ⟨work.seen, queue⟩ with
          | .inl found => (some found, 1)
          | .inr next =>
              let result := exploreMeter adj s fuel next
              (result.1, result.2 + 1)

theorem exploreMeter_correct (adj : Fin r → List (Fin h)) (s : State r h)
    (fuel : Nat) (work : PathWork r) :
    (exploreMeter adj s fuel work).1 = explorePaths adj s fuel work ∧
    (exploreMeter adj s fuel work).2 ≤ fuel := by
  induction fuel generalizing work with
  | zero => exact ⟨rfl, Nat.le_refl 0⟩
  | succ fuel ih =>
      cases q : work.queue with
      | nil => simp [exploreMeter, explorePaths, q]
      | cons path queue =>
          cases path with
          | nil => simp [exploreMeter, explorePaths, q]
          | cons row rest =>
              cases scanned : scanPaths s (row :: rest) (adj row) ⟨work.seen, queue⟩ with
              | inl found => simp [exploreMeter, explorePaths, q, scanned]
              | inr next =>
                  have previous := ih next
                  simp only [exploreMeter, explorePaths, q, scanned]
                  exact ⟨previous.1, Nat.add_le_add_right previous.2 1⟩

def rawMeter (adj : Fin r → List (Fin h)) (s : State r h)
    (root : Fin r) (fuel : Nat) : Option (Fin h × List (Fin r)) × Nat :=
  exploreMeter adj s fuel ⟨{root}, [[root]]⟩

theorem rawMeter_correct (adj : Fin r → List (Fin h)) (s : State r h)
    (root : Fin r) (fuel : Nat) :
    (rawMeter adj s root fuel).1 = rawSearchPath adj s root fuel ∧
    (rawMeter adj s root fuel).2 ≤ fuel :=
  exploreMeter_correct adj s fuel ⟨{root}, [[root]]⟩

/-- The plain BFS still computes a cut/free outcome. Only additional raw
path-search row expansions are counted by this instrument. -/
def proposeMeter (adj : Fin r → List (Fin h)) (s : State r h) (root : Fin r) :
    Proposal r h × Nat :=
  match explore adj s.owner r (Frontier.start root) with
  | .exhausted final => (.cut final.reached, 0)
  | .budget => (.inconclusive, 0)
  | .free _ =>
      let result := rawMeter adj s root r
      match result.1 with
      | none => (.inconclusive, result.2)
      | some (hole, rows) => (.path hole rows, result.2)

theorem proposeMeter_correct (adj : Fin r → List (Fin h)) (s : State r h)
    (root : Fin r) :
    (proposeMeter adj s root).1 =
      proposeFromBfs adj (fun state row => rawSearchPath adj state row r) s root ∧
    (proposeMeter adj s root).2 ≤ r := by
  cases plain : explore adj s.owner r (Frontier.start root) with
  | exhausted final => simp [proposeMeter, proposeFromBfs, plain]
  | budget => simp [proposeMeter, proposeFromBfs, plain]
  | free hole =>
      have measured := rawMeter_correct adj s root r
      cases found : (rawMeter adj s root r).1 with
      | none =>
          have rawNone : rawSearchPath adj s root r = none := measured.1.symm.trans found
          simpa [proposeMeter, proposeFromBfs, plain, found, rawNone] using measured.2
      | some result =>
          rcases result with ⟨k, rows⟩
          have rawFound := measured.1.symm.trans found
          simpa [proposeMeter, proposeFromBfs, plain, found, rawFound] using measured.2

#print axioms exploreMeter_correct
#print axioms rawMeter_correct
#print axioms proposeMeter_correct
end PEqualNP.Outside.MatchingRoundCost
